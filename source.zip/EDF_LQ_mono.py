"""
Earliest Deadline First algorithm for uniprocessor architectures.
"""
from simso.core import Scheduler
from simso.schedulers import scheduler
from simso.core import Timer
from simso.core.Task import SporadicTask
from simso.schedulers.EDF_LQ_Server import add_job, SingleClientServer, SlackServer


@scheduler("simso.schedulers.EDF_LQ_mono")
class EDF_LQ_mono(Scheduler):

    def init(self):
        self.ready_list = []

    def on_activate(self, job):
        # add single client to the ready queue
        if isinstance(job.task, SporadicTask):
            single_client_server = [sc for sc in self.task_list if (isinstance(sc, SingleClientServer) and sc.task == job.task)]
            add_job(self.sim, job, single_client_server[0])
            self.ready_list.append(single_client_server[0])
            single_client_server[0].update_budget()
        else:
            # add other jobsto the ready queue
            self.ready_list.append(job)
        job.cpu.resched()

    def on_terminated(self, job):
        if job not in self.ready_list:
            for item in self.ready_list:
                if isinstance(item, SingleClientServer):
                    if item.job == job:
                        item.update_budget()
                        item.cpu.resched()
#                        if (item.budget == 0) and (item.job.end_date is not None):
                        if item.job.end_date is not None:
                            self.ready_list.remove(item)
#                if isinstance(item, SlackServer):
#                    print("Slack Server")

        else:
            self.ready_list.remove(job)
            job.cpu.resched()

    def schedule(self, cpu):

        current_time = self.sim.now()

        menor = self.sim.duration
        for s in self.ready_list:
            if s.absolute_deadline < menor and s.absolute_deadline_cycles > current_time:
                menor = s.absolute_deadline
                highest_priority_job = s


#        # POG - highest priority job será um slack server
#        # cansada!
 #       if highest_priority_job == None:

#        highest_priority_job = min(self.ready_list, key=lambda x: x.absolute_deadline)

        # add the slack server to the ready queue list at t=0
        if current_time == 0:
            self.add_slack_server()

        slack_server = self.find_slack_server()

        if slack_server is not None and slack_server.children:
            if slack_server.job.end_date is not None:
                slack_server.children = []
                slack_server.job = None
                slack_server.task = None

        ######## Se não tem mais nada para executar, apenas atualiza o slack server (POG - eu acho)
        if len(self.ready_list) == 1 and slack_server in self.ready_list:
            highest_priority_job = self.ready_list[0]
        else:
            highest_priority_job = min(self.ready_list, key=lambda x: x.absolute_deadline)
            #if highest_priority_job is None:
            #    if self.ready_list:
            #        highest_priority_job = min(self.ready_list, key=lambda x: x.absolute_deadline)
            #    else:
            #        highest_priority_job = slack_server.job



        # slack server budget
        if (current_time == 0) or (current_time >= slack_server.absolute_deadline_cycles) and not isinstance(highest_priority_job, SlackServer):
            add_job(self.sim, highest_priority_job, slack_server)

        # list with jobs (and servers) that are ready to run
        ready_list = [j for j in self.ready_list if (j.absolute_deadline > 0)]

        # check if slack server has a client assigned to it
        if slack_server in ready_list and not slack_server.children:
            ready_list.remove(slack_server)

#        # check if single client server has a positive budget
#        for sc in ready_list:
#            if isinstance(sc, SingleClientServer):
#                if sc.budget == 0:
#                    ready_list.remove(sc)

        if ready_list:
            # job with the highest priority is selected to run (EDF)
            # ties are broken to favor the execution of hard tasks first
            min_deadline = min(ready_list, key=lambda x: x.absolute_deadline).absolute_deadline
            same_deadline = [s for s in ready_list if (s.absolute_deadline == min_deadline)]
            if len(same_deadline) > 1:
                for aux in same_deadline:
                    if not isinstance(aux, SlackServer):
                        selected_to_run = aux
                        break
            else:
                selected_to_run = same_deadline[0]
            # highest priority job is a single client server
            if isinstance(selected_to_run, SingleClientServer):
                selected_to_run.to_reschedule = False
                # SINGLE CLIENT SERVER > 0
                if selected_to_run.budget > 0:
                    selected_to_run.last_update = current_time
                    if selected_to_run.job.end_date is not None:
#                        print("SINGLE CLIENT donates budget to the SLACK SERVER! :) ")
                        if slack_server:
                            if slack_server.absolute_deadline > selected_to_run.absolute_deadline:
                                slack_server.add_deadline(current_time, selected_to_run.absolute_deadline_cycles)
                                slack_server.budget = slack_server.budget + selected_to_run.budget + int((slack_server.absolute_deadline_cycles - selected_to_run.absolute_deadline_cycles) * slack_server.utilization)
                            else:
                                if slack_server.absolute_deadline_cycles < current_time:
                                    # slack server was not active
                                    slack_server.add_deadline(current_time, selected_to_run.absolute_deadline_cycles)
                                    slack_server.budget = selected_to_run.budget + int((slack_server.absolute_deadline_cycles - current_time) * slack_server.utilization)
                                else:
                                    slack_server.budget = slack_server.budget + selected_to_run.budget
                            selected_to_run.budget = 0

                    else:
#                        print("SINGLE CLIENT executes the job of a SOFT TASK! \O/ ")
                        # causes a preemption when the job execution time is greater than the expected average
                        if (selected_to_run.budget < int(selected_to_run.job._etm.et[selected_to_run.job])) \
                                or (selected_to_run.budget > int(selected_to_run.job._etm.et[selected_to_run.job])):
                            # delay
                            wakeup_delay = min(selected_to_run.budget,
                                               int(selected_to_run.job._etm.et[selected_to_run.job]),
                                               int(slack_server.absolute_deadline_cycles) - current_time)
                            if wakeup_delay > 0:
                                if wakeup_delay == int(slack_server.absolute_deadline_cycles) - current_time:
                                    self.timer = Timer(self.sim, SlackServer.on_slack_server_deadline,
                                                       (self, self.processors[0]), wakeup_delay, cpu=self.processors[0],
                                                       in_ms=False)
                                else:
                                    self.timer = Timer(self.sim, SingleClientServer.end_of_job_event,
                                                  (self, self.processors[0]), wakeup_delay, cpu=self.processors[0],
                                                  in_ms=False)
                                self.timer.start()

                else:
                    # SINGLE CLIENT SERVER = 0
                    if selected_to_run.job.end_date is None:
#                        print("SLACK SERVER executes the job of a SOFT TASK")
                        slack_server.children.append(selected_to_run.task)
                        slack_server.task = selected_to_run.task
                        slack_server.job = selected_to_run.job
                        ready_list.remove(selected_to_run)
                        self.ready_list.remove(selected_to_run)
                        selected_to_run = slack_server
                        selected_to_run.last_update = current_time
                        selected_to_run.to_reschedule = False
                        wakeup_delay = min(selected_to_run.budget, selected_to_run.job._etm.et[selected_to_run.job]-selected_to_run.job.computation_time_cycles)
                        if wakeup_delay > 0:

                            self.timer = Timer(self.sim, SlackServer.end_of_job_event_ss,
                                           (self, self.processors[0]), wakeup_delay, cpu=self.processors[0],
                                           in_ms=False)
                            self.timer.start()
#                    else:
#                        print("XABU!")

                job = selected_to_run.job
            # highest priority job is a hard sporadic task
            else:
                if isinstance(selected_to_run, SlackServer):
                    selected_to_run.last_update = current_time
                    selected_to_run.to_reschedule = False
                    if selected_to_run.budget > 0:
                        wakeup_delay = min(selected_to_run.budget, int(selected_to_run.job._etm.et[selected_to_run.job]))
                        if wakeup_delay > 0:
                            self.timer = Timer(self.sim, SlackServer.end_of_job_event_ss,
                                               (self, self.processors[0]), wakeup_delay, cpu=self.processors[0],
                                               in_ms=False)
                            self.timer.start()
                        job = selected_to_run.job
                    else:
                        wakeup_delay = int(slack_server.absolute_deadline_cycles) - current_time
                        if wakeup_delay > 0:
                            self.timer = Timer(self.sim, SlackServer.end_of_job_event_ss,
                                               (self, self.processors[0]), wakeup_delay, cpu=self.processors[0],
                                               in_ms=False)
                            self.timer.start()
                        job = None
                else:
                    # runs the job
                    wakeup_delay = min(int(selected_to_run._etm.et[selected_to_run]), int(slack_server.absolute_deadline_cycles) - current_time)
                    if (wakeup_delay > 0) and (wakeup_delay == int(slack_server.absolute_deadline_cycles) - current_time):
                        self.timer = Timer(self.sim, SlackServer.on_slack_server_deadline,
                                           (self, self.processors[0]), wakeup_delay, cpu=self.processors[0],
                                           in_ms=False)
                        self.timer.start()

                    job = selected_to_run
        else:
            job = None
            wakeup_delay = int(slack_server.absolute_deadline_cycles) - current_time
            if (wakeup_delay > 0):
                self.timer = Timer(self.sim, SlackServer.on_slack_server_deadline, (self, self.processors[0]),
                                   wakeup_delay, cpu=self.processors[0], in_ms=False)
                self.timer.start()

        return (job, cpu)

    def add_slack_server(self):

        for server in self.task_list:
            if isinstance(server, SlackServer):
                if server not in self.ready_list:
                    self.ready_list.append(server)


    def find_slack_server(self):
        for item in self.ready_list:
            if isinstance(item, SlackServer):
                return item
        else:
            return None
