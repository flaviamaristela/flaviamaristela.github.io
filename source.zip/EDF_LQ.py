"""
Partitionned EDF implementing Local Queue aprooach with arbitrary deadlines.
Use EDF_mono.
"""
from simso.core import Scheduler
from simso.schedulers import scheduler
from simso.core.Scheduler import SchedulerInfo
from simso.core.Task import GenericTask
from simso.schedulers.EDF_LQ_mono import EDF_LQ_mono
from simso.schedulers.EDF_LQ_Server import SingleClientServer, SlackServer
from simso.core.Task import SporadicTask
import sys


@scheduler("simso.schedulers.EDF_LQ")
class EDF_LQ(Scheduler):

    def init(self):
        # Mapping processor to scheduler.
        self.map_cpu_sched = {}
        # Mapping task to scheduler.
        self.map_task_sched = {}

        cpus = []
        for cpu in self.processors:
            # Append the processor to a list with an initial utilization of 0.
            cpus.append([cpu, 0])

            # Instantiate a scheduler.
            sched = EDF_LQ_mono(self.sim, SchedulerInfo("simso.schedulers.EDF_LQ_mono"))
            sched.add_processor(cpu)
            sched.init()

            # Affect the scheduler to the processor.
            self.map_cpu_sched[cpu.identifier] = sched

        # DBF Approximation for task set partitioning
        # sorted_list = sorted(unsorted_list, key=lambda k: k['name'])
        self.task_list = sorted(self.task_list, key=lambda x: x.deadline)
        for task in self.task_list:
            for j in range(0, len(self.processors)):
                if (task.deadline - dbf_approximation(self, task, cpus[j][0]) >= float(task.acet)) \
                        and (1 - cpus[j][1] >= float(task.acet) / task.period):
                    # Get the scheduler for this processor.
                    sched = self.map_cpu_sched[cpus[j][0].identifier]

                    # Affect it to the task.
                    self.map_task_sched[task.identifier] = sched
                    sched.add_task(task)

                    # Put the task on that processor.
                    task.cpu = cpus[j][0]
                    self.sim.logger.log("task " + task.name + " on " + task.cpu.name)

                    # Update utilization.
                    cpus[j][1] += float(task.acet) / task.period

                    break
            else:
                sys.exit("Partitioning Failed")
                #break

        # create aperiodic server based on processor static slack
        for j in range(0, len(self.processors)):
            aperiodic_server = SlackServer()
            aperiodic_server.utilization = 1-cpus[j][1]
            sched = self.map_cpu_sched[cpus[j][0].identifier]
            self.map_task_sched[aperiodic_server.identifier] = sched
            sched.add_task(aperiodic_server)
            aperiodic_server.cpu = cpus[j][0]

        # Create the single client server to encapsulate soft tasks
        for index in self.processors:
            for index2 in range(0, len(self.map_cpu_sched[index.identifier].task_list)):
                if isinstance(self.map_cpu_sched[index.identifier].task_list[index2], SporadicTask):
                    self.map_cpu_sched[index.identifier].task_list[index2] = SingleClientServer(self.map_cpu_sched[index.identifier].task_list[index2])

    def get_lock(self):
        # No lock mechanism is needed.
        return True

    def schedule(self, cpu):
        jobs = self.map_cpu_sched[cpu.identifier].schedule(cpu)
        return jobs

    def on_activate(self, job):
        self.map_task_sched[job.task.identifier].on_activate(job)

    def on_terminated(self, job):
        self.map_task_sched[job.task.identifier].on_terminated(job)


def dbf_approximation(self, new_task, processor):

    dbf_t = 0
    t = new_task.deadline

    for task in self.task_list:
        if task.cpu == processor:
            if t < task.deadline:
                dbf_t = dbf_t + 0
            else:
                dbf_t = dbf_t + float(task.acet) + (t - task.deadline) * (float(task.acet/task.period))
    return dbf_t
