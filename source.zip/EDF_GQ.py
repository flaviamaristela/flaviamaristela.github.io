"""
Partitionned EDF implementing Local Queue aprooach with arbitrary deadlines.
Use EDF_mono.
"""
from simso.core import Scheduler
from simso.schedulers import scheduler
from simso.core.Scheduler import SchedulerInfo
from simso.core.Task import GenericTask
#from simso.schedulers.EDF_GQ_mono import EDF_GQ_mono
from simso.schedulers.EDF_GQ_mono import EDF_GQ_mono
from simso.schedulers.EDF_GQ_Server import SingleClientServer, SlackServer
from simso.core.Task import SporadicTask
import sys
import math


@scheduler("simso.schedulers.EDF_GQ")
class EDF_GQ(Scheduler):

    def init(self):
        # Mapping processor to scheduler.
        self.map_cpu_sched = {}
        # Mapping task to scheduler.
        self.map_task_sched = {}

        # Variables that control which tasks are running currently
        self.running_jobs = [] ##
        self.sched_to_do = False
        self.soft_task_list = [] ##

        cpus = []
        for cpu in self.processors:
            # Append the processor to a list with an initial utilization of 0.
            cpus.append([cpu, 0])

            # Instantiate a scheduler.
            sched = EDF_GQ_mono(self.sim, SchedulerInfo("simso.schedulers.EDF_GQ_mono"))
            sched.add_processor(cpu)
            sched.init()

            # Affect the scheduler to the processor.
            self.map_cpu_sched[cpu.identifier] = sched

        # DBF Approximation for task set partitioning (only hard tasks)
        hard_task_list = [t for t in self.task_list if (not isinstance(t, SporadicTask))]
        hard_task_list = sorted(hard_task_list, key=lambda x: x.deadline)
        for task in hard_task_list:
            for j in range(0, len(self.processors)):
                if (task.deadline - dbf_approximation(self, task, cpus[j][0]) >= float(task.acet)) \
                        and (1 - cpus[j][1] >= float(task.acet) / task.period):
                    # Get the scheduler for this processor.
                    sched = self.map_cpu_sched[cpus[j][0].identifier]

                    # Affect it to the task.
                    self.map_task_sched[task.identifier] = sched
                    sched.add_task(task)

                    # Put the task on that processor.
                    task.cpu = cpus[j][0]
                    self.sim.logger.log("task " + task.name + " on " + task.cpu.name)

                    # Update utilization.
                    cpus[j][1] += float(task.acet) / task.period

                    break
            else:
                sys.exit("Partitioning Failed")
                #break

        # create aperiodic server based on processor static slack
        for j in range(0, len(self.processors)):
            aperiodic_server = SlackServer()
            aperiodic_server.utilization = 1-cpus[j][1]
            sched = self.map_cpu_sched[cpus[j][0].identifier]
            self.map_task_sched[aperiodic_server.identifier] = sched
            sched.add_task(aperiodic_server)
            aperiodic_server.cpu = cpus[j][0]


    def resched(self, cpu):
        if not self.sched_to_do:
            cpu.resched()
        self.sched_to_do = True

    def schedule(self, cpu):

        self.sched_to_do = False
#        decisions = []

        slack_server = find_slack_server(self, cpu)

        if slack_server.children:
            if slack_server.job.end_date is not None:
                slack_server.children = []
                slack_server.job = None
                slack_server.task = None

        # scheduling for hard tasks - partitioned EDF
        hard_jobs = [s.job for s in self.task_list if (s.job and s.job.is_active() and s.job in self.map_cpu_sched[cpu.identifier].ready_list)]
        if hard_jobs:
            jobs = self.map_cpu_sched[cpu.identifier].schedule(cpu)
            if isinstance (jobs[0], SlackServer):
                jobs = (jobs[0].job, cpu)
        #scheduling for soft tasks (GLOBAL  QUEUE)
        else:
            jobs = None
            ready_jobs = sorted([t.job for t in self.task_list if (t.job and t.job.is_active() and isinstance(t.job.task, SporadicTask))], key=lambda x: x.absolute_deadline)
            if ready_jobs:
                # deadline job mais alta prioridade
#                processor = dbf(self, ready_jobs[0].task)
                if dbf_accept(self, ready_jobs[0].task, cpu):
#                    slack_server = find_slack_server(self, cpu)
                    slack_server.children.append(ready_jobs[0].task)
                    if slack_server.job is None:
                        slack_server.task = ready_jobs[0].task
                        slack_server.job = ready_jobs[0]
                        jobs = self.map_cpu_sched[cpu.identifier].schedule(cpu)
                    ready_jobs.remove(ready_jobs[0])
                    # append
                    jobs = (slack_server.job, cpu)
                else:
                    # soft job does not fir current processor
                    jobs = None

#            jobs_aux = ready_jobs[:len(self.processors)]
#        #available_procs = list(self.processors)
#        for job in jobs:
#            if not isinstance(job.task, SporadicTask):
#                decisions.append(self.map_cpu_sched[cpu.identifier].schedule(cpu))
#                available_procs.remove(job.cpu)
#            else:
#                # teste do dbf
#                for i in range (0, len(available_procs)):
#                    if dbf(job.task, available_procs[i]):
#                        break
#                else:
#                    print("No available processor for this job right now")
                    # procurar o slack server do processador


                # associar o job ao slack server

                #executar o slack server com suas regras

        #jobs = self.map_cpu_sched[cpu.identifier].schedule(cpu)
        return jobs

    def on_activate(self, job):
        if not isinstance(job.task, SporadicTask):
            self.map_task_sched[job.task.identifier].on_activate(job)
        else:
#            processor = dbf(self, job.task)
#            if processor is not None:
                self.resched(job.cpu)
#            self.map_cpu_sched[job.cpu.identifier].on_activate(job)



    def on_terminated(self, job):
        if not isinstance(job.task, SporadicTask):
            self.map_task_sched[job.task.identifier].on_terminated(job)
#        else:
#            self.map_cpu_sched[job.cpu.identifier].on_terminated(job)
#            self.resched(job.cpu)


def dbf_approximation(self, new_task, processor):

    dbf_t = 0
    t = new_task.deadline

    for task in self.task_list:
        if task.cpu == processor:
            if t < task.deadline:
                dbf_t = dbf_t + 0
            else:
                dbf_t = dbf_t + float(task.acet) + (t - task.deadline) * (float(task.acet/task.period))
    return dbf_t


def dbf(self, new_task):

    dbf_t = 0
#    t = new_task.job.absolute_deadline_cycles

    for index in range (0, len(self.processors)):
        hard_jobs = [s for s in self.map_cpu_sched[self.processors[index].identifier].task_list if
                     (not isinstance(s, SlackServer) and s.job.is_active())]
        if hard_jobs:
            t = min(min(hard_jobs, key=lambda x: x.deadline).deadline * self.sim.cycles_per_ms,
                    new_task.job.absolute_deadline_cycles)
        else:
            t = new_task.job.absolute_deadline_cycles
        for task in self.map_cpu_sched[self.processors[index].identifier].task_list:
            if not isinstance(task, SlackServer):
                dbf_t = dbf_t + max(0, 1 + math.floor((t - (task.deadline * self.sim.cycles_per_ms))/(task.period * self.sim.cycles_per_ms)))*float(task.acet)
        if dbf_t <= t:
            processor = self.processors[index]
            break

    if dbf_t <= t:
        return processor
    else:
        return None


def dbf_accept(self, new_task, cpu):

    dbf_t = 0
#    t = new_task.job.absolute_deadline_cycles

    hard_jobs = [s for s in self.map_cpu_sched[cpu.identifier].task_list if (not isinstance(s, SlackServer) and s.job.is_active())]

    if hard_jobs:
        t = min(min(hard_jobs, key=lambda x: x.deadline).deadline * self.sim.cycles_per_ms, new_task.job.absolute_deadline_cycles)
    else:
        t = new_task.job.absolute_deadline_cycles

    for task in self.map_cpu_sched[cpu.identifier].task_list:
        if not isinstance(task, SlackServer):
            dbf_t = dbf_t + max(0, 1 + math.floor((t - (task.deadline * self.sim.cycles_per_ms))/(task.period * self.sim.cycles_per_ms)))*float(task.acet)
        else:
            if task.children and task.job.end_date is None:
                dbf_t = dbf_t + task.job._etm.et[task.job] - task.job.computation_time
#                for child in task.children:
#                    if child.job._etm.et[child.job]:
#                        dbf_t = dbf_t + child.job._etm.et[child.job] - child.job.computation_time

    if new_task.job.absolute_deadline_cycles - dbf_t >= new_task.job._etm.et[new_task.job]:
        return True
    else:
        return False


def find_slack_server(self, cpu):
    list = self.map_cpu_sched[cpu.identifier].task_list
    slack_server = [s for s in list if (isinstance(s, SlackServer))]

    return slack_server[0]
