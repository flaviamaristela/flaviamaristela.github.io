"""
This class is part of the EDF_LocalQueue implementation (see EDF_LQ.py).
"""

from fractions import Fraction
from simso.core.etm import ACET
from simso.core.Task import SporadicTask


class _Server(object):
    """
    Abstract class that defines a server.
    """
    next_id = 100

    def __init__(self, task=None):
        self.utilization = Fraction(0, 1)
        self.task = task
        self.job = None
        self.deadlines = [0]
        self.budget = 0
        self.last_update = 0
        self.absolute_deadline = 0
        self.absolute_deadline_cycles = 0
        self.to_reschedule = False
        self.running = False #
        self.identifier = _Server.next_id
        _Server.next_id += 1

        if task:
            if hasattr(task, 'utilization'):
                self.utilization += task.utilization
            else:
                self.utilization += float(task._task_info.acet) / task._task_info.period



    def add_deadline(self, current_instant, deadline):
        """
        Add a deadline to the server.
        """
        self.deadlines.append(deadline)

        self.deadlines = [d for d in self.deadlines if d > current_instant]
        self.deadlines.sort()
        if self.deadlines:
            self.absolute_deadline_cycles = min(self.deadlines)
            self.absolute_deadline = self.absolute_deadline_cycles / self.cpu.sim.cycles_per_ms


    def create_job(self, current_time, sim):
        """
        Replenish the budget.
        """
        if (isinstance(self, SingleClientServer)):
            if isinstance(self.task, SporadicTask):
                self.budget = int(self.task.acet * sim.cycles_per_ms)
        else:
            if (isinstance(self, SlackServer)):
                self.budget = int(self.utilization * (self.absolute_deadline_cycles - current_time))

    def update_budget(self):
        """
        Update the budget of servers.
        """

        if self.last_update == 0:
            time_since_last_update = self.last_update
        else:
            time_since_last_update = self.cpu.sim.now() - self.last_update

        if isinstance(self, SingleClientServer) and self.is_isolation and self.budget > 0:
           self.budget -= time_since_last_update
        if isinstance(self, SlackServer) and self.budget > 0:
            self.budget -= time_since_last_update
        self.last_update = self.cpu.sim.now()

    def resched(self, cpu):
        """
        Plannify a scheduling decision on processor cpu. Ignore it if already
        planned.
        """
        if not self.to_reschedule:
            self.to_reschedule = True
            cpu.resched()

    def end_of_job_event(self, cpu):
        """
        Virtual scheduling event. Happens when a virtual job terminates.
        """
        single_client = [s for s in self.ready_list if (isinstance(s, SingleClientServer))]
        if single_client:
            single_client[0].update_budget()
            single_client[0].resched(cpu)

    def end_of_job_event_ss(self, cpu):
        """
        Virtual scheduling event. Happens when a virtual job terminates.
        """
        slack_server = [s for s in self.ready_list if (isinstance(s, SlackServer))]
        slack_server[0].update_budget()
        slack_server[0].resched(cpu)

    def on_slack_server_deadline(self, cpu):
        slack_server = [ss for ss in self.ready_list if (isinstance(ss, SlackServer))]
#        add_job(self.sim, slack_server[0])
        slack_server[0].resched(cpu)


class SingleClientServer( _Server):
    """
    A Single Client server is a server that contains a real Task.
    It is responsible for the temporal isolation for aperiodic tasks execution
    """

    def __init__(self, task):
        super(SingleClientServer, self).__init__(task)
        self.cpu = task.cpu
        self.is_active = True#
        self.is_isolation = True #
        self.is_idle = False#


class SlackServer(_Server):
    """
    A Slack Server is a Server with multiple children scheduled with EDF that is responsible for managing processor available slack.
    """

    def __init__(self):
        super(SlackServer, self).__init__()
        self.children = []
        self.cpu = None
        self.is_active = True
        self.is_isolation = False#
        self.is_idle = True#



    def add_child(self, server):
        """
        Add a child to this EDFServer (used by the packing function).
        """
        self.children.append(server)
        self.utilization += server.utilization
        server.parent = self





def add_job(sim, job, server):
    """
    Recursively update the deadlines of the parents of server.
    """

    if isinstance(server, SingleClientServer):
        server.job = job
        server.add_deadline(sim.now(), job.absolute_deadline_cycles)
        server.create_job(sim.now(), sim)
    else:
        server.add_deadline(sim.now(), job.absolute_deadline_cycles)
        server.create_job(sim.now(), sim)

#        if isinstance(job, SingleClientServer):
#            server.add_deadline(sim.now(), job.absolute_deadline)
#            server.create_job(sim.now(), sim)
#        else:
#            server.add_deadline(sim.now(), job.absolute_deadline)
#            server.create_job(sim.now(), sim)

# se for aperiodic server
#         server.add_deadline(sim.now(), job.absolute_deadline * sim.cycles_per_ms)
#                        server.next_deadline = server.children[0].next_deadline
#                        server.create_job(sim.now(), sim)

