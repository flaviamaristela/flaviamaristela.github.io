

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task6", identifier=6, period=33.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.717421, et_stddev=0.23914033333333332 , list_activation_dates=[10, 75, 167, 312, 379, 450, 488, 648, 768, 838, 872, 951, 1052, 1094, 1130, 1287, 1393, 1439, 1487, 1548, 1650, 1696, 1730, 1798, 1853, 1888, 1933, 1969], deadline = 53)
        configuration.add_task(name="Task5", identifier=5, period=17.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=5, acet=4.523805, et_stddev=1.507935 , list_activation_dates=[15, 47, 73, 103, 121, 148, 192, 239, 267, 287, 307, 334, 351, 393, 513, 545, 583, 620, 653, 671, 689, 729, 759, 779, 797, 866, 898, 923, 943, 996, 1034, 1059, 1092, 1110, 1157, 1176, 1196, 1215, 1261, 1304, 1327, 1397, 1461, 1512, 1550, 1574, 1606, 1663, 1684, 1707, 1744, 1779, 1849, 1903, 1986], deadline = 5)
        configuration.add_task(name="Task4", identifier=4, period=32.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.388919, et_stddev=0.12963966666666668 , list_activation_dates=[19, 80, 117, 171, 219, 267, 308, 349, 392, 562, 638, 706, 784, 817, 861, 905, 951, 1035, 1072, 1146, 1195, 1264, 1321, 1440, 1477, 1550, 1591, 1628, 1700, 1757, 1808, 1894, 1962], deadline = 19)
        configuration.add_task(name="Task2", identifier=2, period=10.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=8.525702, acet=8.525702, et_stddev=2.841900666666667, deadline= 14)
        configuration.add_task(name="Task1", identifier=1, period=32.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=4.672541, acet=4.672541, et_stddev=1.5575136666666667, deadline= 39)
        configuration.add_task(name="Task3", identifier=3, period=4.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=2.405651, acet=2.405651, et_stddev=0.8018836666666668, deadline= 7)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "1")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "1")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "1")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "1")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task4", identifier=4, period=1.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.068108, et_stddev=0.022702666666666666 , list_activation_dates=[2, 3, 6, 8, 9, 12, 13, 15, 16, 17, 18, 21, 22, 23, 25, 27, 28, 31, 33, 34, 36, 38, 40, 42, 44, 45, 47, 51, 52, 55, 57, 60, 65, 66, 68, 71, 72, 74, 78, 81, 83, 84, 86, 88, 89, 90, 91, 95, 101, 103, 106, 108, 109, 112, 113, 114, 116, 118, 119, 120, 121, 125, 127, 129, 130, 132, 133, 138, 141, 145, 152, 153, 156, 157, 158, 160, 161, 163, 164, 168, 170, 171, 174, 176, 177, 178, 179, 180, 182, 185, 186, 187, 189, 190, 192, 193, 194, 195, 199, 202, 203, 206, 210, 212, 214, 215, 216, 217, 218, 220, 222, 223, 225, 227, 229, 231, 235, 237, 238, 242, 244, 246, 247, 251, 254, 256, 257, 258, 259, 261, 263, 264, 265, 270, 271, 273, 276, 277, 284, 286, 288, 291, 293, 295, 296, 298, 300, 301, 302, 303, 304, 306, 308, 309, 310, 312, 314, 316, 318, 320, 322, 324, 325, 326, 328, 330, 332, 334, 337, 338, 340, 342, 345, 348, 353, 354, 357, 359, 363, 365, 370, 371, 373, 374, 376, 377, 380, 382, 384, 385, 390, 392, 395, 397, 398, 400, 402, 403, 404, 406, 407, 411, 413, 414, 415, 417, 419, 422, 424, 425, 426, 429, 432, 435, 437, 438, 442, 443, 445, 446, 448, 449, 450, 452, 454, 456, 457, 460, 462, 465, 469, 470, 471, 475, 477, 480, 481, 484, 486, 487, 490, 493, 497, 498, 500, 502, 504, 507, 509, 512, 514, 515, 516, 520, 522, 524, 526, 527, 528, 530, 533, 535, 536, 538, 539, 541, 543, 544, 546, 547, 550, 551, 553, 555, 557, 559, 560, 563, 565, 566, 568, 571, 572, 576, 578, 579, 584, 586, 587, 589, 590, 594, 597, 598, 601, 604, 605, 606, 608, 610, 613, 615, 618, 619, 621, 622, 623, 624, 625, 627, 628, 629, 633, 637, 641, 643, 646, 648, 650, 651, 653, 655, 659, 660, 663, 666, 667, 669, 670, 672, 674, 675, 678, 682, 684, 686, 688, 690, 693, 695, 697, 699, 701, 702, 704, 706, 707, 708, 709, 710, 712, 714, 715, 716, 718, 721, 723, 725, 726, 728, 733, 735, 737, 739, 741, 743, 744, 747, 751, 753, 755, 757, 760, 761, 762, 763, 764, 766, 768, 769, 771, 774, 776, 777, 779, 781, 786, 787, 789, 790, 794, 797, 798, 799, 800, 802, 804, 805, 807, 809, 810, 811, 812, 814, 817, 818, 820, 823, 824, 826, 827, 829, 831, 835, 836, 837, 838, 839, 840, 841, 842, 843, 845, 846, 848, 850, 852, 853, 859, 860, 861, 864, 867, 868, 869, 870, 871, 873, 875, 876, 877, 879, 880, 881, 882, 885, 886, 888, 889, 890, 891, 892, 894, 895, 897, 898, 901, 902, 905, 906, 910, 913, 916, 918, 919, 920, 922, 923, 926, 928, 929, 933, 937, 938, 940, 941, 944, 946, 949, 950, 953, 957, 959, 961, 963, 966, 968, 969, 970, 972, 973, 975, 976, 978, 980, 982, 986, 987, 989, 996, 998, 999, 1001, 1003, 1005, 1007, 1008, 1010, 1012, 1013, 1014, 1016, 1018, 1021, 1022, 1025, 1027, 1028, 1031, 1033, 1035, 1037, 1038, 1045, 1048, 1050, 1052, 1053, 1054, 1055, 1056, 1058, 1059, 1061, 1066, 1067, 1069, 1071, 1073, 1076, 1078, 1079, 1081, 1083, 1085, 1087, 1089, 1091, 1092, 1094, 1097, 1098, 1100, 1102, 1103, 1104, 1105, 1106, 1108, 1109, 1110, 1113, 1118, 1121, 1122, 1124, 1126, 1128, 1129, 1133, 1135, 1139, 1143, 1145, 1146, 1150, 1153, 1155, 1156, 1158, 1160, 1162, 1163, 1164, 1165, 1166, 1167, 1169, 1174, 1175, 1176, 1177, 1178, 1181, 1182, 1184, 1185, 1187, 1189, 1190, 1191, 1193, 1195, 1199, 1200, 1202, 1205, 1207, 1208, 1211, 1213, 1214, 1216, 1218, 1219, 1221, 1223, 1224, 1226, 1227, 1229, 1231, 1236, 1239, 1241, 1249, 1250, 1251, 1253, 1254, 1255, 1258, 1259, 1261, 1263, 1264, 1265, 1266, 1267, 1268, 1270, 1272, 1273, 1274, 1276, 1277, 1279, 1280, 1281, 1282, 1283, 1284, 1285, 1287, 1289, 1291, 1295, 1297, 1300, 1304, 1306, 1308, 1311, 1314, 1316, 1318, 1320, 1321, 1323, 1326, 1327, 1328, 1331, 1333, 1335, 1336, 1339, 1340, 1341, 1345, 1346, 1347, 1348, 1352, 1358, 1360, 1362, 1364, 1366, 1368, 1370, 1372, 1376, 1378, 1380, 1383, 1384, 1385, 1387, 1391, 1392, 1393, 1396, 1397, 1399, 1401, 1403, 1405, 1408, 1410, 1412, 1414, 1416, 1417, 1422, 1424, 1428, 1432, 1435, 1439, 1441, 1443, 1445, 1446, 1449, 1451, 1453, 1454, 1457, 1460, 1461, 1462, 1466, 1468, 1471, 1474, 1476, 1477, 1479, 1481, 1486, 1488, 1489, 1490, 1492, 1495, 1497, 1498, 1503, 1506, 1507, 1509, 1512, 1514, 1516, 1518, 1522, 1525, 1527, 1529, 1531, 1534, 1535, 1537, 1540, 1542, 1544, 1547, 1548, 1550, 1553, 1557, 1560, 1562, 1563, 1565, 1572, 1576, 1579, 1580, 1581, 1585, 1586, 1588, 1589, 1591, 1595, 1598, 1599, 1601, 1602, 1606, 1608, 1609, 1613, 1615, 1616, 1617, 1618, 1620, 1623, 1625, 1628, 1629, 1632, 1634, 1635, 1638, 1641, 1642, 1644, 1647, 1648, 1649, 1651, 1655, 1656, 1657, 1660, 1662, 1664, 1665, 1666, 1668, 1670, 1672, 1676, 1678, 1680, 1681, 1684, 1687, 1689, 1691, 1695, 1698, 1699, 1700, 1701, 1704, 1707, 1708, 1709, 1710, 1711, 1714, 1720, 1722, 1724, 1725, 1726, 1729, 1730, 1731, 1732, 1734, 1736, 1738, 1739, 1742, 1745, 1746, 1747, 1749, 1751, 1752, 1755, 1756, 1758, 1759, 1761, 1763, 1766, 1767, 1769, 1770, 1772, 1773, 1776, 1779, 1781, 1782, 1783, 1786, 1787, 1789, 1792, 1793, 1795, 1796, 1797, 1800, 1802, 1804, 1805, 1807, 1810, 1811, 1813, 1817, 1818, 1822, 1824, 1825, 1827, 1829, 1831, 1832, 1834, 1836, 1837, 1840, 1843, 1845, 1846, 1847, 1853, 1856, 1858, 1859, 1861, 1862, 1865, 1867, 1870, 1871, 1872, 1874, 1875, 1879, 1881, 1883, 1884, 1888, 1891, 1893, 1894, 1897, 1899, 1901, 1903, 1908, 1910, 1911, 1912, 1913, 1914, 1916, 1917, 1919, 1921, 1923, 1924, 1927, 1930, 1934, 1935, 1936, 1937, 1939, 1940, 1941, 1942, 1944, 1945, 1946, 1947, 1949, 1950, 1951, 1953, 1954, 1955, 1956, 1958, 1960, 1962, 1964, 1966, 1967, 1969, 1970, 1972, 1973, 1975, 1980, 1981, 1984, 1985, 1987, 1989, 1990, 1995, 1996, 1998, 1999], deadline = 1)
        configuration.add_task(name="Task5", identifier=5, period=3.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.401785, et_stddev=0.13392833333333334 , list_activation_dates=[2, 13, 18, 22, 25, 29, 34, 39, 50, 55, 61, 64, 68, 73, 77, 85, 90, 94, 100, 104, 109, 114, 118, 124, 130, 136, 139, 145, 149, 165, 171, 175, 182, 191, 195, 204, 208, 217, 223, 231, 236, 242, 250, 254, 261, 266, 271, 275, 280, 286, 289, 294, 298, 303, 308, 334, 343, 355, 370, 375, 383, 387, 394, 397, 414, 419, 424, 429, 437, 453, 459, 462, 470, 473, 477, 483, 489, 492, 496, 501, 505, 509, 514, 518, 521, 528, 536, 541, 548, 551, 555, 558, 565, 569, 582, 586, 589, 593, 599, 609, 616, 622, 629, 636, 640, 646, 651, 655, 659, 664, 671, 675, 679, 683, 687, 691, 694, 700, 705, 709, 719, 723, 728, 744, 749, 753, 757, 761, 770, 779, 785, 791, 794, 798, 802, 806, 811, 818, 826, 836, 841, 845, 852, 855, 860, 866, 870, 875, 883, 900, 903, 908, 912, 918, 922, 929, 932, 936, 942, 946, 950, 959, 967, 981, 985, 995, 999, 1010, 1017, 1032, 1037, 1040, 1047, 1050, 1056, 1061, 1065, 1072, 1076, 1079, 1088, 1094, 1099, 1103, 1107, 1110, 1115, 1122, 1125, 1129, 1137, 1141, 1144, 1148, 1151, 1158, 1173, 1177, 1182, 1187, 1192, 1195, 1200, 1206, 1215, 1222, 1225, 1229, 1233, 1240, 1245, 1253, 1257, 1260, 1281, 1291, 1295, 1300, 1304, 1308, 1311, 1316, 1321, 1325, 1328, 1333, 1336, 1343, 1350, 1354, 1368, 1375, 1381, 1386, 1396, 1405, 1409, 1415, 1420, 1425, 1431, 1438, 1442, 1445, 1452, 1456, 1462, 1466, 1478, 1481, 1485, 1490, 1497, 1505, 1511, 1515, 1520, 1523, 1529, 1539, 1546, 1550, 1554, 1559, 1563, 1569, 1574, 1581, 1587, 1590, 1597, 1607, 1611, 1618, 1625, 1629, 1636, 1647, 1652, 1655, 1658, 1665, 1669, 1672, 1676, 1681, 1685, 1691, 1697, 1702, 1707, 1715, 1722, 1726, 1731, 1739, 1744, 1751, 1763, 1770, 1775, 1781, 1785, 1793, 1800, 1805, 1810, 1818, 1827, 1836, 1844, 1855, 1860, 1865, 1873, 1880, 1888, 1894, 1898, 1902, 1922, 1926, 1931, 1935, 1941, 1947, 1953, 1962, 1969, 1981, 1990, 1995, 1999], deadline = 6)
        configuration.add_task(name="Task2", identifier=2, period=7.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=2.417067, acet=2.417067, et_stddev=0.805689, deadline= 9)
        configuration.add_task(name="Task3", identifier=3, period=18.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=9.251077, acet=9.251077, et_stddev=3.0836923333333335, deadline= 29)
        configuration.add_task(name="Task6", identifier=6, period=10.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.97963, et_stddev=0.32654333333333335 , list_activation_dates=[9, 26, 39, 75, 94, 110, 130, 145, 188, 199, 210, 229, 240, 252, 264, 293, 343, 381, 402, 425, 440, 471, 491, 507, 549, 564, 578, 594, 609, 623, 638, 660, 686, 705, 728, 742, 752, 808, 818, 828, 901, 914, 944, 982, 995, 1008, 1023, 1038, 1069, 1137, 1160, 1172, 1184, 1207, 1248, 1264, 1279, 1297, 1312, 1335, 1361, 1405, 1415, 1426, 1448, 1487, 1514, 1527, 1540, 1552, 1562, 1588, 1604, 1624, 1638, 1674, 1715, 1728, 1741, 1763, 1793, 1803, 1817, 1831, 1843, 1855, 1866, 1878, 1896, 1910, 1921, 1933, 1959, 1982, 1998], deadline = 20)
        configuration.add_task(name="Task1", identifier=1, period=8.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=5.926046, acet=5.926046, et_stddev=1.9753486666666669, deadline= 11)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "2")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "2")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "2")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "2")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task4", identifier=4, period=2.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.413414, et_stddev=0.13780466666666666 , list_activation_dates=[2, 6, 12, 14, 19, 23, 27, 30, 36, 39, 41, 46, 50, 56, 59, 61, 64, 71, 75, 78, 80, 82, 85, 95, 100, 103, 110, 113, 117, 121, 127, 129, 134, 147, 150, 154, 161, 163, 167, 172, 179, 183, 186, 190, 194, 196, 202, 205, 212, 217, 219, 224, 230, 235, 238, 240, 244, 248, 252, 256, 258, 262, 267, 270, 273, 279, 281, 285, 292, 298, 302, 306, 310, 312, 315, 321, 325, 328, 330, 332, 336, 344, 349, 352, 357, 361, 364, 368, 371, 376, 379, 382, 386, 393, 397, 403, 410, 418, 421, 429, 437, 439, 442, 448, 451, 454, 456, 458, 462, 466, 469, 472, 478, 482, 484, 490, 492, 494, 496, 500, 504, 507, 509, 512, 517, 520, 526, 531, 535, 537, 539, 544, 547, 550, 558, 562, 569, 573, 575, 577, 580, 582, 584, 590, 592, 595, 598, 606, 608, 611, 618, 621, 624, 627, 629, 634, 638, 641, 644, 650, 652, 655, 658, 660, 663, 666, 670, 674, 677, 679, 683, 691, 694, 699, 706, 708, 713, 717, 722, 725, 729, 731, 737, 740, 744, 747, 751, 754, 757, 760, 762, 766, 769, 773, 785, 788, 791, 794, 803, 807, 810, 816, 820, 822, 825, 827, 829, 833, 836, 845, 847, 851, 854, 858, 861, 863, 865, 867, 873, 879, 881, 884, 888, 890, 898, 901, 904, 907, 912, 915, 927, 929, 932, 934, 939, 941, 943, 948, 951, 953, 955, 960, 963, 966, 968, 974, 977, 983, 989, 993, 1000, 1003, 1006, 1008, 1011, 1019, 1022, 1025, 1032, 1036, 1040, 1043, 1045, 1048, 1052, 1057, 1060, 1063, 1067, 1070, 1075, 1079, 1082, 1086, 1089, 1093, 1095, 1098, 1102, 1108, 1110, 1117, 1120, 1123, 1126, 1130, 1133, 1135, 1137, 1140, 1143, 1147, 1149, 1152, 1155, 1158, 1161, 1165, 1174, 1178, 1181, 1184, 1187, 1189, 1193, 1200, 1206, 1209, 1211, 1214, 1216, 1219, 1226, 1231, 1235, 1241, 1249, 1252, 1257, 1259, 1270, 1275, 1284, 1287, 1297, 1301, 1305, 1313, 1320, 1323, 1327, 1334, 1338, 1341, 1344, 1349, 1352, 1355, 1359, 1363, 1367, 1369, 1371, 1377, 1379, 1383, 1385, 1391, 1394, 1397, 1399, 1402, 1405, 1407, 1410, 1412, 1421, 1423, 1427, 1431, 1434, 1436, 1440, 1445, 1453, 1458, 1469, 1473, 1475, 1478, 1480, 1485, 1498, 1501, 1503, 1509, 1516, 1518, 1522, 1525, 1530, 1533, 1536, 1539, 1543, 1547, 1553, 1563, 1571, 1573, 1577, 1579, 1583, 1593, 1596, 1599, 1602, 1605, 1608, 1611, 1617, 1620, 1623, 1626, 1628, 1631, 1633, 1641, 1647, 1651, 1653, 1656, 1661, 1663, 1667, 1669, 1671, 1675, 1678, 1687, 1690, 1692, 1696, 1704, 1707, 1710, 1713, 1719, 1725, 1729, 1735, 1739, 1743, 1746, 1749, 1751, 1753, 1755, 1758, 1760, 1763, 1766, 1769, 1779, 1783, 1786, 1793, 1797, 1801, 1806, 1809, 1814, 1819, 1821, 1825, 1827, 1831, 1833, 1837, 1841, 1844, 1846, 1850, 1853, 1859, 1864, 1869, 1875, 1878, 1881, 1884, 1890, 1896, 1900, 1904, 1908, 1912, 1918, 1923, 1926, 1929, 1931, 1934, 1940, 1945, 1950, 1954, 1956, 1959, 1965, 1972, 1980, 1986, 1988, 1999], deadline = 2)
        configuration.add_task(name="Task1", identifier=1, period=12.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=8.94004, acet=8.94004, et_stddev=2.9800133333333334, deadline= 15)
        configuration.add_task(name="Task6", identifier=6, period=41.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=2, acet=1.259395, et_stddev=0.41979833333333333 , list_activation_dates=[56, 192, 255, 308, 424, 492, 693, 789, 833, 883, 930, 991, 1112, 1159, 1222, 1269, 1395, 1529, 1585, 1647, 1704, 1775, 1850, 1927], deadline = 36)
        configuration.add_task(name="Task2", identifier=2, period=2.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=0.753198, acet=0.753198, et_stddev=0.251066, deadline= 4)
        configuration.add_task(name="Task3", identifier=3, period=1.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=0.478397, acet=0.478397, et_stddev=0.15946566666666667, deadline= 1)
        configuration.add_task(name="Task5", identifier=5, period=1.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.062575, et_stddev=0.020858333333333336 , list_activation_dates=[1, 2, 7, 9, 10, 13, 14, 16, 17, 19, 20, 22, 23, 24, 28, 30, 31, 33, 35, 38, 40, 42, 43, 46, 49, 52, 54, 57, 61, 63, 66, 67, 68, 69, 70, 71, 75, 76, 77, 78, 79, 82, 84, 87, 88, 91, 93, 95, 97, 104, 106, 107, 108, 109, 110, 113, 115, 117, 120, 123, 124, 126, 127, 128, 129, 132, 134, 136, 138, 140, 142, 146, 147, 149, 150, 153, 154, 155, 156, 158, 159, 163, 165, 166, 169, 175, 177, 179, 181, 182, 183, 184, 185, 188, 190, 191, 193, 195, 196, 199, 201, 202, 203, 205, 206, 208, 211, 213, 215, 217, 218, 221, 222, 223, 226, 228, 230, 231, 232, 239, 240, 243, 246, 250, 252, 254, 255, 256, 257, 258, 262, 263, 265, 270, 272, 274, 276, 277, 278, 279, 282, 283, 285, 287, 289, 290, 292, 294, 297, 299, 300, 302, 303, 305, 307, 310, 311, 313, 314, 316, 319, 321, 322, 324, 325, 328, 330, 332, 335, 336, 337, 339, 341, 342, 343, 344, 348, 350, 353, 354, 356, 357, 359, 361, 364, 365, 366, 370, 371, 372, 374, 375, 377, 380, 381, 384, 385, 387, 389, 390, 391, 393, 394, 396, 397, 398, 399, 400, 403, 404, 406, 407, 410, 411, 412, 413, 414, 419, 421, 423, 425, 428, 430, 432, 436, 437, 439, 441, 442, 443, 445, 448, 452, 457, 458, 462, 464, 465, 467, 468, 471, 472, 473, 475, 477, 478, 479, 484, 487, 488, 489, 492, 493, 494, 498, 499, 500, 501, 502, 504, 506, 507, 508, 512, 514, 516, 517, 520, 524, 526, 527, 530, 533, 535, 536, 537, 539, 540, 542, 544, 546, 548, 550, 552, 555, 556, 558, 560, 562, 566, 567, 568, 570, 572, 573, 575, 578, 580, 581, 583, 585, 586, 587, 588, 593, 600, 602, 606, 609, 611, 614, 615, 617, 619, 621, 622, 623, 625, 626, 627, 628, 629, 630, 632, 633, 634, 636, 639, 642, 643, 645, 648, 650, 652, 653, 655, 657, 659, 661, 663, 665, 667, 669, 671, 672, 674, 675, 677, 678, 679, 680, 682, 684, 687, 690, 692, 696, 698, 700, 702, 705, 708, 709, 711, 713, 714, 717, 718, 719, 720, 722, 724, 727, 729, 731, 737, 738, 740, 741, 744, 746, 747, 751, 753, 755, 757, 759, 761, 765, 766, 768, 775, 776, 777, 778, 780, 782, 783, 785, 789, 791, 794, 796, 799, 801, 804, 805, 807, 808, 809, 811, 813, 816, 819, 820, 822, 824, 828, 829, 834, 836, 839, 842, 844, 846, 847, 848, 849, 850, 852, 856, 857, 858, 859, 860, 862, 863, 865, 866, 868, 869, 870, 871, 872, 873, 875, 880, 882, 883, 885, 887, 888, 890, 892, 893, 895, 897, 898, 904, 906, 908, 909, 911, 914, 920, 921, 923, 925, 927, 929, 931, 933, 935, 938, 940, 943, 945, 946, 949, 952, 953, 955, 958, 959, 960, 962, 964, 966, 967, 969, 971, 973, 974, 978, 981, 984, 985, 986, 987, 989, 991, 993, 995, 998, 1000, 1002, 1003, 1004, 1006, 1009, 1011, 1013, 1014, 1016, 1017, 1018, 1019, 1020, 1022, 1024, 1025, 1026, 1028, 1030, 1031, 1033, 1036, 1041, 1044, 1047, 1048, 1049, 1051, 1054, 1059, 1060, 1061, 1064, 1065, 1067, 1068, 1070, 1071, 1074, 1076, 1081, 1083, 1085, 1086, 1088, 1093, 1095, 1098, 1100, 1101, 1102, 1103, 1104, 1105, 1107, 1109, 1111, 1113, 1115, 1118, 1119, 1121, 1122, 1125, 1126, 1128, 1129, 1131, 1133, 1134, 1135, 1136, 1138, 1140, 1141, 1143, 1148, 1149, 1152, 1154, 1156, 1161, 1164, 1168, 1170, 1175, 1176, 1177, 1178, 1180, 1182, 1184, 1186, 1188, 1189, 1191, 1192, 1193, 1194, 1196, 1197, 1198, 1200, 1201, 1204, 1205, 1206, 1207, 1209, 1210, 1212, 1214, 1217, 1219, 1221, 1223, 1224, 1226, 1228, 1230, 1232, 1234, 1235, 1237, 1238, 1239, 1240, 1241, 1242, 1243, 1245, 1247, 1248, 1249, 1250, 1251, 1253, 1255, 1258, 1259, 1260, 1261, 1264, 1265, 1266, 1267, 1268, 1273, 1276, 1277, 1278, 1279, 1280, 1281, 1283, 1286, 1287, 1289, 1293, 1295, 1297, 1298, 1299, 1302, 1304, 1307, 1309, 1310, 1313, 1315, 1317, 1318, 1320, 1322, 1323, 1325, 1331, 1333, 1334, 1338, 1342, 1344, 1345, 1346, 1347, 1348, 1350, 1353, 1356, 1359, 1361, 1362, 1363, 1365, 1366, 1372, 1374, 1376, 1378, 1380, 1381, 1383, 1385, 1389, 1391, 1394, 1395, 1397, 1401, 1402, 1404, 1406, 1409, 1410, 1412, 1415, 1417, 1419, 1422, 1423, 1425, 1429, 1430, 1431, 1433, 1434, 1436, 1437, 1438, 1440, 1442, 1444, 1445, 1447, 1449, 1450, 1454, 1461, 1463, 1467, 1469, 1471, 1473, 1475, 1476, 1480, 1482, 1483, 1485, 1488, 1489, 1490, 1492, 1495, 1496, 1498, 1499, 1500, 1501, 1502, 1505, 1506, 1507, 1509, 1511, 1514, 1516, 1518, 1520, 1524, 1526, 1527, 1528, 1530, 1531, 1533, 1535, 1536, 1538, 1539, 1541, 1543, 1544, 1545, 1547, 1550, 1551, 1553, 1555, 1556, 1561, 1562, 1570, 1573, 1574, 1577, 1578, 1579, 1583, 1585, 1586, 1587, 1593, 1595, 1598, 1600, 1601, 1603, 1604, 1606, 1608, 1609, 1610, 1611, 1612, 1615, 1617, 1619, 1621, 1623, 1628, 1631, 1635, 1637, 1640, 1645, 1646, 1647, 1649, 1650, 1651, 1656, 1658, 1659, 1662, 1664, 1665, 1668, 1670, 1673, 1674, 1675, 1676, 1678, 1679, 1680, 1683, 1685, 1686, 1688, 1690, 1692, 1695, 1696, 1697, 1699, 1700, 1701, 1702, 1703, 1705, 1708, 1712, 1713, 1715, 1716, 1718, 1719, 1721, 1723, 1725, 1727, 1729, 1730, 1732, 1734, 1735, 1736, 1740, 1742, 1744, 1746, 1748, 1749, 1750, 1751, 1753, 1755, 1756, 1757, 1758, 1760, 1763, 1766, 1768, 1771, 1772, 1774, 1778, 1780, 1781, 1783, 1787, 1788, 1789, 1793, 1794, 1796, 1799, 1801, 1803, 1805, 1806, 1809, 1811, 1812, 1813, 1814, 1816, 1817, 1818, 1820, 1822, 1824, 1828, 1830, 1833, 1835, 1836, 1837, 1838, 1839, 1840, 1841, 1843, 1845, 1847, 1849, 1850, 1856, 1858, 1859, 1863, 1864, 1865, 1867, 1868, 1869, 1870, 1873, 1875, 1878, 1881, 1882, 1884, 1887, 1888, 1889, 1893, 1895, 1897, 1899, 1901, 1902, 1904, 1907, 1909, 1910, 1911, 1912, 1913, 1914, 1915, 1916, 1917, 1918, 1921, 1925, 1926, 1929, 1930, 1932, 1934, 1935, 1937, 1939, 1940, 1944, 1945, 1946, 1948, 1950, 1951, 1952, 1954, 1955, 1957, 1961, 1963, 1964, 1967, 1968, 1970, 1975, 1976, 1977, 1978, 1980, 1981, 1982, 1983, 1985, 1989, 1990, 1992, 1993, 1994, 1995, 1997, 1999, 2000], deadline = 1)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "3")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "3")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "3")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "3")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task1", identifier=1, period=7.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=6.314343, acet=6.314343, et_stddev=2.104781, deadline= 14)
        configuration.add_task(name="Task3", identifier=3, period=29.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=13.743839, acet=13.743839, et_stddev=4.581279666666666, deadline= 26)
        configuration.add_task(name="Task6", identifier=6, period=18.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=4, acet=3.402616, et_stddev=1.1342053333333333 , list_activation_dates=[21, 41, 75, 98, 141, 170, 190, 209, 227, 254, 294, 327, 379, 433, 453, 474, 523, 583, 643, 729, 777, 799, 863, 891, 928, 949, 982, 1007, 1032, 1065, 1115, 1158, 1186, 1206, 1226, 1264, 1294, 1335, 1354, 1374, 1396, 1419, 1442, 1482, 1507, 1584, 1622, 1692, 1710, 1730, 1767, 1803, 1862, 1967, 1998], deadline = 24)
        configuration.add_task(name="Task2", identifier=2, period=42.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=9.409066, acet=9.409066, et_stddev=3.136355333333333, deadline= 38)
        configuration.add_task(name="Task5", identifier=5, period=4.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.216239, et_stddev=0.07207966666666667 , list_activation_dates=[11, 17, 24, 28, 34, 40, 49, 55, 61, 69, 73, 88, 94, 104, 110, 117, 123, 129, 133, 143, 149, 171, 193, 200, 224, 229, 233, 254, 263, 268, 287, 294, 299, 303, 308, 314, 320, 326, 331, 337, 348, 362, 367, 376, 393, 400, 405, 412, 421, 438, 451, 461, 469, 475, 496, 502, 508, 512, 522, 530, 536, 542, 547, 560, 566, 582, 587, 593, 598, 609, 613, 619, 624, 629, 636, 650, 656, 665, 670, 674, 682, 686, 720, 732, 743, 755, 760, 772, 779, 793, 797, 802, 806, 813, 818, 823, 839, 847, 851, 857, 864, 871, 876, 882, 886, 902, 909, 914, 925, 941, 947, 955, 967, 975, 981, 991, 995, 1001, 1009, 1016, 1021, 1027, 1032, 1037, 1046, 1053, 1061, 1067, 1074, 1078, 1085, 1090, 1106, 1111, 1118, 1125, 1130, 1144, 1150, 1162, 1180, 1186, 1191, 1198, 1207, 1214, 1218, 1223, 1231, 1235, 1244, 1252, 1259, 1264, 1277, 1285, 1294, 1303, 1320, 1329, 1334, 1339, 1350, 1358, 1370, 1379, 1391, 1400, 1411, 1419, 1424, 1431, 1435, 1442, 1449, 1455, 1468, 1475, 1482, 1493, 1500, 1505, 1518, 1525, 1530, 1535, 1540, 1550, 1555, 1561, 1575, 1582, 1586, 1590, 1602, 1616, 1623, 1643, 1653, 1657, 1665, 1676, 1681, 1693, 1698, 1703, 1715, 1719, 1725, 1731, 1736, 1745, 1754, 1761, 1766, 1772, 1779, 1798, 1805, 1809, 1814, 1828, 1832, 1836, 1843, 1851, 1857, 1862, 1866, 1878, 1887, 1894, 1899, 1906, 1913, 1925, 1941, 1946, 1952, 1959, 1963, 1983, 1988, 1996], deadline = 5)
        configuration.add_task(name="Task4", identifier=4, period=4.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.227623, et_stddev=0.07587433333333334 , list_activation_dates=[2, 12, 20, 24, 30, 39, 49, 59, 67, 75, 79, 85, 90, 99, 113, 118, 122, 132, 147, 151, 167, 173, 178, 185, 194, 201, 213, 219, 225, 243, 252, 256, 264, 271, 276, 281, 289, 294, 299, 313, 328, 333, 341, 350, 356, 371, 379, 385, 389, 401, 407, 414, 421, 426, 435, 443, 447, 459, 483, 489, 496, 504, 519, 528, 538, 544, 557, 563, 573, 579, 584, 597, 623, 628, 639, 645, 651, 655, 659, 669, 688, 696, 701, 705, 713, 720, 725, 732, 741, 750, 758, 762, 767, 783, 789, 805, 812, 824, 828, 834, 840, 847, 860, 873, 878, 893, 902, 906, 912, 917, 922, 927, 938, 943, 952, 961, 978, 986, 992, 998, 1002, 1010, 1018, 1025, 1032, 1048, 1059, 1064, 1071, 1082, 1092, 1098, 1108, 1114, 1128, 1132, 1141, 1147, 1153, 1163, 1170, 1177, 1193, 1201, 1208, 1214, 1218, 1229, 1236, 1251, 1264, 1271, 1276, 1283, 1294, 1301, 1305, 1311, 1318, 1324, 1330, 1335, 1339, 1348, 1352, 1358, 1374, 1379, 1385, 1390, 1395, 1401, 1406, 1411, 1415, 1420, 1427, 1431, 1442, 1450, 1458, 1463, 1467, 1472, 1479, 1488, 1496, 1504, 1508, 1515, 1525, 1536, 1543, 1550, 1555, 1565, 1572, 1577, 1584, 1597, 1619, 1623, 1630, 1636, 1641, 1647, 1656, 1661, 1684, 1688, 1692, 1700, 1705, 1713, 1721, 1728, 1736, 1741, 1747, 1751, 1758, 1767, 1772, 1779, 1786, 1797, 1808, 1814, 1822, 1826, 1834, 1838, 1850, 1861, 1873, 1906, 1912, 1919, 1925, 1929, 1943, 1949, 1957, 1962, 1972, 1978, 1987, 1992, 1996], deadline = 1)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "4")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "4")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "4")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "4")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task2", identifier=2, period=10.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=1.186155, acet=1.186155, et_stddev=0.39538500000000004, deadline= 2)
        configuration.add_task(name="Task4", identifier=4, period=3.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.194153, et_stddev=0.06471766666666666 , list_activation_dates=[1, 5, 11, 15, 23, 32, 35, 39, 43, 47, 58, 69, 77, 84, 90, 94, 98, 106, 113, 126, 141, 147, 153, 159, 166, 170, 176, 181, 187, 195, 200, 204, 208, 212, 215, 218, 228, 231, 240, 245, 248, 256, 262, 271, 278, 281, 284, 288, 297, 304, 310, 314, 318, 323, 342, 348, 351, 356, 363, 371, 381, 384, 390, 396, 403, 407, 410, 416, 419, 425, 441, 444, 447, 450, 462, 466, 470, 474, 481, 486, 497, 502, 508, 512, 525, 530, 537, 552, 557, 562, 567, 571, 574, 577, 581, 587, 592, 596, 599, 604, 609, 617, 624, 627, 630, 634, 641, 646, 650, 664, 668, 678, 682, 691, 694, 699, 709, 713, 719, 728, 733, 741, 749, 752, 761, 768, 771, 774, 777, 785, 792, 796, 801, 808, 812, 817, 821, 827, 832, 838, 844, 847, 856, 860, 867, 872, 878, 881, 887, 890, 893, 896, 905, 910, 927, 932, 943, 957, 961, 967, 972, 976, 981, 985, 988, 1000, 1011, 1015, 1020, 1023, 1033, 1054, 1059, 1062, 1065, 1070, 1074, 1079, 1083, 1093, 1098, 1105, 1111, 1116, 1122, 1138, 1143, 1149, 1154, 1160, 1164, 1167, 1172, 1178, 1182, 1187, 1192, 1197, 1205, 1212, 1218, 1222, 1229, 1236, 1240, 1249, 1261, 1265, 1271, 1277, 1281, 1292, 1299, 1304, 1310, 1320, 1324, 1328, 1332, 1336, 1344, 1350, 1354, 1357, 1364, 1373, 1378, 1382, 1386, 1390, 1394, 1402, 1406, 1417, 1422, 1434, 1438, 1443, 1447, 1457, 1464, 1470, 1473, 1478, 1489, 1493, 1502, 1509, 1521, 1525, 1539, 1544, 1548, 1553, 1556, 1560, 1564, 1568, 1573, 1579, 1590, 1594, 1605, 1609, 1616, 1643, 1648, 1651, 1655, 1661, 1665, 1674, 1680, 1687, 1695, 1699, 1709, 1721, 1725, 1728, 1733, 1738, 1742, 1745, 1754, 1757, 1773, 1782, 1786, 1793, 1797, 1806, 1814, 1823, 1830, 1834, 1837, 1843, 1846, 1851, 1857, 1861, 1870, 1876, 1883, 1890, 1896, 1904, 1907, 1911, 1914, 1918, 1923, 1926, 1934, 1938, 1946, 1950, 1954, 1959, 1969, 1973, 1981, 1991, 1999], deadline = 1)
        configuration.add_task(name="Task3", identifier=3, period=2.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=1.969932, acet=1.969932, et_stddev=0.656644, deadline= 2)
        configuration.add_task(name="Task5", identifier=5, period=6.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=2, acet=1.102704, et_stddev=0.36756799999999995 , list_activation_dates=[4, 11, 19, 31, 42, 53, 66, 74, 83, 91, 99, 110, 118, 127, 137, 144, 151, 168, 179, 191, 203, 211, 219, 243, 252, 260, 267, 276, 286, 293, 304, 317, 325, 338, 346, 358, 369, 380, 389, 397, 405, 429, 439, 450, 457, 464, 473, 481, 489, 497, 511, 523, 538, 547, 557, 564, 590, 598, 604, 620, 633, 648, 657, 682, 690, 707, 715, 722, 730, 737, 764, 770, 777, 797, 804, 813, 821, 849, 861, 879, 917, 938, 945, 953, 959, 972, 985, 1016, 1022, 1028, 1034, 1044, 1055, 1065, 1073, 1089, 1116, 1131, 1139, 1150, 1157, 1163, 1184, 1204, 1214, 1246, 1257, 1267, 1275, 1281, 1293, 1302, 1315, 1324, 1332, 1352, 1367, 1374, 1391, 1398, 1407, 1417, 1425, 1441, 1450, 1460, 1479, 1490, 1497, 1505, 1517, 1529, 1536, 1545, 1572, 1578, 1595, 1603, 1614, 1622, 1629, 1639, 1649, 1658, 1672, 1679, 1687, 1694, 1710, 1720, 1740, 1765, 1777, 1784, 1791, 1800, 1807, 1815, 1826, 1836, 1842, 1856, 1901, 1911, 1920, 1926, 1932, 1947, 1979, 1992, 1998], deadline = 2)
        configuration.add_task(name="Task1", identifier=1, period=2.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=0.992836, acet=0.992836, et_stddev=0.33094533333333337, deadline= 4)
        configuration.add_task(name="Task6", identifier=6, period=1.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.051498, et_stddev=0.017166 , list_activation_dates=[2, 4, 6, 7, 8, 9, 11, 12, 14, 16, 18, 20, 22, 24, 25, 27, 30, 31, 32, 36, 38, 39, 40, 42, 44, 47, 49, 50, 52, 53, 54, 56, 57, 59, 61, 65, 71, 72, 73, 77, 79, 81, 82, 85, 88, 90, 91, 92, 95, 96, 97, 99, 101, 108, 109, 111, 112, 113, 114, 116, 120, 122, 123, 126, 127, 129, 132, 134, 136, 137, 138, 140, 142, 144, 146, 148, 150, 151, 153, 154, 155, 157, 159, 161, 163, 164, 166, 168, 171, 172, 173, 174, 176, 178, 179, 180, 181, 182, 185, 188, 190, 194, 197, 200, 203, 204, 207, 208, 210, 211, 212, 214, 216, 217, 218, 220, 222, 223, 224, 226, 229, 231, 233, 234, 236, 238, 240, 243, 246, 247, 250, 252, 255, 257, 259, 260, 261, 262, 267, 268, 270, 271, 272, 275, 276, 277, 279, 280, 281, 282, 283, 285, 289, 290, 293, 294, 296, 298, 300, 304, 307, 309, 311, 314, 315, 317, 319, 320, 321, 322, 328, 330, 332, 334, 335, 336, 342, 343, 345, 349, 351, 354, 356, 358, 360, 361, 366, 367, 373, 375, 377, 379, 381, 382, 383, 385, 387, 391, 394, 398, 399, 401, 403, 404, 406, 408, 409, 411, 416, 417, 418, 419, 421, 423, 425, 426, 428, 429, 433, 437, 441, 443, 444, 447, 449, 450, 452, 454, 456, 459, 460, 464, 465, 468, 470, 473, 478, 479, 480, 481, 483, 485, 488, 489, 492, 496, 497, 499, 501, 502, 505, 508, 510, 512, 514, 516, 517, 518, 519, 521, 523, 525, 526, 528, 532, 533, 534, 535, 537, 540, 541, 543, 544, 546, 548, 550, 552, 554, 557, 559, 561, 563, 564, 566, 571, 573, 575, 576, 578, 583, 587, 588, 589, 590, 591, 593, 599, 601, 604, 606, 609, 610, 612, 613, 616, 617, 618, 621, 625, 626, 627, 629, 630, 633, 637, 639, 642, 644, 646, 648, 649, 650, 652, 655, 656, 660, 661, 662, 663, 665, 668, 669, 672, 673, 674, 676, 677, 679, 681, 683, 685, 686, 688, 689, 691, 695, 697, 698, 700, 703, 705, 707, 708, 710, 711, 714, 716, 717, 719, 720, 723, 724, 728, 731, 732, 734, 736, 737, 740, 741, 742, 743, 744, 745, 748, 750, 753, 754, 755, 758, 760, 761, 763, 764, 765, 766, 769, 770, 771, 773, 774, 775, 777, 778, 779, 781, 782, 783, 785, 787, 788, 790, 792, 793, 796, 798, 800, 801, 802, 804, 805, 807, 811, 813, 816, 819, 821, 823, 824, 825, 826, 828, 831, 833, 834, 835, 837, 838, 841, 843, 844, 847, 848, 850, 852, 855, 856, 857, 859, 860, 862, 864, 866, 867, 868, 869, 871, 872, 873, 875, 876, 879, 880, 882, 883, 885, 886, 888, 889, 892, 896, 898, 903, 904, 905, 906, 908, 911, 912, 916, 917, 918, 921, 923, 925, 927, 929, 931, 934, 935, 936, 938, 939, 942, 945, 950, 953, 956, 958, 961, 963, 966, 969, 973, 974, 975, 979, 981, 982, 983, 984, 987, 989, 990, 991, 993, 997, 999, 1002, 1003, 1004, 1005, 1008, 1011, 1012, 1013, 1015, 1016, 1018, 1019, 1020, 1022, 1024, 1026, 1027, 1029, 1031, 1032, 1034, 1035, 1038, 1039, 1040, 1041, 1044, 1046, 1049, 1051, 1055, 1057, 1058, 1060, 1063, 1065, 1066, 1068, 1069, 1070, 1071, 1073, 1075, 1077, 1080, 1082, 1085, 1087, 1089, 1090, 1091, 1092, 1094, 1095, 1097, 1099, 1101, 1103, 1104, 1105, 1107, 1109, 1111, 1116, 1118, 1119, 1121, 1122, 1123, 1126, 1128, 1129, 1130, 1133, 1136, 1137, 1138, 1143, 1144, 1146, 1147, 1149, 1150, 1152, 1153, 1158, 1161, 1164, 1167, 1169, 1170, 1171, 1173, 1175, 1176, 1178, 1183, 1184, 1186, 1187, 1189, 1190, 1192, 1193, 1194, 1198, 1199, 1201, 1205, 1206, 1207, 1209, 1210, 1212, 1213, 1215, 1218, 1219, 1220, 1221, 1226, 1227, 1229, 1230, 1232, 1233, 1236, 1238, 1239, 1241, 1242, 1244, 1247, 1248, 1250, 1254, 1256, 1261, 1264, 1265, 1268, 1272, 1273, 1276, 1277, 1278, 1280, 1282, 1283, 1286, 1288, 1289, 1290, 1292, 1294, 1297, 1299, 1302, 1303, 1310, 1312, 1313, 1314, 1319, 1321, 1322, 1323, 1324, 1325, 1327, 1329, 1333, 1334, 1336, 1338, 1340, 1341, 1342, 1344, 1346, 1349, 1350, 1352, 1354, 1357, 1360, 1361, 1363, 1364, 1366, 1368, 1371, 1372, 1374, 1376, 1378, 1379, 1381, 1383, 1384, 1386, 1387, 1388, 1389, 1391, 1393, 1394, 1397, 1398, 1399, 1406, 1407, 1408, 1409, 1411, 1413, 1414, 1418, 1420, 1421, 1423, 1425, 1427, 1428, 1430, 1431, 1433, 1434, 1436, 1437, 1439, 1441, 1443, 1444, 1447, 1449, 1450, 1451, 1453, 1454, 1456, 1458, 1460, 1462, 1463, 1465, 1467, 1468, 1470, 1471, 1473, 1476, 1478, 1481, 1483, 1484, 1486, 1489, 1490, 1493, 1495, 1496, 1499, 1502, 1503, 1504, 1505, 1508, 1509, 1513, 1514, 1516, 1521, 1522, 1524, 1525, 1526, 1528, 1530, 1532, 1533, 1535, 1537, 1539, 1540, 1542, 1545, 1547, 1549, 1550, 1551, 1553, 1554, 1555, 1556, 1557, 1558, 1559, 1560, 1562, 1567, 1569, 1572, 1574, 1576, 1577, 1579, 1582, 1583, 1586, 1589, 1590, 1592, 1593, 1594, 1601, 1603, 1605, 1608, 1609, 1611, 1612, 1614, 1617, 1619, 1621, 1624, 1627, 1629, 1631, 1633, 1635, 1636, 1639, 1640, 1643, 1645, 1646, 1649, 1651, 1654, 1655, 1656, 1658, 1660, 1662, 1665, 1666, 1667, 1668, 1669, 1672, 1674, 1677, 1678, 1682, 1683, 1685, 1687, 1689, 1690, 1691, 1692, 1694, 1696, 1697, 1700, 1702, 1703, 1704, 1706, 1708, 1711, 1715, 1716, 1718, 1719, 1721, 1725, 1727, 1728, 1730, 1733, 1734, 1736, 1738, 1741, 1743, 1746, 1748, 1750, 1752, 1754, 1756, 1757, 1758, 1760, 1762, 1765, 1766, 1769, 1771, 1772, 1776, 1778, 1779, 1781, 1782, 1784, 1786, 1787, 1789, 1790, 1791, 1792, 1795, 1797, 1798, 1799, 1801, 1803, 1804, 1806, 1809, 1810, 1811, 1815, 1816, 1817, 1820, 1822, 1827, 1829, 1831, 1833, 1834, 1837, 1838, 1839, 1840, 1842, 1844, 1846, 1849, 1852, 1855, 1856, 1859, 1861, 1864, 1866, 1868, 1871, 1872, 1873, 1874, 1875, 1878, 1879, 1881, 1883, 1884, 1885, 1886, 1888, 1890, 1892, 1894, 1897, 1900, 1901, 1903, 1905, 1906, 1910, 1911, 1913, 1914, 1916, 1917, 1918, 1919, 1922, 1923, 1926, 1927, 1928, 1933, 1937, 1939, 1941, 1943, 1944, 1945, 1946, 1948, 1950, 1952, 1953, 1957, 1960, 1961, 1962, 1964, 1965, 1966, 1967, 1968, 1969, 1971, 1972, 1973, 1974, 1976, 1978, 1979, 1981, 1982, 1984, 1986, 1987, 1989, 1990, 1991, 1993, 1995, 1997, 1998, 2000], deadline = 1)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "5")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "5")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "5")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "5")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task6", identifier=6, period=12.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=2, acet=1.386068, et_stddev=0.4620226666666667 , list_activation_dates=[1, 17, 35, 60, 77, 105, 125, 139, 152, 171, 191, 213, 226, 242, 268, 303, 333, 361, 376, 400, 421, 447, 474, 517, 546, 559, 572, 596, 627, 641, 660, 718, 777, 790, 808, 825, 838, 857, 870, 890, 923, 941, 958, 982, 995, 1007, 1021, 1035, 1069, 1091, 1134, 1160, 1180, 1196, 1208, 1236, 1264, 1289, 1307, 1377, 1398, 1430, 1458, 1473, 1500, 1518, 1534, 1550, 1570, 1602, 1617, 1647, 1661, 1681, 1700, 1721, 1734, 1746, 1798, 1814, 1829, 1849, 1867, 1894, 1916, 1962], deadline = 4)
        configuration.add_task(name="Task5", identifier=5, period=4.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.26081, et_stddev=0.08693666666666666 , list_activation_dates=[2, 11, 19, 26, 31, 35, 42, 49, 60, 64, 74, 103, 107, 113, 121, 135, 140, 147, 152, 158, 173, 181, 186, 191, 201, 205, 219, 226, 234, 239, 245, 252, 258, 269, 274, 284, 291, 297, 306, 312, 325, 330, 337, 348, 354, 359, 366, 374, 388, 398, 412, 419, 423, 433, 445, 454, 458, 464, 482, 493, 500, 519, 525, 532, 539, 544, 549, 553, 558, 564, 569, 583, 596, 601, 611, 615, 625, 649, 657, 683, 688, 696, 704, 709, 719, 726, 731, 742, 748, 753, 761, 777, 782, 790, 796, 800, 804, 809, 815, 828, 833, 843, 848, 855, 859, 864, 870, 877, 883, 888, 894, 904, 910, 917, 921, 932, 950, 957, 961, 968, 974, 978, 984, 998, 1003, 1013, 1019, 1031, 1035, 1044, 1053, 1063, 1076, 1081, 1100, 1106, 1114, 1122, 1126, 1130, 1144, 1155, 1161, 1167, 1181, 1186, 1191, 1204, 1208, 1218, 1226, 1234, 1240, 1245, 1252, 1257, 1266, 1284, 1299, 1305, 1310, 1321, 1333, 1355, 1367, 1374, 1381, 1386, 1393, 1415, 1428, 1443, 1449, 1463, 1468, 1476, 1483, 1492, 1497, 1506, 1518, 1525, 1538, 1545, 1553, 1561, 1566, 1571, 1577, 1583, 1593, 1620, 1626, 1635, 1639, 1644, 1655, 1659, 1666, 1684, 1689, 1697, 1708, 1713, 1717, 1723, 1727, 1733, 1744, 1764, 1769, 1773, 1784, 1800, 1805, 1817, 1836, 1841, 1850, 1856, 1863, 1888, 1898, 1906, 1918, 1922, 1929, 1936, 1941, 1946, 1957, 1961, 1970, 1977, 1982, 1991], deadline = 6)
        configuration.add_task(name="Task2", identifier=2, period=7.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=2.265106, acet=2.265106, et_stddev=0.7550353333333333, deadline= 14)
        configuration.add_task(name="Task3", identifier=3, period=5.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=1.925301, acet=1.925301, et_stddev=0.641767, deadline= 3)
        configuration.add_task(name="Task4", identifier=4, period=2.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.238583, et_stddev=0.07952766666666666 , list_activation_dates=[1, 5, 9, 12, 14, 17, 20, 25, 28, 31, 35, 38, 41, 44, 54, 56, 62, 66, 70, 73, 79, 86, 89, 95, 100, 103, 111, 114, 119, 121, 125, 130, 134, 137, 139, 145, 150, 153, 161, 164, 169, 177, 180, 183, 186, 188, 191, 202, 205, 207, 211, 214, 218, 220, 224, 226, 230, 233, 240, 242, 251, 256, 260, 263, 267, 271, 274, 278, 280, 285, 288, 294, 297, 299, 303, 305, 308, 312, 320, 323, 325, 328, 335, 339, 348, 351, 353, 356, 359, 361, 364, 368, 371, 374, 376, 383, 386, 391, 394, 397, 400, 408, 410, 417, 420, 425, 428, 431, 434, 438, 440, 446, 450, 453, 456, 458, 460, 464, 469, 472, 475, 481, 484, 486, 489, 492, 496, 498, 500, 504, 508, 510, 513, 515, 518, 520, 523, 528, 531, 533, 539, 542, 544, 550, 556, 560, 562, 567, 577, 581, 584, 587, 589, 593, 596, 598, 600, 605, 607, 609, 611, 617, 623, 628, 633, 637, 639, 643, 651, 653, 656, 658, 662, 666, 668, 672, 675, 678, 681, 685, 688, 690, 693, 697, 701, 705, 708, 710, 713, 716, 722, 724, 729, 732, 734, 738, 740, 745, 748, 752, 759, 762, 766, 768, 771, 773, 777, 781, 784, 787, 796, 799, 802, 804, 808, 810, 815, 820, 824, 827, 831, 834, 837, 842, 845, 848, 852, 856, 860, 862, 867, 870, 874, 882, 887, 891, 893, 897, 904, 908, 911, 914, 917, 922, 926, 929, 931, 941, 945, 947, 949, 952, 955, 959, 968, 974, 978, 981, 985, 989, 996, 999, 1002, 1009, 1012, 1017, 1021, 1024, 1028, 1030, 1033, 1040, 1043, 1045, 1052, 1054, 1056, 1060, 1062, 1066, 1068, 1071, 1074, 1076, 1091, 1095, 1097, 1100, 1110, 1114, 1116, 1123, 1126, 1128, 1131, 1133, 1137, 1140, 1143, 1146, 1152, 1155, 1160, 1162, 1165, 1167, 1173, 1177, 1180, 1184, 1188, 1193, 1196, 1199, 1208, 1211, 1216, 1220, 1222, 1225, 1229, 1231, 1236, 1241, 1245, 1247, 1249, 1252, 1254, 1263, 1266, 1270, 1272, 1275, 1278, 1286, 1291, 1295, 1299, 1302, 1306, 1309, 1312, 1314, 1324, 1327, 1332, 1335, 1337, 1344, 1346, 1350, 1352, 1356, 1361, 1363, 1367, 1372, 1375, 1379, 1383, 1385, 1387, 1391, 1394, 1397, 1400, 1404, 1410, 1412, 1414, 1418, 1425, 1430, 1433, 1438, 1441, 1444, 1446, 1448, 1450, 1454, 1456, 1463, 1466, 1468, 1471, 1480, 1485, 1492, 1494, 1500, 1503, 1508, 1510, 1513, 1518, 1523, 1525, 1528, 1533, 1535, 1540, 1544, 1551, 1555, 1561, 1566, 1573, 1577, 1584, 1589, 1597, 1606, 1609, 1616, 1622, 1625, 1628, 1634, 1637, 1644, 1650, 1652, 1654, 1657, 1660, 1667, 1670, 1673, 1676, 1681, 1683, 1686, 1691, 1695, 1698, 1703, 1708, 1711, 1716, 1718, 1720, 1723, 1728, 1744, 1747, 1750, 1753, 1758, 1760, 1764, 1770, 1774, 1777, 1781, 1793, 1795, 1797, 1808, 1812, 1820, 1823, 1829, 1834, 1839, 1842, 1846, 1858, 1866, 1870, 1873, 1876, 1878, 1880, 1883, 1887, 1890, 1893, 1898, 1901, 1905, 1907, 1911, 1913, 1915, 1922, 1927, 1929, 1932, 1940, 1942, 1949, 1953, 1957, 1959, 1963, 1965, 1974, 1978, 1985, 1987, 1999], deadline = 1)
        configuration.add_task(name="Task1", identifier=1, period=9.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=8.022176, acet=8.022176, et_stddev=2.674058666666667, deadline= 15)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "6")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "6")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "6")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "6")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task4", identifier=4, period=21.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=2, acet=1.239896, et_stddev=0.4132986666666667 , list_activation_dates=[4, 30, 54, 101, 141, 162, 216, 267, 294, 339, 398, 427, 460, 483, 548, 624, 660, 696, 744, 767, 802, 842, 865, 898, 941, 965, 992, 1028, 1062, 1087, 1140, 1175, 1219, 1246, 1300, 1328, 1351, 1380, 1460, 1520, 1581, 1642, 1696, 1741, 1829, 1867, 1901, 1925, 1947, 1979], deadline = 30)
        configuration.add_task(name="Task2", identifier=2, period=44.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=43.837843, acet=43.837843, et_stddev=14.612614333333333, deadline= 85)
        configuration.add_task(name="Task1", identifier=1, period=7.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=4.024025, acet=4.024025, et_stddev=1.3413416666666667, deadline= 5)
        configuration.add_task(name="Task5", identifier=5, period=1.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.068936, et_stddev=0.022978666666666665 , list_activation_dates=[2, 3, 4, 5, 6, 8, 9, 10, 11, 16, 17, 19, 21, 25, 27, 28, 29, 32, 36, 39, 40, 42, 43, 44, 45, 46, 47, 49, 50, 53, 54, 55, 57, 59, 62, 63, 65, 68, 70, 71, 74, 76, 80, 81, 83, 85, 88, 89, 94, 95, 96, 98, 100, 102, 103, 104, 105, 109, 113, 115, 117, 121, 124, 126, 127, 128, 130, 133, 135, 138, 140, 142, 145, 146, 148, 149, 151, 153, 156, 157, 158, 159, 160, 161, 163, 164, 165, 167, 168, 170, 171, 173, 176, 177, 181, 183, 184, 186, 187, 189, 194, 195, 196, 197, 198, 200, 201, 203, 206, 207, 209, 211, 212, 213, 215, 217, 218, 221, 224, 226, 229, 232, 234, 235, 236, 237, 240, 242, 243, 244, 247, 248, 249, 250, 252, 254, 257, 258, 261, 262, 265, 267, 268, 269, 271, 272, 273, 276, 278, 280, 284, 286, 288, 290, 291, 293, 294, 295, 297, 298, 299, 303, 304, 305, 307, 310, 311, 312, 313, 317, 318, 324, 326, 328, 331, 334, 335, 338, 340, 341, 344, 346, 347, 348, 349, 351, 352, 353, 354, 356, 358, 362, 363, 368, 372, 374, 376, 378, 379, 380, 381, 383, 386, 389, 391, 394, 397, 400, 401, 405, 407, 410, 411, 413, 415, 417, 418, 420, 424, 426, 428, 433, 435, 437, 439, 442, 445, 448, 449, 450, 451, 453, 455, 456, 457, 458, 459, 464, 465, 467, 468, 469, 473, 476, 478, 480, 481, 482, 486, 489, 493, 494, 495, 496, 498, 499, 501, 503, 504, 505, 507, 509, 511, 513, 516, 518, 522, 524, 526, 528, 531, 533, 536, 538, 541, 545, 546, 550, 551, 553, 554, 555, 556, 558, 560, 562, 563, 564, 565, 567, 570, 571, 573, 574, 575, 577, 578, 579, 581, 583, 584, 586, 587, 588, 590, 591, 592, 594, 598, 601, 602, 603, 609, 612, 613, 616, 617, 619, 620, 622, 624, 625, 628, 630, 631, 633, 635, 637, 639, 641, 643, 644, 645, 647, 648, 651, 653, 655, 657, 661, 663, 664, 665, 666, 668, 670, 672, 674, 675, 677, 678, 680, 683, 685, 688, 689, 691, 693, 694, 696, 698, 701, 702, 703, 705, 706, 709, 710, 712, 713, 716, 718, 724, 728, 730, 734, 736, 738, 743, 745, 747, 749, 750, 753, 756, 758, 759, 760, 765, 767, 768, 769, 771, 774, 775, 776, 778, 780, 781, 786, 788, 791, 792, 793, 795, 798, 799, 800, 801, 802, 804, 807, 809, 810, 816, 818, 820, 822, 823, 824, 825, 827, 831, 833, 834, 836, 837, 839, 841, 842, 843, 845, 852, 855, 856, 857, 859, 863, 865, 872, 874, 876, 878, 881, 882, 885, 887, 889, 891, 893, 895, 898, 900, 903, 905, 906, 908, 909, 911, 913, 914, 915, 918, 920, 921, 925, 926, 928, 930, 932, 935, 936, 937, 938, 940, 943, 944, 945, 947, 948, 951, 953, 955, 957, 959, 961, 962, 965, 968, 971, 972, 973, 974, 976, 979, 984, 988, 990, 991, 993, 995, 998, 999, 1001, 1002, 1003, 1006, 1009, 1010, 1011, 1012, 1015, 1017, 1020, 1021, 1023, 1026, 1027, 1028, 1030, 1031, 1033, 1035, 1036, 1037, 1040, 1042, 1045, 1047, 1048, 1049, 1050, 1052, 1054, 1057, 1058, 1059, 1060, 1063, 1064, 1065, 1067, 1069, 1070, 1071, 1074, 1077, 1078, 1079, 1082, 1083, 1085, 1087, 1089, 1092, 1093, 1096, 1097, 1099, 1101, 1102, 1104, 1108, 1109, 1110, 1112, 1115, 1116, 1118, 1120, 1122, 1126, 1130, 1132, 1134, 1136, 1137, 1146, 1147, 1149, 1151, 1152, 1154, 1156, 1159, 1162, 1163, 1164, 1166, 1168, 1170, 1171, 1173, 1175, 1177, 1182, 1185, 1188, 1190, 1192, 1194, 1197, 1198, 1201, 1202, 1203, 1205, 1207, 1208, 1211, 1213, 1215, 1216, 1218, 1219, 1221, 1224, 1227, 1229, 1230, 1233, 1237, 1241, 1243, 1246, 1247, 1251, 1253, 1254, 1255, 1257, 1258, 1260, 1262, 1264, 1265, 1268, 1277, 1281, 1282, 1285, 1286, 1289, 1290, 1298, 1300, 1302, 1304, 1307, 1310, 1312, 1314, 1315, 1317, 1318, 1322, 1323, 1324, 1325, 1327, 1328, 1332, 1333, 1336, 1338, 1344, 1345, 1351, 1353, 1355, 1357, 1361, 1362, 1363, 1364, 1366, 1371, 1372, 1374, 1375, 1376, 1379, 1381, 1383, 1385, 1388, 1392, 1396, 1398, 1400, 1401, 1404, 1406, 1409, 1410, 1411, 1413, 1415, 1416, 1418, 1423, 1424, 1425, 1428, 1430, 1432, 1433, 1436, 1438, 1439, 1442, 1443, 1445, 1446, 1450, 1451, 1453, 1454, 1464, 1465, 1467, 1468, 1470, 1471, 1473, 1481, 1482, 1485, 1489, 1490, 1492, 1493, 1496, 1499, 1500, 1505, 1506, 1508, 1509, 1510, 1517, 1519, 1520, 1523, 1524, 1530, 1532, 1535, 1538, 1540, 1541, 1543, 1545, 1547, 1549, 1550, 1551, 1556, 1558, 1560, 1561, 1566, 1568, 1573, 1574, 1576, 1577, 1580, 1584, 1585, 1586, 1590, 1591, 1594, 1595, 1596, 1600, 1602, 1603, 1607, 1608, 1609, 1610, 1612, 1614, 1616, 1619, 1621, 1622, 1624, 1626, 1628, 1630, 1631, 1632, 1633, 1634, 1637, 1642, 1644, 1646, 1647, 1649, 1650, 1652, 1654, 1656, 1658, 1661, 1663, 1664, 1666, 1667, 1670, 1671, 1672, 1673, 1674, 1675, 1677, 1679, 1682, 1684, 1685, 1690, 1691, 1693, 1694, 1695, 1697, 1698, 1701, 1703, 1704, 1706, 1708, 1709, 1710, 1712, 1713, 1715, 1719, 1722, 1723, 1726, 1730, 1732, 1733, 1735, 1736, 1737, 1739, 1742, 1744, 1745, 1746, 1747, 1750, 1751, 1753, 1756, 1759, 1761, 1765, 1767, 1768, 1769, 1770, 1771, 1773, 1774, 1777, 1781, 1782, 1784, 1785, 1787, 1791, 1792, 1795, 1796, 1797, 1800, 1801, 1803, 1804, 1807, 1808, 1813, 1815, 1816, 1817, 1819, 1820, 1822, 1823, 1824, 1826, 1828, 1830, 1832, 1833, 1834, 1837, 1839, 1840, 1841, 1842, 1844, 1847, 1849, 1851, 1852, 1854, 1859, 1860, 1862, 1866, 1867, 1869, 1870, 1872, 1875, 1878, 1881, 1882, 1883, 1885, 1888, 1890, 1894, 1896, 1897, 1898, 1899, 1900, 1902, 1903, 1904, 1907, 1909, 1910, 1912, 1915, 1919, 1921, 1922, 1923, 1924, 1925, 1927, 1928, 1930, 1931, 1933, 1935, 1940, 1941, 1943, 1945, 1946, 1947, 1948, 1952, 1953, 1954, 1955, 1962, 1964, 1967, 1970, 1971, 1973, 1974, 1975, 1976, 1977, 1981, 1983, 1985, 1986, 1987, 1989, 1991, 1992, 1993, 1995, 1997, 2000], deadline = 2)
        configuration.add_task(name="Task6", identifier=6, period=1.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.17202, et_stddev=0.05734 , list_activation_dates=[1, 2, 3, 6, 8, 10, 12, 14, 16, 19, 21, 23, 25, 27, 30, 32, 33, 35, 36, 38, 40, 41, 42, 44, 46, 47, 49, 51, 53, 58, 61, 66, 67, 72, 74, 76, 77, 79, 80, 81, 83, 84, 85, 86, 92, 94, 96, 98, 100, 102, 105, 106, 108, 110, 111, 113, 114, 116, 117, 118, 124, 126, 128, 131, 133, 135, 136, 137, 140, 144, 147, 149, 150, 152, 157, 159, 162, 163, 166, 168, 171, 172, 174, 176, 178, 179, 180, 183, 184, 186, 190, 191, 193, 195, 197, 198, 200, 202, 204, 206, 209, 214, 215, 217, 218, 219, 223, 226, 227, 228, 229, 232, 234, 235, 237, 239, 241, 243, 244, 245, 246, 250, 251, 254, 255, 256, 260, 262, 264, 266, 269, 271, 273, 276, 278, 280, 281, 284, 285, 288, 290, 292, 293, 295, 296, 297, 298, 301, 302, 303, 305, 306, 308, 309, 311, 313, 314, 315, 318, 321, 322, 323, 324, 325, 326, 328, 329, 331, 333, 337, 340, 341, 343, 345, 347, 350, 353, 355, 358, 359, 360, 366, 368, 369, 374, 376, 377, 379, 380, 381, 382, 385, 387, 388, 389, 390, 391, 397, 398, 399, 400, 401, 403, 406, 408, 413, 415, 417, 419, 423, 424, 429, 431, 432, 434, 437, 441, 443, 445, 446, 449, 451, 453, 456, 458, 460, 461, 464, 469, 471, 472, 473, 475, 477, 478, 480, 481, 482, 483, 485, 486, 487, 489, 492, 494, 495, 496, 499, 502, 504, 506, 508, 510, 512, 514, 516, 519, 521, 525, 527, 530, 532, 533, 534, 540, 541, 542, 543, 548, 551, 552, 555, 558, 560, 561, 563, 565, 568, 570, 571, 572, 574, 575, 578, 580, 582, 587, 594, 595, 596, 597, 599, 602, 604, 606, 607, 609, 612, 613, 614, 617, 618, 621, 623, 624, 626, 628, 629, 631, 632, 635, 638, 639, 642, 643, 644, 645, 647, 648, 650, 652, 653, 655, 658, 660, 661, 662, 663, 664, 666, 667, 668, 670, 672, 674, 675, 677, 679, 681, 683, 684, 687, 689, 690, 694, 695, 696, 698, 699, 702, 703, 705, 707, 710, 712, 714, 717, 718, 720, 725, 727, 730, 733, 734, 736, 738, 739, 744, 746, 747, 748, 749, 752, 754, 755, 757, 758, 760, 762, 763, 766, 768, 769, 771, 772, 774, 776, 778, 781, 785, 787, 793, 794, 797, 799, 801, 802, 803, 804, 805, 810, 811, 813, 815, 817, 820, 821, 823, 825, 826, 827, 831, 832, 835, 837, 838, 840, 842, 844, 846, 850, 851, 853, 855, 857, 861, 863, 864, 870, 872, 874, 875, 876, 878, 879, 880, 883, 885, 886, 887, 889, 890, 891, 893, 894, 896, 898, 899, 900, 903, 906, 910, 914, 915, 916, 917, 918, 919, 921, 923, 924, 927, 929, 930, 931, 933, 935, 937, 939, 942, 944, 945, 946, 947, 948, 949, 951, 953, 955, 957, 958, 959, 961, 966, 967, 968, 970, 972, 975, 976, 978, 980, 982, 983, 986, 987, 991, 992, 994, 996, 998, 999, 1001, 1005, 1006, 1008, 1011, 1014, 1019, 1020, 1022, 1023, 1025, 1029, 1032, 1033, 1035, 1037, 1038, 1039, 1041, 1046, 1047, 1049, 1050, 1053, 1054, 1055, 1058, 1063, 1064, 1066, 1067, 1068, 1072, 1073, 1074, 1076, 1078, 1079, 1080, 1081, 1084, 1085, 1087, 1089, 1091, 1093, 1094, 1095, 1097, 1098, 1100, 1101, 1104, 1107, 1108, 1110, 1112, 1114, 1115, 1116, 1118, 1120, 1121, 1122, 1125, 1126, 1128, 1131, 1136, 1137, 1139, 1141, 1143, 1144, 1147, 1148, 1151, 1153, 1155, 1157, 1160, 1161, 1163, 1166, 1167, 1169, 1170, 1172, 1174, 1175, 1182, 1183, 1186, 1188, 1189, 1190, 1191, 1198, 1199, 1202, 1206, 1208, 1209, 1212, 1216, 1220, 1223, 1224, 1225, 1227, 1229, 1230, 1232, 1234, 1237, 1238, 1240, 1243, 1245, 1247, 1248, 1249, 1251, 1252, 1253, 1254, 1255, 1256, 1257, 1259, 1260, 1265, 1268, 1271, 1273, 1274, 1277, 1278, 1279, 1280, 1282, 1286, 1288, 1291, 1293, 1296, 1298, 1300, 1302, 1305, 1308, 1309, 1311, 1313, 1315, 1317, 1319, 1320, 1322, 1324, 1325, 1326, 1332, 1333, 1335, 1338, 1339, 1341, 1342, 1343, 1346, 1348, 1351, 1353, 1355, 1357, 1359, 1361, 1364, 1366, 1373, 1374, 1376, 1378, 1382, 1384, 1385, 1386, 1388, 1390, 1393, 1394, 1396, 1398, 1401, 1402, 1404, 1407, 1409, 1410, 1413, 1415, 1416, 1418, 1420, 1422, 1424, 1426, 1427, 1428, 1430, 1432, 1434, 1437, 1440, 1442, 1443, 1445, 1447, 1449, 1451, 1452, 1453, 1455, 1457, 1458, 1459, 1461, 1463, 1465, 1467, 1469, 1470, 1472, 1474, 1476, 1479, 1480, 1481, 1482, 1483, 1485, 1487, 1488, 1490, 1491, 1492, 1493, 1495, 1497, 1498, 1500, 1501, 1503, 1508, 1510, 1511, 1512, 1515, 1517, 1520, 1523, 1527, 1529, 1530, 1531, 1532, 1534, 1536, 1541, 1542, 1546, 1550, 1552, 1554, 1555, 1557, 1559, 1562, 1563, 1565, 1566, 1571, 1573, 1574, 1577, 1579, 1580, 1581, 1584, 1587, 1588, 1591, 1597, 1598, 1599, 1601, 1603, 1607, 1608, 1611, 1612, 1613, 1616, 1618, 1622, 1624, 1626, 1627, 1629, 1631, 1633, 1635, 1636, 1638, 1639, 1640, 1642, 1643, 1645, 1647, 1649, 1650, 1651, 1653, 1655, 1657, 1658, 1659, 1660, 1663, 1666, 1668, 1670, 1671, 1674, 1676, 1677, 1680, 1682, 1686, 1687, 1689, 1690, 1691, 1693, 1696, 1697, 1699, 1701, 1703, 1705, 1707, 1709, 1710, 1712, 1713, 1714, 1715, 1718, 1722, 1725, 1728, 1730, 1731, 1733, 1734, 1738, 1740, 1742, 1746, 1748, 1751, 1753, 1755, 1756, 1759, 1761, 1764, 1765, 1767, 1769, 1770, 1771, 1773, 1775, 1776, 1780, 1781, 1783, 1784, 1785, 1786, 1787, 1789, 1790, 1792, 1796, 1798, 1799, 1803, 1805, 1806, 1807, 1808, 1810, 1811, 1812, 1814, 1820, 1822, 1824, 1825, 1827, 1828, 1830, 1831, 1832, 1834, 1839, 1841, 1843, 1844, 1845, 1847, 1849, 1851, 1854, 1855, 1856, 1858, 1860, 1861, 1862, 1863, 1864, 1865, 1867, 1869, 1874, 1876, 1877, 1878, 1879, 1880, 1881, 1883, 1885, 1890, 1893, 1895, 1896, 1897, 1900, 1902, 1903, 1905, 1906, 1907, 1909, 1911, 1915, 1916, 1917, 1918, 1919, 1920, 1922, 1925, 1927, 1928, 1930, 1931, 1932, 1933, 1934, 1937, 1939, 1940, 1941, 1942, 1945, 1947, 1949, 1951, 1953, 1956, 1959, 1961, 1962, 1963, 1964, 1967, 1970, 1974, 1976, 1978, 1980, 1981, 1983, 1985, 1987, 1988, 1990, 1993, 1994, 1995, 1996, 1998, 2000], deadline = 1)
        configuration.add_task(name="Task3", identifier=3, period=6.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=0.172947, acet=0.172947, et_stddev=0.057649, deadline= 8)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "7")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "7")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "7")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "7")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task5", identifier=5, period=10.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.886276, et_stddev=0.2954253333333333 , list_activation_dates=[11, 21, 38, 54, 96, 108, 139, 150, 164, 182, 196, 213, 226, 237, 250, 276, 292, 321, 358, 369, 382, 393, 407, 431, 450, 490, 501, 512, 525, 562, 585, 607, 618, 637, 653, 666, 689, 708, 722, 736, 755, 767, 788, 812, 826, 859, 872, 906, 919, 941, 957, 976, 997, 1014, 1024, 1040, 1058, 1086, 1110, 1129, 1142, 1156, 1190, 1205, 1220, 1233, 1248, 1265, 1285, 1295, 1314, 1331, 1345, 1362, 1378, 1394, 1429, 1454, 1476, 1516, 1531, 1582, 1603, 1619, 1634, 1650, 1661, 1677, 1693, 1707, 1717, 1729, 1748, 1786, 1806, 1825, 1839, 1869, 1906, 1918, 1931, 1952, 1979, 1998], deadline = 4)
        configuration.add_task(name="Task4", identifier=4, period=1.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.126941, et_stddev=0.042313666666666666 , list_activation_dates=[2, 5, 8, 10, 16, 17, 18, 19, 20, 22, 26, 28, 30, 31, 32, 35, 38, 42, 43, 45, 52, 53, 54, 55, 56, 57, 60, 62, 64, 65, 66, 69, 70, 71, 73, 74, 76, 80, 81, 82, 83, 84, 86, 88, 90, 94, 95, 100, 103, 104, 107, 111, 116, 117, 119, 120, 121, 122, 125, 128, 129, 131, 132, 134, 135, 140, 141, 143, 144, 146, 148, 150, 152, 153, 154, 156, 158, 160, 161, 164, 166, 167, 168, 170, 172, 173, 174, 177, 178, 180, 183, 184, 187, 189, 192, 194, 197, 198, 200, 201, 203, 205, 206, 208, 209, 211, 214, 216, 218, 220, 221, 223, 224, 226, 228, 232, 235, 237, 238, 239, 241, 245, 247, 249, 251, 253, 256, 260, 262, 263, 265, 267, 269, 270, 273, 275, 279, 280, 281, 282, 283, 286, 287, 292, 293, 294, 295, 297, 298, 299, 301, 304, 306, 310, 312, 313, 314, 315, 318, 319, 320, 321, 322, 327, 329, 331, 332, 333, 334, 336, 337, 338, 339, 341, 343, 345, 346, 349, 354, 356, 357, 358, 362, 365, 370, 371, 372, 375, 376, 379, 380, 381, 384, 385, 387, 388, 389, 392, 393, 395, 397, 398, 401, 403, 404, 406, 409, 411, 413, 415, 416, 418, 420, 422, 427, 429, 431, 434, 435, 437, 439, 440, 441, 444, 447, 449, 453, 455, 456, 457, 459, 460, 462, 463, 465, 467, 468, 470, 472, 474, 478, 481, 484, 485, 490, 492, 494, 497, 498, 500, 503, 504, 505, 506, 507, 508, 510, 512, 513, 514, 517, 519, 521, 523, 524, 528, 530, 531, 532, 533, 534, 537, 538, 540, 541, 543, 544, 546, 550, 551, 556, 559, 562, 563, 565, 568, 571, 572, 574, 577, 578, 580, 582, 585, 586, 589, 590, 592, 593, 594, 597, 598, 602, 604, 606, 607, 610, 612, 614, 616, 619, 621, 623, 625, 626, 629, 631, 633, 634, 635, 636, 638, 640, 641, 642, 644, 648, 650, 654, 656, 658, 659, 661, 663, 664, 667, 670, 672, 674, 677, 682, 685, 687, 691, 692, 693, 694, 696, 701, 703, 705, 706, 707, 709, 710, 711, 717, 722, 723, 727, 730, 732, 734, 736, 738, 739, 742, 745, 748, 749, 751, 752, 756, 758, 760, 762, 763, 764, 765, 768, 770, 772, 774, 775, 777, 779, 781, 782, 785, 786, 788, 790, 791, 792, 793, 796, 800, 802, 804, 805, 806, 810, 811, 812, 813, 814, 817, 820, 821, 823, 825, 826, 830, 831, 833, 834, 836, 837, 839, 840, 844, 846, 847, 853, 854, 856, 858, 859, 860, 861, 863, 864, 865, 867, 869, 870, 871, 873, 875, 877, 879, 881, 883, 884, 885, 890, 891, 893, 894, 895, 898, 900, 901, 903, 905, 909, 910, 912, 913, 916, 918, 919, 921, 924, 925, 927, 928, 929, 930, 933, 934, 936, 938, 939, 940, 941, 942, 943, 946, 947, 949, 950, 953, 955, 956, 958, 959, 961, 966, 968, 969, 974, 975, 977, 978, 980, 982, 987, 989, 991, 992, 994, 996, 998, 1000, 1004, 1005, 1006, 1007, 1009, 1012, 1013, 1015, 1019, 1022, 1023, 1025, 1027, 1028, 1030, 1033, 1035, 1036, 1038, 1039, 1041, 1044, 1045, 1047, 1048, 1049, 1053, 1057, 1059, 1061, 1063, 1064, 1066, 1068, 1070, 1071, 1072, 1073, 1074, 1076, 1079, 1081, 1088, 1091, 1095, 1097, 1098, 1100, 1102, 1104, 1106, 1108, 1109, 1112, 1113, 1115, 1117, 1119, 1121, 1122, 1124, 1126, 1127, 1129, 1133, 1134, 1136, 1137, 1139, 1140, 1142, 1143, 1144, 1146, 1148, 1150, 1153, 1155, 1156, 1157, 1158, 1161, 1163, 1165, 1167, 1168, 1170, 1174, 1175, 1176, 1178, 1179, 1180, 1181, 1182, 1183, 1184, 1185, 1189, 1190, 1193, 1195, 1198, 1199, 1201, 1206, 1207, 1208, 1210, 1212, 1215, 1216, 1218, 1219, 1221, 1222, 1225, 1227, 1230, 1231, 1233, 1236, 1238, 1239, 1241, 1243, 1245, 1246, 1248, 1249, 1250, 1251, 1253, 1255, 1256, 1258, 1260, 1261, 1263, 1264, 1265, 1266, 1268, 1269, 1270, 1271, 1273, 1274, 1285, 1287, 1290, 1293, 1296, 1300, 1303, 1305, 1308, 1310, 1311, 1314, 1315, 1316, 1317, 1320, 1322, 1323, 1325, 1326, 1328, 1329, 1331, 1333, 1338, 1339, 1342, 1344, 1346, 1347, 1348, 1350, 1352, 1354, 1355, 1356, 1357, 1358, 1360, 1363, 1367, 1370, 1371, 1372, 1375, 1377, 1380, 1384, 1386, 1389, 1391, 1393, 1395, 1396, 1398, 1400, 1402, 1403, 1404, 1405, 1408, 1412, 1416, 1417, 1419, 1424, 1425, 1426, 1429, 1430, 1432, 1435, 1436, 1437, 1439, 1441, 1443, 1445, 1447, 1449, 1450, 1452, 1454, 1457, 1458, 1461, 1463, 1465, 1466, 1467, 1470, 1473, 1474, 1476, 1478, 1480, 1483, 1484, 1485, 1486, 1487, 1489, 1491, 1493, 1496, 1499, 1502, 1504, 1506, 1508, 1509, 1511, 1512, 1513, 1514, 1515, 1516, 1517, 1519, 1521, 1522, 1524, 1526, 1528, 1529, 1531, 1535, 1537, 1538, 1539, 1541, 1542, 1544, 1545, 1546, 1547, 1548, 1550, 1553, 1554, 1556, 1557, 1560, 1562, 1565, 1566, 1568, 1570, 1573, 1577, 1579, 1581, 1585, 1586, 1588, 1589, 1590, 1593, 1595, 1596, 1597, 1598, 1600, 1601, 1602, 1603, 1605, 1607, 1610, 1611, 1612, 1613, 1615, 1617, 1619, 1622, 1624, 1626, 1627, 1629, 1632, 1636, 1637, 1638, 1640, 1641, 1643, 1645, 1650, 1651, 1653, 1655, 1657, 1658, 1659, 1663, 1665, 1667, 1669, 1671, 1674, 1676, 1677, 1679, 1681, 1685, 1689, 1691, 1692, 1694, 1696, 1698, 1699, 1701, 1703, 1706, 1708, 1712, 1715, 1718, 1720, 1722, 1725, 1727, 1728, 1731, 1733, 1735, 1738, 1739, 1741, 1742, 1744, 1747, 1749, 1750, 1752, 1754, 1755, 1756, 1758, 1760, 1761, 1762, 1763, 1765, 1766, 1769, 1770, 1773, 1775, 1777, 1779, 1781, 1784, 1785, 1787, 1788, 1790, 1792, 1794, 1796, 1798, 1799, 1804, 1805, 1809, 1810, 1812, 1815, 1817, 1818, 1820, 1822, 1824, 1826, 1828, 1830, 1834, 1835, 1838, 1840, 1841, 1842, 1843, 1844, 1848, 1849, 1852, 1853, 1855, 1857, 1859, 1861, 1863, 1865, 1866, 1867, 1869, 1871, 1872, 1873, 1875, 1876, 1879, 1881, 1882, 1886, 1890, 1891, 1893, 1894, 1895, 1897, 1898, 1901, 1903, 1905, 1906, 1912, 1915, 1917, 1918, 1919, 1921, 1924, 1926, 1927, 1929, 1930, 1932, 1933, 1934, 1937, 1939, 1942, 1943, 1945, 1948, 1949, 1952, 1953, 1958, 1959, 1960, 1962, 1963, 1964, 1967, 1969, 1972, 1974, 1977, 1978, 1979, 1981, 1982, 1984, 1988, 1990, 1993, 1995, 1996, 1997, 1999, 2000], deadline = 2)
        configuration.add_task(name="Task2", identifier=2, period=3.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=2.540922, acet=2.540922, et_stddev=0.846974, deadline= 5)
        configuration.add_task(name="Task3", identifier=3, period=3.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=1.274507, acet=1.274507, et_stddev=0.42483566666666667, deadline= 3)
        configuration.add_task(name="Task1", identifier=1, period=1.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=0.32819, acet=0.32819, et_stddev=0.10939666666666666, deadline= 2)
        configuration.add_task(name="Task6", identifier=6, period=8.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.67545, et_stddev=0.22515 , list_activation_dates=[6, 22, 44, 62, 75, 96, 112, 157, 186, 197, 215, 225, 239, 257, 276, 296, 312, 333, 343, 353, 375, 408, 424, 433, 443, 456, 479, 490, 502, 515, 529, 540, 551, 565, 590, 600, 619, 629, 641, 650, 667, 677, 694, 717, 736, 757, 776, 797, 806, 826, 841, 865, 877, 904, 918, 930, 941, 954, 973, 989, 1005, 1020, 1030, 1040, 1056, 1103, 1115, 1139, 1148, 1158, 1167, 1175, 1212, 1220, 1240, 1258, 1284, 1297, 1306, 1316, 1326, 1339, 1368, 1379, 1401, 1430, 1450, 1467, 1475, 1493, 1506, 1521, 1531, 1554, 1563, 1575, 1628, 1638, 1654, 1667, 1685, 1694, 1707, 1716, 1730, 1740, 1750, 1763, 1774, 1806, 1840, 1855, 1864, 1885, 1894, 1914, 1928, 1947, 1959, 1978, 1987, 1998], deadline = 4)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "8")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "8")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "8")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "8")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task1", identifier=1, period=37.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=34.851225, acet=34.851225, et_stddev=11.617075, deadline= 65)
        configuration.add_task(name="Task5", identifier=5, period=8.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.910434, et_stddev=0.30347799999999997 , list_activation_dates=[16, 37, 56, 69, 83, 103, 113, 124, 143, 174, 191, 250, 259, 273, 285, 294, 303, 314, 328, 341, 357, 367, 383, 392, 400, 415, 426, 438, 450, 462, 478, 490, 506, 516, 525, 544, 552, 563, 594, 608, 619, 627, 645, 655, 668, 690, 703, 720, 752, 773, 789, 813, 842, 874, 885, 900, 921, 931, 941, 989, 997, 1015, 1035, 1053, 1072, 1086, 1099, 1108, 1125, 1135, 1164, 1192, 1205, 1215, 1227, 1239, 1261, 1272, 1281, 1291, 1303, 1319, 1330, 1340, 1349, 1361, 1370, 1383, 1412, 1436, 1451, 1465, 1479, 1493, 1514, 1544, 1563, 1571, 1594, 1604, 1614, 1624, 1652, 1672, 1681, 1709, 1719, 1727, 1736, 1753, 1771, 1782, 1817, 1826, 1837, 1856, 1865, 1877, 1887, 1912, 1920, 1942, 1952, 1961, 1979, 1990], deadline = 16)
        configuration.add_task(name="Task3", identifier=3, period=3.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=0.813419, acet=0.813419, et_stddev=0.27113966666666667, deadline= 5)
        configuration.add_task(name="Task4", identifier=4, period=3.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.167769, et_stddev=0.055923 , list_activation_dates=[3, 11, 15, 22, 26, 31, 34, 45, 48, 51, 57, 66, 75, 78, 83, 92, 99, 104, 107, 113, 116, 124, 127, 133, 137, 141, 152, 159, 163, 172, 184, 198, 206, 211, 214, 225, 231, 234, 243, 250, 254, 258, 263, 268, 272, 276, 280, 285, 290, 301, 311, 319, 322, 329, 332, 337, 342, 346, 351, 357, 360, 370, 373, 377, 382, 388, 391, 403, 407, 411, 415, 418, 427, 431, 435, 443, 449, 454, 459, 465, 472, 476, 484, 497, 506, 510, 520, 523, 527, 533, 549, 552, 556, 569, 577, 586, 593, 596, 599, 604, 611, 614, 617, 631, 640, 645, 648, 664, 668, 683, 690, 702, 707, 710, 714, 719, 725, 731, 735, 741, 745, 753, 757, 762, 766, 771, 775, 779, 783, 787, 796, 801, 805, 809, 813, 817, 822, 826, 830, 840, 850, 854, 859, 865, 869, 872, 878, 896, 904, 908, 913, 918, 925, 929, 937, 943, 950, 956, 962, 965, 971, 974, 980, 983, 991, 1007, 1011, 1015, 1022, 1028, 1033, 1038, 1043, 1046, 1050, 1055, 1059, 1062, 1066, 1075, 1080, 1088, 1094, 1097, 1102, 1108, 1115, 1120, 1124, 1129, 1134, 1139, 1145, 1152, 1163, 1167, 1171, 1176, 1180, 1190, 1199, 1210, 1214, 1217, 1222, 1225, 1229, 1232, 1238, 1244, 1247, 1252, 1256, 1264, 1269, 1275, 1279, 1284, 1304, 1309, 1313, 1319, 1323, 1339, 1345, 1363, 1373, 1381, 1385, 1389, 1394, 1398, 1403, 1409, 1417, 1426, 1432, 1439, 1443, 1450, 1461, 1464, 1472, 1478, 1481, 1484, 1494, 1502, 1505, 1512, 1520, 1531, 1544, 1555, 1559, 1563, 1567, 1570, 1576, 1581, 1588, 1599, 1602, 1606, 1610, 1614, 1618, 1621, 1632, 1640, 1643, 1647, 1657, 1671, 1674, 1679, 1686, 1690, 1694, 1710, 1715, 1722, 1725, 1735, 1739, 1743, 1747, 1754, 1759, 1768, 1773, 1777, 1781, 1787, 1792, 1796, 1802, 1810, 1821, 1826, 1833, 1845, 1856, 1864, 1867, 1871, 1878, 1883, 1886, 1890, 1893, 1900, 1904, 1908, 1911, 1915, 1923, 1928, 1939, 1942, 1948, 1958, 1962, 1965, 1971, 1975, 1979, 1982, 1987, 1991, 1995, 1998], deadline = 5)
        configuration.add_task(name="Task2", identifier=2, period=14.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=5.41709, acet=5.41709, et_stddev=1.8056966666666667, deadline= 14)
        configuration.add_task(name="Task6", identifier=6, period=25.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=4, acet=3.256815, et_stddev=1.085605 , list_activation_dates=[2, 35, 88, 132, 161, 223, 360, 385, 412, 438, 466, 502, 550, 628, 683, 717, 759, 794, 838, 863, 948, 982, 1012, 1068, 1108, 1151, 1178, 1231, 1281, 1310, 1341, 1392, 1446, 1519, 1548, 1605, 1646, 1676, 1740, 1789, 1826, 1926, 1961], deadline = 10)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "9")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "9")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "9")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "9")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task6", identifier=6, period=4.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.165445, et_stddev=0.055148333333333334 , list_activation_dates=[28, 34, 43, 57, 71, 77, 81, 85, 99, 110, 117, 122, 130, 144, 148, 157, 165, 175, 182, 191, 198, 202, 211, 219, 225, 234, 242, 252, 271, 277, 282, 296, 300, 306, 319, 349, 354, 362, 376, 381, 389, 393, 398, 405, 426, 432, 440, 451, 458, 481, 494, 502, 508, 513, 519, 524, 532, 538, 542, 548, 553, 561, 570, 574, 584, 588, 599, 605, 611, 617, 621, 629, 633, 643, 649, 654, 662, 667, 676, 681, 685, 694, 700, 710, 714, 720, 724, 729, 736, 743, 755, 759, 764, 772, 781, 788, 794, 799, 810, 818, 836, 859, 863, 867, 871, 879, 886, 899, 903, 907, 921, 928, 937, 949, 955, 966, 973, 978, 986, 993, 1003, 1010, 1026, 1040, 1047, 1056, 1065, 1071, 1075, 1079, 1084, 1090, 1094, 1109, 1131, 1137, 1148, 1157, 1162, 1168, 1175, 1186, 1194, 1199, 1208, 1213, 1218, 1223, 1229, 1241, 1254, 1258, 1265, 1277, 1290, 1297, 1309, 1314, 1320, 1328, 1351, 1358, 1370, 1377, 1385, 1389, 1393, 1404, 1417, 1433, 1441, 1448, 1452, 1459, 1464, 1473, 1491, 1503, 1514, 1522, 1526, 1534, 1542, 1547, 1553, 1567, 1571, 1578, 1595, 1610, 1616, 1623, 1629, 1634, 1640, 1647, 1651, 1658, 1662, 1668, 1674, 1681, 1690, 1696, 1700, 1705, 1711, 1719, 1726, 1744, 1749, 1759, 1767, 1780, 1786, 1800, 1804, 1812, 1820, 1826, 1837, 1841, 1851, 1856, 1861, 1866, 1876, 1895, 1903, 1907, 1911, 1923, 1927, 1939, 1943, 1952, 1959, 1963, 1970, 1990, 1995, 1999], deadline = 8)
        configuration.add_task(name="Task4", identifier=4, period=1.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.238777, et_stddev=0.07959233333333333 , list_activation_dates=[3, 5, 6, 9, 12, 14, 18, 20, 23, 24, 25, 27, 28, 30, 31, 33, 35, 37, 38, 39, 40, 41, 43, 44, 46, 47, 49, 53, 55, 56, 58, 59, 60, 61, 62, 63, 64, 66, 70, 72, 74, 75, 76, 77, 80, 82, 84, 85, 86, 88, 89, 90, 92, 94, 95, 98, 99, 102, 103, 106, 107, 109, 110, 111, 113, 114, 115, 118, 120, 121, 122, 126, 127, 129, 131, 133, 134, 136, 137, 139, 140, 143, 145, 147, 148, 151, 152, 156, 158, 162, 165, 166, 168, 170, 173, 175, 177, 178, 180, 181, 182, 184, 186, 188, 189, 192, 193, 195, 198, 201, 202, 204, 207, 208, 210, 214, 216, 218, 220, 222, 223, 224, 225, 228, 229, 231, 233, 235, 238, 240, 244, 245, 246, 248, 250, 251, 252, 253, 254, 255, 258, 259, 260, 263, 269, 270, 272, 274, 278, 280, 283, 284, 285, 287, 290, 291, 293, 294, 297, 302, 304, 306, 308, 309, 310, 312, 313, 315, 317, 320, 321, 324, 327, 330, 331, 335, 339, 343, 344, 346, 348, 353, 355, 356, 357, 358, 363, 366, 369, 370, 371, 375, 376, 377, 378, 379, 380, 381, 382, 383, 384, 386, 395, 396, 399, 401, 402, 403, 404, 406, 413, 418, 422, 424, 425, 426, 427, 429, 431, 436, 439, 442, 445, 447, 451, 452, 454, 456, 457, 464, 465, 466, 467, 468, 469, 472, 473, 474, 476, 478, 481, 482, 486, 488, 490, 491, 493, 496, 497, 500, 502, 503, 504, 508, 509, 510, 512, 513, 515, 518, 522, 525, 531, 532, 533, 536, 537, 540, 541, 544, 547, 555, 558, 559, 560, 561, 563, 565, 569, 571, 572, 574, 577, 578, 581, 582, 584, 585, 587, 588, 590, 591, 593, 594, 596, 598, 599, 600, 602, 605, 607, 609, 610, 612, 614, 615, 616, 618, 620, 621, 624, 627, 629, 631, 633, 635, 638, 639, 641, 643, 645, 647, 649, 651, 653, 654, 655, 657, 658, 659, 661, 664, 665, 666, 667, 669, 671, 673, 674, 676, 678, 679, 683, 684, 686, 688, 690, 691, 692, 694, 696, 698, 699, 701, 702, 704, 707, 708, 710, 711, 714, 716, 718, 720, 723, 724, 725, 728, 729, 730, 732, 734, 737, 741, 742, 745, 747, 748, 749, 751, 753, 754, 757, 759, 761, 765, 767, 772, 775, 778, 782, 783, 785, 787, 789, 790, 792, 794, 797, 798, 799, 802, 803, 805, 807, 809, 811, 813, 815, 817, 819, 820, 822, 823, 824, 825, 827, 829, 830, 831, 834, 838, 839, 841, 842, 843, 845, 847, 848, 849, 851, 854, 856, 857, 859, 863, 864, 865, 868, 870, 871, 872, 875, 878, 880, 881, 882, 883, 885, 887, 891, 893, 895, 898, 899, 902, 904, 907, 908, 910, 911, 912, 916, 917, 920, 921, 924, 926, 927, 929, 931, 934, 935, 936, 938, 940, 941, 942, 944, 945, 946, 948, 950, 952, 954, 957, 962, 963, 964, 966, 969, 970, 972, 973, 975, 978, 980, 983, 986, 987, 990, 991, 993, 995, 997, 999, 1000, 1005, 1007, 1008, 1009, 1011, 1013, 1015, 1016, 1018, 1020, 1021, 1023, 1024, 1025, 1026, 1033, 1035, 1036, 1039, 1042, 1044, 1045, 1048, 1050, 1051, 1054, 1057, 1059, 1061, 1064, 1065, 1067, 1068, 1071, 1072, 1073, 1074, 1075, 1079, 1081, 1085, 1086, 1087, 1089, 1091, 1098, 1100, 1103, 1107, 1110, 1112, 1113, 1114, 1115, 1116, 1120, 1122, 1124, 1125, 1128, 1131, 1133, 1135, 1137, 1139, 1140, 1141, 1143, 1146, 1151, 1152, 1153, 1154, 1156, 1158, 1160, 1163, 1164, 1167, 1170, 1172, 1174, 1175, 1178, 1179, 1180, 1183, 1186, 1188, 1190, 1191, 1192, 1193, 1195, 1197, 1201, 1203, 1204, 1206, 1208, 1210, 1212, 1215, 1217, 1218, 1219, 1220, 1222, 1223, 1225, 1226, 1227, 1228, 1229, 1230, 1232, 1234, 1238, 1239, 1240, 1242, 1243, 1245, 1249, 1250, 1251, 1252, 1254, 1256, 1259, 1262, 1263, 1264, 1272, 1273, 1277, 1278, 1280, 1284, 1285, 1287, 1290, 1292, 1294, 1296, 1297, 1298, 1299, 1300, 1301, 1303, 1304, 1307, 1309, 1311, 1312, 1314, 1316, 1318, 1319, 1322, 1324, 1325, 1327, 1328, 1329, 1330, 1332, 1337, 1339, 1342, 1343, 1347, 1350, 1352, 1356, 1358, 1360, 1362, 1364, 1366, 1370, 1373, 1375, 1377, 1379, 1380, 1381, 1383, 1386, 1387, 1388, 1391, 1395, 1397, 1398, 1400, 1404, 1405, 1406, 1409, 1415, 1417, 1420, 1422, 1423, 1425, 1428, 1430, 1431, 1432, 1434, 1435, 1436, 1438, 1439, 1441, 1444, 1447, 1448, 1449, 1450, 1451, 1452, 1454, 1456, 1458, 1459, 1462, 1463, 1465, 1468, 1470, 1472, 1476, 1478, 1481, 1484, 1486, 1487, 1490, 1494, 1495, 1496, 1498, 1499, 1505, 1508, 1509, 1512, 1514, 1517, 1519, 1521, 1524, 1526, 1529, 1531, 1533, 1534, 1536, 1537, 1538, 1539, 1542, 1545, 1547, 1549, 1551, 1553, 1555, 1557, 1560, 1564, 1565, 1566, 1568, 1569, 1570, 1573, 1578, 1579, 1580, 1582, 1585, 1589, 1590, 1591, 1592, 1596, 1598, 1601, 1603, 1605, 1606, 1607, 1608, 1609, 1612, 1613, 1616, 1618, 1619, 1620, 1621, 1623, 1625, 1627, 1629, 1630, 1631, 1632, 1635, 1637, 1638, 1639, 1641, 1643, 1646, 1650, 1652, 1654, 1655, 1657, 1658, 1659, 1661, 1663, 1666, 1668, 1669, 1671, 1672, 1674, 1675, 1676, 1679, 1681, 1683, 1685, 1686, 1688, 1689, 1691, 1692, 1694, 1697, 1699, 1700, 1703, 1705, 1707, 1708, 1709, 1710, 1712, 1713, 1714, 1715, 1719, 1720, 1721, 1725, 1728, 1729, 1730, 1731, 1733, 1735, 1736, 1738, 1740, 1741, 1743, 1747, 1751, 1753, 1754, 1756, 1757, 1760, 1761, 1764, 1766, 1769, 1770, 1771, 1772, 1773, 1774, 1776, 1777, 1778, 1781, 1782, 1787, 1789, 1791, 1793, 1794, 1797, 1798, 1800, 1801, 1802, 1803, 1806, 1807, 1809, 1810, 1812, 1815, 1819, 1821, 1823, 1824, 1829, 1830, 1832, 1833, 1835, 1836, 1838, 1840, 1843, 1846, 1847, 1849, 1851, 1852, 1854, 1857, 1858, 1859, 1861, 1863, 1867, 1868, 1869, 1870, 1872, 1873, 1875, 1879, 1881, 1882, 1884, 1886, 1888, 1892, 1893, 1896, 1897, 1898, 1899, 1900, 1902, 1904, 1906, 1910, 1912, 1913, 1917, 1920, 1922, 1928, 1931, 1932, 1933, 1935, 1936, 1937, 1940, 1941, 1942, 1944, 1945, 1948, 1950, 1953, 1957, 1960, 1962, 1963, 1964, 1966, 1968, 1969, 1970, 1971, 1973, 1975, 1979, 1980, 1981, 1984, 1987, 1989, 1991, 1992, 1994, 1995, 2000], deadline = 2)
        configuration.add_task(name="Task1", identifier=1, period=9.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=2.953015, acet=2.953015, et_stddev=0.9843383333333334, deadline= 15)
        configuration.add_task(name="Task5", identifier=5, period=15.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.297918, et_stddev=0.099306 , list_activation_dates=[25, 58, 74, 95, 125, 145, 196, 220, 266, 289, 304, 340, 388, 405, 433, 486, 508, 527, 544, 590, 632, 651, 682, 709, 735, 751, 787, 807, 845, 884, 904, 927, 953, 970, 987, 1017, 1042, 1071, 1094, 1110, 1137, 1183, 1208, 1226, 1276, 1297, 1324, 1341, 1357, 1390, 1408, 1431, 1463, 1498, 1514, 1532, 1554, 1586, 1658, 1697, 1712, 1741, 1765, 1780, 1816, 1834, 1855, 1880, 1904, 1930, 1946, 1993], deadline = 25)
        configuration.add_task(name="Task3", identifier=3, period=4.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=1.152711, acet=1.152711, et_stddev=0.384237, deadline= 6)
        configuration.add_task(name="Task2", identifier=2, period=13.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=12.788222, acet=12.788222, et_stddev=4.262740666666667, deadline= 22)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "12")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "12")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "12")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "12")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task6", identifier=6, period=25.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=2, acet=1.014589, et_stddev=0.3381963333333333 , list_activation_dates=[3, 69, 113, 152, 192, 331, 410, 436, 471, 538, 580, 675, 756, 802, 829, 878, 925, 953, 994, 1127, 1229, 1255, 1288, 1359, 1425, 1452, 1482, 1510, 1551, 1578, 1620, 1664, 1701, 1754, 1789, 1827, 1860, 1896, 1930, 1974, 2000], deadline = 47)
        configuration.add_task(name="Task4", identifier=4, period=18.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=3, acet=2.762266, et_stddev=0.9207553333333333 , list_activation_dates=[11, 34, 68, 106, 159, 197, 256, 280, 299, 324, 362, 388, 410, 452, 474, 513, 583, 631, 660, 687, 740, 774, 817, 862, 923, 965, 1013, 1054, 1079, 1104, 1142, 1182, 1208, 1240, 1301, 1360, 1379, 1402, 1424, 1488, 1548, 1576, 1621, 1643, 1720, 1776, 1838, 1922, 1978, 1999], deadline = 25)
        configuration.add_task(name="Task2", identifier=2, period=3.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=2.913272, acet=2.913272, et_stddev=0.9710906666666667, deadline= 3)
        configuration.add_task(name="Task5", identifier=5, period=4.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.423828, et_stddev=0.14127599999999998 , list_activation_dates=[3, 14, 20, 24, 35, 47, 51, 58, 66, 71, 77, 82, 91, 101, 115, 123, 128, 136, 142, 155, 159, 166, 173, 180, 185, 190, 209, 214, 221, 230, 235, 246, 252, 265, 271, 289, 308, 313, 318, 325, 332, 338, 349, 357, 362, 367, 375, 385, 391, 396, 403, 410, 417, 424, 429, 434, 438, 443, 449, 454, 460, 468, 474, 478, 483, 489, 494, 499, 509, 517, 525, 532, 536, 546, 551, 555, 564, 568, 576, 581, 588, 597, 601, 606, 611, 627, 631, 640, 650, 655, 665, 682, 686, 693, 698, 708, 714, 720, 730, 737, 744, 755, 764, 776, 781, 791, 802, 811, 823, 827, 839, 846, 857, 868, 873, 882, 891, 899, 903, 912, 920, 929, 937, 945, 951, 957, 968, 974, 978, 987, 992, 997, 1007, 1014, 1020, 1034, 1043, 1056, 1061, 1065, 1071, 1077, 1085, 1091, 1096, 1101, 1115, 1120, 1124, 1130, 1136, 1140, 1147, 1153, 1160, 1175, 1180, 1191, 1196, 1206, 1210, 1223, 1229, 1238, 1244, 1249, 1258, 1263, 1269, 1281, 1288, 1298, 1303, 1317, 1321, 1331, 1337, 1347, 1352, 1362, 1372, 1376, 1394, 1398, 1406, 1411, 1417, 1436, 1443, 1451, 1455, 1459, 1468, 1473, 1478, 1483, 1491, 1496, 1501, 1513, 1522, 1531, 1546, 1559, 1563, 1567, 1589, 1601, 1605, 1609, 1617, 1629, 1660, 1665, 1671, 1678, 1690, 1695, 1702, 1710, 1719, 1730, 1735, 1746, 1750, 1755, 1765, 1771, 1777, 1781, 1785, 1790, 1799, 1808, 1820, 1832, 1840, 1851, 1857, 1862, 1870, 1874, 1880, 1886, 1891, 1910, 1915, 1925, 1939, 1948, 1954, 1961, 1965, 1974, 1978, 1992], deadline = 5)
        configuration.add_task(name="Task3", identifier=3, period=2.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=0.588721, acet=0.588721, et_stddev=0.19624033333333335, deadline= 2)
        configuration.add_task(name="Task1", identifier=1, period=7.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=2.341838, acet=2.341838, et_stddev=0.7806126666666667, deadline= 10)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "14")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "14")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "14")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "14")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task4", identifier=4, period=1.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.074178, et_stddev=0.024725999999999998 , list_activation_dates=[1, 2, 4, 5, 6, 8, 10, 12, 13, 15, 18, 21, 23, 25, 28, 29, 31, 33, 36, 43, 45, 46, 47, 49, 50, 53, 54, 56, 57, 58, 59, 60, 62, 63, 64, 66, 68, 70, 73, 74, 76, 78, 80, 81, 82, 84, 85, 87, 93, 95, 97, 99, 101, 102, 107, 108, 111, 114, 115, 118, 119, 120, 123, 124, 125, 130, 134, 136, 138, 141, 144, 147, 151, 154, 156, 158, 160, 161, 162, 163, 165, 167, 168, 169, 171, 173, 174, 176, 180, 182, 183, 184, 187, 190, 193, 195, 196, 197, 199, 201, 202, 203, 206, 208, 210, 211, 213, 215, 218, 220, 222, 224, 226, 227, 229, 231, 233, 237, 239, 241, 245, 251, 252, 254, 257, 259, 261, 262, 263, 264, 266, 269, 271, 272, 273, 275, 278, 280, 281, 283, 285, 286, 288, 290, 291, 293, 294, 296, 300, 302, 304, 306, 309, 311, 314, 316, 317, 318, 322, 324, 325, 326, 327, 329, 331, 334, 336, 338, 339, 342, 343, 344, 347, 348, 349, 351, 353, 354, 357, 358, 359, 360, 365, 369, 371, 372, 374, 376, 378, 380, 385, 387, 388, 393, 394, 395, 397, 399, 400, 401, 404, 408, 411, 412, 414, 416, 419, 420, 422, 424, 426, 428, 429, 433, 436, 438, 440, 441, 442, 444, 446, 448, 449, 450, 454, 455, 456, 457, 458, 459, 460, 462, 463, 467, 468, 470, 472, 474, 476, 478, 479, 482, 483, 485, 487, 488, 492, 493, 494, 495, 498, 499, 501, 503, 505, 507, 511, 516, 518, 519, 525, 527, 528, 529, 531, 532, 533, 535, 536, 537, 538, 539, 540, 542, 543, 545, 546, 548, 550, 551, 554, 558, 560, 562, 563, 567, 570, 572, 574, 576, 578, 581, 582, 584, 586, 587, 590, 593, 595, 596, 598, 601, 602, 603, 605, 608, 609, 610, 612, 616, 618, 625, 626, 629, 630, 631, 633, 635, 637, 638, 640, 642, 647, 649, 650, 651, 653, 654, 657, 658, 659, 662, 664, 668, 669, 671, 673, 676, 678, 680, 682, 684, 686, 688, 691, 693, 694, 695, 697, 698, 701, 702, 704, 706, 710, 714, 716, 717, 719, 720, 721, 722, 724, 726, 727, 730, 732, 734, 741, 743, 747, 749, 752, 753, 754, 762, 763, 764, 766, 768, 769, 771, 775, 777, 780, 781, 782, 785, 789, 791, 793, 795, 796, 797, 798, 800, 801, 802, 804, 806, 809, 811, 815, 817, 819, 824, 827, 828, 829, 830, 832, 833, 835, 837, 838, 840, 842, 843, 844, 846, 848, 849, 850, 852, 854, 857, 859, 861, 864, 867, 868, 869, 871, 872, 873, 876, 877, 881, 884, 886, 887, 888, 890, 891, 892, 895, 896, 898, 900, 901, 903, 904, 907, 911, 912, 914, 916, 917, 920, 921, 924, 925, 926, 927, 930, 934, 938, 939, 942, 943, 947, 950, 953, 955, 957, 961, 962, 964, 965, 968, 972, 976, 977, 980, 982, 986, 987, 988, 990, 991, 993, 995, 997, 1001, 1004, 1005, 1006, 1008, 1010, 1012, 1013, 1019, 1021, 1023, 1024, 1028, 1031, 1032, 1033, 1035, 1037, 1038, 1040, 1042, 1044, 1045, 1047, 1048, 1049, 1051, 1057, 1059, 1060, 1062, 1064, 1066, 1067, 1068, 1071, 1073, 1075, 1076, 1078, 1082, 1083, 1084, 1086, 1087, 1089, 1091, 1092, 1093, 1095, 1097, 1099, 1100, 1102, 1104, 1105, 1107, 1108, 1109, 1111, 1113, 1115, 1117, 1119, 1120, 1121, 1122, 1123, 1125, 1128, 1130, 1131, 1133, 1136, 1138, 1141, 1142, 1144, 1147, 1148, 1151, 1154, 1156, 1159, 1162, 1163, 1164, 1166, 1168, 1171, 1172, 1173, 1174, 1175, 1177, 1180, 1181, 1183, 1185, 1187, 1189, 1190, 1192, 1194, 1196, 1197, 1198, 1203, 1205, 1207, 1208, 1210, 1212, 1214, 1215, 1216, 1218, 1221, 1223, 1225, 1226, 1228, 1230, 1234, 1235, 1237, 1238, 1239, 1242, 1244, 1245, 1247, 1248, 1250, 1252, 1255, 1259, 1263, 1265, 1267, 1268, 1271, 1272, 1274, 1275, 1278, 1280, 1283, 1284, 1285, 1286, 1290, 1291, 1293, 1294, 1295, 1296, 1298, 1302, 1303, 1305, 1307, 1308, 1309, 1310, 1312, 1313, 1315, 1316, 1318, 1320, 1321, 1323, 1324, 1326, 1328, 1330, 1331, 1334, 1335, 1336, 1337, 1338, 1339, 1341, 1342, 1345, 1346, 1348, 1349, 1356, 1358, 1360, 1361, 1363, 1366, 1367, 1369, 1371, 1373, 1374, 1375, 1377, 1379, 1380, 1382, 1383, 1385, 1386, 1389, 1393, 1394, 1399, 1400, 1401, 1403, 1404, 1406, 1407, 1408, 1409, 1411, 1413, 1415, 1418, 1420, 1422, 1425, 1427, 1431, 1433, 1435, 1437, 1439, 1440, 1441, 1446, 1448, 1453, 1457, 1458, 1459, 1460, 1462, 1466, 1468, 1470, 1472, 1473, 1474, 1475, 1478, 1482, 1484, 1485, 1487, 1491, 1492, 1493, 1496, 1500, 1503, 1507, 1509, 1512, 1514, 1517, 1518, 1519, 1521, 1522, 1524, 1525, 1526, 1527, 1530, 1532, 1533, 1534, 1536, 1538, 1540, 1541, 1544, 1547, 1548, 1551, 1553, 1555, 1556, 1560, 1561, 1563, 1567, 1569, 1571, 1574, 1576, 1579, 1583, 1585, 1587, 1589, 1591, 1593, 1594, 1596, 1599, 1600, 1602, 1604, 1605, 1609, 1611, 1612, 1614, 1617, 1619, 1620, 1622, 1623, 1625, 1628, 1630, 1631, 1634, 1636, 1637, 1638, 1639, 1641, 1643, 1646, 1648, 1650, 1651, 1656, 1659, 1661, 1663, 1666, 1667, 1668, 1670, 1672, 1674, 1678, 1679, 1680, 1685, 1686, 1688, 1690, 1692, 1693, 1695, 1697, 1698, 1701, 1703, 1704, 1706, 1710, 1712, 1713, 1714, 1717, 1720, 1722, 1723, 1725, 1728, 1731, 1733, 1734, 1736, 1738, 1741, 1742, 1743, 1744, 1745, 1751, 1754, 1756, 1758, 1760, 1762, 1764, 1766, 1768, 1771, 1773, 1774, 1776, 1777, 1779, 1781, 1784, 1785, 1786, 1788, 1790, 1792, 1794, 1795, 1797, 1801, 1803, 1805, 1808, 1809, 1810, 1812, 1813, 1815, 1820, 1821, 1822, 1823, 1825, 1827, 1828, 1830, 1831, 1833, 1835, 1839, 1841, 1842, 1843, 1845, 1847, 1849, 1850, 1851, 1852, 1853, 1854, 1857, 1858, 1859, 1860, 1862, 1864, 1866, 1867, 1868, 1869, 1872, 1877, 1878, 1879, 1880, 1882, 1883, 1884, 1886, 1889, 1892, 1893, 1894, 1897, 1900, 1901, 1906, 1908, 1909, 1912, 1914, 1920, 1925, 1928, 1930, 1932, 1934, 1935, 1937, 1939, 1941, 1943, 1945, 1946, 1948, 1949, 1950, 1952, 1953, 1955, 1956, 1957, 1958, 1959, 1960, 1962, 1963, 1965, 1966, 1971, 1973, 1975, 1976, 1978, 1980, 1981, 1984, 1986, 1988, 1989, 1991, 1994, 1995, 1997, 2000], deadline = 1)
        configuration.add_task(name="Task3", identifier=3, period=2.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=0.807104, acet=0.807104, et_stddev=0.2690346666666667, deadline= 3)
        configuration.add_task(name="Task2", identifier=2, period=7.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=3.042567, acet=3.042567, et_stddev=1.014189, deadline= 8)
        configuration.add_task(name="Task5", identifier=5, period=2.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.36723, et_stddev=0.12241 , list_activation_dates=[2, 4, 8, 10, 14, 23, 25, 29, 34, 38, 41, 45, 49, 51, 53, 55, 58, 61, 67, 71, 77, 80, 83, 85, 90, 95, 97, 102, 106, 109, 113, 116, 121, 124, 128, 133, 137, 141, 145, 153, 158, 164, 166, 170, 174, 178, 185, 187, 194, 196, 199, 204, 207, 210, 216, 218, 222, 225, 229, 233, 235, 240, 242, 244, 247, 250, 252, 255, 258, 263, 265, 269, 276, 283, 286, 291, 295, 302, 307, 310, 316, 322, 327, 333, 338, 341, 344, 346, 350, 353, 357, 362, 365, 367, 371, 373, 376, 379, 382, 385, 387, 391, 394, 397, 400, 404, 410, 415, 418, 424, 428, 430, 433, 436, 438, 442, 447, 449, 454, 458, 461, 463, 467, 472, 476, 479, 482, 487, 496, 502, 507, 515, 517, 519, 523, 525, 529, 533, 544, 546, 552, 554, 558, 561, 574, 578, 581, 586, 590, 594, 597, 600, 603, 605, 609, 611, 614, 617, 619, 625, 634, 639, 645, 647, 649, 651, 654, 656, 659, 664, 667, 670, 677, 680, 686, 690, 694, 697, 703, 705, 708, 713, 722, 724, 727, 730, 732, 739, 742, 744, 746, 751, 757, 761, 765, 778, 782, 786, 790, 798, 804, 806, 815, 818, 823, 827, 830, 833, 839, 843, 845, 852, 855, 857, 863, 866, 870, 876, 880, 884, 888, 896, 901, 905, 909, 912, 914, 917, 920, 924, 929, 933, 937, 942, 945, 949, 955, 957, 961, 967, 973, 979, 982, 986, 988, 990, 997, 999, 1002, 1004, 1014, 1016, 1021, 1024, 1026, 1028, 1030, 1032, 1036, 1040, 1043, 1046, 1050, 1052, 1055, 1059, 1068, 1070, 1072, 1076, 1079, 1082, 1084, 1089, 1091, 1094, 1097, 1100, 1104, 1109, 1112, 1115, 1120, 1125, 1130, 1133, 1136, 1138, 1142, 1144, 1147, 1150, 1152, 1156, 1160, 1165, 1168, 1171, 1174, 1179, 1183, 1188, 1192, 1197, 1206, 1208, 1210, 1216, 1220, 1228, 1232, 1234, 1241, 1244, 1255, 1259, 1267, 1270, 1274, 1281, 1286, 1291, 1294, 1296, 1298, 1304, 1306, 1309, 1314, 1318, 1326, 1334, 1338, 1341, 1344, 1349, 1361, 1369, 1372, 1375, 1378, 1380, 1383, 1385, 1388, 1392, 1396, 1398, 1400, 1403, 1409, 1415, 1421, 1425, 1432, 1435, 1437, 1440, 1443, 1447, 1453, 1456, 1458, 1464, 1466, 1470, 1472, 1474, 1484, 1486, 1494, 1497, 1499, 1501, 1503, 1508, 1510, 1518, 1521, 1525, 1528, 1530, 1536, 1538, 1546, 1552, 1554, 1558, 1565, 1568, 1574, 1578, 1580, 1582, 1584, 1586, 1589, 1595, 1598, 1600, 1604, 1607, 1610, 1612, 1618, 1622, 1626, 1628, 1634, 1637, 1640, 1644, 1648, 1651, 1655, 1658, 1660, 1662, 1664, 1667, 1669, 1672, 1675, 1677, 1680, 1684, 1687, 1690, 1693, 1695, 1702, 1705, 1710, 1713, 1715, 1724, 1733, 1739, 1742, 1746, 1751, 1753, 1756, 1763, 1767, 1769, 1772, 1775, 1780, 1789, 1792, 1795, 1799, 1801, 1807, 1811, 1813, 1816, 1819, 1827, 1829, 1831, 1833, 1836, 1840, 1842, 1845, 1848, 1853, 1858, 1861, 1865, 1869, 1873, 1877, 1883, 1885, 1891, 1894, 1900, 1902, 1905, 1915, 1920, 1925, 1927, 1930, 1933, 1937, 1939, 1942, 1945, 1950, 1953, 1960, 1963, 1965, 1970, 1974, 1985, 1987, 1994, 1997], deadline = 2)
        configuration.add_task(name="Task6", identifier=6, period=2.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.084411, et_stddev=0.028137 , list_activation_dates=[4, 7, 10, 14, 16, 23, 26, 38, 41, 45, 53, 59, 61, 64, 68, 70, 73, 77, 81, 84, 87, 98, 103, 108, 111, 115, 124, 126, 132, 136, 139, 142, 145, 148, 152, 156, 162, 164, 166, 169, 175, 182, 184, 186, 189, 195, 202, 209, 213, 215, 224, 231, 238, 242, 246, 250, 253, 256, 258, 263, 265, 268, 270, 273, 278, 282, 285, 287, 290, 293, 297, 300, 307, 312, 315, 318, 321, 324, 329, 334, 337, 340, 343, 346, 348, 351, 356, 360, 370, 372, 376, 380, 383, 386, 388, 390, 397, 400, 403, 407, 411, 414, 417, 421, 423, 425, 428, 439, 442, 445, 448, 452, 455, 461, 466, 479, 483, 487, 492, 496, 500, 503, 509, 512, 518, 522, 525, 530, 533, 536, 539, 542, 546, 548, 552, 557, 559, 563, 566, 568, 572, 577, 582, 585, 588, 590, 592, 595, 600, 606, 614, 618, 620, 622, 630, 638, 642, 645, 649, 652, 657, 661, 663, 665, 667, 674, 676, 680, 688, 692, 699, 701, 703, 708, 711, 713, 715, 717, 721, 728, 730, 733, 738, 741, 744, 752, 755, 758, 760, 762, 769, 773, 779, 782, 784, 789, 791, 795, 797, 799, 804, 807, 810, 814, 823, 828, 831, 836, 842, 847, 850, 853, 857, 866, 870, 872, 874, 876, 880, 886, 889, 893, 895, 900, 903, 914, 917, 921, 923, 929, 931, 934, 937, 939, 941, 943, 947, 952, 956, 959, 961, 964, 969, 973, 977, 980, 987, 990, 992, 995, 999, 1002, 1004, 1012, 1016, 1019, 1027, 1030, 1033, 1037, 1039, 1042, 1045, 1048, 1054, 1058, 1061, 1064, 1069, 1072, 1076, 1078, 1082, 1084, 1091, 1093, 1096, 1099, 1104, 1106, 1110, 1116, 1118, 1121, 1127, 1130, 1132, 1137, 1141, 1144, 1147, 1149, 1151, 1155, 1158, 1163, 1165, 1168, 1171, 1173, 1176, 1179, 1182, 1189, 1197, 1201, 1204, 1206, 1214, 1217, 1219, 1221, 1224, 1228, 1234, 1237, 1239, 1242, 1248, 1252, 1257, 1262, 1265, 1269, 1274, 1276, 1280, 1283, 1286, 1291, 1302, 1307, 1311, 1317, 1320, 1324, 1328, 1333, 1336, 1339, 1341, 1344, 1349, 1352, 1355, 1358, 1367, 1373, 1378, 1380, 1382, 1385, 1388, 1390, 1393, 1395, 1403, 1405, 1411, 1414, 1416, 1420, 1427, 1431, 1434, 1436, 1439, 1441, 1448, 1450, 1454, 1456, 1460, 1464, 1468, 1470, 1474, 1476, 1481, 1484, 1487, 1489, 1494, 1498, 1501, 1504, 1510, 1515, 1521, 1523, 1526, 1535, 1537, 1539, 1542, 1544, 1549, 1551, 1554, 1558, 1562, 1570, 1574, 1579, 1581, 1593, 1597, 1600, 1607, 1609, 1611, 1615, 1619, 1622, 1625, 1630, 1632, 1636, 1642, 1645, 1652, 1655, 1658, 1660, 1662, 1665, 1670, 1674, 1679, 1682, 1684, 1688, 1692, 1696, 1701, 1706, 1708, 1711, 1714, 1720, 1723, 1731, 1738, 1741, 1745, 1748, 1751, 1756, 1761, 1763, 1767, 1770, 1772, 1777, 1780, 1782, 1785, 1788, 1791, 1795, 1798, 1800, 1803, 1808, 1811, 1815, 1818, 1826, 1829, 1832, 1834, 1838, 1842, 1844, 1846, 1850, 1855, 1862, 1865, 1868, 1871, 1877, 1884, 1887, 1890, 1897, 1901, 1908, 1912, 1915, 1920, 1923, 1925, 1927, 1931, 1934, 1936, 1940, 1946, 1948, 1951, 1956, 1960, 1963, 1965, 1967, 1971, 1973, 1976, 1978, 1981, 1984, 1986, 1991, 1995, 1999], deadline = 3)
        configuration.add_task(name="Task1", identifier=1, period=24.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=18.283083, acet=18.283083, et_stddev=6.094361, deadline= 21)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "15")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "15")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "15")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "15")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task4", identifier=4, period=9.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=2, acet=1.343355, et_stddev=0.44778500000000004 , list_activation_dates=[1, 19, 35, 49, 74, 85, 101, 111, 123, 143, 152, 170, 183, 201, 224, 236, 249, 260, 282, 292, 301, 340, 351, 376, 387, 398, 407, 422, 442, 456, 486, 499, 523, 547, 561, 578, 589, 605, 614, 655, 670, 702, 713, 727, 741, 752, 765, 777, 789, 832, 863, 876, 886, 902, 912, 928, 938, 948, 1004, 1021, 1030, 1040, 1056, 1109, 1118, 1138, 1155, 1185, 1195, 1222, 1246, 1270, 1280, 1306, 1319, 1334, 1345, 1363, 1401, 1413, 1428, 1441, 1453, 1464, 1483, 1507, 1516, 1537, 1554, 1588, 1597, 1616, 1627, 1653, 1673, 1700, 1712, 1727, 1739, 1754, 1764, 1775, 1798, 1808, 1820, 1832, 1847, 1862, 1878, 1888, 1912, 1925, 1946, 1956, 1970, 1982, 1995], deadline = 16)
        configuration.add_task(name="Task1", identifier=1, period=25.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=24.971082, acet=24.971082, et_stddev=8.323694, deadline= 33)
        configuration.add_task(name="Task2", identifier=2, period=16.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=0.175521, acet=0.175521, et_stddev=0.058507, deadline= 18)
        configuration.add_task(name="Task3", identifier=3, period=2.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=1.180373, acet=1.180373, et_stddev=0.39345766666666665, deadline= 3)
        configuration.add_task(name="Task6", identifier=6, period=9.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=2, acet=1.180369, et_stddev=0.39345633333333335 , list_activation_dates=[5, 25, 38, 49, 63, 72, 87, 102, 112, 131, 141, 153, 177, 197, 212, 229, 239, 266, 278, 301, 319, 328, 339, 349, 370, 380, 395, 407, 420, 431, 445, 455, 468, 479, 491, 505, 527, 547, 563, 580, 590, 614, 625, 634, 645, 659, 686, 698, 715, 741, 751, 774, 784, 801, 815, 827, 837, 847, 857, 867, 878, 897, 921, 943, 953, 977, 1005, 1036, 1054, 1065, 1095, 1117, 1130, 1146, 1162, 1177, 1229, 1256, 1275, 1293, 1313, 1322, 1335, 1344, 1384, 1394, 1416, 1430, 1442, 1452, 1467, 1480, 1521, 1545, 1581, 1590, 1608, 1623, 1648, 1673, 1684, 1695, 1722, 1741, 1764, 1790, 1819, 1830, 1843, 1852, 1861, 1881, 1912, 1933, 1943, 1973, 2000], deadline = 14)
        configuration.add_task(name="Task5", identifier=5, period=12.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.235033, et_stddev=0.07834433333333334 , list_activation_dates=[27, 48, 72, 121, 150, 268, 302, 335, 378, 395, 444, 488, 503, 527, 548, 564, 580, 598, 617, 631, 668, 697, 789, 802, 849, 877, 890, 926, 954, 971, 988, 1011, 1025, 1054, 1074, 1105, 1173, 1190, 1220, 1275, 1287, 1306, 1320, 1359, 1373, 1387, 1403, 1428, 1441, 1458, 1474, 1543, 1556, 1596, 1611, 1623, 1657, 1682, 1695, 1716, 1843, 1876, 1892, 1905, 1921, 1941, 1961, 1982], deadline = 4)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "16")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "16")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "16")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "16")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task5", identifier=5, period=27.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=2, acet=1.886439, et_stddev=0.628813 , list_activation_dates=[17, 52, 111, 167, 209, 240, 277, 305, 333, 386, 432, 472, 500, 536, 677, 714, 749, 782, 843, 872, 899, 978, 1026, 1100, 1138, 1210, 1282, 1345, 1373, 1400, 1448, 1486, 1530, 1606, 1711, 1757, 1838, 1885, 1921], deadline = 30)
        configuration.add_task(name="Task6", identifier=6, period=2.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.091329, et_stddev=0.030442999999999998 , list_activation_dates=[3, 8, 12, 17, 30, 33, 42, 45, 47, 51, 53, 60, 63, 68, 77, 80, 86, 90, 93, 97, 102, 106, 109, 113, 116, 118, 121, 127, 133, 135, 145, 147, 151, 154, 158, 162, 164, 167, 170, 174, 180, 182, 184, 188, 192, 194, 202, 206, 210, 213, 219, 224, 231, 237, 240, 242, 247, 250, 254, 256, 266, 272, 280, 282, 287, 290, 292, 294, 302, 304, 309, 311, 313, 315, 318, 325, 329, 334, 336, 340, 343, 347, 349, 351, 358, 361, 366, 370, 372, 379, 383, 386, 389, 391, 395, 397, 400, 405, 408, 410, 413, 415, 418, 422, 426, 429, 432, 434, 437, 440, 447, 451, 454, 458, 460, 465, 469, 471, 474, 481, 483, 485, 491, 494, 500, 503, 507, 509, 512, 514, 517, 520, 523, 530, 532, 535, 540, 543, 548, 551, 554, 559, 563, 567, 570, 575, 577, 579, 588, 590, 592, 597, 600, 603, 606, 612, 615, 617, 619, 622, 625, 630, 632, 634, 640, 645, 651, 655, 660, 665, 669, 672, 675, 679, 683, 688, 690, 694, 699, 701, 703, 706, 709, 712, 715, 719, 721, 726, 730, 733, 735, 737, 742, 744, 747, 754, 759, 762, 765, 768, 771, 774, 777, 783, 787, 793, 797, 799, 803, 806, 808, 811, 814, 817, 820, 823, 829, 838, 840, 843, 848, 857, 870, 873, 877, 881, 888, 891, 896, 898, 900, 906, 910, 913, 919, 926, 931, 933, 935, 941, 947, 950, 952, 955, 958, 963, 967, 973, 976, 979, 987, 990, 1000, 1002, 1006, 1010, 1016, 1019, 1023, 1026, 1031, 1035, 1038, 1040, 1044, 1047, 1051, 1054, 1057, 1060, 1065, 1068, 1071, 1074, 1078, 1080, 1085, 1095, 1101, 1103, 1112, 1117, 1122, 1127, 1135, 1137, 1143, 1154, 1161, 1167, 1170, 1172, 1174, 1184, 1188, 1191, 1195, 1199, 1203, 1208, 1211, 1218, 1220, 1223, 1226, 1228, 1235, 1241, 1244, 1248, 1250, 1255, 1263, 1266, 1270, 1272, 1277, 1280, 1288, 1290, 1299, 1305, 1307, 1311, 1320, 1323, 1326, 1328, 1330, 1332, 1334, 1342, 1345, 1350, 1352, 1357, 1360, 1362, 1365, 1372, 1374, 1379, 1383, 1385, 1387, 1389, 1391, 1396, 1400, 1403, 1405, 1408, 1411, 1417, 1420, 1423, 1426, 1429, 1433, 1435, 1443, 1446, 1450, 1452, 1454, 1458, 1460, 1462, 1464, 1467, 1471, 1477, 1480, 1487, 1492, 1498, 1503, 1505, 1507, 1510, 1513, 1519, 1521, 1524, 1526, 1530, 1533, 1535, 1539, 1546, 1551, 1554, 1556, 1559, 1563, 1566, 1576, 1580, 1586, 1590, 1597, 1604, 1609, 1612, 1615, 1619, 1621, 1627, 1629, 1633, 1636, 1642, 1656, 1659, 1662, 1665, 1667, 1670, 1675, 1678, 1683, 1686, 1693, 1695, 1698, 1703, 1706, 1709, 1711, 1714, 1716, 1719, 1733, 1743, 1748, 1753, 1761, 1763, 1766, 1768, 1771, 1774, 1783, 1786, 1789, 1791, 1797, 1800, 1810, 1815, 1820, 1823, 1828, 1835, 1837, 1840, 1848, 1852, 1855, 1863, 1868, 1870, 1874, 1877, 1881, 1892, 1895, 1901, 1903, 1905, 1910, 1919, 1922, 1926, 1928, 1931, 1935, 1940, 1946, 1948, 1952, 1954, 1957, 1960, 1968, 1970, 1974, 1978, 1983, 1986, 1988, 1990, 1992, 1995, 1997], deadline = 3)
        configuration.add_task(name="Task2", identifier=2, period=1.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=0.333644, acet=0.333644, et_stddev=0.11121466666666667, deadline= 1)
        configuration.add_task(name="Task1", identifier=1, period=15.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=4.695236, acet=4.695236, et_stddev=1.5650786666666667, deadline= 10)
        configuration.add_task(name="Task3", identifier=3, period=7.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=6.673375, acet=6.673375, et_stddev=2.224458333333333, deadline= 11)
        configuration.add_task(name="Task4", identifier=4, period=20.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=4, acet=3.689337, et_stddev=1.229779 , list_activation_dates=[10, 41, 103, 194, 220, 243, 318, 343, 372, 409, 432, 483, 520, 564, 598, 646, 671, 715, 762, 786, 824, 847, 871, 898, 941, 976, 1000, 1037, 1062, 1091, 1111, 1153, 1242, 1263, 1353, 1407, 1438, 1474, 1521, 1542, 1578, 1600, 1637, 1723, 1784, 1806, 1839, 1863, 1895, 1933], deadline = 36)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "17")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "17")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "17")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "17")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task5", identifier=5, period=1.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.223809, et_stddev=0.074603 , list_activation_dates=[1, 2, 7, 9, 11, 13, 14, 17, 18, 19, 20, 22, 23, 24, 26, 27, 29, 31, 32, 36, 37, 39, 43, 44, 45, 47, 48, 49, 51, 58, 59, 60, 65, 66, 68, 69, 74, 76, 77, 78, 79, 82, 83, 85, 86, 87, 92, 93, 95, 96, 98, 99, 100, 102, 103, 106, 108, 110, 114, 115, 116, 117, 119, 123, 126, 127, 129, 130, 131, 132, 134, 135, 137, 140, 143, 146, 148, 150, 151, 153, 154, 156, 158, 159, 161, 163, 165, 169, 170, 174, 176, 177, 179, 181, 183, 185, 186, 188, 195, 199, 200, 201, 202, 205, 208, 211, 212, 216, 220, 222, 223, 225, 227, 231, 233, 234, 236, 238, 240, 243, 246, 247, 248, 251, 253, 256, 257, 258, 259, 260, 261, 263, 265, 267, 268, 271, 272, 273, 274, 276, 277, 281, 282, 284, 285, 288, 290, 291, 293, 295, 297, 302, 304, 305, 311, 312, 314, 317, 319, 325, 327, 333, 339, 342, 343, 346, 349, 352, 355, 356, 358, 360, 361, 363, 366, 369, 370, 372, 374, 375, 377, 378, 383, 387, 389, 390, 392, 395, 396, 397, 400, 402, 404, 405, 406, 408, 410, 411, 413, 415, 419, 421, 422, 424, 426, 428, 429, 431, 432, 434, 438, 440, 442, 443, 444, 446, 448, 449, 451, 453, 455, 457, 459, 461, 463, 465, 467, 468, 470, 472, 475, 477, 479, 483, 485, 486, 488, 490, 491, 492, 494, 495, 498, 502, 504, 506, 507, 509, 510, 515, 516, 518, 521, 523, 526, 529, 530, 532, 535, 537, 538, 540, 541, 543, 547, 550, 551, 553, 555, 556, 558, 560, 562, 563, 565, 566, 568, 569, 571, 573, 574, 582, 583, 587, 592, 595, 598, 599, 602, 603, 604, 610, 611, 612, 614, 615, 618, 619, 622, 623, 624, 626, 627, 629, 631, 634, 636, 637, 639, 643, 645, 650, 653, 654, 655, 656, 659, 661, 663, 668, 671, 672, 673, 675, 676, 677, 679, 681, 682, 683, 686, 688, 690, 691, 693, 697, 700, 702, 704, 706, 712, 715, 716, 718, 720, 726, 729, 731, 732, 734, 737, 739, 740, 743, 744, 746, 747, 749, 751, 752, 754, 756, 757, 758, 762, 766, 769, 772, 774, 775, 777, 780, 781, 782, 785, 787, 788, 789, 791, 793, 794, 798, 800, 802, 803, 804, 805, 806, 807, 809, 810, 813, 814, 817, 818, 820, 823, 825, 826, 828, 831, 832, 833, 834, 836, 839, 843, 845, 848, 852, 853, 855, 857, 859, 861, 866, 867, 869, 871, 872, 873, 874, 875, 878, 880, 881, 882, 884, 886, 891, 893, 895, 896, 897, 899, 901, 905, 906, 908, 909, 911, 912, 914, 917, 919, 920, 922, 924, 926, 927, 929, 931, 933, 936, 937, 941, 944, 946, 949, 950, 952, 957, 958, 959, 961, 962, 963, 964, 966, 968, 971, 973, 974, 975, 976, 977, 980, 983, 984, 986, 987, 989, 992, 993, 995, 997, 1000, 1002, 1005, 1006, 1008, 1009, 1010, 1011, 1012, 1013, 1015, 1018, 1021, 1022, 1025, 1028, 1030, 1031, 1032, 1033, 1034, 1036, 1037, 1038, 1040, 1042, 1044, 1046, 1047, 1050, 1052, 1054, 1055, 1057, 1058, 1060, 1061, 1062, 1063, 1064, 1065, 1069, 1071, 1074, 1075, 1076, 1078, 1080, 1082, 1083, 1085, 1087, 1092, 1095, 1097, 1099, 1100, 1104, 1107, 1108, 1110, 1112, 1113, 1114, 1116, 1120, 1121, 1124, 1128, 1129, 1132, 1133, 1135, 1137, 1139, 1140, 1143, 1146, 1150, 1151, 1153, 1154, 1156, 1159, 1160, 1161, 1164, 1166, 1167, 1168, 1170, 1171, 1174, 1175, 1180, 1182, 1185, 1186, 1187, 1188, 1192, 1193, 1194, 1196, 1197, 1198, 1199, 1200, 1201, 1202, 1203, 1204, 1206, 1207, 1210, 1211, 1216, 1218, 1220, 1221, 1223, 1224, 1225, 1230, 1231, 1232, 1234, 1237, 1240, 1243, 1246, 1247, 1249, 1250, 1251, 1253, 1255, 1256, 1260, 1262, 1263, 1265, 1266, 1268, 1269, 1271, 1273, 1274, 1276, 1279, 1281, 1282, 1284, 1286, 1288, 1289, 1292, 1293, 1295, 1297, 1298, 1299, 1302, 1305, 1307, 1309, 1310, 1311, 1313, 1314, 1315, 1318, 1320, 1322, 1324, 1325, 1327, 1329, 1332, 1333, 1334, 1335, 1337, 1338, 1340, 1342, 1344, 1345, 1349, 1350, 1351, 1352, 1355, 1356, 1358, 1359, 1361, 1362, 1363, 1364, 1366, 1367, 1368, 1369, 1371, 1373, 1375, 1377, 1378, 1383, 1385, 1386, 1387, 1388, 1391, 1392, 1400, 1401, 1403, 1408, 1410, 1411, 1415, 1416, 1418, 1424, 1427, 1428, 1429, 1430, 1433, 1434, 1436, 1438, 1440, 1444, 1446, 1450, 1452, 1453, 1455, 1458, 1462, 1463, 1465, 1466, 1468, 1469, 1473, 1474, 1476, 1479, 1482, 1486, 1488, 1489, 1490, 1494, 1496, 1498, 1502, 1504, 1505, 1507, 1508, 1511, 1512, 1514, 1517, 1518, 1521, 1523, 1525, 1526, 1527, 1529, 1534, 1536, 1538, 1541, 1542, 1543, 1546, 1550, 1552, 1554, 1555, 1557, 1561, 1564, 1565, 1566, 1567, 1569, 1573, 1574, 1575, 1576, 1580, 1583, 1585, 1587, 1588, 1590, 1593, 1595, 1596, 1598, 1601, 1602, 1603, 1605, 1607, 1609, 1610, 1611, 1613, 1614, 1615, 1617, 1618, 1620, 1622, 1624, 1626, 1628, 1629, 1631, 1634, 1635, 1639, 1640, 1642, 1644, 1645, 1646, 1648, 1649, 1650, 1652, 1655, 1658, 1660, 1663, 1665, 1667, 1669, 1671, 1673, 1675, 1676, 1677, 1681, 1684, 1686, 1688, 1690, 1691, 1692, 1694, 1696, 1698, 1699, 1701, 1703, 1705, 1707, 1708, 1710, 1712, 1715, 1716, 1718, 1719, 1723, 1727, 1729, 1730, 1732, 1733, 1736, 1739, 1741, 1743, 1744, 1746, 1747, 1749, 1750, 1751, 1753, 1754, 1755, 1759, 1761, 1763, 1765, 1767, 1768, 1773, 1776, 1778, 1781, 1782, 1783, 1786, 1789, 1791, 1793, 1795, 1796, 1798, 1799, 1801, 1803, 1810, 1811, 1813, 1816, 1817, 1819, 1820, 1821, 1823, 1824, 1826, 1827, 1829, 1831, 1832, 1834, 1837, 1838, 1839, 1842, 1844, 1847, 1849, 1853, 1858, 1859, 1860, 1863, 1865, 1866, 1868, 1871, 1872, 1874, 1877, 1882, 1884, 1886, 1889, 1892, 1893, 1896, 1901, 1903, 1904, 1909, 1910, 1913, 1916, 1918, 1919, 1920, 1921, 1923, 1925, 1927, 1929, 1931, 1932, 1935, 1936, 1938, 1939, 1941, 1943, 1944, 1946, 1947, 1949, 1952, 1954, 1957, 1960, 1962, 1963, 1965, 1967, 1968, 1969, 1971, 1972, 1975, 1978, 1979, 1980, 1982, 1983, 1985, 1986, 1989, 1990, 1991, 1993, 1994, 1996, 1998], deadline = 2)
        configuration.add_task(name="Task1", identifier=1, period=10.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=3.169297, acet=3.169297, et_stddev=1.0564323333333332, deadline= 17)
        configuration.add_task(name="Task4", identifier=4, period=2.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.148744, et_stddev=0.04958133333333333 , list_activation_dates=[3, 6, 16, 26, 33, 36, 38, 45, 48, 52, 54, 63, 66, 71, 75, 79, 82, 84, 86, 89, 92, 94, 97, 99, 104, 108, 112, 115, 117, 120, 125, 129, 135, 140, 142, 145, 148, 152, 158, 161, 166, 174, 177, 184, 186, 188, 192, 195, 197, 202, 206, 209, 212, 216, 219, 223, 229, 231, 235, 238, 242, 247, 257, 260, 266, 272, 277, 279, 281, 286, 288, 291, 300, 305, 311, 314, 316, 320, 324, 327, 334, 336, 343, 348, 350, 353, 359, 364, 366, 369, 374, 379, 381, 384, 388, 391, 401, 403, 407, 413, 416, 420, 423, 426, 429, 431, 434, 443, 447, 450, 452, 459, 462, 470, 473, 483, 490, 494, 496, 498, 500, 507, 511, 515, 521, 526, 529, 535, 540, 543, 546, 553, 556, 561, 563, 566, 571, 573, 575, 578, 580, 583, 585, 588, 590, 593, 596, 599, 601, 604, 607, 609, 614, 620, 625, 628, 636, 640, 643, 647, 653, 658, 661, 668, 671, 677, 679, 682, 686, 689, 692, 698, 701, 705, 710, 713, 718, 723, 728, 732, 735, 739, 742, 744, 750, 753, 757, 759, 762, 764, 767, 774, 779, 783, 785, 787, 790, 799, 801, 805, 809, 818, 821, 826, 830, 833, 835, 840, 844, 850, 855, 860, 867, 869, 872, 876, 880, 882, 884, 887, 889, 893, 895, 898, 902, 906, 913, 916, 925, 928, 932, 935, 940, 945, 947, 953, 956, 965, 967, 974, 976, 978, 981, 983, 986, 992, 996, 1002, 1005, 1008, 1017, 1024, 1026, 1028, 1030, 1036, 1041, 1043, 1045, 1049, 1053, 1057, 1060, 1062, 1065, 1068, 1073, 1078, 1082, 1086, 1089, 1095, 1098, 1102, 1105, 1108, 1110, 1112, 1119, 1123, 1128, 1130, 1132, 1134, 1137, 1141, 1146, 1152, 1157, 1159, 1162, 1169, 1172, 1175, 1177, 1181, 1185, 1188, 1192, 1195, 1201, 1206, 1213, 1216, 1221, 1224, 1227, 1230, 1232, 1239, 1241, 1244, 1247, 1250, 1253, 1256, 1262, 1265, 1269, 1271, 1273, 1276, 1280, 1282, 1284, 1289, 1302, 1304, 1311, 1315, 1319, 1321, 1332, 1334, 1339, 1344, 1352, 1354, 1358, 1361, 1365, 1368, 1371, 1374, 1376, 1379, 1385, 1389, 1391, 1394, 1399, 1407, 1411, 1413, 1418, 1423, 1425, 1429, 1432, 1437, 1444, 1447, 1452, 1455, 1457, 1459, 1461, 1463, 1466, 1468, 1472, 1481, 1485, 1490, 1494, 1497, 1500, 1508, 1514, 1520, 1526, 1529, 1531, 1537, 1543, 1548, 1551, 1554, 1561, 1563, 1570, 1575, 1577, 1579, 1585, 1587, 1590, 1592, 1594, 1596, 1601, 1606, 1609, 1614, 1617, 1620, 1623, 1627, 1629, 1635, 1638, 1647, 1652, 1655, 1660, 1664, 1673, 1676, 1678, 1683, 1685, 1688, 1690, 1697, 1702, 1705, 1708, 1712, 1714, 1718, 1721, 1724, 1727, 1730, 1733, 1737, 1741, 1743, 1749, 1753, 1756, 1758, 1766, 1770, 1774, 1782, 1784, 1787, 1793, 1795, 1798, 1800, 1804, 1808, 1816, 1822, 1825, 1828, 1831, 1833, 1838, 1842, 1844, 1846, 1849, 1857, 1861, 1863, 1867, 1871, 1874, 1876, 1878, 1880, 1882, 1890, 1898, 1901, 1905, 1908, 1918, 1921, 1924, 1928, 1936, 1938, 1941, 1944, 1948, 1950, 1953, 1956, 1958, 1960, 1964, 1967, 1969, 1972, 1977, 1980, 1983, 1986, 1989, 1994, 1998], deadline = 4)
        configuration.add_task(name="Task2", identifier=2, period=1.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=0.797061, acet=0.797061, et_stddev=0.265687, deadline= 1)
        configuration.add_task(name="Task6", identifier=6, period=11.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.020005, et_stddev=0.0066683333333333325 , list_activation_dates=[6, 20, 53, 68, 91, 108, 139, 159, 176, 198, 212, 229, 252, 267, 279, 295, 317, 337, 371, 384, 396, 410, 423, 438, 450, 472, 509, 522, 533, 572, 603, 616, 631, 680, 703, 722, 742, 761, 780, 798, 813, 855, 869, 884, 898, 918, 990, 1003, 1039, 1056, 1070, 1092, 1105, 1144, 1158, 1172, 1187, 1204, 1221, 1260, 1275, 1288, 1305, 1317, 1335, 1351, 1367, 1407, 1425, 1443, 1457, 1471, 1516, 1532, 1545, 1560, 1573, 1596, 1614, 1636, 1659, 1680, 1697, 1713, 1730, 1744, 1780, 1794, 1812, 1825, 1847, 1864, 1897, 1913, 1937, 1975, 1988], deadline = 2)
        configuration.add_task(name="Task3", identifier=3, period=4.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=1.944035, acet=1.944035, et_stddev=0.6480116666666667, deadline= 3)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "18")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "18")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "18")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "18")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task2", identifier=2, period=7.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=4.075705, acet=4.075705, et_stddev=1.3585683333333334, deadline= 6)
        configuration.add_task(name="Task4", identifier=4, period=18.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.827647, et_stddev=0.27588233333333334 , list_activation_dates=[13, 41, 106, 128, 157, 180, 233, 322, 367, 387, 415, 449, 491, 510, 562, 590, 609, 627, 658, 708, 734, 760, 789, 850, 883, 920, 970, 1011, 1035, 1069, 1109, 1137, 1196, 1220, 1251, 1298, 1317, 1348, 1366, 1401, 1426, 1448, 1474, 1527, 1545, 1563, 1597, 1625, 1650, 1682, 1757, 1789, 1819, 1842, 1865, 1897, 1918, 1948, 1984], deadline = 30)
        configuration.add_task(name="Task6", identifier=6, period=6.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.720099, et_stddev=0.24003300000000002 , list_activation_dates=[6, 17, 27, 44, 56, 67, 75, 84, 102, 113, 123, 133, 141, 152, 158, 167, 176, 183, 197, 209, 216, 229, 239, 248, 258, 266, 273, 289, 304, 314, 327, 343, 350, 360, 378, 387, 393, 400, 409, 419, 425, 432, 439, 454, 462, 468, 476, 483, 495, 503, 536, 554, 560, 570, 597, 614, 635, 654, 665, 691, 701, 720, 731, 741, 748, 755, 780, 787, 798, 822, 829, 837, 844, 850, 860, 871, 877, 884, 893, 899, 906, 916, 922, 934, 941, 959, 967, 975, 986, 1003, 1009, 1017, 1025, 1033, 1050, 1058, 1066, 1073, 1081, 1088, 1096, 1104, 1111, 1123, 1132, 1153, 1164, 1172, 1195, 1209, 1218, 1233, 1239, 1245, 1256, 1269, 1280, 1287, 1299, 1307, 1316, 1325, 1335, 1342, 1353, 1359, 1365, 1373, 1382, 1404, 1411, 1420, 1430, 1437, 1450, 1458, 1465, 1476, 1488, 1527, 1550, 1561, 1569, 1577, 1590, 1601, 1608, 1617, 1629, 1636, 1654, 1666, 1672, 1683, 1689, 1701, 1708, 1719, 1728, 1737, 1754, 1764, 1774, 1781, 1796, 1805, 1814, 1822, 1828, 1853, 1862, 1875, 1891, 1904, 1918, 1929, 1935, 1945, 1958, 1967, 1979, 1990], deadline = 6)
        configuration.add_task(name="Task3", identifier=3, period=7.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=0.595276, acet=0.595276, et_stddev=0.19842533333333334, deadline= 6)
        configuration.add_task(name="Task1", identifier=1, period=12.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=11.1926, acet=11.1926, et_stddev=3.730866666666667, deadline= 18)
        configuration.add_task(name="Task5", identifier=5, period=3.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.402009, et_stddev=0.134003 , list_activation_dates=[3, 13, 17, 23, 28, 32, 36, 39, 43, 46, 50, 53, 70, 80, 90, 93, 97, 102, 107, 111, 114, 121, 127, 132, 139, 143, 148, 151, 154, 162, 166, 170, 176, 182, 185, 189, 193, 200, 206, 210, 214, 218, 222, 228, 231, 238, 242, 246, 249, 252, 262, 269, 273, 278, 283, 293, 298, 304, 309, 319, 323, 327, 335, 345, 348, 352, 356, 364, 367, 373, 379, 383, 389, 395, 402, 408, 416, 421, 427, 431, 435, 443, 448, 457, 462, 470, 473, 476, 480, 485, 497, 503, 511, 514, 517, 528, 533, 540, 549, 553, 557, 561, 565, 569, 575, 578, 586, 593, 597, 601, 605, 609, 616, 619, 623, 633, 638, 647, 651, 654, 657, 660, 664, 667, 671, 676, 680, 691, 700, 705, 712, 723, 732, 735, 739, 751, 755, 759, 764, 768, 771, 784, 790, 797, 808, 821, 828, 834, 837, 843, 847, 857, 863, 866, 872, 876, 883, 890, 898, 909, 914, 918, 923, 926, 931, 952, 957, 962, 968, 972, 978, 984, 988, 991, 997, 1000, 1004, 1008, 1012, 1017, 1023, 1029, 1032, 1036, 1040, 1049, 1063, 1066, 1073, 1079, 1089, 1109, 1116, 1120, 1127, 1130, 1138, 1143, 1146, 1149, 1155, 1160, 1171, 1176, 1182, 1185, 1191, 1198, 1206, 1215, 1222, 1230, 1234, 1238, 1243, 1247, 1253, 1257, 1262, 1265, 1278, 1283, 1288, 1297, 1301, 1305, 1313, 1320, 1324, 1327, 1333, 1341, 1351, 1357, 1364, 1368, 1372, 1379, 1384, 1388, 1393, 1397, 1401, 1421, 1431, 1444, 1448, 1452, 1460, 1467, 1472, 1477, 1486, 1492, 1500, 1503, 1507, 1510, 1513, 1524, 1533, 1537, 1546, 1549, 1553, 1563, 1569, 1580, 1585, 1588, 1595, 1599, 1603, 1609, 1613, 1621, 1629, 1632, 1640, 1645, 1654, 1660, 1664, 1677, 1682, 1685, 1693, 1696, 1702, 1708, 1715, 1720, 1725, 1729, 1738, 1741, 1746, 1751, 1759, 1764, 1768, 1775, 1780, 1784, 1790, 1793, 1800, 1808, 1813, 1818, 1822, 1826, 1831, 1836, 1843, 1848, 1853, 1856, 1860, 1869, 1872, 1876, 1880, 1884, 1894, 1900, 1909, 1917, 1924, 1929, 1939, 1943, 1947, 1950, 1959, 1963, 1968, 1978, 1981, 1988], deadline = 3)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "19")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "19")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "19")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "19")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task2", identifier=2, period=10.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=6.205512, acet=6.205512, et_stddev=2.068504, deadline= 19)
        configuration.add_task(name="Task6", identifier=6, period=2.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.023903, et_stddev=0.007967666666666666 , list_activation_dates=[5, 9, 14, 17, 23, 26, 28, 31, 35, 38, 43, 49, 57, 63, 67, 71, 74, 77, 79, 85, 89, 97, 100, 103, 106, 110, 112, 115, 119, 125, 127, 131, 135, 137, 143, 149, 152, 159, 161, 164, 167, 171, 173, 178, 181, 185, 190, 197, 200, 204, 206, 213, 218, 220, 222, 225, 229, 233, 243, 247, 250, 253, 257, 260, 262, 265, 267, 269, 273, 276, 279, 285, 288, 290, 294, 299, 304, 306, 308, 310, 313, 315, 318, 324, 327, 331, 334, 336, 339, 341, 345, 349, 353, 359, 362, 366, 369, 372, 374, 377, 381, 384, 387, 394, 397, 401, 405, 409, 415, 420, 423, 426, 430, 434, 439, 441, 446, 448, 453, 458, 462, 466, 469, 473, 476, 479, 482, 484, 486, 490, 492, 494, 498, 501, 503, 507, 510, 512, 515, 524, 527, 533, 541, 544, 546, 553, 555, 557, 561, 566, 570, 573, 576, 580, 583, 586, 590, 594, 604, 611, 613, 618, 621, 627, 635, 649, 655, 658, 664, 667, 671, 680, 683, 687, 692, 697, 701, 705, 707, 714, 717, 724, 731, 733, 736, 740, 743, 746, 749, 752, 757, 760, 767, 770, 779, 791, 795, 798, 800, 805, 808, 816, 818, 820, 823, 827, 831, 833, 836, 839, 844, 848, 852, 855, 857, 861, 865, 867, 869, 875, 877, 879, 882, 884, 887, 890, 893, 898, 900, 903, 907, 914, 916, 918, 920, 924, 927, 936, 940, 943, 953, 956, 959, 962, 965, 967, 970, 972, 977, 980, 985, 995, 999, 1001, 1004, 1006, 1012, 1015, 1019, 1026, 1029, 1033, 1038, 1046, 1048, 1053, 1057, 1064, 1068, 1070, 1074, 1077, 1079, 1088, 1093, 1095, 1098, 1106, 1108, 1111, 1116, 1124, 1127, 1130, 1133, 1136, 1138, 1150, 1160, 1162, 1167, 1170, 1172, 1174, 1180, 1189, 1193, 1196, 1201, 1205, 1211, 1215, 1217, 1221, 1223, 1228, 1231, 1235, 1239, 1242, 1248, 1256, 1259, 1261, 1265, 1267, 1271, 1274, 1279, 1286, 1288, 1290, 1295, 1297, 1300, 1302, 1305, 1309, 1314, 1319, 1322, 1325, 1330, 1334, 1338, 1342, 1346, 1349, 1352, 1356, 1358, 1363, 1366, 1369, 1374, 1382, 1385, 1387, 1391, 1396, 1403, 1410, 1420, 1424, 1427, 1433, 1436, 1440, 1445, 1449, 1451, 1454, 1457, 1464, 1469, 1472, 1475, 1477, 1482, 1486, 1491, 1494, 1496, 1501, 1504, 1507, 1509, 1517, 1521, 1526, 1529, 1532, 1534, 1536, 1538, 1540, 1542, 1547, 1549, 1551, 1560, 1563, 1567, 1569, 1578, 1581, 1587, 1589, 1592, 1596, 1598, 1602, 1605, 1609, 1613, 1615, 1618, 1622, 1625, 1627, 1629, 1631, 1633, 1637, 1639, 1641, 1644, 1647, 1650, 1653, 1657, 1660, 1663, 1666, 1671, 1677, 1679, 1681, 1684, 1686, 1690, 1692, 1697, 1701, 1703, 1707, 1709, 1716, 1718, 1721, 1726, 1730, 1733, 1736, 1738, 1742, 1746, 1753, 1760, 1763, 1767, 1771, 1776, 1778, 1780, 1783, 1787, 1792, 1794, 1798, 1801, 1805, 1813, 1816, 1822, 1825, 1829, 1832, 1835, 1838, 1840, 1842, 1846, 1851, 1853, 1856, 1862, 1866, 1870, 1880, 1885, 1891, 1899, 1902, 1904, 1906, 1909, 1912, 1915, 1918, 1922, 1928, 1931, 1933, 1935, 1938, 1940, 1942, 1945, 1948, 1950, 1953, 1956, 1959, 1961, 1964, 1970, 1974, 1976, 1984, 1987, 1991, 1997], deadline = 4)
        configuration.add_task(name="Task5", identifier=5, period=2.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.500053, et_stddev=0.16668433333333332 , list_activation_dates=[4, 7, 9, 16, 18, 20, 22, 26, 29, 32, 34, 36, 38, 41, 43, 45, 47, 61, 64, 71, 73, 75, 80, 84, 94, 99, 101, 105, 107, 110, 112, 115, 118, 122, 125, 135, 137, 139, 141, 143, 148, 154, 157, 159, 165, 168, 170, 173, 176, 179, 181, 184, 187, 190, 192, 195, 198, 204, 208, 211, 218, 228, 232, 234, 238, 241, 243, 245, 249, 253, 255, 258, 261, 263, 268, 271, 273, 281, 284, 287, 291, 293, 302, 305, 312, 316, 318, 321, 324, 329, 333, 336, 339, 342, 345, 347, 349, 352, 355, 360, 365, 369, 374, 376, 381, 383, 385, 389, 391, 394, 397, 409, 422, 429, 434, 439, 441, 445, 452, 456, 462, 466, 469, 472, 478, 480, 485, 487, 491, 495, 498, 504, 506, 509, 513, 521, 525, 529, 532, 535, 540, 546, 548, 552, 556, 560, 565, 568, 572, 576, 580, 582, 584, 589, 594, 602, 607, 611, 614, 617, 620, 626, 635, 638, 640, 642, 644, 649, 652, 655, 660, 662, 666, 669, 672, 676, 679, 685, 688, 691, 695, 697, 703, 711, 714, 717, 719, 724, 727, 729, 732, 734, 739, 744, 749, 754, 757, 761, 765, 767, 773, 777, 781, 784, 790, 795, 804, 808, 811, 813, 815, 818, 822, 826, 831, 833, 835, 837, 840, 843, 847, 856, 859, 863, 865, 867, 869, 874, 876, 879, 884, 888, 895, 899, 903, 905, 908, 912, 916, 919, 924, 928, 930, 935, 937, 942, 947, 950, 952, 957, 960, 965, 969, 972, 975, 979, 981, 985, 990, 993, 998, 1001, 1004, 1011, 1013, 1022, 1025, 1027, 1029, 1032, 1035, 1038, 1041, 1043, 1049, 1052, 1054, 1058, 1060, 1063, 1067, 1071, 1073, 1076, 1080, 1083, 1086, 1088, 1092, 1095, 1098, 1103, 1112, 1114, 1119, 1121, 1127, 1134, 1138, 1141, 1144, 1146, 1149, 1151, 1153, 1157, 1165, 1169, 1173, 1177, 1183, 1185, 1190, 1194, 1196, 1198, 1201, 1205, 1209, 1213, 1216, 1218, 1221, 1224, 1227, 1230, 1232, 1237, 1242, 1247, 1250, 1253, 1259, 1263, 1266, 1268, 1273, 1277, 1279, 1282, 1284, 1287, 1289, 1293, 1299, 1301, 1304, 1307, 1309, 1312, 1314, 1317, 1324, 1328, 1330, 1334, 1336, 1347, 1352, 1355, 1358, 1363, 1365, 1367, 1373, 1383, 1386, 1388, 1392, 1394, 1397, 1401, 1404, 1409, 1414, 1416, 1419, 1422, 1424, 1429, 1440, 1445, 1448, 1467, 1470, 1478, 1480, 1488, 1490, 1493, 1495, 1501, 1507, 1513, 1515, 1517, 1520, 1527, 1532, 1540, 1545, 1550, 1552, 1555, 1558, 1560, 1564, 1570, 1581, 1585, 1588, 1590, 1593, 1601, 1607, 1609, 1616, 1619, 1622, 1625, 1629, 1634, 1638, 1650, 1654, 1659, 1663, 1666, 1668, 1671, 1676, 1681, 1687, 1690, 1693, 1698, 1702, 1705, 1712, 1716, 1719, 1725, 1728, 1736, 1738, 1743, 1745, 1751, 1753, 1756, 1761, 1768, 1772, 1774, 1777, 1781, 1783, 1790, 1792, 1794, 1797, 1803, 1807, 1810, 1813, 1816, 1819, 1822, 1824, 1827, 1835, 1839, 1844, 1850, 1852, 1854, 1856, 1858, 1860, 1863, 1866, 1870, 1873, 1875, 1877, 1883, 1885, 1888, 1897, 1900, 1905, 1914, 1916, 1919, 1926, 1930, 1935, 1937, 1942, 1945, 1947, 1950, 1956, 1960, 1963, 1967, 1971, 1973, 1976, 1979, 1982, 1986, 1991, 1996, 1999], deadline = 2)
        configuration.add_task(name="Task3", identifier=3, period=1.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=0.462595, acet=0.462595, et_stddev=0.15419833333333333, deadline= 1)
        configuration.add_task(name="Task4", identifier=4, period=12.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.456257, et_stddev=0.15208566666666667 , list_activation_dates=[9, 24, 44, 71, 87, 112, 125, 151, 167, 184, 197, 223, 239, 253, 266, 298, 333, 355, 384, 408, 420, 443, 462, 481, 505, 536, 565, 598, 654, 698, 716, 732, 749, 771, 808, 835, 854, 875, 907, 943, 980, 992, 1005, 1024, 1048, 1063, 1086, 1104, 1126, 1149, 1171, 1209, 1227, 1252, 1266, 1292, 1332, 1348, 1366, 1406, 1425, 1438, 1451, 1464, 1490, 1503, 1520, 1550, 1571, 1602, 1662, 1735, 1763, 1778, 1819, 1837, 1858, 1875, 1900, 1917, 1929, 1959, 1977], deadline = 10)
        configuration.add_task(name="Task1", identifier=1, period=26.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=13.438186, acet=13.438186, et_stddev=4.479395333333334, deadline= 39)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "20")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "20")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "20")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "20")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task3", identifier=3, period=12.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=3.698472, acet=3.698472, et_stddev=1.2328240000000001, deadline= 7)
        configuration.add_task(name="Task2", identifier=2, period=5.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=2.52851, acet=2.52851, et_stddev=0.8428366666666666, deadline= 10)
        configuration.add_task(name="Task1", identifier=1, period=2.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=1.572183, acet=1.572183, et_stddev=0.524061, deadline= 4)
        configuration.add_task(name="Task4", identifier=4, period=2.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.105611, et_stddev=0.03520366666666667 , list_activation_dates=[4, 7, 12, 16, 20, 23, 25, 29, 31, 36, 38, 41, 43, 47, 50, 53, 57, 62, 67, 73, 77, 81, 86, 88, 93, 95, 104, 107, 110, 112, 117, 120, 126, 128, 131, 135, 141, 144, 148, 154, 159, 162, 164, 168, 171, 173, 178, 185, 188, 194, 201, 208, 215, 217, 219, 221, 224, 235, 237, 243, 251, 253, 258, 260, 263, 266, 270, 273, 276, 279, 283, 285, 289, 297, 299, 303, 308, 312, 315, 318, 321, 324, 328, 333, 341, 346, 351, 355, 357, 361, 365, 367, 372, 375, 377, 382, 386, 391, 397, 403, 406, 409, 416, 418, 421, 424, 434, 438, 442, 444, 448, 455, 458, 461, 467, 471, 475, 482, 488, 494, 497, 503, 507, 512, 517, 524, 528, 532, 534, 537, 541, 544, 549, 553, 558, 563, 566, 569, 572, 574, 576, 583, 590, 596, 600, 607, 612, 614, 617, 619, 621, 623, 627, 632, 636, 638, 644, 649, 653, 656, 664, 666, 668, 670, 674, 678, 680, 685, 687, 692, 695, 698, 704, 709, 715, 720, 724, 727, 730, 733, 737, 745, 748, 750, 753, 756, 763, 769, 773, 775, 779, 781, 789, 797, 803, 806, 809, 814, 818, 821, 826, 828, 834, 837, 840, 844, 847, 850, 852, 858, 863, 871, 874, 878, 884, 886, 888, 890, 892, 894, 896, 898, 905, 909, 917, 921, 926, 929, 931, 934, 936, 940, 943, 947, 950, 960, 962, 968, 973, 976, 978, 983, 985, 987, 989, 992, 1002, 1007, 1010, 1014, 1018, 1022, 1025, 1028, 1033, 1038, 1042, 1047, 1050, 1055, 1058, 1063, 1068, 1070, 1073, 1075, 1081, 1086, 1091, 1097, 1100, 1103, 1107, 1110, 1112, 1115, 1125, 1128, 1132, 1136, 1139, 1144, 1151, 1156, 1161, 1164, 1167, 1170, 1174, 1178, 1181, 1185, 1187, 1190, 1192, 1197, 1199, 1204, 1207, 1213, 1218, 1220, 1222, 1228, 1231, 1234, 1237, 1244, 1246, 1249, 1252, 1257, 1259, 1263, 1266, 1276, 1279, 1282, 1284, 1288, 1292, 1296, 1298, 1300, 1304, 1309, 1313, 1316, 1318, 1320, 1323, 1326, 1329, 1332, 1334, 1336, 1339, 1345, 1351, 1357, 1361, 1364, 1368, 1376, 1380, 1383, 1386, 1389, 1397, 1400, 1403, 1406, 1408, 1411, 1416, 1419, 1422, 1431, 1435, 1439, 1442, 1447, 1449, 1452, 1455, 1464, 1467, 1471, 1477, 1482, 1485, 1487, 1492, 1495, 1499, 1502, 1505, 1511, 1514, 1517, 1520, 1523, 1527, 1530, 1533, 1535, 1540, 1543, 1547, 1553, 1556, 1565, 1573, 1578, 1581, 1585, 1588, 1595, 1598, 1604, 1609, 1611, 1614, 1620, 1625, 1630, 1633, 1636, 1639, 1641, 1648, 1650, 1661, 1668, 1671, 1673, 1676, 1679, 1682, 1685, 1692, 1694, 1696, 1699, 1702, 1705, 1710, 1713, 1718, 1720, 1723, 1726, 1734, 1737, 1741, 1746, 1749, 1751, 1754, 1758, 1760, 1762, 1765, 1768, 1770, 1775, 1782, 1785, 1788, 1790, 1792, 1794, 1798, 1801, 1804, 1808, 1812, 1814, 1818, 1820, 1823, 1826, 1828, 1831, 1837, 1840, 1845, 1858, 1861, 1864, 1867, 1871, 1875, 1882, 1885, 1888, 1897, 1903, 1906, 1910, 1914, 1917, 1922, 1925, 1930, 1936, 1943, 1947, 1951, 1958, 1960, 1965, 1967, 1973, 1977, 1979, 1991, 1993, 1996, 1999], deadline = 1)
        configuration.add_task(name="Task6", identifier=6, period=1.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.069884, et_stddev=0.02329466666666667 , list_activation_dates=[2, 3, 5, 6, 8, 9, 11, 16, 17, 19, 21, 23, 25, 27, 28, 31, 32, 33, 36, 38, 39, 40, 41, 43, 47, 52, 54, 55, 60, 61, 63, 65, 66, 68, 71, 72, 73, 75, 76, 78, 79, 82, 84, 86, 88, 90, 94, 96, 97, 98, 99, 100, 102, 103, 105, 107, 109, 111, 114, 116, 117, 118, 121, 123, 124, 125, 126, 128, 129, 130, 131, 132, 137, 138, 141, 145, 146, 149, 152, 153, 155, 157, 159, 161, 163, 165, 168, 171, 173, 176, 177, 179, 181, 183, 185, 186, 187, 188, 189, 191, 192, 194, 195, 198, 199, 201, 205, 207, 210, 212, 214, 215, 216, 218, 219, 221, 224, 225, 227, 230, 232, 233, 234, 236, 238, 240, 244, 245, 247, 248, 250, 252, 256, 258, 260, 262, 264, 266, 267, 268, 270, 271, 272, 273, 275, 276, 278, 280, 284, 288, 289, 291, 295, 296, 298, 300, 301, 304, 306, 307, 309, 312, 313, 316, 318, 319, 320, 323, 326, 328, 330, 334, 336, 338, 339, 341, 343, 344, 346, 348, 353, 355, 361, 362, 363, 367, 369, 370, 372, 373, 375, 377, 378, 379, 384, 386, 388, 389, 391, 392, 393, 395, 398, 400, 401, 403, 405, 406, 407, 412, 414, 418, 421, 422, 426, 428, 429, 432, 434, 436, 438, 441, 443, 447, 450, 451, 453, 457, 458, 459, 460, 461, 464, 465, 466, 467, 468, 469, 471, 473, 474, 475, 478, 479, 480, 482, 487, 489, 493, 494, 495, 497, 498, 500, 502, 504, 505, 507, 508, 509, 510, 512, 513, 515, 516, 517, 518, 519, 520, 522, 524, 526, 529, 530, 532, 533, 534, 536, 538, 540, 542, 543, 544, 547, 551, 553, 555, 556, 558, 559, 561, 563, 565, 566, 568, 570, 577, 578, 580, 581, 583, 584, 586, 588, 591, 593, 596, 597, 599, 601, 603, 605, 607, 609, 610, 613, 614, 615, 616, 617, 618, 621, 622, 623, 625, 627, 628, 629, 635, 636, 641, 642, 646, 648, 649, 652, 655, 657, 658, 661, 662, 663, 664, 666, 669, 671, 673, 674, 676, 677, 681, 682, 683, 685, 687, 689, 692, 695, 696, 698, 702, 705, 706, 707, 708, 709, 710, 711, 712, 715, 717, 718, 719, 721, 723, 726, 728, 730, 732, 734, 735, 737, 741, 742, 745, 746, 748, 750, 751, 754, 757, 759, 761, 764, 765, 767, 769, 775, 776, 778, 781, 783, 784, 785, 787, 788, 789, 792, 794, 796, 799, 801, 802, 804, 806, 808, 810, 812, 814, 816, 817, 819, 821, 822, 823, 825, 826, 827, 829, 831, 833, 834, 836, 844, 847, 849, 850, 851, 852, 853, 856, 857, 867, 871, 873, 875, 877, 879, 880, 882, 887, 888, 889, 890, 891, 892, 893, 895, 896, 899, 901, 903, 905, 906, 907, 909, 910, 912, 914, 915, 918, 920, 921, 923, 925, 927, 931, 932, 933, 935, 937, 938, 940, 941, 945, 946, 947, 948, 950, 952, 953, 955, 959, 961, 964, 966, 968, 971, 973, 975, 976, 978, 979, 982, 984, 985, 986, 987, 992, 994, 995, 996, 997, 998, 1002, 1007, 1008, 1010, 1011, 1012, 1014, 1015, 1018, 1020, 1022, 1024, 1029, 1031, 1033, 1034, 1036, 1039, 1040, 1042, 1043, 1044, 1045, 1046, 1048, 1051, 1052, 1055, 1057, 1059, 1060, 1063, 1065, 1066, 1069, 1071, 1073, 1074, 1075, 1076, 1079, 1080, 1081, 1082, 1084, 1085, 1086, 1088, 1089, 1091, 1093, 1094, 1096, 1099, 1101, 1102, 1104, 1106, 1107, 1110, 1112, 1113, 1117, 1122, 1125, 1126, 1128, 1129, 1130, 1131, 1132, 1133, 1136, 1137, 1140, 1141, 1143, 1144, 1147, 1148, 1151, 1152, 1155, 1157, 1159, 1160, 1163, 1164, 1165, 1168, 1169, 1170, 1171, 1172, 1175, 1176, 1177, 1179, 1183, 1186, 1187, 1190, 1191, 1192, 1194, 1196, 1198, 1200, 1203, 1204, 1205, 1208, 1210, 1213, 1214, 1217, 1218, 1219, 1220, 1222, 1225, 1228, 1229, 1233, 1235, 1237, 1239, 1241, 1244, 1245, 1248, 1249, 1250, 1253, 1255, 1258, 1264, 1265, 1267, 1269, 1270, 1271, 1272, 1275, 1279, 1281, 1284, 1285, 1286, 1287, 1289, 1290, 1291, 1293, 1295, 1298, 1299, 1304, 1306, 1309, 1310, 1311, 1312, 1313, 1315, 1317, 1319, 1320, 1321, 1322, 1323, 1325, 1327, 1328, 1330, 1331, 1334, 1335, 1337, 1340, 1343, 1344, 1347, 1349, 1354, 1355, 1361, 1363, 1364, 1368, 1370, 1373, 1375, 1379, 1382, 1383, 1385, 1387, 1389, 1390, 1394, 1398, 1400, 1401, 1402, 1403, 1404, 1406, 1408, 1410, 1413, 1414, 1415, 1417, 1418, 1420, 1421, 1423, 1424, 1425, 1428, 1429, 1431, 1433, 1435, 1438, 1441, 1443, 1444, 1448, 1449, 1452, 1454, 1456, 1458, 1459, 1462, 1463, 1467, 1468, 1469, 1470, 1471, 1472, 1475, 1476, 1478, 1480, 1481, 1482, 1486, 1488, 1489, 1492, 1494, 1495, 1497, 1498, 1499, 1500, 1503, 1507, 1510, 1513, 1517, 1520, 1521, 1523, 1529, 1530, 1532, 1537, 1541, 1544, 1546, 1548, 1549, 1551, 1552, 1553, 1557, 1560, 1561, 1563, 1566, 1568, 1570, 1571, 1574, 1575, 1577, 1578, 1580, 1582, 1584, 1585, 1588, 1591, 1593, 1594, 1595, 1596, 1597, 1600, 1601, 1603, 1605, 1608, 1612, 1616, 1618, 1619, 1620, 1622, 1623, 1624, 1627, 1628, 1629, 1631, 1632, 1634, 1636, 1637, 1639, 1643, 1644, 1646, 1647, 1650, 1651, 1652, 1655, 1658, 1659, 1661, 1664, 1665, 1667, 1668, 1669, 1670, 1671, 1672, 1673, 1675, 1677, 1678, 1679, 1681, 1683, 1685, 1687, 1689, 1691, 1693, 1696, 1697, 1699, 1700, 1702, 1704, 1706, 1707, 1709, 1711, 1713, 1715, 1717, 1719, 1720, 1722, 1724, 1728, 1729, 1731, 1732, 1735, 1736, 1740, 1742, 1743, 1745, 1747, 1749, 1751, 1753, 1755, 1758, 1759, 1761, 1764, 1767, 1768, 1769, 1770, 1773, 1775, 1777, 1778, 1780, 1781, 1782, 1783, 1784, 1786, 1788, 1789, 1791, 1792, 1795, 1797, 1799, 1802, 1805, 1806, 1810, 1812, 1816, 1818, 1821, 1823, 1825, 1826, 1827, 1828, 1830, 1832, 1834, 1835, 1837, 1838, 1839, 1842, 1843, 1844, 1845, 1846, 1847, 1848, 1850, 1853, 1854, 1856, 1857, 1859, 1860, 1862, 1865, 1866, 1867, 1869, 1871, 1873, 1875, 1877, 1879, 1882, 1883, 1885, 1888, 1890, 1893, 1896, 1898, 1900, 1902, 1905, 1908, 1911, 1912, 1913, 1914, 1915, 1917, 1919, 1921, 1923, 1925, 1927, 1928, 1930, 1932, 1934, 1937, 1938, 1943, 1945, 1948, 1951, 1952, 1956, 1957, 1958, 1963, 1964, 1966, 1969, 1970, 1972, 1973, 1975, 1976, 1978, 1980, 1983, 1987, 1989, 1991, 1995, 1997, 1998, 2000], deadline = 1)
        configuration.add_task(name="Task5", identifier=5, period=23.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=5, acet=4.078136, et_stddev=1.3593786666666665 , list_activation_dates=[9, 68, 111, 144, 193, 272, 300, 392, 430, 459, 519, 557, 591, 649, 673, 727, 792, 829, 860, 911, 956, 1009, 1036, 1061, 1129, 1154, 1220, 1256, 1300, 1328, 1397, 1435, 1462, 1491, 1541, 1572, 1599, 1665, 1724, 1756, 1787, 1834, 1889, 1915, 1976], deadline = 29)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "21")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "21")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "21")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "21")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task3", identifier=3, period=23.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=7.5344, acet=7.5344, et_stddev=2.5114666666666667, deadline= 34)
        configuration.add_task(name="Task5", identifier=5, period=5.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.552738, et_stddev=0.184246 , list_activation_dates=[7, 12, 21, 27, 35, 58, 65, 78, 84, 91, 102, 109, 121, 132, 147, 154, 160, 172, 190, 196, 211, 237, 244, 256, 264, 276, 283, 288, 305, 312, 327, 332, 341, 354, 363, 369, 380, 387, 394, 400, 407, 417, 442, 447, 463, 472, 479, 487, 502, 511, 524, 531, 536, 546, 566, 590, 597, 614, 634, 648, 653, 659, 666, 672, 690, 711, 720, 737, 742, 761, 768, 777, 800, 810, 818, 836, 841, 846, 855, 863, 870, 884, 891, 897, 903, 908, 915, 920, 937, 946, 953, 963, 971, 977, 983, 997, 1021, 1032, 1038, 1049, 1055, 1061, 1075, 1082, 1089, 1098, 1103, 1123, 1129, 1135, 1144, 1153, 1158, 1168, 1185, 1192, 1202, 1215, 1222, 1235, 1242, 1249, 1254, 1266, 1272, 1278, 1283, 1293, 1303, 1332, 1340, 1349, 1356, 1361, 1372, 1379, 1385, 1394, 1401, 1409, 1416, 1421, 1429, 1440, 1451, 1460, 1483, 1498, 1506, 1511, 1524, 1530, 1538, 1545, 1555, 1575, 1592, 1599, 1608, 1618, 1623, 1630, 1637, 1644, 1656, 1667, 1673, 1695, 1722, 1731, 1743, 1754, 1761, 1775, 1781, 1788, 1797, 1805, 1813, 1821, 1828, 1837, 1856, 1863, 1869, 1875, 1880, 1895, 1902, 1907, 1914, 1923, 1933, 1943, 1962, 1968, 1973, 1980, 1990, 1998], deadline = 6)
        configuration.add_task(name="Task1", identifier=1, period=7.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=6.292868, acet=6.292868, et_stddev=2.0976226666666666, deadline= 12)
        configuration.add_task(name="Task6", identifier=6, period=4.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.461435, et_stddev=0.15381166666666665 , list_activation_dates=[4, 9, 34, 42, 47, 51, 57, 63, 74, 81, 92, 111, 132, 137, 144, 156, 164, 169, 176, 180, 188, 197, 206, 212, 219, 225, 232, 239, 243, 249, 254, 262, 266, 274, 281, 290, 296, 306, 317, 323, 336, 344, 348, 354, 363, 369, 377, 382, 388, 393, 411, 420, 429, 439, 446, 454, 458, 468, 479, 489, 495, 505, 514, 521, 528, 534, 538, 543, 549, 553, 562, 568, 579, 586, 595, 600, 606, 612, 618, 624, 631, 640, 645, 651, 657, 668, 672, 683, 689, 694, 698, 705, 714, 719, 727, 734, 738, 743, 749, 758, 769, 775, 779, 784, 798, 808, 814, 822, 827, 833, 856, 886, 905, 912, 919, 926, 931, 946, 951, 966, 970, 987, 997, 1002, 1018, 1023, 1030, 1040, 1044, 1052, 1068, 1072, 1081, 1086, 1091, 1096, 1102, 1109, 1118, 1123, 1128, 1134, 1156, 1168, 1179, 1194, 1199, 1209, 1216, 1223, 1228, 1243, 1248, 1254, 1260, 1266, 1272, 1278, 1297, 1304, 1315, 1321, 1328, 1334, 1368, 1379, 1387, 1393, 1398, 1407, 1425, 1433, 1442, 1454, 1465, 1475, 1480, 1487, 1493, 1514, 1524, 1536, 1542, 1548, 1557, 1571, 1578, 1590, 1595, 1601, 1606, 1616, 1622, 1627, 1634, 1642, 1646, 1651, 1668, 1675, 1682, 1695, 1701, 1705, 1714, 1722, 1732, 1738, 1743, 1747, 1760, 1782, 1801, 1806, 1815, 1820, 1835, 1847, 1851, 1855, 1862, 1869, 1874, 1880, 1886, 1891, 1900, 1906, 1910, 1915, 1920, 1926, 1932, 1936, 1949, 1956, 1961, 1967, 1971, 1976, 1980, 1998], deadline = 2)
        configuration.add_task(name="Task4", identifier=4, period=7.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.518653, et_stddev=0.17288433333333333 , list_activation_dates=[8, 21, 34, 51, 63, 73, 86, 95, 111, 118, 125, 143, 153, 166, 174, 195, 204, 212, 243, 266, 293, 301, 309, 336, 349, 369, 392, 408, 416, 433, 442, 455, 472, 483, 493, 507, 522, 535, 551, 566, 574, 590, 606, 615, 638, 646, 657, 690, 700, 709, 716, 743, 754, 764, 772, 781, 789, 804, 812, 828, 837, 849, 859, 873, 883, 899, 919, 932, 943, 956, 967, 997, 1008, 1031, 1053, 1061, 1076, 1089, 1100, 1113, 1122, 1130, 1140, 1149, 1162, 1179, 1232, 1242, 1253, 1269, 1280, 1290, 1299, 1309, 1317, 1326, 1334, 1366, 1374, 1381, 1402, 1409, 1426, 1435, 1469, 1489, 1505, 1519, 1532, 1540, 1549, 1562, 1587, 1597, 1609, 1625, 1632, 1641, 1653, 1666, 1678, 1686, 1694, 1704, 1713, 1734, 1744, 1751, 1768, 1777, 1792, 1800, 1814, 1823, 1845, 1859, 1868, 1875, 1898, 1910, 1924, 1941, 1950, 1958, 1966, 1976, 1985, 1994], deadline = 11)
        configuration.add_task(name="Task2", identifier=2, period=4.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=1.493744, acet=1.493744, et_stddev=0.49791466666666667, deadline= 6)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "22")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "22")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "22")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "22")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task4", identifier=4, period=9.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=3, acet=2.144847, et_stddev=0.714949 , list_activation_dates=[14, 23, 41, 52, 61, 71, 83, 95, 125, 134, 163, 176, 209, 219, 228, 248, 283, 293, 306, 315, 337, 351, 365, 383, 397, 412, 425, 442, 459, 480, 502, 521, 532, 557, 572, 599, 613, 635, 659, 682, 695, 709, 720, 745, 757, 791, 812, 829, 846, 862, 881, 892, 906, 933, 980, 992, 1009, 1035, 1048, 1064, 1075, 1095, 1116, 1130, 1143, 1153, 1162, 1187, 1200, 1211, 1245, 1258, 1280, 1294, 1336, 1346, 1358, 1376, 1399, 1415, 1430, 1443, 1452, 1480, 1490, 1508, 1517, 1528, 1567, 1586, 1601, 1612, 1638, 1662, 1671, 1680, 1710, 1726, 1737, 1747, 1759, 1770, 1799, 1811, 1848, 1864, 1893, 1904, 1918, 1935, 1994], deadline = 13)
        configuration.add_task(name="Task5", identifier=5, period=5.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.291653, et_stddev=0.09721766666666666 , list_activation_dates=[7, 16, 25, 35, 43, 51, 57, 69, 87, 96, 103, 109, 119, 125, 141, 148, 154, 162, 168, 173, 183, 195, 202, 210, 222, 238, 246, 257, 268, 273, 283, 289, 297, 303, 310, 320, 337, 357, 370, 376, 387, 406, 418, 431, 440, 452, 463, 476, 485, 491, 502, 508, 516, 526, 534, 540, 557, 578, 590, 597, 612, 647, 664, 686, 698, 705, 716, 726, 731, 736, 750, 757, 772, 782, 792, 797, 802, 812, 822, 839, 844, 855, 869, 882, 896, 906, 921, 933, 943, 952, 994, 1005, 1011, 1019, 1028, 1036, 1045, 1059, 1072, 1079, 1088, 1097, 1102, 1114, 1124, 1144, 1159, 1165, 1170, 1175, 1181, 1190, 1200, 1227, 1233, 1238, 1251, 1270, 1275, 1296, 1304, 1328, 1335, 1351, 1361, 1373, 1378, 1402, 1408, 1418, 1425, 1430, 1441, 1449, 1454, 1460, 1475, 1480, 1486, 1501, 1508, 1514, 1525, 1530, 1541, 1554, 1560, 1573, 1583, 1592, 1598, 1603, 1609, 1621, 1637, 1650, 1655, 1660, 1665, 1686, 1691, 1698, 1708, 1716, 1722, 1727, 1737, 1745, 1751, 1770, 1776, 1792, 1799, 1807, 1813, 1824, 1830, 1846, 1856, 1866, 1884, 1891, 1901, 1909, 1922, 1930, 1941, 1947, 1952, 1980, 1990], deadline = 9)
        configuration.add_task(name="Task1", identifier=1, period=1.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=0.009247, acet=0.009247, et_stddev=0.003082333333333333, deadline= 2)
        configuration.add_task(name="Task3", identifier=3, period=3.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=2.169954, acet=2.169954, et_stddev=0.723318, deadline= 3)
        configuration.add_task(name="Task2", identifier=2, period=16.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=13.878952, acet=13.878952, et_stddev=4.626317333333334, deadline= 20)
        configuration.add_task(name="Task6", identifier=6, period=18.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.060351, et_stddev=0.020117 , list_activation_dates=[18, 37, 60, 103, 134, 160, 188, 213, 245, 278, 301, 343, 370, 412, 463, 482, 533, 553, 608, 635, 659, 704, 730, 756, 792, 811, 830, 905, 953, 990, 1031, 1077, 1101, 1126, 1181, 1212, 1255, 1294, 1317, 1414, 1464, 1499, 1534, 1575, 1611, 1666, 1699, 1746, 1769, 1837, 1898, 1993], deadline = 27)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "23")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "23")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "23")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "23")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task2", identifier=2, period=49.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=17.056382, acet=17.056382, et_stddev=5.685460666666667, deadline= 78)
        configuration.add_task(name="Task5", identifier=5, period=22.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=2, acet=1.125601, et_stddev=0.37520033333333336 , list_activation_dates=[62, 93, 116, 158, 195, 247, 279, 334, 408, 442, 497, 537, 563, 596, 656, 680, 722, 807, 888, 973, 998, 1122, 1146, 1172, 1202, 1232, 1262, 1295, 1329, 1363, 1453, 1532, 1563, 1619, 1647, 1729, 1805, 1922, 1964, 1996], deadline = 20)
        configuration.add_task(name="Task4", identifier=4, period=45.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=10, acet=9.470461, et_stddev=3.1568203333333336 , list_activation_dates=[3, 152, 236, 396, 473, 525, 648, 774, 822, 913, 962, 1042, 1144, 1226, 1280, 1354, 1414, 1463, 1540, 1646, 1962], deadline = 65)
        configuration.add_task(name="Task1", identifier=1, period=3.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=2.783134, acet=2.783134, et_stddev=0.9277113333333333, deadline= 5)
        configuration.add_task(name="Task6", identifier=6, period=12.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.460579, et_stddev=0.15352633333333335 , list_activation_dates=[12, 44, 58, 81, 99, 112, 130, 144, 156, 172, 184, 197, 214, 227, 255, 268, 284, 308, 349, 392, 405, 421, 486, 511, 525, 544, 559, 578, 600, 615, 630, 744, 773, 786, 808, 836, 852, 899, 913, 926, 940, 954, 976, 1029, 1088, 1113, 1161, 1179, 1199, 1239, 1258, 1273, 1304, 1317, 1330, 1349, 1377, 1390, 1428, 1446, 1459, 1478, 1491, 1506, 1522, 1540, 1565, 1589, 1622, 1648, 1666, 1682, 1711, 1731, 1757, 1782, 1800, 1827, 1852, 1868, 1885, 1900, 1919, 1946, 1960, 1990], deadline = 21)
        configuration.add_task(name="Task3", identifier=3, period=10.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=3.241991, acet=3.241991, et_stddev=1.0806636666666667, deadline= 16)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "24")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "24")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "24")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "24")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task2", identifier=2, period=18.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=3.156731, acet=3.156731, et_stddev=1.0522436666666668, deadline= 26)
        configuration.add_task(name="Task1", identifier=1, period=27.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=15.674941, acet=15.674941, et_stddev=5.224980333333334, deadline= 40)
        configuration.add_task(name="Task4", identifier=4, period=1.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.109003, et_stddev=0.03633433333333334 , list_activation_dates=[2, 4, 6, 8, 9, 11, 13, 14, 16, 17, 18, 21, 23, 25, 26, 27, 29, 30, 31, 33, 34, 35, 37, 38, 40, 41, 46, 48, 50, 51, 53, 54, 57, 62, 63, 65, 66, 70, 73, 75, 76, 77, 78, 83, 84, 86, 88, 89, 92, 93, 95, 96, 99, 101, 105, 106, 108, 111, 116, 118, 120, 121, 123, 125, 126, 127, 129, 130, 132, 133, 135, 136, 138, 139, 140, 143, 147, 148, 151, 154, 155, 156, 157, 160, 161, 162, 163, 166, 167, 169, 170, 171, 172, 173, 174, 175, 177, 178, 181, 183, 185, 186, 189, 190, 192, 193, 195, 198, 202, 205, 208, 210, 212, 215, 217, 218, 219, 220, 223, 225, 227, 229, 230, 234, 235, 236, 240, 242, 245, 247, 250, 251, 252, 255, 257, 261, 264, 266, 269, 270, 273, 275, 276, 277, 278, 279, 280, 282, 285, 287, 289, 291, 293, 294, 299, 301, 302, 303, 305, 306, 309, 310, 312, 314, 317, 320, 321, 324, 331, 333, 336, 339, 342, 343, 345, 348, 350, 352, 353, 354, 355, 356, 358, 359, 365, 366, 367, 368, 374, 376, 377, 380, 381, 382, 384, 385, 387, 388, 389, 390, 391, 394, 395, 396, 398, 401, 403, 405, 407, 408, 410, 411, 414, 417, 418, 419, 420, 422, 423, 424, 425, 428, 429, 430, 432, 435, 436, 439, 441, 442, 444, 446, 448, 450, 452, 456, 458, 459, 461, 465, 467, 468, 469, 471, 473, 476, 479, 481, 483, 486, 487, 491, 494, 498, 500, 502, 503, 504, 507, 510, 512, 514, 517, 520, 521, 523, 524, 526, 528, 530, 532, 534, 535, 536, 538, 540, 544, 546, 548, 549, 551, 552, 554, 555, 556, 560, 561, 564, 565, 567, 571, 573, 575, 576, 578, 580, 583, 584, 586, 587, 590, 592, 594, 596, 599, 600, 601, 603, 606, 608, 610, 611, 614, 615, 618, 621, 622, 623, 624, 625, 629, 630, 631, 633, 634, 636, 638, 642, 643, 644, 646, 649, 650, 651, 653, 655, 657, 658, 660, 661, 662, 664, 666, 668, 669, 674, 676, 678, 679, 681, 688, 689, 691, 693, 694, 696, 700, 701, 702, 704, 706, 707, 709, 710, 713, 715, 718, 720, 724, 726, 727, 729, 731, 732, 737, 740, 742, 743, 744, 746, 752, 753, 755, 756, 758, 759, 762, 764, 765, 766, 770, 774, 779, 781, 783, 785, 786, 788, 790, 792, 794, 796, 798, 800, 803, 804, 805, 810, 812, 815, 816, 818, 822, 826, 827, 828, 830, 832, 833, 836, 839, 840, 843, 844, 846, 848, 852, 854, 855, 856, 858, 860, 861, 862, 863, 864, 866, 867, 869, 873, 876, 878, 879, 880, 883, 886, 887, 890, 896, 897, 898, 900, 901, 903, 905, 907, 909, 912, 916, 919, 920, 922, 925, 926, 928, 930, 932, 934, 935, 936, 940, 942, 943, 945, 946, 947, 948, 949, 950, 952, 954, 955, 956, 957, 959, 961, 962, 969, 970, 972, 975, 978, 980, 982, 984, 986, 988, 991, 995, 997, 999, 1000, 1002, 1003, 1004, 1006, 1008, 1010, 1012, 1014, 1016, 1018, 1020, 1023, 1024, 1025, 1026, 1027, 1030, 1032, 1035, 1037, 1039, 1041, 1043, 1046, 1048, 1050, 1051, 1054, 1055, 1057, 1060, 1061, 1062, 1063, 1065, 1067, 1071, 1074, 1076, 1078, 1080, 1081, 1083, 1085, 1089, 1090, 1092, 1093, 1094, 1097, 1099, 1100, 1104, 1105, 1107, 1109, 1111, 1114, 1116, 1118, 1120, 1121, 1122, 1124, 1126, 1128, 1129, 1131, 1134, 1137, 1139, 1140, 1141, 1142, 1143, 1145, 1146, 1147, 1149, 1150, 1153, 1154, 1156, 1158, 1162, 1163, 1165, 1169, 1171, 1172, 1173, 1175, 1177, 1178, 1179, 1180, 1182, 1184, 1187, 1192, 1194, 1196, 1199, 1201, 1202, 1203, 1207, 1208, 1209, 1212, 1214, 1216, 1221, 1223, 1224, 1226, 1227, 1229, 1230, 1232, 1234, 1238, 1239, 1242, 1243, 1246, 1247, 1248, 1249, 1250, 1251, 1253, 1255, 1259, 1261, 1262, 1266, 1273, 1275, 1276, 1277, 1279, 1282, 1283, 1285, 1286, 1288, 1292, 1293, 1294, 1296, 1297, 1298, 1299, 1302, 1305, 1306, 1308, 1309, 1311, 1313, 1315, 1318, 1320, 1322, 1324, 1326, 1328, 1330, 1332, 1335, 1336, 1338, 1339, 1341, 1345, 1347, 1349, 1350, 1352, 1353, 1355, 1359, 1361, 1363, 1365, 1367, 1368, 1369, 1372, 1373, 1374, 1377, 1380, 1384, 1385, 1388, 1390, 1391, 1393, 1396, 1400, 1402, 1403, 1405, 1406, 1408, 1410, 1413, 1415, 1417, 1418, 1421, 1422, 1425, 1427, 1428, 1430, 1432, 1433, 1434, 1435, 1436, 1437, 1438, 1443, 1444, 1446, 1447, 1448, 1453, 1454, 1455, 1457, 1460, 1462, 1463, 1465, 1468, 1470, 1472, 1476, 1478, 1480, 1481, 1482, 1484, 1485, 1486, 1487, 1490, 1493, 1494, 1497, 1498, 1501, 1502, 1508, 1510, 1513, 1514, 1515, 1516, 1518, 1520, 1521, 1522, 1524, 1525, 1527, 1529, 1530, 1531, 1533, 1535, 1536, 1539, 1540, 1541, 1542, 1543, 1544, 1546, 1549, 1550, 1552, 1555, 1557, 1559, 1561, 1563, 1564, 1566, 1567, 1568, 1570, 1571, 1573, 1575, 1577, 1578, 1580, 1581, 1582, 1583, 1585, 1587, 1589, 1592, 1593, 1595, 1597, 1598, 1600, 1601, 1602, 1604, 1606, 1607, 1608, 1611, 1616, 1618, 1620, 1621, 1623, 1625, 1626, 1628, 1631, 1633, 1635, 1637, 1639, 1641, 1642, 1644, 1646, 1647, 1648, 1649, 1652, 1653, 1655, 1656, 1660, 1662, 1664, 1667, 1668, 1670, 1672, 1674, 1675, 1676, 1677, 1678, 1683, 1686, 1691, 1693, 1695, 1697, 1699, 1701, 1705, 1706, 1710, 1711, 1712, 1714, 1715, 1717, 1718, 1720, 1722, 1726, 1728, 1729, 1733, 1734, 1736, 1738, 1740, 1742, 1743, 1745, 1746, 1748, 1750, 1752, 1753, 1759, 1762, 1763, 1766, 1768, 1770, 1771, 1772, 1773, 1774, 1777, 1778, 1779, 1782, 1784, 1786, 1790, 1792, 1798, 1800, 1801, 1802, 1804, 1808, 1810, 1813, 1816, 1818, 1819, 1821, 1822, 1823, 1824, 1829, 1832, 1834, 1836, 1837, 1839, 1842, 1845, 1847, 1848, 1850, 1852, 1856, 1861, 1862, 1864, 1865, 1866, 1867, 1869, 1871, 1872, 1874, 1876, 1878, 1881, 1882, 1883, 1885, 1886, 1887, 1888, 1889, 1891, 1892, 1893, 1894, 1895, 1896, 1898, 1899, 1900, 1901, 1902, 1905, 1908, 1911, 1914, 1915, 1917, 1919, 1920, 1924, 1927, 1928, 1930, 1932, 1936, 1938, 1939, 1941, 1942, 1945, 1947, 1948, 1950, 1951, 1952, 1954, 1956, 1957, 1959, 1961, 1963, 1965, 1966, 1967, 1970, 1973, 1975, 1976, 1977, 1978, 1982, 1983, 1984, 1985, 1986, 1987, 1990, 1991, 1993, 1994, 1996, 1997, 1999], deadline = 2)
        configuration.add_task(name="Task6", identifier=6, period=3.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.175442, et_stddev=0.05848066666666666 , list_activation_dates=[2, 12, 17, 22, 41, 49, 53, 59, 68, 71, 76, 81, 84, 87, 95, 101, 106, 110, 114, 123, 127, 133, 142, 146, 155, 159, 162, 166, 172, 180, 185, 190, 195, 202, 207, 212, 216, 219, 226, 232, 240, 248, 252, 257, 262, 268, 274, 285, 289, 294, 297, 301, 305, 312, 317, 323, 328, 332, 337, 340, 346, 350, 354, 359, 363, 367, 374, 377, 381, 386, 391, 400, 404, 408, 414, 423, 430, 439, 445, 456, 461, 464, 467, 473, 478, 483, 495, 499, 506, 512, 515, 522, 526, 530, 533, 542, 546, 554, 557, 565, 568, 575, 580, 584, 589, 595, 598, 602, 605, 610, 628, 631, 635, 640, 660, 663, 668, 675, 681, 688, 691, 696, 699, 707, 711, 717, 726, 731, 747, 751, 754, 758, 766, 774, 783, 790, 795, 799, 803, 809, 815, 818, 821, 828, 834, 840, 843, 849, 859, 864, 867, 870, 874, 879, 889, 893, 900, 905, 908, 920, 927, 931, 936, 939, 945, 950, 953, 960, 965, 969, 973, 977, 981, 995, 998, 1001, 1010, 1015, 1023, 1027, 1036, 1039, 1045, 1048, 1054, 1058, 1067, 1076, 1080, 1084, 1090, 1096, 1100, 1106, 1109, 1114, 1118, 1125, 1131, 1134, 1138, 1143, 1147, 1152, 1155, 1163, 1167, 1171, 1174, 1179, 1182, 1186, 1199, 1203, 1212, 1218, 1231, 1234, 1239, 1245, 1249, 1254, 1262, 1270, 1276, 1285, 1290, 1294, 1300, 1309, 1312, 1318, 1331, 1335, 1340, 1344, 1351, 1357, 1363, 1369, 1374, 1387, 1390, 1395, 1400, 1404, 1409, 1412, 1416, 1423, 1430, 1434, 1439, 1444, 1451, 1455, 1465, 1470, 1476, 1480, 1484, 1488, 1494, 1497, 1502, 1512, 1518, 1527, 1534, 1538, 1543, 1547, 1552, 1557, 1563, 1569, 1572, 1581, 1590, 1598, 1603, 1606, 1616, 1620, 1625, 1635, 1640, 1648, 1652, 1664, 1669, 1680, 1683, 1689, 1695, 1699, 1710, 1723, 1729, 1735, 1742, 1745, 1752, 1756, 1762, 1766, 1770, 1774, 1790, 1796, 1800, 1808, 1816, 1822, 1831, 1840, 1843, 1846, 1850, 1854, 1860, 1865, 1870, 1874, 1882, 1887, 1892, 1896, 1901, 1905, 1909, 1915, 1925, 1930, 1935, 1943, 1948, 1952, 1966, 1969, 1978, 1981, 1984, 1987, 1996, 2000], deadline = 2)
        configuration.add_task(name="Task3", identifier=3, period=37.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=31.230688, acet=31.230688, et_stddev=10.410229333333334, deadline= 58)
        configuration.add_task(name="Task5", identifier=5, period=1.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.132515, et_stddev=0.044171666666666665 , list_activation_dates=[2, 4, 5, 6, 7, 11, 13, 15, 16, 18, 19, 21, 23, 26, 29, 31, 32, 35, 36, 39, 40, 43, 44, 46, 48, 49, 51, 53, 57, 59, 61, 64, 69, 70, 72, 75, 76, 78, 79, 81, 83, 86, 89, 90, 93, 95, 96, 100, 102, 104, 106, 109, 112, 115, 116, 118, 122, 123, 124, 128, 129, 131, 133, 134, 135, 137, 141, 144, 147, 148, 151, 154, 158, 160, 163, 164, 166, 169, 173, 178, 181, 184, 186, 188, 189, 191, 192, 195, 197, 199, 200, 201, 203, 207, 210, 212, 214, 216, 217, 219, 220, 223, 225, 228, 229, 230, 231, 233, 236, 237, 241, 244, 247, 249, 251, 252, 255, 257, 259, 262, 266, 268, 271, 272, 273, 274, 277, 280, 283, 286, 289, 291, 293, 294, 296, 297, 298, 300, 302, 303, 307, 308, 311, 313, 315, 317, 318, 320, 322, 323, 325, 326, 328, 329, 331, 332, 334, 335, 337, 339, 340, 342, 345, 347, 350, 352, 355, 356, 357, 358, 359, 363, 364, 367, 369, 372, 374, 376, 379, 380, 382, 384, 388, 389, 390, 392, 393, 395, 397, 398, 399, 400, 402, 404, 405, 407, 410, 411, 417, 419, 422, 427, 429, 431, 433, 435, 436, 437, 439, 440, 442, 443, 445, 446, 447, 450, 451, 453, 454, 455, 456, 458, 460, 462, 464, 467, 469, 473, 474, 476, 478, 481, 482, 483, 487, 491, 492, 495, 497, 498, 500, 501, 506, 507, 508, 509, 510, 512, 513, 514, 517, 519, 520, 521, 522, 523, 525, 526, 527, 528, 532, 539, 541, 543, 544, 545, 547, 552, 553, 556, 559, 561, 563, 564, 566, 567, 569, 570, 573, 574, 575, 576, 578, 579, 580, 585, 587, 590, 591, 594, 597, 600, 602, 604, 605, 607, 609, 610, 611, 612, 613, 615, 617, 620, 622, 624, 626, 628, 629, 630, 631, 633, 635, 638, 639, 642, 645, 649, 652, 654, 656, 657, 664, 666, 668, 669, 673, 675, 676, 679, 684, 686, 687, 691, 693, 695, 696, 697, 699, 701, 703, 705, 706, 707, 708, 710, 712, 715, 716, 718, 720, 723, 725, 726, 727, 728, 729, 731, 733, 736, 739, 741, 743, 745, 747, 748, 749, 750, 752, 753, 754, 756, 758, 759, 760, 762, 763, 765, 766, 768, 770, 772, 773, 776, 777, 779, 781, 784, 786, 789, 792, 795, 799, 800, 802, 804, 805, 809, 811, 814, 817, 818, 821, 823, 826, 832, 834, 835, 837, 838, 841, 842, 844, 845, 848, 850, 853, 854, 855, 857, 859, 860, 861, 863, 865, 867, 868, 869, 870, 871, 873, 874, 877, 881, 883, 884, 885, 886, 888, 890, 891, 893, 895, 897, 899, 902, 904, 905, 907, 908, 910, 912, 914, 917, 918, 920, 922, 927, 929, 931, 934, 936, 937, 938, 939, 940, 942, 943, 946, 948, 951, 956, 960, 962, 965, 966, 967, 969, 972, 973, 974, 976, 977, 980, 982, 986, 987, 989, 991, 994, 995, 996, 997, 1000, 1002, 1003, 1006, 1008, 1009, 1010, 1012, 1013, 1014, 1017, 1018, 1019, 1021, 1025, 1031, 1033, 1035, 1036, 1039, 1041, 1043, 1045, 1046, 1048, 1052, 1054, 1056, 1059, 1060, 1061, 1064, 1066, 1068, 1072, 1073, 1075, 1077, 1079, 1082, 1084, 1088, 1090, 1091, 1092, 1094, 1095, 1096, 1097, 1098, 1100, 1102, 1105, 1108, 1111, 1113, 1121, 1124, 1125, 1128, 1129, 1135, 1136, 1137, 1138, 1139, 1140, 1148, 1151, 1152, 1153, 1154, 1156, 1159, 1160, 1162, 1164, 1168, 1170, 1172, 1173, 1175, 1178, 1183, 1184, 1185, 1187, 1189, 1191, 1193, 1195, 1196, 1197, 1200, 1203, 1205, 1208, 1209, 1211, 1212, 1213, 1214, 1216, 1218, 1221, 1224, 1225, 1227, 1229, 1231, 1232, 1233, 1235, 1237, 1238, 1239, 1244, 1246, 1248, 1251, 1253, 1254, 1255, 1257, 1259, 1261, 1264, 1267, 1268, 1270, 1271, 1273, 1277, 1279, 1282, 1283, 1284, 1286, 1288, 1291, 1293, 1297, 1300, 1302, 1304, 1306, 1307, 1309, 1313, 1315, 1321, 1323, 1326, 1330, 1333, 1335, 1336, 1338, 1340, 1342, 1343, 1347, 1349, 1353, 1354, 1359, 1361, 1368, 1370, 1373, 1374, 1376, 1378, 1379, 1381, 1383, 1385, 1387, 1388, 1389, 1390, 1392, 1395, 1396, 1399, 1400, 1403, 1404, 1408, 1411, 1412, 1415, 1416, 1417, 1420, 1421, 1422, 1425, 1426, 1427, 1430, 1432, 1434, 1436, 1437, 1438, 1440, 1442, 1443, 1444, 1446, 1448, 1449, 1451, 1453, 1457, 1459, 1462, 1464, 1466, 1467, 1468, 1470, 1472, 1473, 1475, 1477, 1478, 1479, 1481, 1483, 1484, 1487, 1491, 1492, 1496, 1497, 1498, 1499, 1503, 1506, 1507, 1510, 1511, 1512, 1513, 1519, 1520, 1523, 1524, 1527, 1528, 1529, 1530, 1532, 1533, 1535, 1536, 1538, 1539, 1541, 1543, 1544, 1545, 1547, 1549, 1550, 1553, 1554, 1555, 1558, 1560, 1562, 1563, 1566, 1568, 1569, 1570, 1573, 1574, 1576, 1578, 1579, 1581, 1586, 1587, 1589, 1590, 1592, 1594, 1596, 1597, 1599, 1600, 1601, 1604, 1606, 1607, 1608, 1610, 1612, 1613, 1614, 1616, 1618, 1620, 1622, 1624, 1629, 1634, 1635, 1636, 1638, 1643, 1644, 1646, 1648, 1652, 1653, 1656, 1658, 1660, 1661, 1662, 1666, 1668, 1670, 1671, 1674, 1676, 1678, 1682, 1683, 1685, 1687, 1689, 1691, 1693, 1695, 1698, 1700, 1702, 1704, 1705, 1706, 1707, 1708, 1710, 1712, 1715, 1718, 1720, 1723, 1726, 1727, 1731, 1732, 1735, 1737, 1739, 1741, 1743, 1746, 1747, 1750, 1753, 1755, 1758, 1759, 1761, 1764, 1765, 1766, 1768, 1769, 1770, 1772, 1773, 1775, 1777, 1780, 1781, 1783, 1784, 1785, 1789, 1793, 1794, 1796, 1798, 1800, 1802, 1804, 1805, 1807, 1812, 1813, 1815, 1816, 1819, 1820, 1823, 1825, 1827, 1829, 1832, 1835, 1836, 1840, 1842, 1844, 1845, 1846, 1849, 1851, 1852, 1853, 1855, 1856, 1858, 1859, 1860, 1862, 1863, 1864, 1866, 1870, 1871, 1872, 1874, 1875, 1876, 1877, 1880, 1881, 1883, 1885, 1886, 1890, 1894, 1896, 1897, 1900, 1902, 1904, 1906, 1908, 1910, 1913, 1914, 1916, 1918, 1919, 1920, 1922, 1924, 1925, 1928, 1930, 1931, 1934, 1936, 1938, 1941, 1944, 1945, 1947, 1950, 1951, 1952, 1953, 1956, 1957, 1958, 1959, 1961, 1963, 1964, 1967, 1970, 1971, 1972, 1973, 1976, 1977, 1979, 1983, 1984, 1987, 1988, 1989, 1990, 1992, 1994, 1997, 1999], deadline = 2)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "25")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "25")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "25")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "25")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task1", identifier=1, period=4.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=3.611512, acet=3.611512, et_stddev=1.2038373333333332, deadline= 8)
        configuration.add_task(name="Task4", identifier=4, period=1.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.114428, et_stddev=0.038142666666666665 , list_activation_dates=[1, 3, 4, 6, 9, 15, 16, 17, 20, 22, 25, 26, 29, 33, 35, 40, 41, 43, 46, 49, 50, 52, 54, 56, 59, 61, 66, 67, 69, 71, 72, 74, 77, 78, 79, 82, 87, 88, 90, 92, 94, 98, 101, 102, 103, 105, 106, 107, 108, 110, 111, 113, 118, 119, 120, 121, 122, 124, 125, 128, 131, 133, 135, 137, 139, 140, 144, 146, 149, 151, 152, 154, 155, 156, 158, 159, 160, 162, 163, 165, 166, 167, 168, 172, 173, 176, 177, 180, 182, 183, 185, 189, 191, 198, 201, 203, 205, 207, 208, 210, 211, 214, 215, 217, 218, 219, 220, 223, 224, 226, 227, 229, 230, 233, 237, 239, 241, 242, 246, 247, 248, 250, 251, 253, 254, 256, 257, 258, 260, 261, 262, 264, 265, 267, 270, 272, 274, 276, 278, 279, 280, 283, 285, 286, 289, 290, 291, 293, 296, 299, 302, 304, 307, 308, 309, 312, 314, 316, 318, 319, 322, 326, 328, 330, 332, 333, 334, 336, 339, 341, 343, 344, 345, 348, 350, 352, 354, 355, 359, 362, 363, 364, 368, 370, 371, 375, 377, 379, 385, 386, 388, 390, 396, 397, 399, 400, 402, 403, 404, 406, 407, 411, 414, 417, 419, 421, 423, 426, 428, 431, 432, 434, 436, 437, 438, 442, 443, 445, 447, 448, 449, 451, 452, 453, 455, 457, 460, 463, 465, 466, 468, 469, 471, 472, 474, 478, 480, 481, 484, 485, 486, 488, 490, 492, 495, 497, 499, 500, 501, 503, 504, 505, 507, 508, 509, 510, 513, 516, 518, 519, 520, 523, 525, 527, 528, 530, 531, 533, 535, 536, 538, 539, 541, 542, 544, 546, 547, 555, 556, 558, 560, 562, 563, 567, 568, 569, 570, 572, 573, 574, 575, 577, 579, 581, 582, 583, 587, 589, 593, 595, 596, 598, 599, 601, 604, 605, 606, 608, 610, 611, 614, 617, 619, 624, 626, 627, 629, 630, 631, 634, 636, 639, 641, 643, 646, 648, 649, 652, 653, 656, 659, 660, 661, 662, 665, 667, 669, 671, 673, 676, 680, 682, 683, 684, 688, 694, 697, 698, 699, 700, 701, 708, 710, 713, 718, 722, 724, 725, 727, 729, 731, 733, 736, 738, 739, 740, 741, 742, 744, 745, 746, 747, 749, 752, 754, 755, 757, 758, 759, 760, 761, 762, 763, 765, 768, 770, 775, 779, 781, 782, 784, 786, 788, 790, 791, 793, 795, 798, 802, 803, 804, 806, 807, 810, 813, 815, 818, 819, 821, 823, 825, 826, 827, 828, 832, 834, 835, 836, 837, 838, 839, 840, 842, 845, 850, 852, 855, 857, 858, 861, 863, 865, 868, 869, 870, 872, 873, 876, 881, 883, 887, 889, 890, 891, 893, 894, 895, 900, 902, 906, 908, 909, 910, 912, 913, 914, 916, 919, 921, 923, 924, 927, 928, 929, 930, 933, 935, 936, 937, 938, 939, 941, 942, 944, 945, 946, 948, 949, 950, 952, 953, 954, 956, 958, 961, 963, 965, 969, 970, 971, 973, 974, 976, 977, 979, 982, 984, 986, 988, 989, 990, 991, 993, 996, 998, 1000, 1001, 1003, 1007, 1009, 1011, 1013, 1015, 1016, 1018, 1019, 1021, 1025, 1028, 1030, 1031, 1033, 1035, 1036, 1039, 1043, 1047, 1049, 1051, 1052, 1053, 1055, 1056, 1059, 1060, 1062, 1064, 1066, 1068, 1069, 1070, 1072, 1073, 1076, 1078, 1079, 1080, 1082, 1083, 1084, 1085, 1089, 1091, 1092, 1093, 1096, 1098, 1104, 1106, 1108, 1112, 1115, 1117, 1118, 1119, 1122, 1123, 1124, 1127, 1128, 1129, 1131, 1135, 1136, 1139, 1140, 1142, 1144, 1147, 1150, 1153, 1155, 1157, 1161, 1163, 1165, 1166, 1168, 1170, 1171, 1172, 1173, 1175, 1176, 1177, 1180, 1182, 1183, 1185, 1188, 1190, 1192, 1194, 1196, 1198, 1201, 1203, 1207, 1208, 1209, 1210, 1212, 1214, 1216, 1221, 1224, 1227, 1228, 1230, 1231, 1233, 1235, 1239, 1244, 1245, 1247, 1248, 1250, 1252, 1253, 1255, 1256, 1258, 1261, 1263, 1264, 1265, 1267, 1273, 1275, 1276, 1279, 1280, 1283, 1284, 1285, 1288, 1291, 1292, 1293, 1295, 1297, 1298, 1300, 1302, 1304, 1307, 1308, 1309, 1310, 1312, 1313, 1315, 1318, 1320, 1322, 1324, 1325, 1327, 1330, 1332, 1335, 1336, 1339, 1342, 1343, 1344, 1345, 1348, 1350, 1352, 1353, 1357, 1358, 1359, 1362, 1363, 1365, 1366, 1368, 1370, 1371, 1372, 1373, 1375, 1376, 1378, 1379, 1382, 1384, 1386, 1389, 1390, 1392, 1395, 1396, 1398, 1399, 1401, 1402, 1406, 1407, 1408, 1410, 1412, 1413, 1415, 1417, 1418, 1420, 1422, 1424, 1426, 1427, 1428, 1429, 1431, 1433, 1434, 1435, 1436, 1437, 1440, 1444, 1445, 1449, 1450, 1451, 1453, 1457, 1458, 1460, 1464, 1467, 1470, 1471, 1474, 1476, 1478, 1480, 1483, 1485, 1488, 1490, 1492, 1493, 1494, 1495, 1497, 1499, 1500, 1503, 1504, 1507, 1511, 1512, 1514, 1516, 1517, 1518, 1520, 1522, 1524, 1525, 1526, 1527, 1529, 1530, 1531, 1532, 1535, 1536, 1538, 1540, 1542, 1543, 1544, 1545, 1550, 1552, 1554, 1555, 1556, 1558, 1560, 1561, 1563, 1564, 1568, 1569, 1572, 1574, 1576, 1580, 1582, 1583, 1586, 1587, 1589, 1591, 1594, 1595, 1598, 1599, 1600, 1602, 1604, 1606, 1609, 1612, 1614, 1615, 1619, 1621, 1623, 1625, 1628, 1630, 1631, 1633, 1636, 1639, 1640, 1644, 1645, 1647, 1649, 1651, 1653, 1658, 1659, 1666, 1668, 1669, 1670, 1671, 1673, 1676, 1677, 1680, 1681, 1683, 1685, 1688, 1689, 1691, 1692, 1693, 1695, 1697, 1699, 1701, 1703, 1705, 1707, 1709, 1711, 1714, 1715, 1716, 1720, 1721, 1722, 1723, 1725, 1726, 1728, 1729, 1731, 1733, 1736, 1737, 1738, 1744, 1746, 1750, 1752, 1753, 1754, 1755, 1756, 1757, 1758, 1759, 1761, 1762, 1764, 1767, 1772, 1774, 1775, 1777, 1778, 1780, 1781, 1783, 1789, 1790, 1792, 1796, 1798, 1801, 1803, 1805, 1807, 1809, 1810, 1813, 1815, 1816, 1818, 1820, 1821, 1822, 1824, 1826, 1828, 1831, 1832, 1834, 1838, 1840, 1842, 1844, 1846, 1848, 1849, 1851, 1853, 1855, 1857, 1859, 1863, 1865, 1867, 1870, 1871, 1872, 1874, 1875, 1878, 1880, 1882, 1883, 1885, 1887, 1889, 1890, 1892, 1893, 1898, 1899, 1901, 1903, 1904, 1905, 1906, 1908, 1910, 1912, 1913, 1914, 1915, 1918, 1921, 1922, 1923, 1924, 1926, 1929, 1931, 1934, 1935, 1938, 1940, 1941, 1943, 1944, 1947, 1949, 1952, 1953, 1954, 1955, 1958, 1960, 1963, 1965, 1967, 1968, 1970, 1973, 1975, 1977, 1979, 1982, 1983, 1984, 1986, 1988, 1990, 1993, 1994, 1998, 1999, 2000], deadline = 2)
        configuration.add_task(name="Task6", identifier=6, period=12.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=3, acet=2.052559, et_stddev=0.6841863333333333 , list_activation_dates=[24, 37, 83, 104, 135, 183, 197, 231, 308, 324, 351, 371, 384, 407, 429, 457, 512, 551, 564, 616, 630, 679, 707, 726, 739, 781, 797, 813, 838, 859, 876, 894, 908, 928, 948, 974, 995, 1023, 1061, 1097, 1125, 1138, 1181, 1201, 1270, 1286, 1319, 1364, 1412, 1431, 1447, 1478, 1524, 1538, 1552, 1576, 1588, 1603, 1616, 1635, 1653, 1666, 1687, 1714, 1749, 1764, 1782, 1795, 1823, 1844, 1881, 1905, 1933, 1952, 1975, 1997], deadline = 24)
        configuration.add_task(name="Task5", identifier=5, period=7.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.101672, et_stddev=0.033890666666666666 , list_activation_dates=[6, 26, 34, 45, 55, 63, 71, 86, 114, 126, 141, 154, 165, 174, 183, 193, 201, 210, 218, 228, 264, 282, 290, 311, 324, 335, 360, 368, 375, 383, 406, 422, 438, 450, 459, 476, 484, 500, 511, 519, 539, 554, 562, 573, 591, 603, 611, 622, 630, 647, 654, 679, 687, 695, 708, 721, 741, 758, 789, 806, 813, 822, 836, 847, 861, 870, 878, 891, 899, 908, 917, 929, 948, 969, 982, 994, 1008, 1015, 1023, 1034, 1046, 1060, 1080, 1087, 1104, 1112, 1122, 1131, 1145, 1166, 1182, 1191, 1214, 1222, 1233, 1248, 1261, 1298, 1316, 1326, 1345, 1359, 1378, 1405, 1412, 1427, 1447, 1466, 1496, 1504, 1517, 1534, 1547, 1567, 1577, 1590, 1611, 1623, 1638, 1647, 1657, 1669, 1687, 1694, 1706, 1734, 1752, 1770, 1783, 1794, 1806, 1824, 1836, 1847, 1860, 1874, 1889, 1916, 1923, 1943, 1957, 1970, 1979], deadline = 13)
        configuration.add_task(name="Task3", identifier=3, period=21.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=5.049335, acet=5.049335, et_stddev=1.6831116666666668, deadline= 18)
        configuration.add_task(name="Task2", identifier=2, period=30.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=13.700323, acet=13.700323, et_stddev=4.566774333333333, deadline= 27)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "26")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "26")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "26")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "26")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task1", identifier=1, period=9.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=2.009883, acet=2.009883, et_stddev=0.6699609999999999, deadline= 8)
        configuration.add_task(name="Task2", identifier=2, period=2.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=1.416113, acet=1.416113, et_stddev=0.47203766666666663, deadline= 3)
        configuration.add_task(name="Task4", identifier=4, period=3.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.231783, et_stddev=0.077261 , list_activation_dates=[5, 9, 13, 21, 27, 33, 56, 71, 82, 88, 92, 96, 106, 113, 120, 124, 127, 134, 138, 142, 145, 154, 157, 161, 166, 172, 176, 180, 188, 199, 208, 212, 215, 221, 226, 238, 244, 250, 253, 260, 265, 270, 276, 281, 285, 292, 297, 301, 305, 309, 313, 320, 326, 330, 333, 336, 341, 350, 356, 361, 368, 387, 394, 401, 409, 412, 415, 419, 424, 429, 438, 451, 454, 458, 466, 469, 473, 479, 489, 496, 500, 505, 510, 513, 530, 536, 540, 547, 551, 555, 560, 564, 569, 574, 578, 595, 599, 605, 613, 617, 622, 625, 629, 634, 637, 641, 650, 653, 657, 661, 666, 670, 673, 678, 681, 685, 695, 698, 709, 714, 719, 725, 731, 735, 744, 748, 751, 760, 768, 771, 777, 781, 786, 789, 793, 800, 804, 807, 813, 818, 836, 842, 845, 849, 853, 856, 860, 864, 870, 873, 881, 894, 897, 907, 912, 915, 918, 925, 931, 938, 945, 951, 955, 959, 962, 965, 974, 986, 991, 996, 999, 1003, 1009, 1014, 1018, 1022, 1025, 1031, 1057, 1067, 1084, 1089, 1095, 1101, 1106, 1111, 1116, 1120, 1126, 1131, 1134, 1141, 1144, 1149, 1154, 1158, 1165, 1174, 1194, 1203, 1206, 1212, 1215, 1220, 1227, 1230, 1233, 1237, 1245, 1251, 1261, 1275, 1284, 1288, 1292, 1297, 1300, 1309, 1315, 1320, 1324, 1328, 1332, 1339, 1342, 1349, 1352, 1362, 1368, 1371, 1376, 1384, 1387, 1391, 1400, 1412, 1418, 1426, 1429, 1437, 1447, 1457, 1461, 1466, 1474, 1480, 1486, 1492, 1499, 1506, 1512, 1515, 1522, 1530, 1535, 1548, 1554, 1560, 1564, 1575, 1581, 1587, 1594, 1598, 1608, 1614, 1618, 1622, 1630, 1634, 1638, 1641, 1647, 1651, 1657, 1662, 1665, 1672, 1676, 1684, 1690, 1693, 1702, 1706, 1710, 1714, 1717, 1727, 1733, 1737, 1742, 1746, 1761, 1768, 1771, 1785, 1789, 1794, 1802, 1806, 1812, 1816, 1822, 1826, 1831, 1839, 1842, 1849, 1856, 1862, 1866, 1875, 1881, 1884, 1897, 1900, 1905, 1914, 1917, 1920, 1928, 1932, 1939, 1945, 1948, 1951, 1955, 1962, 1965, 1971, 1978, 1981, 1989, 1996, 2000], deadline = 6)
        configuration.add_task(name="Task6", identifier=6, period=10.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=2, acet=1.010638, et_stddev=0.3368793333333333 , list_activation_dates=[2, 18, 50, 60, 76, 105, 138, 153, 164, 178, 205, 217, 230, 241, 254, 265, 279, 300, 312, 331, 342, 365, 377, 387, 400, 417, 441, 454, 470, 487, 506, 540, 555, 567, 584, 596, 634, 670, 684, 698, 718, 728, 747, 759, 778, 792, 804, 816, 867, 879, 893, 925, 955, 977, 992, 1018, 1034, 1048, 1060, 1073, 1101, 1124, 1145, 1160, 1179, 1208, 1243, 1284, 1300, 1315, 1334, 1347, 1379, 1415, 1427, 1444, 1455, 1467, 1481, 1516, 1532, 1544, 1559, 1571, 1594, 1643, 1659, 1674, 1699, 1731, 1749, 1767, 1781, 1792, 1835, 1847, 1895, 1910, 1922, 1935, 1952, 1963, 1983], deadline = 11)
        configuration.add_task(name="Task5", identifier=5, period=4.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.4867, et_stddev=0.16223333333333334 , list_activation_dates=[6, 24, 33, 39, 48, 52, 62, 80, 85, 102, 110, 127, 142, 152, 160, 173, 179, 187, 197, 202, 207, 212, 225, 231, 237, 249, 257, 262, 270, 284, 290, 296, 303, 309, 314, 320, 329, 338, 346, 355, 362, 382, 388, 394, 401, 408, 412, 431, 436, 448, 453, 462, 478, 483, 489, 494, 499, 505, 518, 527, 535, 542, 547, 553, 558, 564, 572, 579, 591, 597, 608, 613, 619, 626, 633, 638, 650, 657, 662, 667, 673, 682, 689, 698, 705, 711, 717, 725, 731, 735, 743, 756, 762, 766, 773, 781, 785, 792, 807, 828, 839, 844, 849, 854, 860, 867, 873, 881, 887, 894, 906, 922, 930, 935, 944, 955, 965, 970, 982, 992, 1000, 1004, 1010, 1018, 1030, 1040, 1051, 1064, 1072, 1083, 1094, 1103, 1110, 1114, 1119, 1126, 1134, 1142, 1154, 1162, 1167, 1172, 1177, 1201, 1209, 1220, 1227, 1231, 1236, 1241, 1251, 1258, 1263, 1267, 1273, 1281, 1288, 1292, 1303, 1324, 1334, 1346, 1355, 1360, 1364, 1368, 1374, 1379, 1387, 1396, 1400, 1413, 1418, 1424, 1432, 1438, 1444, 1474, 1479, 1501, 1507, 1516, 1523, 1534, 1541, 1546, 1552, 1560, 1564, 1572, 1581, 1585, 1596, 1600, 1604, 1608, 1613, 1619, 1626, 1631, 1635, 1646, 1654, 1661, 1665, 1671, 1676, 1683, 1694, 1699, 1709, 1713, 1724, 1734, 1742, 1751, 1757, 1764, 1768, 1778, 1787, 1794, 1801, 1809, 1820, 1825, 1835, 1841, 1845, 1851, 1857, 1861, 1867, 1874, 1884, 1895, 1900, 1906, 1911, 1925, 1931, 1935, 1941, 1949, 1953, 1965, 1969, 1974, 1983, 1991], deadline = 5)
        configuration.add_task(name="Task3", identifier=3, period=2.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=1.337246, acet=1.337246, et_stddev=0.4457486666666666, deadline= 4)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "27")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "27")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "27")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "27")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task5", identifier=5, period=2.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.003761, et_stddev=0.0012536666666666666 , list_activation_dates=[9, 11, 14, 19, 26, 28, 32, 38, 45, 48, 55, 57, 60, 63, 70, 72, 74, 77, 79, 81, 84, 86, 91, 97, 99, 103, 105, 107, 110, 112, 116, 118, 126, 129, 132, 134, 136, 139, 142, 145, 150, 154, 157, 161, 164, 170, 172, 178, 181, 189, 193, 196, 198, 202, 204, 208, 211, 213, 217, 226, 229, 233, 236, 238, 241, 247, 249, 255, 264, 267, 271, 274, 277, 283, 288, 291, 295, 298, 300, 302, 308, 310, 316, 318, 325, 328, 330, 333, 338, 341, 345, 354, 356, 360, 363, 369, 372, 375, 385, 391, 394, 396, 400, 406, 415, 420, 422, 425, 427, 430, 433, 437, 439, 443, 449, 452, 455, 460, 465, 467, 470, 476, 479, 481, 483, 485, 488, 491, 494, 498, 503, 506, 510, 513, 517, 521, 523, 527, 531, 533, 538, 543, 547, 551, 555, 558, 562, 564, 570, 574, 578, 581, 589, 591, 595, 597, 599, 605, 608, 610, 612, 615, 618, 627, 630, 632, 640, 642, 645, 648, 650, 654, 656, 659, 662, 664, 672, 675, 678, 681, 683, 685, 688, 696, 701, 705, 711, 715, 720, 724, 731, 738, 741, 749, 752, 755, 762, 777, 780, 783, 785, 789, 791, 799, 802, 818, 822, 825, 831, 839, 841, 844, 846, 850, 853, 857, 860, 863, 867, 870, 872, 875, 878, 882, 885, 890, 893, 904, 907, 912, 915, 919, 925, 929, 933, 938, 941, 944, 947, 950, 952, 955, 959, 962, 964, 973, 980, 987, 991, 997, 1001, 1006, 1011, 1014, 1016, 1019, 1022, 1027, 1029, 1034, 1037, 1039, 1043, 1047, 1049, 1053, 1059, 1065, 1070, 1074, 1076, 1078, 1086, 1088, 1091, 1093, 1099, 1102, 1105, 1107, 1114, 1116, 1120, 1124, 1126, 1129, 1132, 1135, 1138, 1141, 1145, 1151, 1153, 1157, 1166, 1173, 1175, 1179, 1184, 1189, 1191, 1196, 1199, 1202, 1211, 1220, 1223, 1227, 1230, 1232, 1234, 1237, 1241, 1245, 1249, 1252, 1263, 1266, 1268, 1271, 1274, 1279, 1283, 1289, 1294, 1296, 1299, 1303, 1305, 1313, 1317, 1320, 1328, 1331, 1335, 1337, 1339, 1341, 1344, 1346, 1348, 1352, 1356, 1361, 1364, 1371, 1376, 1380, 1385, 1389, 1393, 1395, 1397, 1400, 1406, 1408, 1413, 1418, 1421, 1423, 1428, 1430, 1434, 1439, 1449, 1451, 1453, 1457, 1459, 1462, 1464, 1466, 1474, 1478, 1480, 1483, 1486, 1493, 1503, 1506, 1508, 1513, 1516, 1523, 1526, 1529, 1532, 1534, 1538, 1542, 1545, 1551, 1554, 1557, 1563, 1574, 1582, 1585, 1591, 1601, 1603, 1605, 1608, 1610, 1614, 1621, 1627, 1631, 1633, 1640, 1645, 1651, 1658, 1662, 1667, 1673, 1678, 1681, 1683, 1687, 1690, 1695, 1704, 1708, 1716, 1718, 1727, 1730, 1732, 1737, 1743, 1746, 1752, 1761, 1766, 1768, 1773, 1778, 1784, 1786, 1793, 1796, 1802, 1805, 1808, 1810, 1813, 1816, 1819, 1824, 1829, 1832, 1838, 1845, 1847, 1849, 1851, 1853, 1859, 1863, 1866, 1873, 1878, 1880, 1889, 1891, 1895, 1899, 1907, 1911, 1914, 1918, 1925, 1927, 1929, 1933, 1938, 1944, 1949, 1952, 1954, 1958, 1961, 1967, 1969, 1975, 1978, 1984, 1989, 1994, 1996], deadline = 3)
        configuration.add_task(name="Task4", identifier=4, period=5.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.201823, et_stddev=0.06727433333333334 , list_activation_dates=[2, 16, 24, 32, 39, 50, 57, 70, 77, 89, 98, 104, 110, 116, 122, 130, 139, 146, 155, 172, 184, 193, 199, 212, 223, 228, 234, 248, 267, 279, 287, 293, 303, 309, 333, 349, 356, 371, 392, 405, 424, 433, 441, 456, 464, 473, 480, 490, 520, 540, 547, 553, 561, 567, 572, 578, 584, 599, 611, 621, 630, 643, 649, 663, 695, 701, 712, 732, 738, 743, 752, 767, 776, 781, 789, 801, 809, 818, 827, 845, 851, 861, 868, 874, 887, 896, 905, 910, 925, 932, 940, 948, 958, 964, 970, 978, 987, 995, 1004, 1015, 1029, 1035, 1041, 1054, 1061, 1070, 1096, 1118, 1125, 1131, 1146, 1159, 1167, 1183, 1194, 1200, 1205, 1212, 1217, 1224, 1246, 1255, 1264, 1276, 1284, 1291, 1307, 1314, 1324, 1335, 1350, 1358, 1364, 1379, 1391, 1407, 1419, 1427, 1432, 1439, 1444, 1449, 1455, 1462, 1483, 1492, 1501, 1507, 1517, 1522, 1534, 1543, 1548, 1554, 1564, 1572, 1579, 1589, 1597, 1603, 1619, 1628, 1635, 1644, 1651, 1656, 1679, 1703, 1710, 1717, 1739, 1746, 1754, 1767, 1776, 1783, 1797, 1805, 1810, 1827, 1836, 1843, 1849, 1860, 1865, 1871, 1878, 1884, 1898, 1905, 1911, 1923, 1930, 1940, 1945, 1955, 1961, 1969, 1977, 1988, 1998], deadline = 3)
        configuration.add_task(name="Task3", identifier=3, period=11.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=4.244959, acet=4.244959, et_stddev=1.4149863333333332, deadline= 12)
        configuration.add_task(name="Task6", identifier=6, period=15.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=4, acet=3.866315, et_stddev=1.2887716666666666 , list_activation_dates=[8, 29, 52, 103, 124, 142, 179, 196, 217, 249, 316, 360, 378, 395, 432, 454, 478, 523, 539, 582, 606, 653, 676, 701, 731, 756, 787, 821, 838, 855, 893, 911, 933, 957, 1015, 1038, 1072, 1087, 1131, 1173, 1208, 1230, 1265, 1286, 1311, 1342, 1379, 1405, 1436, 1473, 1507, 1525, 1573, 1622, 1638, 1666, 1689, 1730, 1798, 1843, 1868, 1933, 1964, 1981], deadline = 26)
        configuration.add_task(name="Task1", identifier=1, period=27.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=17.157061, acet=17.157061, et_stddev=5.719020333333333, deadline= 31)
        configuration.add_task(name="Task2", identifier=2, period=3.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=1.735943, acet=1.735943, et_stddev=0.5786476666666667, deadline= 4)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "29")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "29")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "29")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "29")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task5", identifier=5, period=23.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.458186, et_stddev=0.15272866666666665 , list_activation_dates=[7, 96, 132, 166, 189, 332, 370, 430, 512, 610, 634, 677, 707, 780, 880, 923, 984, 1041, 1129, 1156, 1234, 1286, 1329, 1353, 1407, 1434, 1496, 1529, 1555, 1614, 1651, 1706, 1742, 1813, 1947, 1990], deadline = 35)
        configuration.add_task(name="Task2", identifier=2, period=33.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=32.875217, acet=32.875217, et_stddev=10.958405666666666, deadline= 42)
        configuration.add_task(name="Task6", identifier=6, period=2.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.554876, et_stddev=0.1849586666666667 , list_activation_dates=[1, 4, 7, 10, 22, 25, 30, 33, 37, 40, 42, 45, 51, 57, 60, 64, 67, 70, 73, 77, 79, 82, 85, 90, 93, 96, 101, 103, 106, 108, 111, 114, 120, 123, 126, 129, 133, 139, 141, 148, 152, 157, 160, 162, 165, 171, 175, 177, 182, 185, 197, 201, 206, 210, 212, 220, 224, 226, 228, 240, 243, 246, 251, 254, 256, 259, 262, 265, 272, 277, 280, 284, 289, 294, 296, 299, 301, 305, 309, 313, 316, 319, 321, 325, 329, 332, 336, 340, 344, 350, 353, 358, 362, 371, 374, 378, 380, 389, 393, 396, 400, 403, 408, 411, 418, 428, 435, 438, 442, 447, 455, 465, 468, 471, 475, 480, 482, 485, 489, 493, 497, 500, 506, 510, 512, 514, 518, 520, 522, 527, 529, 532, 536, 539, 542, 544, 548, 553, 556, 560, 562, 564, 567, 570, 572, 576, 578, 580, 591, 596, 598, 604, 607, 613, 615, 617, 620, 622, 631, 634, 644, 647, 649, 653, 656, 660, 663, 666, 672, 674, 679, 683, 685, 688, 691, 698, 701, 703, 706, 711, 713, 719, 726, 730, 733, 737, 743, 747, 753, 757, 760, 766, 770, 774, 777, 780, 783, 787, 791, 795, 805, 807, 810, 813, 819, 824, 826, 829, 831, 835, 838, 841, 843, 845, 848, 851, 859, 863, 865, 869, 875, 877, 886, 888, 890, 894, 896, 901, 904, 906, 908, 913, 916, 919, 921, 930, 934, 937, 945, 948, 954, 960, 966, 974, 978, 980, 983, 987, 989, 993, 998, 1002, 1007, 1014, 1016, 1023, 1025, 1028, 1033, 1036, 1041, 1046, 1048, 1053, 1059, 1068, 1073, 1075, 1077, 1080, 1084, 1087, 1089, 1093, 1099, 1102, 1104, 1106, 1111, 1118, 1121, 1132, 1134, 1137, 1141, 1149, 1154, 1156, 1158, 1161, 1166, 1168, 1170, 1175, 1181, 1186, 1189, 1191, 1195, 1200, 1203, 1206, 1209, 1211, 1213, 1217, 1223, 1226, 1229, 1231, 1235, 1241, 1243, 1248, 1251, 1255, 1257, 1259, 1262, 1265, 1268, 1271, 1276, 1278, 1280, 1283, 1290, 1293, 1295, 1298, 1306, 1308, 1311, 1318, 1320, 1322, 1327, 1331, 1334, 1336, 1339, 1342, 1344, 1347, 1349, 1353, 1357, 1359, 1363, 1371, 1375, 1378, 1381, 1384, 1386, 1389, 1393, 1398, 1400, 1404, 1411, 1413, 1421, 1426, 1428, 1431, 1436, 1440, 1443, 1450, 1455, 1460, 1466, 1470, 1475, 1478, 1480, 1486, 1490, 1492, 1496, 1509, 1512, 1515, 1523, 1526, 1530, 1532, 1534, 1537, 1539, 1541, 1547, 1550, 1558, 1561, 1563, 1565, 1568, 1572, 1575, 1579, 1581, 1587, 1591, 1595, 1598, 1600, 1602, 1604, 1607, 1610, 1612, 1616, 1619, 1621, 1623, 1628, 1631, 1634, 1640, 1642, 1645, 1648, 1654, 1657, 1664, 1667, 1670, 1672, 1679, 1682, 1685, 1689, 1693, 1701, 1703, 1705, 1712, 1719, 1722, 1725, 1727, 1729, 1732, 1735, 1740, 1745, 1748, 1753, 1755, 1761, 1766, 1771, 1776, 1784, 1791, 1797, 1802, 1809, 1815, 1818, 1821, 1827, 1833, 1840, 1845, 1847, 1849, 1851, 1854, 1860, 1863, 1871, 1876, 1880, 1884, 1887, 1890, 1894, 1911, 1917, 1920, 1923, 1926, 1928, 1931, 1933, 1939, 1945, 1947, 1955, 1960, 1967, 1975, 1980, 1987, 1992, 1994, 1998], deadline = 2)
        configuration.add_task(name="Task1", identifier=1, period=4.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=0.782369, acet=0.782369, et_stddev=0.26078966666666664, deadline= 1)
        configuration.add_task(name="Task4", identifier=4, period=1.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.00264, et_stddev=0.00088 , list_activation_dates=[1, 2, 3, 6, 8, 10, 11, 12, 14, 18, 20, 23, 25, 27, 29, 31, 33, 35, 37, 42, 44, 46, 49, 50, 53, 56, 58, 59, 61, 62, 64, 65, 67, 69, 70, 72, 76, 77, 81, 82, 84, 85, 87, 88, 89, 91, 92, 93, 95, 96, 97, 99, 100, 104, 106, 108, 110, 112, 113, 117, 118, 119, 120, 121, 122, 125, 126, 127, 130, 136, 138, 139, 140, 141, 142, 144, 146, 148, 150, 152, 153, 156, 157, 158, 162, 164, 165, 166, 168, 170, 172, 173, 175, 179, 181, 182, 183, 186, 188, 190, 191, 194, 195, 196, 197, 198, 200, 202, 204, 208, 209, 210, 212, 214, 216, 218, 220, 226, 228, 230, 232, 238, 240, 241, 243, 244, 246, 248, 250, 251, 254, 256, 259, 261, 266, 267, 269, 271, 273, 274, 276, 278, 280, 282, 283, 286, 289, 292, 293, 295, 298, 299, 301, 303, 305, 308, 312, 314, 316, 317, 318, 320, 321, 324, 326, 327, 330, 331, 333, 335, 338, 340, 342, 343, 345, 346, 348, 351, 352, 354, 357, 358, 359, 365, 366, 368, 370, 371, 373, 376, 378, 379, 380, 382, 384, 386, 388, 389, 393, 395, 398, 399, 400, 402, 405, 406, 407, 409, 412, 413, 414, 416, 418, 419, 420, 423, 426, 428, 430, 431, 433, 434, 435, 437, 439, 441, 443, 447, 450, 451, 452, 454, 455, 456, 459, 461, 464, 466, 467, 468, 470, 472, 475, 477, 479, 481, 482, 483, 484, 485, 489, 492, 494, 495, 500, 502, 505, 508, 511, 514, 518, 519, 520, 522, 523, 524, 526, 527, 532, 535, 537, 539, 540, 541, 543, 544, 550, 552, 553, 556, 557, 558, 562, 563, 565, 566, 568, 570, 571, 573, 576, 577, 582, 584, 586, 590, 592, 593, 594, 595, 596, 598, 599, 601, 603, 607, 608, 610, 611, 612, 615, 616, 617, 618, 620, 622, 623, 624, 627, 630, 633, 634, 636, 639, 641, 642, 644, 648, 649, 650, 651, 653, 655, 657, 658, 661, 662, 664, 667, 671, 672, 674, 676, 678, 680, 682, 683, 684, 686, 689, 691, 693, 694, 695, 700, 701, 705, 706, 708, 713, 715, 717, 720, 721, 722, 725, 726, 727, 729, 730, 732, 734, 736, 738, 739, 741, 743, 745, 756, 758, 759, 760, 762, 763, 764, 765, 769, 771, 772, 774, 777, 779, 780, 781, 782, 783, 784, 785, 786, 788, 789, 791, 796, 798, 799, 800, 802, 803, 806, 808, 810, 812, 813, 815, 817, 818, 820, 821, 823, 825, 826, 832, 834, 835, 837, 841, 842, 843, 844, 846, 848, 850, 852, 853, 855, 857, 858, 859, 860, 864, 867, 869, 871, 874, 880, 882, 885, 887, 890, 896, 902, 903, 905, 907, 908, 909, 911, 912, 914, 918, 919, 924, 928, 931, 933, 934, 937, 940, 944, 945, 947, 948, 953, 954, 957, 958, 960, 962, 966, 967, 968, 971, 974, 976, 977, 979, 981, 982, 984, 989, 991, 993, 997, 998, 1000, 1001, 1002, 1004, 1006, 1008, 1010, 1011, 1013, 1014, 1016, 1017, 1019, 1024, 1027, 1029, 1031, 1033, 1035, 1039, 1045, 1046, 1048, 1052, 1054, 1055, 1057, 1061, 1065, 1068, 1070, 1071, 1073, 1075, 1078, 1079, 1081, 1082, 1083, 1085, 1086, 1087, 1092, 1093, 1095, 1097, 1100, 1103, 1105, 1107, 1108, 1110, 1112, 1113, 1114, 1116, 1118, 1123, 1125, 1129, 1131, 1133, 1136, 1137, 1139, 1141, 1143, 1145, 1147, 1149, 1151, 1155, 1156, 1161, 1164, 1166, 1168, 1170, 1172, 1173, 1174, 1177, 1184, 1186, 1188, 1191, 1193, 1194, 1197, 1199, 1202, 1203, 1205, 1207, 1208, 1210, 1211, 1213, 1215, 1217, 1218, 1219, 1220, 1225, 1227, 1229, 1231, 1232, 1233, 1235, 1236, 1237, 1239, 1240, 1242, 1243, 1244, 1245, 1248, 1249, 1250, 1252, 1254, 1256, 1257, 1260, 1262, 1265, 1266, 1268, 1270, 1271, 1273, 1274, 1278, 1281, 1284, 1286, 1290, 1291, 1292, 1293, 1294, 1297, 1300, 1302, 1304, 1308, 1311, 1314, 1316, 1318, 1320, 1321, 1323, 1324, 1326, 1327, 1328, 1330, 1331, 1333, 1336, 1338, 1340, 1342, 1343, 1346, 1347, 1351, 1352, 1354, 1356, 1359, 1364, 1367, 1368, 1370, 1371, 1375, 1376, 1378, 1381, 1383, 1384, 1386, 1389, 1391, 1393, 1394, 1399, 1402, 1404, 1406, 1408, 1410, 1412, 1414, 1415, 1417, 1419, 1420, 1421, 1422, 1426, 1427, 1429, 1432, 1433, 1435, 1438, 1441, 1443, 1444, 1446, 1448, 1451, 1453, 1455, 1457, 1458, 1459, 1460, 1462, 1466, 1469, 1471, 1473, 1475, 1477, 1479, 1480, 1482, 1484, 1485, 1487, 1489, 1490, 1492, 1494, 1495, 1497, 1498, 1499, 1501, 1502, 1503, 1504, 1506, 1509, 1510, 1512, 1515, 1520, 1523, 1525, 1527, 1528, 1529, 1532, 1534, 1535, 1536, 1538, 1539, 1540, 1541, 1542, 1544, 1545, 1548, 1550, 1552, 1554, 1555, 1556, 1558, 1559, 1560, 1562, 1564, 1565, 1567, 1568, 1570, 1571, 1573, 1574, 1579, 1580, 1582, 1584, 1587, 1588, 1591, 1592, 1593, 1594, 1596, 1597, 1600, 1601, 1602, 1604, 1607, 1610, 1611, 1612, 1613, 1614, 1615, 1616, 1617, 1618, 1619, 1621, 1623, 1625, 1626, 1627, 1628, 1631, 1632, 1634, 1636, 1638, 1643, 1644, 1646, 1647, 1648, 1649, 1650, 1651, 1653, 1655, 1657, 1659, 1660, 1662, 1664, 1667, 1669, 1670, 1671, 1673, 1674, 1676, 1678, 1679, 1680, 1682, 1683, 1684, 1686, 1689, 1690, 1693, 1695, 1696, 1697, 1698, 1699, 1700, 1701, 1702, 1703, 1704, 1705, 1710, 1711, 1714, 1718, 1720, 1721, 1725, 1726, 1727, 1734, 1736, 1738, 1742, 1744, 1746, 1748, 1750, 1752, 1755, 1756, 1760, 1762, 1765, 1769, 1770, 1771, 1774, 1775, 1777, 1779, 1780, 1782, 1784, 1785, 1786, 1788, 1790, 1791, 1792, 1794, 1796, 1798, 1802, 1803, 1804, 1807, 1809, 1810, 1811, 1813, 1814, 1817, 1819, 1820, 1822, 1825, 1826, 1828, 1830, 1831, 1832, 1834, 1836, 1838, 1840, 1841, 1842, 1843, 1845, 1847, 1853, 1854, 1855, 1857, 1859, 1864, 1865, 1867, 1870, 1872, 1874, 1876, 1877, 1879, 1883, 1885, 1886, 1889, 1890, 1891, 1898, 1900, 1902, 1904, 1905, 1907, 1909, 1910, 1913, 1916, 1917, 1920, 1922, 1924, 1928, 1930, 1931, 1933, 1934, 1935, 1936, 1938, 1940, 1941, 1943, 1945, 1946, 1947, 1948, 1950, 1952, 1954, 1955, 1957, 1958, 1959, 1960, 1961, 1963, 1964, 1972, 1973, 1977, 1978, 1981, 1983, 1984, 1986, 1987, 1988, 1991, 1993, 1995, 1996, 1999, 2000], deadline = 1)
        configuration.add_task(name="Task3", identifier=3, period=8.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=3.265511, acet=3.265511, et_stddev=1.0885036666666668, deadline= 7)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "31")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "31")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "31")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "31")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task5", identifier=5, period=17.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.226166, et_stddev=0.07538866666666667 , list_activation_dates=[9, 31, 58, 85, 103, 137, 159, 180, 204, 237, 255, 277, 309, 338, 380, 403, 423, 442, 465, 491, 516, 579, 606, 647, 713, 750, 799, 826, 857, 877, 937, 1022, 1060, 1078, 1097, 1118, 1167, 1186, 1219, 1282, 1301, 1327, 1345, 1372, 1394, 1416, 1446, 1477, 1508, 1559, 1610, 1639, 1665, 1706, 1750, 1769, 1822, 1840, 1910, 1929, 1947, 1966, 1993], deadline = 11)
        configuration.add_task(name="Task3", identifier=3, period=3.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=0.202932, acet=0.202932, et_stddev=0.067644, deadline= 6)
        configuration.add_task(name="Task4", identifier=4, period=4.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.287327, et_stddev=0.09577566666666666 , list_activation_dates=[2, 8, 22, 28, 32, 36, 41, 56, 78, 92, 97, 102, 107, 113, 124, 134, 142, 147, 155, 162, 169, 173, 179, 192, 198, 202, 206, 212, 217, 227, 232, 239, 251, 256, 267, 273, 283, 299, 312, 327, 332, 336, 341, 347, 352, 362, 370, 374, 380, 394, 403, 408, 413, 418, 423, 428, 432, 438, 444, 450, 458, 467, 488, 494, 500, 510, 518, 530, 534, 539, 557, 571, 575, 582, 586, 597, 603, 607, 619, 628, 635, 643, 648, 654, 660, 675, 680, 687, 701, 708, 717, 724, 730, 740, 751, 787, 791, 796, 803, 810, 817, 825, 832, 837, 842, 847, 869, 874, 879, 888, 894, 902, 908, 912, 917, 923, 927, 938, 942, 947, 952, 961, 966, 970, 981, 987, 993, 1000, 1007, 1012, 1017, 1024, 1032, 1040, 1045, 1053, 1058, 1063, 1069, 1088, 1092, 1096, 1105, 1112, 1116, 1122, 1132, 1138, 1148, 1153, 1159, 1163, 1169, 1176, 1183, 1190, 1198, 1204, 1220, 1224, 1229, 1234, 1239, 1258, 1270, 1274, 1280, 1285, 1295, 1300, 1310, 1319, 1326, 1333, 1341, 1356, 1361, 1367, 1371, 1376, 1380, 1402, 1415, 1422, 1437, 1441, 1447, 1451, 1458, 1463, 1472, 1479, 1486, 1490, 1496, 1505, 1509, 1516, 1522, 1527, 1545, 1552, 1557, 1562, 1572, 1576, 1584, 1592, 1601, 1608, 1620, 1631, 1637, 1646, 1651, 1660, 1668, 1675, 1680, 1686, 1699, 1707, 1716, 1723, 1739, 1751, 1758, 1765, 1772, 1777, 1794, 1799, 1803, 1811, 1816, 1823, 1831, 1836, 1842, 1851, 1856, 1861, 1866, 1875, 1887, 1891, 1899, 1907, 1912, 1919, 1925, 1936, 1946, 1955, 1960, 1967, 1973, 1989, 1993, 2000], deadline = 6)
        configuration.add_task(name="Task1", identifier=1, period=16.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=15.666536, acet=15.666536, et_stddev=5.222178666666667, deadline= 17)
        configuration.add_task(name="Task2", identifier=2, period=8.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=4.425578, acet=4.425578, et_stddev=1.4751926666666666, deadline= 11)
        configuration.add_task(name="Task6", identifier=6, period=20.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=5, acet=4.297283, et_stddev=1.4324276666666667 , list_activation_dates=[12, 64, 86, 141, 177, 206, 272, 313, 364, 474, 577, 657, 686, 707, 730, 764, 784, 820, 869, 929, 949, 977, 1000, 1061, 1082, 1121, 1167, 1222, 1267, 1349, 1384, 1429, 1453, 1489, 1511, 1533, 1557, 1604, 1637, 1669, 1711, 1734, 1778, 1833, 1881, 1928, 1977], deadline = 34)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "34")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "34")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "34")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "34")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task5", identifier=5, period=16.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.582226, et_stddev=0.19407533333333335 , list_activation_dates=[10, 35, 76, 94, 113, 144, 167, 188, 214, 236, 260, 278, 300, 350, 385, 404, 428, 456, 475, 498, 517, 549, 606, 627, 645, 679, 729, 802, 821, 840, 863, 881, 899, 924, 990, 1012, 1045, 1065, 1102, 1174, 1194, 1234, 1252, 1319, 1365, 1404, 1420, 1437, 1453, 1485, 1504, 1522, 1541, 1587, 1612, 1635, 1669, 1693, 1724, 1752, 1777, 1832, 1855, 1876, 1894, 1912, 1944, 1973], deadline = 1)
        configuration.add_task(name="Task4", identifier=4, period=23.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=6, acet=5.180746, et_stddev=1.7269153333333334 , list_activation_dates=[4, 40, 75, 126, 183, 226, 252, 283, 352, 377, 403, 428, 452, 480, 594, 663, 686, 726, 751, 781, 841, 919, 943, 1004, 1048, 1077, 1105, 1134, 1167, 1251, 1288, 1316, 1364, 1396, 1437, 1461, 1556, 1592, 1627, 1660, 1752, 1779, 1825, 1873, 1921, 1965], deadline = 46)
        configuration.add_task(name="Task1", identifier=1, period=12.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=4.274391, acet=4.274391, et_stddev=1.4247969999999999, deadline= 8)
        configuration.add_task(name="Task6", identifier=6, period=2.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.076721, et_stddev=0.025573666666666665 , list_activation_dates=[2, 5, 7, 10, 13, 15, 20, 26, 29, 31, 35, 37, 46, 50, 61, 63, 66, 68, 71, 74, 80, 83, 90, 94, 99, 102, 105, 121, 125, 129, 131, 135, 148, 150, 154, 157, 161, 165, 170, 175, 178, 181, 186, 189, 193, 196, 199, 203, 206, 211, 216, 224, 227, 231, 233, 238, 241, 243, 249, 252, 254, 258, 261, 266, 269, 281, 284, 287, 289, 297, 301, 303, 305, 312, 315, 320, 323, 326, 332, 336, 342, 345, 349, 352, 357, 360, 364, 367, 370, 376, 383, 391, 395, 400, 403, 405, 408, 412, 416, 419, 421, 424, 427, 429, 440, 444, 447, 453, 455, 461, 463, 465, 473, 477, 481, 483, 485, 489, 497, 499, 504, 507, 511, 514, 518, 522, 524, 528, 530, 539, 545, 549, 552, 555, 558, 560, 567, 569, 573, 579, 582, 585, 588, 591, 595, 598, 600, 603, 605, 608, 611, 619, 626, 628, 640, 642, 644, 650, 655, 657, 660, 663, 665, 667, 671, 675, 679, 683, 686, 691, 696, 699, 703, 706, 709, 711, 714, 716, 720, 725, 728, 733, 735, 738, 742, 746, 749, 751, 757, 763, 766, 768, 772, 779, 782, 786, 793, 798, 800, 803, 805, 810, 815, 819, 823, 826, 829, 831, 834, 837, 841, 845, 848, 852, 860, 863, 869, 873, 875, 885, 887, 889, 895, 899, 902, 908, 917, 923, 926, 929, 932, 934, 938, 941, 945, 956, 960, 965, 968, 970, 974, 978, 980, 983, 993, 995, 997, 1001, 1004, 1012, 1016, 1019, 1024, 1029, 1031, 1038, 1041, 1050, 1052, 1060, 1064, 1067, 1069, 1071, 1073, 1078, 1081, 1087, 1092, 1097, 1099, 1101, 1104, 1108, 1114, 1116, 1121, 1126, 1129, 1135, 1143, 1146, 1149, 1151, 1155, 1157, 1164, 1169, 1172, 1175, 1184, 1188, 1191, 1193, 1216, 1222, 1226, 1230, 1234, 1237, 1240, 1245, 1250, 1253, 1257, 1264, 1273, 1278, 1280, 1284, 1294, 1298, 1302, 1309, 1315, 1321, 1323, 1326, 1330, 1341, 1343, 1347, 1357, 1362, 1370, 1374, 1376, 1379, 1388, 1396, 1403, 1405, 1408, 1410, 1414, 1417, 1420, 1429, 1432, 1435, 1440, 1446, 1448, 1454, 1457, 1460, 1464, 1467, 1470, 1473, 1476, 1478, 1480, 1483, 1493, 1498, 1500, 1502, 1506, 1510, 1513, 1518, 1521, 1525, 1528, 1530, 1535, 1538, 1541, 1546, 1549, 1551, 1563, 1566, 1568, 1574, 1577, 1584, 1590, 1593, 1609, 1611, 1614, 1617, 1619, 1627, 1630, 1635, 1638, 1641, 1648, 1651, 1657, 1660, 1664, 1666, 1668, 1671, 1677, 1680, 1682, 1686, 1700, 1704, 1708, 1710, 1713, 1718, 1720, 1725, 1730, 1733, 1743, 1749, 1752, 1755, 1759, 1764, 1767, 1769, 1773, 1776, 1781, 1784, 1791, 1795, 1798, 1801, 1809, 1811, 1813, 1817, 1824, 1828, 1830, 1834, 1838, 1844, 1846, 1850, 1855, 1857, 1860, 1862, 1866, 1870, 1874, 1876, 1881, 1885, 1889, 1891, 1895, 1903, 1911, 1916, 1919, 1922, 1925, 1927, 1931, 1937, 1939, 1942, 1945, 1949, 1953, 1955, 1961, 1966, 1970, 1974, 1979, 1990, 1993, 1998], deadline = 3)
        configuration.add_task(name="Task2", identifier=2, period=34.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=29.266158, acet=29.266158, et_stddev=9.755386, deadline= 34)
        configuration.add_task(name="Task3", identifier=3, period=5.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=1.915156, acet=1.915156, et_stddev=0.6383853333333334, deadline= 5)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "35")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "35")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "35")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "35")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task6", identifier=6, period=5.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=2, acet=1.123645, et_stddev=0.3745483333333333 , list_activation_dates=[4, 30, 39, 48, 55, 67, 74, 79, 87, 94, 102, 110, 115, 121, 129, 147, 154, 162, 172, 177, 205, 211, 217, 222, 231, 237, 248, 261, 273, 286, 293, 299, 317, 325, 334, 349, 356, 362, 370, 381, 392, 404, 413, 418, 424, 431, 436, 449, 457, 465, 475, 481, 489, 501, 511, 517, 530, 536, 542, 552, 560, 575, 586, 599, 607, 617, 625, 637, 647, 666, 672, 679, 685, 694, 699, 708, 724, 731, 738, 751, 757, 769, 775, 784, 790, 799, 804, 809, 816, 825, 833, 840, 849, 860, 866, 872, 877, 888, 898, 905, 926, 935, 943, 953, 962, 977, 1004, 1010, 1021, 1039, 1046, 1053, 1069, 1076, 1084, 1104, 1109, 1123, 1138, 1144, 1151, 1156, 1163, 1168, 1187, 1197, 1211, 1217, 1224, 1233, 1239, 1263, 1275, 1282, 1291, 1301, 1306, 1322, 1334, 1340, 1349, 1357, 1365, 1378, 1389, 1397, 1402, 1417, 1439, 1456, 1461, 1475, 1480, 1487, 1498, 1507, 1514, 1520, 1535, 1544, 1554, 1574, 1583, 1591, 1621, 1630, 1637, 1650, 1655, 1661, 1671, 1679, 1691, 1709, 1715, 1723, 1733, 1739, 1751, 1773, 1779, 1788, 1804, 1811, 1819, 1828, 1842, 1848, 1862, 1869, 1880, 1889, 1902, 1909, 1916, 1929, 1940, 1952, 1961, 1972, 1982], deadline = 2)
        configuration.add_task(name="Task5", identifier=5, period=2.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.032268, et_stddev=0.010756 , list_activation_dates=[5, 7, 10, 14, 32, 35, 37, 40, 42, 49, 51, 54, 57, 60, 63, 67, 69, 71, 74, 76, 78, 80, 86, 89, 94, 97, 100, 102, 109, 117, 121, 126, 128, 131, 137, 142, 147, 149, 152, 156, 158, 163, 165, 170, 173, 180, 185, 189, 191, 193, 195, 198, 201, 208, 211, 214, 218, 223, 226, 230, 234, 238, 243, 245, 248, 251, 256, 259, 261, 264, 266, 270, 274, 276, 280, 293, 295, 300, 303, 309, 312, 318, 322, 326, 328, 332, 335, 338, 341, 344, 352, 355, 358, 366, 371, 374, 377, 383, 387, 389, 391, 396, 399, 402, 412, 420, 422, 426, 429, 433, 436, 439, 443, 446, 449, 452, 457, 459, 461, 467, 470, 473, 479, 481, 483, 486, 489, 491, 493, 498, 502, 505, 513, 515, 517, 519, 526, 529, 533, 536, 539, 541, 544, 546, 550, 553, 555, 557, 561, 565, 568, 575, 580, 582, 587, 590, 593, 596, 600, 602, 612, 620, 625, 631, 637, 641, 645, 653, 658, 660, 668, 671, 675, 679, 682, 684, 686, 689, 691, 695, 699, 702, 704, 709, 716, 718, 723, 726, 733, 735, 750, 755, 758, 764, 772, 775, 778, 781, 784, 791, 797, 800, 803, 806, 809, 814, 817, 820, 825, 827, 833, 836, 839, 841, 844, 847, 850, 854, 860, 864, 866, 869, 873, 876, 879, 885, 887, 892, 895, 903, 906, 908, 910, 914, 916, 920, 926, 931, 937, 940, 943, 946, 949, 952, 956, 959, 962, 964, 967, 969, 978, 980, 983, 990, 992, 998, 1000, 1004, 1008, 1011, 1013, 1018, 1022, 1025, 1029, 1032, 1034, 1036, 1040, 1042, 1045, 1048, 1051, 1055, 1058, 1061, 1065, 1070, 1073, 1076, 1082, 1085, 1089, 1094, 1107, 1109, 1111, 1114, 1118, 1120, 1124, 1129, 1132, 1134, 1136, 1139, 1143, 1146, 1148, 1150, 1152, 1154, 1157, 1161, 1163, 1165, 1167, 1170, 1174, 1178, 1181, 1184, 1186, 1191, 1196, 1200, 1207, 1211, 1213, 1216, 1218, 1221, 1223, 1227, 1229, 1233, 1238, 1243, 1246, 1251, 1261, 1264, 1266, 1274, 1277, 1286, 1294, 1299, 1302, 1308, 1313, 1315, 1319, 1322, 1324, 1327, 1332, 1334, 1338, 1342, 1345, 1349, 1352, 1362, 1364, 1367, 1371, 1373, 1376, 1383, 1388, 1395, 1399, 1401, 1411, 1415, 1419, 1425, 1427, 1436, 1440, 1443, 1445, 1449, 1453, 1455, 1457, 1464, 1469, 1474, 1478, 1480, 1482, 1485, 1487, 1492, 1494, 1496, 1498, 1500, 1504, 1508, 1512, 1516, 1520, 1523, 1527, 1532, 1536, 1542, 1545, 1548, 1550, 1556, 1559, 1565, 1571, 1574, 1576, 1579, 1586, 1589, 1593, 1596, 1598, 1602, 1608, 1613, 1616, 1620, 1622, 1626, 1629, 1632, 1634, 1647, 1649, 1652, 1655, 1662, 1667, 1669, 1677, 1682, 1684, 1687, 1699, 1703, 1706, 1716, 1721, 1723, 1725, 1728, 1736, 1739, 1744, 1748, 1751, 1755, 1758, 1762, 1766, 1770, 1783, 1798, 1801, 1812, 1814, 1821, 1824, 1830, 1832, 1836, 1839, 1842, 1846, 1848, 1851, 1854, 1858, 1862, 1867, 1870, 1872, 1874, 1877, 1879, 1881, 1884, 1886, 1889, 1893, 1896, 1899, 1901, 1905, 1907, 1911, 1917, 1920, 1924, 1930, 1934, 1938, 1949, 1952, 1959, 1961, 1967, 1969, 1972, 1977, 1980, 1983, 1989, 1991, 1996, 2000], deadline = 4)
        configuration.add_task(name="Task1", identifier=1, period=2.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=0.496419, acet=0.496419, et_stddev=0.165473, deadline= 2)
        configuration.add_task(name="Task3", identifier=3, period=13.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=9.831066, acet=9.831066, et_stddev=3.277022, deadline= 26)
        configuration.add_task(name="Task2", identifier=2, period=6.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=3.573326, acet=3.573326, et_stddev=1.1911086666666666, deadline= 9)
        configuration.add_task(name="Task4", identifier=4, period=2.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.118273, et_stddev=0.03942433333333333 , list_activation_dates=[1, 8, 11, 17, 25, 28, 32, 35, 37, 45, 53, 57, 60, 63, 69, 72, 76, 79, 84, 87, 91, 95, 104, 106, 109, 112, 117, 122, 127, 130, 134, 138, 146, 148, 150, 152, 159, 163, 165, 168, 171, 174, 179, 182, 193, 196, 198, 201, 203, 205, 207, 212, 217, 220, 223, 226, 229, 231, 244, 247, 250, 254, 257, 260, 262, 264, 266, 273, 277, 279, 283, 285, 287, 291, 293, 296, 299, 302, 307, 310, 314, 319, 323, 325, 327, 332, 336, 340, 342, 347, 353, 358, 367, 373, 376, 379, 382, 385, 390, 395, 398, 401, 406, 411, 416, 419, 422, 426, 430, 435, 438, 443, 445, 452, 457, 460, 464, 466, 471, 475, 478, 480, 482, 484, 488, 491, 495, 501, 506, 508, 511, 515, 517, 520, 526, 528, 531, 534, 537, 540, 545, 548, 552, 554, 559, 564, 571, 573, 582, 586, 589, 591, 596, 607, 610, 614, 618, 621, 625, 628, 633, 640, 642, 650, 653, 656, 661, 664, 669, 671, 674, 677, 681, 686, 688, 692, 696, 701, 705, 709, 712, 715, 720, 723, 726, 734, 737, 739, 751, 759, 762, 765, 771, 775, 786, 790, 793, 795, 798, 802, 805, 807, 811, 815, 818, 823, 826, 829, 831, 836, 840, 845, 855, 858, 870, 873, 876, 879, 881, 883, 885, 888, 891, 893, 896, 898, 902, 906, 909, 915, 918, 922, 929, 932, 935, 939, 942, 945, 955, 957, 960, 965, 968, 972, 977, 980, 992, 998, 1000, 1005, 1007, 1009, 1016, 1021, 1029, 1036, 1041, 1043, 1046, 1049, 1054, 1056, 1058, 1061, 1064, 1069, 1072, 1076, 1079, 1084, 1089, 1094, 1098, 1100, 1102, 1105, 1107, 1109, 1112, 1114, 1116, 1119, 1123, 1131, 1133, 1137, 1140, 1144, 1148, 1150, 1154, 1160, 1162, 1167, 1175, 1179, 1184, 1187, 1192, 1195, 1202, 1204, 1208, 1210, 1214, 1217, 1220, 1222, 1227, 1232, 1236, 1240, 1246, 1252, 1257, 1261, 1265, 1269, 1272, 1276, 1288, 1294, 1296, 1301, 1305, 1307, 1311, 1314, 1317, 1322, 1325, 1329, 1335, 1339, 1341, 1344, 1348, 1351, 1354, 1357, 1359, 1362, 1364, 1371, 1374, 1377, 1384, 1388, 1391, 1398, 1401, 1404, 1409, 1412, 1417, 1423, 1425, 1427, 1429, 1432, 1436, 1443, 1447, 1451, 1454, 1457, 1460, 1462, 1464, 1467, 1474, 1481, 1484, 1489, 1493, 1498, 1501, 1503, 1505, 1511, 1514, 1518, 1520, 1523, 1527, 1530, 1537, 1542, 1545, 1551, 1553, 1557, 1559, 1561, 1567, 1571, 1575, 1581, 1583, 1590, 1593, 1595, 1599, 1601, 1606, 1612, 1617, 1621, 1624, 1628, 1637, 1640, 1644, 1653, 1656, 1659, 1662, 1665, 1671, 1674, 1677, 1680, 1683, 1688, 1694, 1696, 1704, 1708, 1711, 1715, 1717, 1723, 1726, 1729, 1733, 1738, 1743, 1748, 1751, 1755, 1758, 1761, 1763, 1766, 1769, 1773, 1776, 1779, 1782, 1785, 1789, 1799, 1802, 1804, 1808, 1811, 1815, 1817, 1820, 1823, 1827, 1831, 1833, 1841, 1844, 1849, 1855, 1859, 1861, 1865, 1873, 1877, 1880, 1882, 1887, 1890, 1894, 1898, 1900, 1905, 1907, 1910, 1913, 1916, 1919, 1924, 1926, 1932, 1937, 1944, 1951, 1956, 1960, 1965, 1969, 1972, 1974, 1977, 1981, 1984, 1988, 1991, 1996, 1999], deadline = 4)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "36")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "36")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "36")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "36")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task4", identifier=4, period=3.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.049009, et_stddev=0.01633633333333333 , list_activation_dates=[3, 15, 23, 27, 32, 36, 40, 43, 48, 58, 65, 69, 77, 85, 90, 96, 101, 104, 110, 115, 125, 135, 139, 143, 146, 152, 159, 163, 170, 176, 182, 187, 195, 201, 205, 215, 224, 227, 232, 238, 241, 251, 256, 267, 272, 276, 284, 293, 302, 307, 311, 322, 325, 333, 337, 349, 357, 369, 379, 383, 390, 394, 400, 410, 418, 422, 426, 432, 439, 446, 451, 459, 463, 477, 482, 486, 489, 493, 497, 500, 514, 522, 526, 541, 546, 550, 553, 566, 581, 589, 592, 600, 605, 610, 615, 618, 623, 630, 635, 639, 653, 658, 675, 679, 683, 692, 696, 703, 712, 720, 724, 729, 732, 738, 741, 745, 750, 765, 768, 772, 777, 785, 790, 794, 802, 807, 810, 814, 818, 823, 827, 833, 838, 845, 849, 855, 859, 862, 866, 869, 874, 881, 887, 890, 897, 901, 910, 916, 921, 925, 932, 936, 943, 947, 950, 960, 967, 972, 979, 993, 997, 1003, 1007, 1012, 1017, 1020, 1024, 1028, 1033, 1038, 1045, 1051, 1055, 1058, 1061, 1076, 1079, 1087, 1094, 1102, 1106, 1110, 1119, 1127, 1137, 1141, 1149, 1153, 1157, 1160, 1165, 1171, 1175, 1183, 1191, 1194, 1197, 1201, 1205, 1211, 1214, 1221, 1227, 1230, 1235, 1239, 1242, 1247, 1252, 1257, 1267, 1273, 1280, 1284, 1289, 1292, 1296, 1306, 1318, 1325, 1332, 1335, 1339, 1342, 1346, 1351, 1360, 1365, 1370, 1376, 1382, 1386, 1391, 1397, 1401, 1406, 1409, 1417, 1427, 1432, 1439, 1445, 1451, 1455, 1459, 1468, 1472, 1477, 1483, 1491, 1495, 1503, 1507, 1512, 1515, 1518, 1524, 1532, 1536, 1544, 1548, 1554, 1562, 1565, 1570, 1574, 1579, 1583, 1587, 1591, 1595, 1600, 1603, 1619, 1622, 1627, 1631, 1640, 1644, 1649, 1655, 1659, 1663, 1667, 1674, 1677, 1687, 1691, 1699, 1702, 1706, 1716, 1719, 1725, 1733, 1736, 1741, 1746, 1753, 1760, 1765, 1769, 1772, 1788, 1797, 1807, 1810, 1815, 1823, 1836, 1841, 1846, 1857, 1862, 1866, 1870, 1881, 1889, 1896, 1902, 1906, 1909, 1919, 1923, 1926, 1931, 1939, 1942, 1950, 1957, 1963, 1969, 1974, 1977, 1981, 1986, 1994, 2000], deadline = 3)
        configuration.add_task(name="Task3", identifier=3, period=1.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=0.115381, acet=0.115381, et_stddev=0.03846033333333333, deadline= 2)
        configuration.add_task(name="Task2", identifier=2, period=19.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=15.655574, acet=15.655574, et_stddev=5.218524666666666, deadline= 28)
        configuration.add_task(name="Task5", identifier=5, period=47.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=8, acet=7.757807, et_stddev=2.5859356666666664 , list_activation_dates=[5, 100, 273, 323, 467, 516, 572, 682, 749, 993, 1097, 1192, 1313, 1470, 1529, 1729, 1779, 1833, 1881, 1940, 1987], deadline = 45)
        configuration.add_task(name="Task1", identifier=1, period=48.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=31.710783, acet=31.710783, et_stddev=10.570261, deadline= 83)
        configuration.add_task(name="Task6", identifier=6, period=19.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=3, acet=2.253474, et_stddev=0.7511580000000001 , list_activation_dates=[14, 45, 97, 129, 195, 217, 244, 285, 311, 336, 368, 405, 440, 462, 489, 546, 570, 600, 624, 644, 664, 689, 732, 752, 832, 881, 923, 946, 969, 992, 1024, 1106, 1136, 1243, 1266, 1287, 1329, 1352, 1381, 1406, 1446, 1469, 1525, 1557, 1587, 1628, 1697, 1717, 1737, 1778, 1823, 1843, 1864, 1935, 1960], deadline = 29)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "37")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "37")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "37")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "37")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task5", identifier=5, period=1.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.070262, et_stddev=0.02342066666666667 , list_activation_dates=[1, 3, 6, 7, 8, 10, 11, 14, 16, 18, 19, 20, 21, 22, 24, 25, 28, 29, 31, 37, 39, 40, 44, 45, 49, 51, 52, 53, 54, 56, 59, 62, 64, 66, 69, 71, 74, 75, 77, 82, 84, 87, 90, 93, 94, 97, 99, 100, 101, 104, 106, 107, 110, 111, 112, 113, 114, 117, 118, 119, 120, 121, 123, 126, 129, 130, 131, 134, 136, 138, 139, 140, 141, 143, 146, 147, 149, 151, 152, 153, 155, 160, 161, 162, 163, 165, 166, 167, 168, 169, 170, 171, 173, 174, 176, 177, 179, 181, 183, 185, 186, 187, 188, 189, 190, 191, 192, 193, 194, 195, 196, 197, 199, 204, 206, 208, 210, 212, 214, 216, 217, 219, 221, 222, 223, 226, 227, 228, 230, 232, 234, 236, 237, 238, 240, 244, 247, 251, 253, 255, 257, 258, 259, 260, 262, 263, 265, 267, 269, 270, 273, 276, 278, 281, 283, 287, 290, 291, 294, 295, 297, 300, 301, 302, 303, 304, 305, 306, 308, 311, 312, 314, 316, 318, 321, 323, 326, 327, 332, 335, 337, 338, 339, 340, 344, 346, 348, 351, 352, 354, 355, 357, 359, 360, 363, 364, 365, 366, 367, 370, 371, 372, 374, 377, 379, 380, 381, 383, 385, 386, 388, 390, 392, 394, 396, 402, 405, 406, 407, 409, 410, 411, 413, 415, 416, 417, 418, 419, 420, 422, 425, 426, 431, 433, 435, 437, 438, 441, 443, 446, 451, 452, 453, 456, 459, 460, 462, 464, 467, 468, 469, 470, 472, 474, 475, 476, 478, 480, 482, 483, 484, 487, 488, 489, 490, 492, 496, 498, 500, 501, 502, 504, 505, 506, 508, 509, 512, 513, 515, 517, 519, 520, 521, 524, 525, 529, 530, 532, 533, 535, 537, 538, 541, 542, 544, 545, 547, 550, 552, 554, 555, 556, 558, 559, 562, 563, 565, 567, 571, 575, 577, 580, 581, 583, 585, 587, 588, 590, 591, 594, 595, 597, 600, 602, 604, 606, 607, 609, 612, 614, 615, 616, 619, 621, 623, 629, 630, 632, 633, 634, 636, 637, 638, 639, 641, 642, 644, 646, 648, 650, 652, 655, 658, 659, 661, 663, 664, 667, 669, 670, 672, 673, 674, 675, 676, 678, 679, 682, 683, 684, 686, 688, 690, 691, 696, 697, 698, 704, 706, 708, 709, 710, 711, 714, 716, 719, 722, 725, 726, 728, 730, 732, 736, 739, 740, 741, 744, 745, 747, 748, 751, 752, 756, 758, 759, 761, 763, 764, 765, 767, 771, 776, 777, 779, 782, 784, 787, 788, 791, 796, 800, 802, 806, 810, 811, 814, 817, 818, 819, 820, 822, 824, 825, 826, 829, 830, 832, 836, 837, 840, 841, 842, 843, 844, 845, 849, 850, 852, 854, 855, 856, 858, 861, 863, 864, 865, 868, 869, 871, 873, 875, 877, 878, 883, 886, 887, 891, 892, 896, 901, 906, 907, 908, 909, 910, 913, 917, 923, 925, 926, 929, 931, 934, 935, 936, 937, 938, 940, 941, 942, 943, 944, 947, 949, 950, 951, 952, 953, 958, 962, 964, 965, 967, 969, 971, 973, 976, 981, 982, 984, 986, 990, 993, 994, 996, 999, 1000, 1003, 1005, 1006, 1007, 1009, 1010, 1013, 1014, 1015, 1016, 1018, 1020, 1022, 1023, 1026, 1027, 1028, 1030, 1032, 1035, 1036, 1037, 1039, 1043, 1045, 1047, 1049, 1051, 1054, 1057, 1060, 1061, 1063, 1067, 1070, 1071, 1074, 1075, 1077, 1083, 1087, 1088, 1089, 1092, 1093, 1095, 1097, 1099, 1101, 1103, 1104, 1105, 1107, 1108, 1110, 1111, 1113, 1114, 1116, 1118, 1119, 1123, 1124, 1126, 1129, 1131, 1133, 1134, 1136, 1138, 1141, 1143, 1145, 1147, 1149, 1150, 1153, 1155, 1157, 1159, 1163, 1164, 1167, 1168, 1171, 1173, 1178, 1180, 1182, 1186, 1188, 1190, 1191, 1193, 1194, 1195, 1196, 1198, 1205, 1207, 1210, 1214, 1216, 1218, 1222, 1224, 1225, 1226, 1228, 1229, 1230, 1232, 1235, 1237, 1239, 1241, 1246, 1247, 1249, 1250, 1252, 1255, 1258, 1261, 1266, 1267, 1268, 1270, 1272, 1273, 1276, 1277, 1279, 1280, 1281, 1284, 1285, 1287, 1289, 1291, 1292, 1294, 1295, 1297, 1298, 1304, 1306, 1307, 1308, 1309, 1310, 1311, 1314, 1317, 1318, 1320, 1321, 1322, 1324, 1326, 1328, 1329, 1331, 1332, 1335, 1338, 1340, 1342, 1345, 1347, 1350, 1351, 1352, 1355, 1356, 1359, 1360, 1362, 1364, 1368, 1370, 1373, 1375, 1377, 1378, 1380, 1382, 1383, 1384, 1385, 1386, 1387, 1388, 1390, 1392, 1394, 1397, 1400, 1405, 1406, 1409, 1411, 1412, 1413, 1414, 1417, 1419, 1420, 1421, 1423, 1425, 1428, 1429, 1430, 1433, 1434, 1435, 1436, 1438, 1441, 1443, 1445, 1447, 1450, 1452, 1453, 1455, 1456, 1458, 1459, 1464, 1467, 1468, 1470, 1473, 1476, 1477, 1478, 1480, 1481, 1482, 1484, 1485, 1487, 1489, 1492, 1493, 1495, 1497, 1498, 1499, 1502, 1503, 1504, 1505, 1506, 1507, 1509, 1510, 1512, 1513, 1515, 1517, 1520, 1521, 1522, 1523, 1525, 1528, 1529, 1531, 1532, 1534, 1536, 1538, 1539, 1540, 1543, 1544, 1545, 1550, 1551, 1552, 1553, 1555, 1556, 1560, 1562, 1564, 1568, 1570, 1571, 1576, 1577, 1580, 1581, 1583, 1584, 1586, 1591, 1593, 1594, 1596, 1597, 1602, 1605, 1606, 1611, 1612, 1614, 1615, 1619, 1621, 1623, 1626, 1628, 1632, 1633, 1635, 1636, 1639, 1643, 1648, 1649, 1650, 1652, 1653, 1657, 1658, 1659, 1661, 1663, 1664, 1666, 1667, 1668, 1670, 1671, 1672, 1675, 1678, 1680, 1681, 1682, 1686, 1687, 1688, 1690, 1694, 1695, 1698, 1699, 1701, 1703, 1705, 1708, 1710, 1712, 1713, 1716, 1719, 1721, 1722, 1724, 1725, 1726, 1728, 1729, 1731, 1733, 1735, 1737, 1739, 1741, 1743, 1744, 1745, 1747, 1750, 1751, 1752, 1754, 1755, 1756, 1758, 1760, 1761, 1762, 1764, 1765, 1767, 1768, 1770, 1771, 1773, 1775, 1776, 1778, 1780, 1782, 1785, 1791, 1793, 1796, 1798, 1800, 1801, 1802, 1803, 1805, 1809, 1810, 1814, 1816, 1818, 1820, 1822, 1823, 1825, 1826, 1828, 1830, 1831, 1833, 1835, 1837, 1838, 1844, 1845, 1848, 1851, 1853, 1855, 1856, 1857, 1859, 1861, 1863, 1866, 1869, 1870, 1872, 1873, 1880, 1883, 1884, 1888, 1890, 1892, 1895, 1896, 1897, 1898, 1900, 1901, 1902, 1903, 1905, 1909, 1911, 1913, 1914, 1917, 1920, 1921, 1922, 1924, 1927, 1931, 1932, 1934, 1936, 1938, 1941, 1943, 1944, 1946, 1947, 1951, 1954, 1959, 1961, 1965, 1967, 1969, 1972, 1973, 1974, 1975, 1976, 1978, 1980, 1982, 1984, 1985, 1987, 1988, 1991, 1994, 1997, 1999], deadline = 2)
        configuration.add_task(name="Task1", identifier=1, period=4.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=2.711344, acet=2.711344, et_stddev=0.9037813333333333, deadline= 3)
        configuration.add_task(name="Task6", identifier=6, period=14.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.655928, et_stddev=0.21864266666666665 , list_activation_dates=[47, 67, 82, 133, 166, 201, 244, 270, 296, 318, 342, 372, 391, 437, 466, 483, 503, 566, 584, 606, 647, 704, 729, 782, 798, 822, 852, 874, 890, 904, 938, 956, 985, 1009, 1037, 1053, 1073, 1167, 1187, 1216, 1245, 1264, 1288, 1325, 1392, 1409, 1441, 1469, 1484, 1502, 1532, 1557, 1577, 1592, 1606, 1622, 1713, 1733, 1753, 1773, 1817, 1834, 1850, 1877, 1895, 1929, 1945, 1962, 1989], deadline = 8)
        configuration.add_task(name="Task4", identifier=4, period=6.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=2, acet=1.09731, et_stddev=0.36577 , list_activation_dates=[5, 15, 32, 40, 50, 70, 97, 106, 122, 146, 171, 191, 198, 205, 229, 240, 253, 262, 277, 305, 312, 327, 342, 348, 367, 393, 422, 431, 444, 453, 459, 471, 478, 484, 496, 502, 512, 524, 533, 541, 551, 559, 581, 591, 597, 609, 619, 625, 636, 655, 667, 679, 701, 716, 728, 739, 747, 773, 780, 793, 801, 807, 825, 836, 847, 854, 871, 878, 906, 913, 935, 945, 956, 977, 988, 1016, 1032, 1039, 1059, 1066, 1092, 1102, 1118, 1127, 1133, 1164, 1181, 1196, 1206, 1229, 1239, 1253, 1260, 1269, 1298, 1306, 1315, 1330, 1337, 1362, 1381, 1390, 1400, 1406, 1435, 1444, 1460, 1470, 1479, 1493, 1504, 1515, 1521, 1532, 1538, 1548, 1556, 1563, 1570, 1578, 1585, 1595, 1604, 1613, 1622, 1631, 1638, 1645, 1653, 1661, 1690, 1710, 1723, 1729, 1737, 1743, 1749, 1757, 1766, 1789, 1796, 1818, 1828, 1835, 1845, 1853, 1862, 1870, 1880, 1890, 1898, 1911, 1918, 1924, 1938, 1947, 1957, 1986, 1995], deadline = 3)
        configuration.add_task(name="Task2", identifier=2, period=2.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=0.880315, acet=0.880315, et_stddev=0.2934383333333333, deadline= 4)
        configuration.add_task(name="Task3", identifier=3, period=20.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=9.640122, acet=9.640122, et_stddev=3.213374, deadline= 37)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "38")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "38")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "38")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "38")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task2", identifier=2, period=11.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=6.97225, acet=6.97225, et_stddev=2.3240833333333333, deadline= 9)
        configuration.add_task(name="Task4", identifier=4, period=5.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.537128, et_stddev=0.17904266666666668 , list_activation_dates=[32, 37, 51, 64, 69, 77, 85, 93, 101, 109, 114, 129, 142, 149, 156, 165, 174, 180, 185, 194, 201, 218, 231, 241, 248, 255, 265, 272, 291, 302, 315, 323, 328, 346, 354, 379, 391, 403, 408, 413, 421, 428, 444, 453, 460, 468, 474, 490, 503, 509, 516, 533, 538, 547, 555, 560, 577, 593, 607, 634, 640, 651, 656, 661, 668, 682, 697, 703, 709, 719, 725, 732, 742, 748, 755, 789, 799, 805, 820, 831, 843, 848, 856, 867, 875, 890, 897, 909, 914, 921, 927, 933, 958, 972, 977, 984, 995, 1005, 1023, 1031, 1042, 1062, 1068, 1078, 1088, 1101, 1107, 1116, 1123, 1133, 1155, 1162, 1174, 1183, 1189, 1196, 1203, 1210, 1216, 1226, 1239, 1265, 1274, 1287, 1293, 1300, 1308, 1317, 1323, 1329, 1334, 1343, 1350, 1356, 1363, 1370, 1377, 1386, 1392, 1407, 1413, 1421, 1430, 1439, 1446, 1451, 1461, 1475, 1496, 1502, 1510, 1518, 1523, 1531, 1537, 1551, 1561, 1569, 1576, 1590, 1600, 1605, 1616, 1631, 1637, 1645, 1651, 1670, 1685, 1695, 1701, 1707, 1717, 1722, 1731, 1738, 1744, 1754, 1761, 1772, 1783, 1803, 1810, 1816, 1825, 1840, 1856, 1864, 1881, 1889, 1895, 1906, 1911, 1925, 1940, 1946, 1953, 1961, 1972, 1978, 1986, 1999], deadline = 5)
        configuration.add_task(name="Task1", identifier=1, period=10.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=7.609475, acet=7.609475, et_stddev=2.5364916666666666, deadline= 19)
        configuration.add_task(name="Task3", identifier=3, period=4.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=0.820845, acet=0.820845, et_stddev=0.273615, deadline= 5)
        configuration.add_task(name="Task5", identifier=5, period=3.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.516426, et_stddev=0.17214200000000002 , list_activation_dates=[8, 17, 20, 24, 29, 34, 43, 48, 53, 56, 62, 68, 74, 80, 87, 93, 106, 110, 114, 118, 122, 126, 133, 137, 141, 155, 162, 169, 172, 177, 193, 201, 205, 213, 222, 225, 233, 243, 247, 251, 254, 259, 262, 265, 269, 274, 278, 282, 285, 290, 294, 305, 308, 311, 315, 322, 330, 335, 345, 350, 354, 357, 361, 366, 375, 379, 387, 391, 396, 404, 411, 416, 424, 430, 440, 455, 463, 469, 473, 477, 483, 486, 491, 496, 499, 504, 508, 511, 517, 521, 530, 534, 539, 554, 558, 562, 568, 581, 590, 600, 606, 610, 618, 624, 628, 634, 640, 645, 652, 656, 661, 669, 673, 678, 682, 691, 700, 704, 707, 712, 720, 726, 732, 739, 749, 753, 759, 763, 767, 772, 777, 780, 785, 790, 796, 801, 804, 808, 812, 825, 830, 835, 842, 854, 857, 864, 869, 872, 875, 886, 889, 895, 902, 905, 908, 922, 926, 931, 936, 940, 943, 951, 954, 957, 962, 980, 984, 989, 992, 997, 1002, 1007, 1015, 1019, 1024, 1037, 1041, 1045, 1051, 1054, 1069, 1074, 1079, 1082, 1087, 1096, 1101, 1105, 1110, 1118, 1123, 1127, 1142, 1148, 1156, 1160, 1166, 1169, 1173, 1182, 1185, 1189, 1195, 1202, 1206, 1209, 1212, 1217, 1221, 1225, 1229, 1232, 1251, 1257, 1268, 1274, 1278, 1286, 1292, 1304, 1307, 1313, 1316, 1323, 1333, 1337, 1340, 1350, 1355, 1359, 1371, 1374, 1383, 1388, 1391, 1402, 1405, 1414, 1420, 1427, 1431, 1438, 1444, 1448, 1457, 1462, 1470, 1477, 1482, 1486, 1492, 1495, 1500, 1503, 1511, 1515, 1522, 1526, 1529, 1540, 1549, 1553, 1556, 1560, 1564, 1567, 1572, 1579, 1585, 1590, 1602, 1614, 1623, 1626, 1631, 1634, 1637, 1641, 1645, 1651, 1659, 1662, 1669, 1672, 1676, 1682, 1688, 1693, 1698, 1701, 1714, 1717, 1721, 1727, 1731, 1737, 1741, 1753, 1756, 1762, 1766, 1771, 1775, 1784, 1790, 1793, 1803, 1809, 1813, 1819, 1826, 1833, 1839, 1843, 1854, 1860, 1863, 1868, 1872, 1875, 1881, 1887, 1894, 1900, 1904, 1917, 1922, 1931, 1945, 1949, 1956, 1962, 1973, 1984, 1988, 1995], deadline = 3)
        configuration.add_task(name="Task6", identifier=6, period=20.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.408642, et_stddev=0.136214 , list_activation_dates=[12, 33, 66, 105, 156, 191, 218, 265, 287, 342, 372, 401, 445, 478, 501, 537, 558, 632, 665, 692, 748, 774, 797, 856, 886, 923, 944, 978, 1025, 1076, 1101, 1126, 1171, 1212, 1246, 1330, 1354, 1396, 1433, 1453, 1515, 1547, 1580, 1601, 1687, 1740, 1775, 1831, 1854, 1885, 1930, 1971], deadline = 25)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "42")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "42")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "42")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "42")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task1", identifier=1, period=2.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=1.390547, acet=1.390547, et_stddev=0.46351566666666666, deadline= 4)
        configuration.add_task(name="Task6", identifier=6, period=5.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.282513, et_stddev=0.094171 , list_activation_dates=[8, 16, 25, 37, 43, 50, 59, 66, 71, 105, 111, 119, 126, 133, 147, 154, 159, 164, 176, 197, 203, 218, 227, 232, 238, 252, 259, 265, 271, 281, 289, 295, 301, 307, 312, 320, 332, 338, 346, 352, 369, 374, 382, 393, 400, 411, 430, 436, 443, 450, 458, 472, 481, 491, 517, 523, 533, 540, 562, 573, 578, 600, 605, 620, 626, 632, 641, 648, 667, 673, 682, 690, 699, 711, 725, 745, 754, 759, 779, 787, 797, 826, 839, 846, 852, 860, 876, 881, 889, 894, 901, 914, 921, 928, 940, 953, 964, 969, 976, 986, 1005, 1013, 1020, 1025, 1033, 1040, 1051, 1059, 1064, 1071, 1079, 1088, 1093, 1099, 1118, 1125, 1133, 1141, 1148, 1154, 1159, 1177, 1186, 1202, 1209, 1214, 1221, 1227, 1233, 1238, 1266, 1272, 1278, 1290, 1297, 1304, 1310, 1319, 1329, 1338, 1347, 1362, 1378, 1384, 1406, 1412, 1426, 1442, 1450, 1458, 1469, 1478, 1484, 1490, 1496, 1503, 1521, 1529, 1535, 1543, 1550, 1564, 1575, 1582, 1587, 1594, 1602, 1622, 1628, 1641, 1651, 1678, 1689, 1695, 1701, 1709, 1718, 1724, 1731, 1738, 1744, 1758, 1768, 1774, 1780, 1808, 1820, 1827, 1836, 1842, 1850, 1860, 1869, 1889, 1895, 1916, 1931, 1940, 1945, 1954, 1966, 1977, 1982, 1993], deadline = 3)
        configuration.add_task(name="Task4", identifier=4, period=10.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=2, acet=1.181812, et_stddev=0.39393733333333336 , list_activation_dates=[2, 23, 35, 52, 66, 87, 117, 136, 153, 185, 204, 237, 255, 267, 304, 315, 356, 368, 390, 402, 416, 445, 457, 467, 477, 494, 507, 537, 619, 649, 666, 724, 736, 764, 784, 799, 845, 859, 871, 881, 895, 906, 918, 966, 983, 1004, 1022, 1034, 1070, 1084, 1094, 1107, 1152, 1170, 1183, 1198, 1224, 1251, 1262, 1272, 1285, 1297, 1329, 1349, 1362, 1374, 1392, 1402, 1416, 1427, 1441, 1462, 1478, 1508, 1524, 1551, 1570, 1584, 1601, 1660, 1678, 1699, 1709, 1726, 1743, 1766, 1778, 1800, 1838, 1857, 1869, 1880, 1908, 1924, 1941, 1954, 1970, 1984, 1997], deadline = 2)
        configuration.add_task(name="Task5", identifier=5, period=1.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.125315, et_stddev=0.04177166666666667 , list_activation_dates=[2, 8, 12, 13, 14, 17, 19, 21, 22, 24, 26, 28, 35, 37, 38, 39, 42, 43, 44, 48, 50, 51, 53, 54, 56, 61, 62, 64, 66, 68, 70, 74, 77, 79, 80, 82, 83, 84, 85, 87, 89, 92, 94, 95, 97, 98, 100, 101, 103, 105, 106, 107, 109, 111, 115, 117, 119, 120, 124, 125, 126, 127, 128, 131, 132, 134, 135, 136, 137, 141, 143, 144, 145, 147, 152, 153, 158, 160, 161, 162, 164, 166, 167, 168, 170, 171, 172, 173, 174, 176, 178, 179, 180, 182, 185, 186, 189, 191, 192, 193, 196, 198, 200, 202, 203, 207, 209, 211, 214, 215, 217, 218, 219, 221, 223, 224, 226, 227, 231, 233, 236, 239, 241, 242, 244, 246, 248, 249, 251, 252, 256, 258, 263, 264, 266, 268, 270, 273, 276, 279, 284, 285, 286, 289, 293, 294, 296, 303, 306, 308, 309, 311, 313, 315, 319, 320, 323, 326, 327, 328, 330, 335, 337, 339, 343, 344, 347, 350, 352, 355, 358, 360, 361, 363, 365, 369, 370, 371, 372, 373, 374, 376, 377, 378, 380, 382, 384, 387, 388, 389, 392, 396, 397, 399, 402, 404, 405, 407, 409, 411, 414, 417, 418, 419, 420, 421, 423, 424, 425, 427, 431, 434, 435, 437, 439, 441, 442, 447, 449, 450, 452, 454, 455, 458, 460, 461, 463, 466, 467, 469, 471, 472, 474, 481, 482, 488, 489, 490, 494, 495, 499, 500, 503, 505, 507, 510, 512, 515, 516, 517, 518, 519, 520, 522, 526, 528, 531, 534, 535, 540, 541, 542, 543, 544, 545, 548, 549, 550, 551, 553, 555, 557, 559, 560, 562, 563, 564, 565, 566, 569, 570, 572, 575, 576, 577, 579, 580, 586, 589, 591, 593, 595, 598, 599, 603, 606, 608, 609, 611, 612, 614, 616, 619, 620, 621, 623, 624, 626, 627, 628, 630, 633, 634, 635, 638, 640, 641, 643, 646, 647, 649, 651, 655, 656, 659, 666, 667, 670, 673, 674, 676, 678, 679, 680, 681, 683, 684, 685, 688, 689, 691, 693, 694, 695, 697, 700, 705, 706, 709, 710, 712, 713, 715, 716, 719, 721, 722, 725, 728, 730, 731, 733, 736, 739, 740, 741, 744, 748, 750, 752, 753, 754, 755, 756, 757, 759, 761, 763, 764, 766, 768, 770, 771, 775, 776, 777, 778, 779, 780, 782, 790, 792, 794, 795, 796, 801, 802, 805, 807, 810, 811, 813, 816, 817, 819, 822, 824, 825, 826, 827, 828, 830, 834, 835, 837, 838, 841, 843, 844, 845, 847, 848, 849, 850, 852, 856, 859, 861, 862, 864, 865, 867, 871, 874, 875, 877, 880, 884, 885, 887, 888, 889, 890, 892, 893, 894, 895, 896, 897, 898, 901, 903, 906, 908, 910, 912, 914, 915, 918, 920, 922, 924, 925, 926, 927, 929, 930, 932, 934, 935, 937, 939, 940, 942, 944, 945, 947, 948, 949, 950, 952, 954, 955, 957, 960, 965, 966, 967, 969, 972, 976, 977, 979, 981, 982, 983, 985, 987, 988, 990, 992, 994, 996, 998, 1000, 1002, 1003, 1006, 1007, 1008, 1010, 1012, 1015, 1016, 1017, 1018, 1022, 1024, 1026, 1028, 1029, 1030, 1034, 1035, 1036, 1039, 1040, 1042, 1043, 1048, 1049, 1051, 1053, 1057, 1060, 1062, 1064, 1066, 1067, 1068, 1070, 1072, 1074, 1076, 1078, 1079, 1080, 1082, 1083, 1084, 1088, 1090, 1093, 1095, 1097, 1099, 1100, 1103, 1104, 1106, 1107, 1109, 1110, 1114, 1116, 1117, 1120, 1121, 1123, 1126, 1130, 1132, 1134, 1136, 1138, 1140, 1141, 1143, 1145, 1146, 1147, 1149, 1154, 1156, 1157, 1159, 1161, 1163, 1164, 1165, 1168, 1169, 1171, 1173, 1174, 1175, 1177, 1178, 1179, 1183, 1185, 1186, 1188, 1189, 1190, 1191, 1192, 1198, 1199, 1201, 1204, 1205, 1209, 1212, 1214, 1215, 1217, 1219, 1220, 1221, 1223, 1225, 1227, 1229, 1232, 1236, 1239, 1242, 1243, 1244, 1247, 1248, 1252, 1254, 1258, 1260, 1261, 1263, 1265, 1266, 1270, 1273, 1274, 1278, 1279, 1283, 1284, 1286, 1288, 1289, 1292, 1293, 1295, 1299, 1304, 1305, 1307, 1311, 1312, 1314, 1317, 1318, 1322, 1324, 1325, 1326, 1327, 1329, 1332, 1334, 1335, 1337, 1338, 1340, 1342, 1345, 1349, 1350, 1353, 1354, 1356, 1357, 1359, 1360, 1362, 1366, 1370, 1372, 1375, 1376, 1378, 1380, 1382, 1383, 1384, 1388, 1390, 1391, 1392, 1395, 1396, 1398, 1400, 1401, 1404, 1405, 1406, 1408, 1411, 1413, 1416, 1417, 1419, 1421, 1423, 1425, 1426, 1429, 1430, 1432, 1433, 1436, 1438, 1439, 1441, 1443, 1444, 1446, 1449, 1450, 1451, 1453, 1454, 1456, 1459, 1463, 1464, 1466, 1467, 1469, 1471, 1472, 1473, 1477, 1478, 1480, 1481, 1483, 1485, 1487, 1489, 1490, 1492, 1494, 1498, 1499, 1502, 1504, 1505, 1508, 1509, 1512, 1516, 1518, 1519, 1522, 1524, 1525, 1527, 1529, 1531, 1532, 1534, 1537, 1541, 1542, 1546, 1548, 1549, 1553, 1555, 1556, 1557, 1559, 1561, 1563, 1566, 1570, 1572, 1575, 1578, 1579, 1580, 1582, 1583, 1585, 1586, 1589, 1592, 1593, 1595, 1597, 1598, 1601, 1604, 1608, 1610, 1611, 1612, 1613, 1614, 1615, 1616, 1619, 1621, 1622, 1624, 1626, 1630, 1633, 1635, 1637, 1638, 1642, 1643, 1644, 1647, 1648, 1653, 1656, 1658, 1659, 1660, 1661, 1662, 1664, 1665, 1667, 1670, 1671, 1673, 1675, 1679, 1682, 1684, 1686, 1687, 1689, 1690, 1692, 1693, 1694, 1697, 1699, 1700, 1701, 1703, 1705, 1706, 1708, 1709, 1710, 1712, 1714, 1716, 1718, 1720, 1722, 1723, 1725, 1727, 1730, 1733, 1735, 1736, 1738, 1739, 1741, 1742, 1743, 1745, 1746, 1748, 1750, 1751, 1754, 1755, 1756, 1757, 1759, 1761, 1762, 1763, 1764, 1766, 1769, 1771, 1772, 1774, 1776, 1779, 1780, 1781, 1784, 1785, 1787, 1788, 1791, 1792, 1793, 1798, 1800, 1805, 1807, 1808, 1810, 1812, 1818, 1819, 1821, 1822, 1823, 1824, 1826, 1828, 1831, 1833, 1835, 1836, 1840, 1842, 1844, 1845, 1848, 1852, 1855, 1858, 1859, 1861, 1863, 1864, 1865, 1866, 1867, 1872, 1873, 1876, 1877, 1882, 1884, 1887, 1888, 1889, 1890, 1892, 1896, 1898, 1899, 1900, 1901, 1903, 1904, 1907, 1908, 1909, 1912, 1913, 1914, 1916, 1918, 1919, 1921, 1924, 1927, 1928, 1930, 1931, 1933, 1934, 1935, 1938, 1941, 1942, 1944, 1946, 1948, 1949, 1950, 1955, 1956, 1958, 1961, 1964, 1965, 1967, 1968, 1971, 1972, 1973, 1974, 1975, 1977, 1978, 1979, 1983, 1989, 1990, 1991, 1993, 1995, 1996, 1997, 1999, 2000], deadline = 1)
        configuration.add_task(name="Task3", identifier=3, period=39.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=11.010148, acet=11.010148, et_stddev=3.670049333333333, deadline= 32)
        configuration.add_task(name="Task2", identifier=2, period=3.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=1.867244, acet=1.867244, et_stddev=0.6224146666666667, deadline= 3)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "43")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "43")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "43")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "43")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task5", identifier=5, period=10.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.615083, et_stddev=0.2050276666666667 , list_activation_dates=[14, 25, 46, 62, 76, 87, 101, 120, 142, 152, 164, 213, 235, 247, 262, 273, 318, 344, 371, 386, 399, 442, 458, 470, 487, 498, 511, 527, 557, 577, 591, 623, 638, 651, 672, 687, 713, 739, 749, 761, 775, 788, 798, 809, 840, 850, 870, 885, 900, 917, 930, 950, 988, 1013, 1029, 1050, 1070, 1087, 1118, 1130, 1156, 1175, 1187, 1202, 1217, 1238, 1257, 1292, 1304, 1356, 1373, 1383, 1398, 1439, 1463, 1513, 1532, 1552, 1589, 1605, 1621, 1653, 1675, 1714, 1725, 1744, 1759, 1770, 1786, 1810, 1822, 1842, 1861, 1874, 1907, 1927, 1940, 1951, 1993], deadline = 2)
        configuration.add_task(name="Task3", identifier=3, period=16.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=8.764173, acet=8.764173, et_stddev=2.921391, deadline= 13)
        configuration.add_task(name="Task6", identifier=6, period=1.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.176727, et_stddev=0.058908999999999996 , list_activation_dates=[2, 4, 7, 10, 11, 12, 15, 19, 21, 25, 26, 27, 28, 30, 31, 32, 33, 34, 35, 37, 40, 41, 43, 47, 48, 50, 55, 57, 58, 60, 61, 63, 65, 69, 71, 75, 77, 79, 80, 82, 84, 87, 90, 91, 92, 95, 96, 98, 100, 101, 103, 105, 107, 110, 112, 115, 117, 120, 122, 126, 127, 131, 133, 134, 135, 136, 137, 139, 142, 144, 146, 147, 148, 149, 151, 152, 156, 158, 162, 164, 165, 169, 171, 172, 174, 175, 178, 180, 181, 183, 184, 186, 189, 191, 193, 195, 197, 200, 201, 202, 203, 204, 206, 209, 211, 212, 213, 215, 216, 217, 221, 224, 225, 228, 230, 231, 232, 235, 237, 240, 242, 244, 248, 249, 252, 253, 255, 258, 261, 263, 266, 267, 270, 272, 273, 277, 280, 282, 284, 285, 288, 289, 291, 293, 295, 296, 298, 302, 305, 308, 314, 315, 316, 319, 321, 323, 326, 327, 331, 332, 334, 336, 338, 339, 340, 342, 344, 346, 348, 350, 351, 352, 354, 357, 361, 362, 363, 364, 366, 368, 371, 373, 375, 379, 380, 382, 384, 385, 387, 389, 391, 393, 395, 396, 397, 400, 402, 403, 407, 409, 411, 413, 414, 415, 417, 419, 421, 423, 424, 426, 428, 430, 433, 437, 438, 440, 442, 444, 445, 446, 447, 450, 451, 452, 455, 457, 459, 460, 462, 464, 466, 467, 468, 470, 473, 476, 479, 482, 486, 488, 491, 493, 494, 498, 500, 501, 502, 504, 507, 511, 512, 513, 514, 517, 520, 522, 523, 525, 527, 532, 533, 534, 538, 540, 542, 544, 545, 548, 550, 551, 552, 554, 555, 557, 560, 562, 566, 567, 568, 570, 571, 574, 575, 580, 581, 582, 584, 585, 586, 588, 590, 591, 592, 593, 595, 596, 599, 600, 601, 602, 606, 608, 609, 610, 612, 613, 615, 617, 618, 619, 620, 623, 625, 627, 628, 629, 630, 635, 636, 637, 638, 639, 641, 644, 646, 647, 648, 650, 652, 656, 657, 658, 663, 664, 665, 667, 669, 670, 672, 673, 674, 676, 680, 682, 684, 686, 688, 689, 691, 692, 694, 695, 697, 698, 700, 703, 705, 706, 709, 711, 712, 714, 718, 722, 723, 725, 727, 729, 731, 732, 733, 735, 736, 741, 742, 744, 745, 747, 748, 749, 752, 754, 756, 758, 759, 760, 763, 765, 767, 768, 770, 771, 773, 774, 775, 777, 778, 779, 780, 782, 784, 786, 788, 789, 790, 794, 797, 799, 801, 803, 804, 806, 809, 814, 815, 816, 819, 821, 823, 826, 827, 829, 831, 834, 836, 838, 840, 841, 846, 850, 851, 854, 855, 857, 860, 861, 863, 865, 866, 868, 871, 872, 873, 876, 877, 878, 880, 882, 883, 884, 887, 888, 889, 890, 892, 893, 897, 899, 901, 904, 906, 908, 910, 911, 914, 916, 917, 919, 921, 924, 927, 928, 930, 933, 935, 936, 938, 939, 944, 946, 948, 953, 954, 955, 957, 958, 959, 961, 962, 967, 969, 971, 972, 973, 974, 975, 977, 979, 981, 983, 985, 986, 987, 989, 991, 992, 995, 997, 998, 999, 1000, 1001, 1002, 1004, 1007, 1009, 1011, 1012, 1014, 1016, 1017, 1019, 1022, 1023, 1024, 1026, 1028, 1031, 1032, 1034, 1037, 1041, 1042, 1043, 1044, 1046, 1048, 1050, 1052, 1053, 1055, 1056, 1058, 1060, 1063, 1064, 1066, 1067, 1068, 1069, 1072, 1074, 1075, 1076, 1077, 1079, 1080, 1084, 1087, 1090, 1093, 1095, 1099, 1100, 1102, 1103, 1104, 1106, 1109, 1114, 1115, 1116, 1117, 1118, 1119, 1120, 1121, 1124, 1125, 1126, 1129, 1131, 1133, 1134, 1136, 1139, 1141, 1143, 1144, 1145, 1147, 1149, 1151, 1153, 1155, 1157, 1159, 1161, 1163, 1165, 1166, 1167, 1169, 1173, 1176, 1178, 1179, 1180, 1182, 1183, 1185, 1186, 1188, 1189, 1190, 1193, 1195, 1197, 1203, 1205, 1208, 1210, 1211, 1212, 1213, 1214, 1216, 1218, 1219, 1221, 1223, 1225, 1228, 1230, 1231, 1233, 1234, 1236, 1237, 1239, 1243, 1246, 1249, 1251, 1252, 1253, 1254, 1256, 1258, 1260, 1262, 1265, 1266, 1268, 1273, 1274, 1275, 1276, 1278, 1279, 1281, 1282, 1283, 1285, 1287, 1289, 1291, 1293, 1295, 1297, 1298, 1299, 1300, 1301, 1302, 1303, 1304, 1306, 1308, 1309, 1310, 1311, 1312, 1314, 1316, 1317, 1319, 1323, 1325, 1328, 1329, 1331, 1332, 1334, 1338, 1339, 1341, 1344, 1349, 1351, 1353, 1357, 1359, 1360, 1361, 1364, 1368, 1369, 1371, 1373, 1374, 1376, 1378, 1380, 1383, 1386, 1390, 1394, 1397, 1398, 1401, 1402, 1404, 1405, 1407, 1409, 1411, 1415, 1417, 1418, 1420, 1423, 1425, 1426, 1428, 1430, 1431, 1435, 1436, 1438, 1440, 1444, 1446, 1449, 1450, 1451, 1454, 1456, 1459, 1460, 1461, 1465, 1466, 1467, 1468, 1471, 1474, 1477, 1479, 1481, 1482, 1484, 1485, 1488, 1490, 1495, 1497, 1498, 1500, 1502, 1505, 1506, 1508, 1509, 1511, 1515, 1516, 1519, 1520, 1521, 1523, 1525, 1527, 1534, 1536, 1539, 1540, 1541, 1542, 1543, 1544, 1545, 1547, 1552, 1553, 1555, 1556, 1558, 1563, 1564, 1566, 1567, 1570, 1574, 1575, 1577, 1578, 1579, 1581, 1582, 1584, 1585, 1587, 1590, 1591, 1592, 1593, 1595, 1598, 1599, 1602, 1604, 1605, 1606, 1607, 1608, 1611, 1615, 1618, 1620, 1622, 1626, 1629, 1634, 1636, 1637, 1638, 1641, 1642, 1644, 1646, 1648, 1649, 1650, 1652, 1655, 1657, 1660, 1661, 1665, 1667, 1669, 1672, 1677, 1683, 1686, 1688, 1690, 1692, 1694, 1696, 1698, 1700, 1702, 1704, 1705, 1708, 1709, 1711, 1714, 1716, 1717, 1718, 1720, 1722, 1724, 1728, 1730, 1736, 1738, 1742, 1745, 1746, 1747, 1748, 1752, 1753, 1756, 1757, 1759, 1760, 1762, 1764, 1766, 1769, 1773, 1775, 1777, 1780, 1781, 1782, 1785, 1786, 1788, 1790, 1791, 1792, 1795, 1798, 1800, 1801, 1802, 1803, 1804, 1810, 1811, 1813, 1815, 1816, 1817, 1818, 1821, 1822, 1824, 1825, 1831, 1834, 1835, 1838, 1839, 1841, 1843, 1845, 1847, 1848, 1851, 1852, 1853, 1854, 1857, 1860, 1861, 1862, 1863, 1864, 1865, 1866, 1868, 1870, 1872, 1874, 1875, 1878, 1879, 1880, 1882, 1883, 1885, 1887, 1892, 1893, 1894, 1895, 1896, 1897, 1899, 1901, 1902, 1904, 1905, 1907, 1909, 1912, 1915, 1918, 1920, 1922, 1924, 1925, 1928, 1929, 1931, 1933, 1935, 1937, 1938, 1939, 1942, 1944, 1947, 1948, 1949, 1953, 1954, 1957, 1959, 1960, 1963, 1964, 1968, 1970, 1973, 1976, 1978, 1979, 1981, 1983, 1984, 1986, 1987, 1990, 1993, 1994, 1995, 1997, 1998, 1999], deadline = 1)
        configuration.add_task(name="Task4", identifier=4, period=6.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.370585, et_stddev=0.12352833333333334 , list_activation_dates=[1, 13, 27, 39, 48, 66, 75, 83, 105, 117, 129, 144, 152, 158, 166, 174, 188, 195, 203, 211, 222, 229, 236, 247, 254, 268, 283, 301, 318, 325, 336, 354, 360, 367, 385, 391, 400, 410, 423, 435, 445, 459, 465, 476, 483, 505, 514, 523, 529, 537, 551, 563, 571, 578, 585, 591, 598, 605, 611, 643, 657, 663, 675, 683, 700, 712, 723, 744, 752, 768, 779, 799, 810, 818, 848, 866, 889, 897, 913, 919, 927, 939, 950, 958, 969, 978, 986, 999, 1008, 1015, 1024, 1037, 1046, 1056, 1067, 1085, 1094, 1105, 1111, 1129, 1158, 1169, 1177, 1187, 1204, 1211, 1218, 1227, 1234, 1241, 1260, 1267, 1285, 1297, 1306, 1313, 1328, 1339, 1347, 1355, 1362, 1371, 1385, 1395, 1410, 1428, 1437, 1448, 1461, 1469, 1479, 1487, 1494, 1511, 1518, 1524, 1531, 1541, 1549, 1557, 1565, 1573, 1598, 1617, 1627, 1640, 1662, 1682, 1693, 1703, 1713, 1721, 1730, 1738, 1746, 1755, 1761, 1777, 1784, 1790, 1811, 1825, 1848, 1866, 1873, 1883, 1890, 1904, 1913, 1926, 1943, 1949, 1956, 1962, 1978, 1987, 1997], deadline = 8)
        configuration.add_task(name="Task2", identifier=2, period=9.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=2.395874, acet=2.395874, et_stddev=0.7986246666666666, deadline= 12)
        configuration.add_task(name="Task1", identifier=1, period=3.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=2.358092, acet=2.358092, et_stddev=0.7860306666666667, deadline= 6)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "44")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "44")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "44")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "44")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task2", identifier=2, period=10.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=6.948787, acet=6.948787, et_stddev=2.3162623333333334, deadline= 7)
        configuration.add_task(name="Task1", identifier=1, period=13.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=6.869276, acet=6.869276, et_stddev=2.2897586666666667, deadline= 16)
        configuration.add_task(name="Task5", identifier=5, period=3.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.103469, et_stddev=0.03448966666666667 , list_activation_dates=[2, 8, 15, 19, 22, 28, 31, 34, 41, 46, 50, 55, 61, 78, 82, 89, 94, 102, 106, 114, 117, 122, 130, 135, 139, 150, 154, 164, 174, 181, 186, 190, 202, 206, 212, 215, 228, 234, 245, 250, 254, 257, 261, 270, 284, 292, 302, 308, 316, 320, 325, 330, 339, 342, 349, 352, 355, 358, 362, 366, 371, 377, 386, 389, 394, 397, 400, 403, 411, 415, 418, 432, 443, 449, 454, 463, 470, 473, 480, 489, 498, 503, 506, 512, 517, 521, 526, 531, 534, 537, 542, 546, 552, 556, 563, 568, 572, 580, 593, 596, 600, 603, 607, 612, 619, 629, 635, 639, 645, 650, 653, 658, 663, 668, 674, 678, 685, 688, 698, 702, 708, 712, 715, 725, 729, 736, 739, 750, 755, 759, 764, 768, 773, 777, 781, 789, 793, 803, 807, 814, 818, 825, 832, 838, 844, 849, 858, 861, 869, 872, 877, 881, 885, 895, 905, 915, 918, 928, 946, 952, 957, 964, 969, 972, 976, 980, 985, 988, 994, 997, 1001, 1008, 1012, 1021, 1024, 1031, 1037, 1047, 1052, 1062, 1066, 1071, 1075, 1080, 1091, 1096, 1101, 1106, 1110, 1114, 1120, 1124, 1132, 1139, 1144, 1154, 1158, 1163, 1172, 1179, 1186, 1193, 1202, 1212, 1218, 1229, 1232, 1239, 1244, 1249, 1253, 1261, 1269, 1272, 1276, 1287, 1291, 1294, 1298, 1303, 1306, 1311, 1319, 1323, 1331, 1336, 1341, 1346, 1350, 1355, 1362, 1367, 1383, 1387, 1393, 1398, 1405, 1412, 1416, 1422, 1426, 1432, 1438, 1445, 1448, 1453, 1457, 1467, 1473, 1480, 1488, 1492, 1508, 1514, 1518, 1524, 1528, 1531, 1540, 1545, 1550, 1554, 1557, 1563, 1570, 1574, 1577, 1581, 1585, 1592, 1603, 1612, 1620, 1626, 1631, 1635, 1651, 1659, 1663, 1671, 1675, 1678, 1682, 1686, 1695, 1703, 1719, 1722, 1727, 1733, 1743, 1750, 1761, 1765, 1768, 1772, 1789, 1796, 1799, 1807, 1814, 1824, 1829, 1835, 1839, 1847, 1854, 1858, 1862, 1866, 1878, 1882, 1886, 1893, 1898, 1904, 1913, 1918, 1922, 1933, 1937, 1944, 1948, 1952, 1956, 1961, 1966, 1970, 1974, 1977, 1981, 1984, 1990, 1994], deadline = 3)
        configuration.add_task(name="Task4", identifier=4, period=4.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=2, acet=1.043271, et_stddev=0.34775700000000004 , list_activation_dates=[1, 8, 16, 22, 30, 35, 40, 49, 60, 65, 72, 79, 86, 92, 99, 103, 112, 134, 140, 146, 154, 165, 173, 187, 192, 200, 206, 213, 220, 225, 236, 242, 248, 254, 264, 271, 277, 285, 290, 295, 300, 306, 313, 317, 321, 330, 339, 346, 359, 366, 372, 376, 384, 392, 399, 403, 411, 417, 427, 436, 459, 464, 472, 480, 487, 491, 496, 502, 508, 513, 540, 553, 560, 567, 579, 585, 589, 599, 603, 607, 616, 621, 651, 658, 662, 673, 680, 691, 696, 708, 714, 719, 734, 741, 745, 750, 756, 762, 766, 785, 791, 796, 807, 816, 826, 832, 837, 841, 860, 866, 884, 892, 908, 916, 923, 930, 938, 955, 961, 967, 972, 984, 991, 998, 1005, 1012, 1016, 1021, 1025, 1033, 1038, 1046, 1054, 1062, 1069, 1074, 1087, 1092, 1100, 1106, 1111, 1126, 1131, 1136, 1142, 1148, 1159, 1166, 1174, 1183, 1187, 1201, 1205, 1209, 1217, 1224, 1231, 1236, 1243, 1254, 1261, 1266, 1270, 1280, 1285, 1289, 1294, 1299, 1317, 1322, 1328, 1332, 1340, 1347, 1352, 1356, 1364, 1369, 1373, 1381, 1387, 1397, 1401, 1406, 1418, 1423, 1433, 1441, 1446, 1454, 1458, 1463, 1482, 1489, 1503, 1517, 1522, 1535, 1543, 1549, 1554, 1562, 1566, 1575, 1589, 1594, 1598, 1603, 1611, 1617, 1626, 1632, 1636, 1640, 1645, 1652, 1660, 1678, 1689, 1701, 1714, 1718, 1738, 1744, 1750, 1757, 1761, 1776, 1780, 1808, 1814, 1820, 1827, 1836, 1842, 1847, 1853, 1858, 1865, 1878, 1883, 1888, 1899, 1906, 1914, 1919, 1926, 1931, 1946, 1956, 1970, 1979, 1992, 1996], deadline = 4)
        configuration.add_task(name="Task6", identifier=6, period=15.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.070383, et_stddev=0.023461 , list_activation_dates=[4, 52, 78, 103, 168, 196, 245, 267, 287, 316, 334, 359, 374, 401, 444, 473, 500, 598, 623, 686, 708, 758, 777, 797, 837, 891, 917, 937, 972, 990, 1014, 1033, 1069, 1093, 1148, 1174, 1194, 1212, 1231, 1269, 1287, 1312, 1353, 1386, 1418, 1436, 1461, 1493, 1510, 1539, 1598, 1625, 1642, 1659, 1679, 1737, 1768, 1828, 1846, 1869, 1904, 1925, 1961, 1987], deadline = 4)
        configuration.add_task(name="Task3", identifier=3, period=2.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=0.75343, acet=0.75343, et_stddev=0.25114333333333333, deadline= 4)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "45")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "45")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "45")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "45")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task3", identifier=3, period=12.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=5.073218, acet=5.073218, et_stddev=1.6910726666666667, deadline= 10)
        configuration.add_task(name="Task4", identifier=4, period=1.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.21191, et_stddev=0.07063666666666667 , list_activation_dates=[1, 3, 4, 5, 10, 12, 14, 16, 17, 18, 20, 24, 26, 28, 31, 32, 34, 38, 43, 44, 46, 48, 49, 50, 52, 55, 57, 58, 59, 62, 66, 69, 71, 72, 73, 77, 78, 80, 81, 83, 84, 85, 90, 91, 93, 94, 95, 96, 98, 99, 100, 102, 106, 107, 109, 111, 114, 115, 118, 120, 123, 126, 129, 130, 132, 133, 135, 137, 139, 141, 143, 144, 145, 146, 148, 151, 152, 153, 155, 160, 161, 164, 166, 167, 170, 172, 173, 176, 178, 180, 182, 185, 187, 188, 191, 192, 194, 195, 197, 198, 201, 202, 203, 206, 208, 210, 212, 215, 216, 220, 222, 225, 227, 228, 232, 234, 237, 239, 241, 242, 244, 249, 253, 254, 256, 257, 261, 262, 263, 265, 267, 269, 270, 272, 273, 275, 276, 277, 278, 281, 283, 287, 289, 291, 292, 294, 297, 299, 300, 302, 304, 305, 308, 311, 313, 318, 323, 324, 326, 327, 328, 330, 331, 332, 334, 335, 337, 338, 340, 341, 343, 345, 348, 350, 352, 354, 356, 358, 359, 362, 364, 365, 369, 370, 372, 374, 375, 376, 379, 381, 383, 388, 389, 391, 393, 394, 398, 399, 401, 403, 405, 407, 408, 409, 410, 411, 414, 415, 416, 419, 421, 422, 423, 424, 426, 427, 429, 433, 434, 436, 438, 440, 442, 444, 445, 448, 450, 451, 452, 455, 458, 461, 464, 466, 468, 470, 472, 474, 476, 478, 480, 483, 484, 485, 487, 488, 491, 492, 493, 494, 496, 497, 498, 502, 504, 510, 512, 514, 516, 520, 521, 523, 525, 527, 531, 533, 535, 536, 537, 538, 541, 542, 546, 547, 548, 550, 552, 555, 556, 559, 561, 563, 565, 567, 568, 569, 571, 573, 576, 577, 579, 580, 582, 583, 585, 586, 587, 588, 589, 591, 593, 595, 598, 600, 602, 605, 606, 608, 609, 612, 614, 616, 618, 620, 622, 625, 627, 628, 629, 630, 631, 632, 634, 635, 637, 639, 641, 642, 645, 649, 651, 652, 653, 655, 657, 658, 659, 660, 662, 664, 668, 670, 672, 674, 675, 677, 680, 681, 683, 686, 687, 688, 690, 691, 692, 693, 694, 696, 697, 699, 700, 704, 705, 706, 708, 710, 713, 715, 720, 722, 724, 726, 727, 731, 734, 741, 742, 743, 745, 747, 748, 750, 751, 752, 755, 757, 759, 760, 762, 763, 765, 767, 772, 775, 778, 779, 780, 782, 783, 785, 786, 788, 791, 792, 793, 794, 795, 800, 802, 805, 806, 809, 810, 813, 816, 822, 824, 826, 829, 832, 837, 840, 841, 842, 844, 847, 849, 853, 855, 856, 858, 860, 862, 864, 865, 867, 870, 871, 873, 875, 877, 878, 880, 883, 884, 885, 889, 890, 891, 893, 895, 897, 899, 900, 901, 902, 905, 909, 911, 913, 914, 917, 919, 921, 922, 926, 927, 928, 929, 930, 931, 933, 938, 941, 945, 947, 950, 952, 954, 955, 956, 959, 961, 963, 967, 969, 972, 974, 976, 977, 978, 980, 984, 986, 989, 991, 992, 994, 995, 998, 999, 1004, 1005, 1006, 1008, 1009, 1014, 1015, 1018, 1019, 1021, 1025, 1027, 1028, 1029, 1030, 1032, 1034, 1035, 1036, 1037, 1039, 1040, 1043, 1044, 1046, 1049, 1051, 1052, 1054, 1056, 1058, 1059, 1061, 1062, 1063, 1065, 1066, 1071, 1073, 1074, 1075, 1078, 1080, 1082, 1083, 1086, 1088, 1090, 1091, 1092, 1093, 1094, 1097, 1100, 1101, 1103, 1104, 1106, 1110, 1115, 1117, 1118, 1121, 1123, 1125, 1126, 1128, 1131, 1133, 1137, 1142, 1143, 1144, 1146, 1148, 1150, 1152, 1155, 1157, 1159, 1162, 1163, 1166, 1168, 1170, 1171, 1173, 1175, 1180, 1182, 1185, 1187, 1188, 1189, 1190, 1191, 1193, 1196, 1198, 1200, 1203, 1207, 1210, 1212, 1216, 1218, 1219, 1221, 1222, 1225, 1228, 1230, 1231, 1233, 1235, 1241, 1243, 1244, 1246, 1248, 1250, 1251, 1252, 1254, 1257, 1258, 1260, 1261, 1262, 1263, 1264, 1265, 1267, 1269, 1270, 1271, 1273, 1274, 1277, 1278, 1279, 1283, 1285, 1286, 1289, 1290, 1292, 1293, 1295, 1297, 1299, 1301, 1303, 1305, 1309, 1311, 1312, 1313, 1315, 1316, 1318, 1320, 1321, 1322, 1324, 1327, 1333, 1335, 1337, 1338, 1340, 1342, 1343, 1345, 1347, 1349, 1351, 1353, 1355, 1357, 1358, 1360, 1362, 1364, 1367, 1371, 1373, 1375, 1376, 1379, 1383, 1385, 1387, 1388, 1391, 1393, 1394, 1396, 1397, 1399, 1401, 1406, 1409, 1411, 1413, 1415, 1418, 1422, 1425, 1427, 1428, 1429, 1433, 1436, 1438, 1440, 1441, 1444, 1445, 1446, 1447, 1448, 1449, 1451, 1453, 1454, 1458, 1460, 1462, 1466, 1467, 1471, 1473, 1475, 1477, 1479, 1480, 1486, 1487, 1488, 1492, 1493, 1497, 1498, 1500, 1501, 1502, 1503, 1508, 1509, 1510, 1511, 1514, 1516, 1517, 1518, 1520, 1522, 1526, 1527, 1528, 1530, 1532, 1535, 1537, 1539, 1540, 1541, 1543, 1545, 1547, 1549, 1551, 1553, 1554, 1556, 1557, 1559, 1561, 1562, 1564, 1567, 1568, 1570, 1573, 1574, 1575, 1576, 1577, 1580, 1581, 1584, 1587, 1589, 1592, 1593, 1594, 1599, 1600, 1602, 1605, 1607, 1609, 1610, 1612, 1615, 1617, 1621, 1622, 1625, 1627, 1630, 1632, 1634, 1636, 1637, 1638, 1639, 1641, 1642, 1644, 1645, 1646, 1648, 1650, 1651, 1652, 1654, 1657, 1658, 1659, 1661, 1663, 1664, 1667, 1669, 1671, 1673, 1674, 1675, 1679, 1681, 1683, 1684, 1687, 1689, 1691, 1693, 1694, 1695, 1696, 1698, 1699, 1700, 1702, 1705, 1706, 1708, 1709, 1711, 1713, 1717, 1718, 1719, 1722, 1723, 1725, 1727, 1728, 1730, 1732, 1734, 1736, 1739, 1741, 1743, 1748, 1751, 1753, 1755, 1757, 1758, 1760, 1762, 1764, 1766, 1768, 1772, 1774, 1775, 1777, 1778, 1780, 1782, 1785, 1786, 1790, 1792, 1793, 1795, 1797, 1799, 1801, 1802, 1804, 1806, 1807, 1809, 1811, 1813, 1814, 1815, 1817, 1818, 1820, 1823, 1825, 1827, 1828, 1830, 1832, 1834, 1836, 1837, 1838, 1839, 1841, 1842, 1844, 1846, 1848, 1849, 1850, 1853, 1855, 1859, 1862, 1864, 1866, 1869, 1870, 1873, 1875, 1877, 1878, 1880, 1882, 1884, 1885, 1887, 1890, 1892, 1895, 1896, 1901, 1903, 1905, 1907, 1911, 1912, 1914, 1915, 1917, 1918, 1920, 1922, 1923, 1924, 1925, 1927, 1929, 1930, 1936, 1938, 1940, 1943, 1945, 1946, 1947, 1948, 1953, 1955, 1956, 1957, 1960, 1963, 1965, 1966, 1971, 1975, 1978, 1980, 1981, 1983, 1984, 1985, 1987, 1989, 1991, 1993, 1995, 1996, 1997, 1999], deadline = 2)
        configuration.add_task(name="Task5", identifier=5, period=6.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.301136, et_stddev=0.10037866666666667 , list_activation_dates=[8, 20, 27, 42, 50, 57, 68, 74, 92, 106, 112, 120, 136, 158, 170, 184, 190, 199, 210, 218, 224, 245, 251, 266, 274, 282, 290, 304, 321, 329, 339, 347, 359, 366, 381, 389, 398, 406, 414, 420, 435, 445, 467, 474, 481, 490, 503, 511, 522, 528, 541, 556, 566, 592, 610, 616, 629, 635, 643, 657, 664, 691, 701, 708, 720, 734, 742, 758, 771, 801, 812, 821, 847, 864, 875, 883, 890, 901, 908, 920, 932, 942, 973, 983, 1004, 1010, 1016, 1028, 1036, 1044, 1051, 1073, 1107, 1116, 1123, 1134, 1148, 1154, 1163, 1170, 1177, 1186, 1195, 1206, 1219, 1236, 1251, 1257, 1270, 1276, 1287, 1296, 1315, 1324, 1330, 1340, 1348, 1355, 1366, 1376, 1390, 1397, 1407, 1433, 1440, 1447, 1455, 1461, 1478, 1488, 1498, 1514, 1526, 1537, 1548, 1554, 1566, 1585, 1593, 1618, 1627, 1638, 1646, 1652, 1671, 1678, 1691, 1732, 1739, 1752, 1759, 1776, 1782, 1789, 1800, 1808, 1816, 1824, 1841, 1852, 1858, 1871, 1879, 1906, 1915, 1922, 1946, 1953, 1967, 1980, 1995], deadline = 3)
        configuration.add_task(name="Task2", identifier=2, period=3.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=2.434483, acet=2.434483, et_stddev=0.8114943333333334, deadline= 4)
        configuration.add_task(name="Task6", identifier=6, period=4.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.151599, et_stddev=0.050533 , list_activation_dates=[5, 9, 29, 43, 49, 53, 59, 64, 69, 75, 82, 86, 91, 96, 109, 115, 127, 141, 153, 167, 179, 183, 189, 195, 200, 212, 219, 228, 232, 239, 244, 249, 254, 263, 270, 275, 279, 284, 290, 297, 301, 306, 313, 319, 325, 330, 343, 362, 367, 378, 389, 396, 402, 407, 413, 420, 435, 442, 449, 460, 475, 489, 500, 505, 515, 526, 533, 541, 548, 556, 561, 571, 580, 584, 590, 605, 618, 624, 632, 636, 643, 648, 652, 667, 684, 691, 707, 716, 720, 726, 735, 739, 751, 756, 761, 768, 777, 788, 797, 805, 810, 815, 820, 824, 831, 836, 843, 848, 853, 866, 875, 887, 894, 899, 906, 912, 918, 934, 938, 944, 949, 957, 969, 978, 982, 988, 997, 1003, 1007, 1020, 1034, 1038, 1042, 1048, 1058, 1069, 1076, 1081, 1086, 1098, 1102, 1113, 1123, 1130, 1134, 1146, 1150, 1155, 1166, 1170, 1178, 1183, 1188, 1193, 1197, 1201, 1205, 1216, 1222, 1230, 1237, 1245, 1256, 1267, 1274, 1278, 1288, 1295, 1299, 1303, 1318, 1325, 1334, 1341, 1347, 1352, 1362, 1370, 1379, 1384, 1389, 1397, 1405, 1430, 1434, 1456, 1464, 1470, 1486, 1490, 1494, 1500, 1514, 1519, 1527, 1534, 1540, 1545, 1550, 1556, 1566, 1572, 1579, 1584, 1595, 1606, 1614, 1631, 1653, 1660, 1665, 1672, 1678, 1683, 1694, 1707, 1716, 1722, 1734, 1743, 1750, 1758, 1763, 1768, 1776, 1781, 1785, 1790, 1814, 1818, 1824, 1840, 1847, 1857, 1862, 1868, 1873, 1878, 1882, 1889, 1896, 1900, 1907, 1911, 1916, 1920, 1930, 1938, 1945, 1953, 1958, 1963, 1969, 1974, 1992], deadline = 2)
        configuration.add_task(name="Task1", identifier=1, period=12.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=4.388848, acet=4.388848, et_stddev=1.4629493333333334, deadline= 13)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "46")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "46")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "46")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "46")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task2", identifier=2, period=24.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=0.284247, acet=0.284247, et_stddev=0.09474900000000001, deadline= 48)
        configuration.add_task(name="Task3", identifier=3, period=2.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=1.557695, acet=1.557695, et_stddev=0.5192316666666666, deadline= 4)
        configuration.add_task(name="Task4", identifier=4, period=2.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.0532, et_stddev=0.017733333333333334 , list_activation_dates=[3, 7, 9, 11, 18, 21, 24, 27, 29, 32, 42, 45, 51, 54, 57, 63, 71, 74, 76, 78, 83, 85, 88, 91, 97, 99, 103, 109, 116, 123, 126, 128, 139, 141, 145, 155, 158, 162, 164, 168, 171, 173, 176, 178, 180, 182, 186, 188, 193, 196, 201, 205, 208, 215, 221, 223, 229, 231, 234, 237, 241, 243, 247, 250, 253, 256, 259, 262, 265, 268, 271, 277, 280, 284, 287, 289, 293, 299, 303, 308, 312, 317, 319, 321, 328, 332, 336, 339, 342, 349, 352, 357, 359, 361, 366, 369, 374, 377, 387, 392, 399, 402, 407, 410, 413, 415, 419, 423, 427, 431, 435, 438, 442, 450, 453, 456, 460, 464, 469, 473, 478, 481, 483, 489, 492, 497, 509, 511, 513, 516, 520, 524, 528, 530, 534, 537, 541, 544, 546, 551, 554, 562, 570, 575, 581, 583, 585, 589, 594, 597, 600, 603, 607, 609, 611, 613, 617, 619, 622, 624, 626, 629, 632, 636, 641, 647, 649, 657, 662, 666, 672, 675, 678, 681, 687, 698, 702, 704, 710, 717, 721, 729, 732, 736, 739, 741, 744, 746, 749, 754, 757, 760, 764, 766, 768, 771, 775, 778, 781, 784, 787, 790, 792, 797, 800, 803, 808, 812, 815, 819, 821, 825, 830, 832, 834, 837, 841, 844, 849, 851, 855, 857, 862, 865, 868, 872, 875, 879, 883, 892, 895, 901, 906, 908, 913, 916, 918, 922, 925, 927, 932, 936, 939, 942, 945, 949, 954, 957, 962, 965, 968, 972, 978, 984, 987, 990, 1000, 1003, 1007, 1012, 1014, 1022, 1024, 1028, 1031, 1036, 1040, 1043, 1047, 1049, 1051, 1059, 1062, 1068, 1071, 1074, 1076, 1080, 1083, 1085, 1090, 1096, 1103, 1106, 1109, 1113, 1117, 1126, 1131, 1141, 1147, 1151, 1157, 1178, 1189, 1192, 1194, 1198, 1201, 1203, 1209, 1212, 1217, 1222, 1225, 1229, 1232, 1235, 1237, 1241, 1243, 1246, 1250, 1252, 1254, 1257, 1259, 1261, 1264, 1267, 1270, 1272, 1274, 1276, 1279, 1281, 1285, 1293, 1298, 1300, 1302, 1304, 1309, 1312, 1320, 1324, 1326, 1331, 1336, 1341, 1346, 1351, 1354, 1358, 1362, 1364, 1370, 1373, 1375, 1379, 1387, 1392, 1397, 1400, 1403, 1410, 1415, 1421, 1424, 1427, 1431, 1436, 1439, 1448, 1455, 1461, 1466, 1470, 1473, 1477, 1482, 1486, 1488, 1497, 1500, 1505, 1511, 1513, 1518, 1521, 1526, 1529, 1533, 1536, 1540, 1543, 1552, 1560, 1563, 1567, 1570, 1576, 1581, 1593, 1598, 1600, 1606, 1609, 1612, 1615, 1618, 1622, 1624, 1628, 1633, 1636, 1642, 1646, 1648, 1650, 1653, 1657, 1663, 1666, 1674, 1679, 1682, 1685, 1687, 1691, 1694, 1696, 1699, 1702, 1704, 1706, 1710, 1713, 1717, 1723, 1727, 1731, 1734, 1738, 1743, 1752, 1755, 1758, 1761, 1770, 1773, 1779, 1781, 1786, 1789, 1791, 1795, 1800, 1803, 1807, 1812, 1818, 1821, 1823, 1828, 1830, 1833, 1837, 1841, 1847, 1849, 1852, 1855, 1862, 1865, 1867, 1869, 1872, 1875, 1877, 1891, 1898, 1901, 1904, 1908, 1910, 1913, 1916, 1920, 1924, 1926, 1930, 1937, 1943, 1948, 1950, 1953, 1956, 1961, 1966, 1969, 1972, 1977, 1983, 1987, 1993, 1995, 1998], deadline = 4)
        configuration.add_task(name="Task5", identifier=5, period=7.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=2, acet=1.192301, et_stddev=0.3974336666666667 , list_activation_dates=[2, 16, 28, 36, 44, 51, 61, 75, 86, 100, 119, 128, 157, 167, 174, 188, 201, 215, 224, 246, 261, 282, 301, 316, 337, 362, 372, 395, 409, 437, 445, 459, 471, 493, 501, 530, 546, 570, 587, 606, 613, 630, 648, 657, 666, 674, 684, 697, 707, 722, 751, 758, 792, 805, 818, 827, 840, 848, 861, 875, 883, 897, 907, 920, 944, 962, 969, 991, 1017, 1043, 1056, 1080, 1109, 1119, 1130, 1139, 1150, 1165, 1181, 1191, 1199, 1215, 1223, 1231, 1250, 1268, 1286, 1297, 1329, 1340, 1350, 1374, 1388, 1410, 1431, 1444, 1454, 1461, 1472, 1482, 1496, 1506, 1517, 1528, 1543, 1550, 1568, 1577, 1587, 1598, 1606, 1616, 1632, 1642, 1655, 1663, 1670, 1677, 1689, 1699, 1714, 1726, 1739, 1751, 1761, 1773, 1785, 1803, 1822, 1833, 1843, 1853, 1871, 1880, 1893, 1904, 1930, 1943, 1956, 1966, 1986, 1996], deadline = 6)
        configuration.add_task(name="Task1", identifier=1, period=9.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=7.283779, acet=7.283779, et_stddev=2.427926333333333, deadline= 17)
        configuration.add_task(name="Task6", identifier=6, period=39.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=5, acet=4.019774, et_stddev=1.3399246666666667 , list_activation_dates=[48, 96, 152, 203, 265, 356, 397, 464, 513, 595, 701, 755, 850, 953, 1010, 1051, 1098, 1152, 1221, 1272, 1363, 1422, 1553, 1606, 1667, 1827, 1875], deadline = 45)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "47")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "47")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "47")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "47")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task3", identifier=3, period=7.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=4.579873, acet=4.579873, et_stddev=1.5266243333333334, deadline= 9)
        configuration.add_task(name="Task4", identifier=4, period=3.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.237898, et_stddev=0.07929933333333333 , list_activation_dates=[4, 16, 26, 31, 35, 39, 47, 51, 56, 61, 65, 73, 77, 82, 87, 93, 103, 106, 114, 122, 127, 137, 141, 147, 151, 155, 158, 164, 169, 176, 180, 186, 190, 194, 205, 213, 216, 221, 225, 228, 232, 237, 243, 247, 251, 257, 266, 269, 273, 282, 292, 300, 305, 308, 311, 315, 318, 322, 325, 332, 336, 346, 350, 355, 360, 364, 369, 377, 380, 384, 387, 390, 395, 399, 405, 410, 415, 419, 424, 427, 433, 437, 447, 455, 464, 474, 481, 487, 490, 497, 505, 508, 515, 518, 526, 530, 535, 543, 547, 552, 556, 561, 565, 571, 576, 594, 597, 603, 606, 611, 617, 620, 624, 627, 640, 644, 652, 655, 659, 664, 669, 672, 683, 689, 695, 699, 702, 714, 720, 726, 738, 744, 748, 754, 761, 767, 770, 782, 790, 794, 799, 810, 814, 819, 823, 828, 835, 844, 849, 853, 856, 862, 872, 877, 881, 884, 891, 894, 898, 902, 912, 916, 920, 929, 936, 944, 949, 953, 960, 965, 973, 977, 983, 986, 990, 995, 1003, 1006, 1011, 1016, 1019, 1022, 1028, 1031, 1035, 1039, 1048, 1058, 1066, 1074, 1084, 1087, 1092, 1095, 1101, 1104, 1108, 1116, 1129, 1134, 1141, 1146, 1159, 1165, 1169, 1178, 1182, 1185, 1191, 1200, 1204, 1210, 1216, 1219, 1225, 1232, 1239, 1244, 1247, 1251, 1254, 1260, 1266, 1270, 1279, 1282, 1285, 1292, 1295, 1298, 1303, 1308, 1316, 1324, 1333, 1356, 1360, 1367, 1372, 1377, 1381, 1391, 1394, 1397, 1401, 1406, 1422, 1425, 1432, 1436, 1440, 1445, 1453, 1458, 1463, 1468, 1471, 1477, 1482, 1486, 1491, 1494, 1498, 1506, 1512, 1519, 1523, 1529, 1535, 1540, 1546, 1550, 1553, 1563, 1570, 1579, 1584, 1588, 1592, 1604, 1612, 1617, 1620, 1626, 1635, 1640, 1645, 1648, 1655, 1662, 1666, 1670, 1692, 1697, 1702, 1706, 1712, 1717, 1723, 1727, 1730, 1733, 1737, 1742, 1749, 1757, 1760, 1763, 1768, 1774, 1781, 1787, 1795, 1803, 1809, 1813, 1819, 1824, 1830, 1838, 1844, 1855, 1861, 1867, 1872, 1877, 1885, 1893, 1897, 1904, 1908, 1918, 1928, 1933, 1941, 1945, 1951, 1954, 1960, 1964, 1968, 1973, 1977, 1980, 1984, 1993, 1997], deadline = 6)
        configuration.add_task(name="Task5", identifier=5, period=28.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=4, acet=3.587463, et_stddev=1.195821 , list_activation_dates=[112, 179, 305, 367, 443, 479, 514, 579, 616, 656, 722, 758, 795, 841, 942, 982, 1031, 1059, 1102, 1139, 1202, 1253, 1285, 1391, 1427, 1475, 1569, 1603, 1684, 1718, 1773, 1825, 1861, 1898, 1932, 1969], deadline = 26)
        configuration.add_task(name="Task6", identifier=6, period=11.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=2, acet=1.018343, et_stddev=0.33944766666666665 , list_activation_dates=[1, 27, 41, 59, 87, 107, 134, 164, 178, 203, 214, 228, 247, 271, 288, 305, 321, 374, 386, 398, 439, 463, 483, 494, 526, 543, 564, 576, 588, 600, 624, 640, 658, 672, 694, 714, 726, 742, 761, 772, 791, 806, 824, 845, 872, 885, 898, 947, 964, 976, 992, 1011, 1026, 1050, 1083, 1128, 1142, 1161, 1178, 1195, 1247, 1265, 1288, 1299, 1315, 1333, 1359, 1387, 1407, 1424, 1448, 1463, 1487, 1499, 1522, 1539, 1560, 1579, 1602, 1621, 1656, 1681, 1716, 1730, 1753, 1786, 1809, 1821, 1843, 1858, 1895, 1911, 1925, 1945, 1958, 1969, 1998], deadline = 4)
        configuration.add_task(name="Task2", identifier=2, period=28.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=22.408213, acet=22.408213, et_stddev=7.469404333333333, deadline= 42)
        configuration.add_task(name="Task1", identifier=1, period=18.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=2.617901, acet=2.617901, et_stddev=0.8726336666666666, deadline= 29)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "48")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "48")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "48")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "48")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task3", identifier=3, period=4.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=1.568941, acet=1.568941, et_stddev=0.5229803333333333, deadline= 4)
        configuration.add_task(name="Task6", identifier=6, period=5.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.397763, et_stddev=0.13258766666666666 , list_activation_dates=[3, 19, 32, 49, 65, 72, 79, 85, 101, 107, 114, 130, 140, 160, 170, 182, 190, 197, 205, 213, 227, 237, 249, 258, 270, 276, 284, 291, 301, 313, 320, 327, 344, 351, 360, 367, 380, 388, 394, 400, 408, 418, 423, 430, 442, 452, 470, 477, 483, 507, 518, 524, 541, 548, 557, 565, 574, 595, 605, 617, 636, 648, 656, 665, 679, 685, 692, 704, 724, 735, 741, 747, 762, 769, 776, 781, 789, 796, 802, 809, 826, 843, 851, 878, 890, 896, 902, 907, 914, 920, 926, 932, 939, 951, 956, 975, 983, 995, 1003, 1010, 1015, 1021, 1028, 1051, 1057, 1064, 1070, 1084, 1095, 1104, 1129, 1135, 1147, 1157, 1164, 1176, 1187, 1192, 1199, 1208, 1213, 1219, 1229, 1243, 1248, 1258, 1270, 1276, 1287, 1296, 1307, 1315, 1340, 1347, 1355, 1367, 1373, 1379, 1385, 1392, 1404, 1416, 1423, 1431, 1436, 1441, 1449, 1457, 1465, 1472, 1479, 1485, 1495, 1502, 1512, 1520, 1530, 1547, 1555, 1565, 1573, 1579, 1606, 1615, 1623, 1633, 1638, 1652, 1658, 1667, 1677, 1686, 1699, 1707, 1716, 1723, 1749, 1771, 1784, 1796, 1803, 1810, 1815, 1824, 1831, 1839, 1848, 1853, 1865, 1871, 1881, 1895, 1904, 1910, 1921, 1931, 1948, 1971, 1985, 1995], deadline = 1)
        configuration.add_task(name="Task2", identifier=2, period=11.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=4.932458, acet=4.932458, et_stddev=1.6441526666666666, deadline= 6)
        configuration.add_task(name="Task5", identifier=5, period=6.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.117136, et_stddev=0.039045333333333335 , list_activation_dates=[5, 15, 27, 41, 49, 66, 90, 97, 113, 120, 142, 155, 163, 182, 192, 205, 237, 245, 253, 269, 277, 287, 293, 300, 310, 320, 343, 363, 371, 378, 388, 396, 409, 418, 427, 447, 455, 462, 473, 483, 494, 500, 506, 514, 523, 533, 546, 554, 563, 575, 589, 595, 604, 611, 619, 627, 659, 671, 678, 685, 693, 699, 742, 749, 768, 786, 796, 807, 813, 820, 835, 848, 861, 868, 876, 888, 900, 906, 916, 924, 947, 957, 974, 983, 993, 1014, 1031, 1041, 1054, 1070, 1077, 1088, 1101, 1114, 1122, 1141, 1152, 1161, 1168, 1190, 1201, 1215, 1234, 1247, 1255, 1266, 1276, 1294, 1307, 1321, 1333, 1339, 1353, 1359, 1413, 1425, 1434, 1448, 1459, 1466, 1477, 1487, 1507, 1530, 1540, 1547, 1554, 1563, 1570, 1580, 1610, 1617, 1630, 1639, 1648, 1676, 1683, 1690, 1698, 1708, 1715, 1739, 1751, 1758, 1766, 1777, 1787, 1796, 1813, 1821, 1830, 1837, 1845, 1862, 1870, 1877, 1886, 1898, 1905, 1912, 1918, 1928, 1944, 1952, 1962, 1972, 1980, 1986, 1994], deadline = 12)
        configuration.add_task(name="Task4", identifier=4, period=9.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=2, acet=1.808321, et_stddev=0.6027736666666667 , list_activation_dates=[13, 31, 49, 72, 92, 115, 138, 150, 163, 175, 191, 204, 215, 229, 238, 252, 274, 292, 302, 316, 331, 378, 390, 406, 430, 441, 463, 478, 490, 511, 534, 544, 553, 575, 584, 593, 609, 629, 654, 667, 683, 696, 711, 746, 767, 777, 793, 827, 851, 861, 878, 901, 911, 935, 993, 1037, 1057, 1066, 1095, 1110, 1125, 1153, 1174, 1185, 1208, 1219, 1232, 1241, 1262, 1272, 1286, 1307, 1320, 1333, 1342, 1362, 1379, 1399, 1414, 1425, 1435, 1447, 1456, 1466, 1477, 1498, 1511, 1521, 1535, 1554, 1564, 1573, 1583, 1593, 1604, 1624, 1637, 1666, 1693, 1702, 1716, 1735, 1744, 1761, 1786, 1798, 1817, 1829, 1843, 1857, 1875, 1893, 1903, 1914, 1925, 1949, 1977, 1996], deadline = 9)
        configuration.add_task(name="Task1", identifier=1, period=3.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=2.278078, acet=2.278078, et_stddev=0.7593593333333333, deadline= 6)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "51")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "51")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "51")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "51")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task6", identifier=6, period=40.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=5, acet=4.103451, et_stddev=1.3678169999999998 , list_activation_dates=[52, 146, 232, 392, 435, 494, 616, 731, 841, 886, 934, 976, 1026, 1075, 1204, 1286, 1360, 1409, 1485, 1527, 1577, 1657, 1783, 1925], deadline = 14)
        configuration.add_task(name="Task3", identifier=3, period=3.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=0.533214, acet=0.533214, et_stddev=0.17773799999999998, deadline= 6)
        configuration.add_task(name="Task5", identifier=5, period=8.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.173058, et_stddev=0.057685999999999994 , list_activation_dates=[8, 18, 30, 40, 75, 85, 110, 124, 134, 153, 162, 177, 185, 196, 211, 228, 256, 271, 279, 292, 309, 328, 344, 357, 370, 386, 399, 411, 422, 441, 453, 482, 492, 502, 519, 539, 548, 559, 577, 587, 599, 615, 623, 655, 691, 701, 724, 733, 745, 758, 767, 776, 802, 812, 829, 837, 882, 903, 911, 922, 951, 962, 974, 985, 994, 1028, 1038, 1051, 1096, 1120, 1143, 1186, 1215, 1230, 1248, 1261, 1280, 1292, 1307, 1335, 1353, 1376, 1389, 1399, 1407, 1416, 1438, 1452, 1476, 1497, 1508, 1524, 1533, 1542, 1551, 1565, 1586, 1600, 1625, 1637, 1650, 1689, 1703, 1716, 1742, 1754, 1763, 1784, 1794, 1804, 1814, 1825, 1838, 1871, 1887, 1919, 1943, 1952, 1961, 1971], deadline = 8)
        configuration.add_task(name="Task2", identifier=2, period=8.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=3.553268, acet=3.553268, et_stddev=1.1844226666666666, deadline= 12)
        configuration.add_task(name="Task4", identifier=4, period=3.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.527344, et_stddev=0.17578133333333334 , list_activation_dates=[2, 5, 12, 24, 29, 32, 44, 48, 59, 71, 74, 85, 93, 101, 104, 109, 112, 115, 121, 128, 136, 143, 147, 155, 165, 170, 174, 177, 181, 187, 197, 204, 208, 219, 224, 233, 240, 246, 250, 258, 267, 273, 278, 281, 290, 299, 304, 312, 317, 321, 327, 332, 336, 343, 346, 351, 354, 359, 364, 368, 372, 377, 382, 386, 390, 393, 403, 407, 412, 416, 430, 434, 437, 443, 451, 459, 465, 472, 479, 482, 488, 492, 497, 501, 507, 512, 518, 521, 526, 533, 537, 543, 550, 554, 557, 560, 563, 566, 571, 576, 582, 587, 590, 595, 600, 609, 617, 621, 625, 630, 635, 640, 646, 650, 654, 657, 662, 668, 675, 680, 685, 690, 694, 698, 703, 717, 724, 730, 734, 737, 744, 749, 754, 761, 766, 769, 777, 781, 793, 798, 805, 811, 817, 824, 828, 833, 838, 842, 846, 852, 857, 863, 866, 871, 878, 884, 888, 896, 900, 908, 911, 922, 926, 931, 940, 943, 948, 954, 959, 968, 971, 975, 982, 987, 995, 1000, 1005, 1009, 1017, 1020, 1024, 1030, 1036, 1040, 1050, 1067, 1075, 1081, 1090, 1094, 1101, 1108, 1112, 1120, 1128, 1135, 1145, 1148, 1158, 1162, 1167, 1170, 1174, 1177, 1182, 1197, 1204, 1211, 1215, 1222, 1231, 1238, 1244, 1250, 1256, 1261, 1275, 1287, 1290, 1299, 1302, 1309, 1318, 1321, 1327, 1331, 1334, 1347, 1351, 1354, 1357, 1379, 1386, 1389, 1392, 1397, 1403, 1411, 1414, 1420, 1425, 1431, 1434, 1451, 1460, 1464, 1468, 1477, 1483, 1490, 1495, 1499, 1502, 1507, 1510, 1518, 1523, 1527, 1537, 1544, 1548, 1553, 1563, 1572, 1576, 1584, 1589, 1593, 1597, 1605, 1609, 1614, 1620, 1623, 1630, 1634, 1641, 1646, 1650, 1656, 1659, 1664, 1676, 1681, 1685, 1699, 1702, 1705, 1709, 1714, 1719, 1725, 1729, 1736, 1743, 1756, 1760, 1767, 1774, 1778, 1782, 1790, 1794, 1798, 1803, 1811, 1817, 1822, 1830, 1833, 1837, 1845, 1851, 1856, 1860, 1863, 1869, 1874, 1877, 1881, 1892, 1898, 1904, 1908, 1911, 1914, 1919, 1930, 1933, 1944, 1949, 1958, 1966, 1973, 1976, 1993, 1999], deadline = 5)
        configuration.add_task(name="Task1", identifier=1, period=30.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=29.343099, acet=29.343099, et_stddev=9.781032999999999, deadline= 53)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "52")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "52")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "52")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "52")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task2", identifier=2, period=39.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=27.254451, acet=27.254451, et_stddev=9.084817, deadline= 71)
        configuration.add_task(name="Task5", identifier=5, period=3.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.408751, et_stddev=0.13625033333333333 , list_activation_dates=[7, 13, 18, 24, 27, 39, 45, 49, 54, 70, 79, 82, 92, 99, 104, 109, 112, 123, 128, 137, 141, 147, 151, 158, 163, 171, 175, 178, 182, 188, 193, 202, 211, 217, 223, 230, 235, 240, 244, 249, 256, 262, 275, 280, 285, 288, 292, 297, 300, 303, 307, 314, 320, 329, 332, 337, 342, 348, 355, 358, 362, 368, 371, 379, 387, 393, 397, 400, 405, 410, 421, 427, 432, 440, 443, 446, 454, 458, 467, 471, 475, 479, 484, 489, 498, 503, 507, 512, 516, 520, 535, 540, 544, 551, 554, 559, 573, 582, 586, 592, 598, 606, 614, 623, 630, 637, 643, 657, 661, 669, 673, 678, 682, 686, 690, 697, 709, 716, 725, 729, 738, 744, 749, 753, 757, 764, 772, 776, 779, 784, 792, 795, 798, 802, 807, 811, 815, 821, 830, 835, 838, 844, 852, 858, 868, 872, 885, 890, 895, 902, 905, 908, 922, 931, 936, 940, 955, 962, 965, 969, 974, 977, 983, 987, 991, 996, 1000, 1005, 1009, 1014, 1019, 1024, 1032, 1035, 1043, 1049, 1052, 1062, 1067, 1077, 1082, 1090, 1101, 1105, 1110, 1120, 1129, 1133, 1142, 1148, 1153, 1162, 1168, 1182, 1188, 1192, 1196, 1209, 1212, 1215, 1218, 1222, 1232, 1235, 1241, 1244, 1249, 1252, 1258, 1269, 1276, 1281, 1284, 1291, 1296, 1299, 1303, 1309, 1316, 1323, 1327, 1337, 1345, 1355, 1361, 1365, 1370, 1378, 1382, 1389, 1394, 1399, 1405, 1409, 1422, 1431, 1437, 1450, 1453, 1464, 1472, 1480, 1484, 1487, 1490, 1495, 1501, 1505, 1508, 1515, 1520, 1523, 1528, 1534, 1538, 1541, 1546, 1551, 1554, 1561, 1565, 1569, 1581, 1587, 1592, 1595, 1602, 1607, 1613, 1616, 1620, 1624, 1631, 1635, 1639, 1643, 1656, 1666, 1672, 1676, 1680, 1684, 1690, 1694, 1703, 1707, 1714, 1721, 1726, 1729, 1748, 1755, 1758, 1764, 1770, 1774, 1779, 1782, 1791, 1796, 1800, 1806, 1812, 1818, 1823, 1826, 1831, 1834, 1839, 1842, 1847, 1851, 1860, 1866, 1869, 1873, 1876, 1881, 1886, 1889, 1900, 1907, 1923, 1928, 1933, 1936, 1942, 1950, 1954, 1957, 1962, 1976, 1980, 1985, 1992, 1996], deadline = 3)
        configuration.add_task(name="Task4", identifier=4, period=19.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=2, acet=1.950509, et_stddev=0.6501696666666666 , list_activation_dates=[15, 63, 95, 120, 162, 190, 226, 268, 399, 458, 516, 538, 566, 602, 650, 690, 718, 740, 761, 794, 939, 969, 990, 1029, 1049, 1079, 1118, 1152, 1185, 1212, 1238, 1261, 1293, 1316, 1348, 1373, 1408, 1430, 1461, 1548, 1575, 1626, 1649, 1683, 1713, 1752, 1824, 1885, 1910, 1967, 1999], deadline = 11)
        configuration.add_task(name="Task1", identifier=1, period=9.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=4.153865, acet=4.153865, et_stddev=1.3846216666666666, deadline= 11)
        configuration.add_task(name="Task6", identifier=6, period=1.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.061091, et_stddev=0.020363666666666665 , list_activation_dates=[1, 3, 5, 7, 9, 11, 13, 14, 16, 17, 20, 22, 23, 25, 26, 27, 28, 30, 32, 34, 36, 37, 39, 41, 43, 46, 47, 50, 53, 55, 57, 60, 61, 63, 65, 67, 68, 70, 72, 74, 75, 77, 81, 82, 83, 84, 86, 89, 90, 96, 98, 99, 101, 103, 105, 107, 109, 110, 113, 115, 116, 118, 119, 121, 122, 124, 126, 127, 128, 129, 132, 136, 138, 139, 140, 142, 143, 144, 145, 147, 148, 153, 154, 156, 158, 160, 161, 165, 168, 169, 172, 175, 176, 178, 180, 181, 183, 186, 188, 192, 193, 194, 195, 197, 199, 202, 203, 204, 205, 208, 212, 213, 214, 217, 218, 219, 221, 222, 223, 227, 228, 229, 230, 232, 234, 235, 239, 242, 243, 245, 246, 247, 249, 250, 252, 254, 256, 259, 262, 263, 265, 266, 267, 268, 270, 272, 273, 276, 278, 281, 282, 283, 287, 289, 291, 292, 293, 294, 298, 300, 301, 302, 303, 306, 309, 311, 313, 314, 316, 318, 321, 322, 324, 325, 326, 328, 331, 332, 334, 335, 336, 337, 339, 340, 341, 342, 343, 344, 348, 349, 351, 353, 355, 356, 360, 361, 363, 364, 366, 368, 370, 371, 373, 375, 377, 381, 383, 385, 387, 390, 391, 392, 393, 395, 396, 397, 400, 402, 403, 404, 408, 409, 410, 412, 413, 414, 415, 417, 419, 421, 424, 429, 436, 439, 440, 446, 448, 453, 456, 457, 458, 460, 462, 463, 466, 468, 471, 472, 473, 474, 475, 476, 478, 479, 483, 485, 487, 488, 489, 490, 492, 501, 502, 503, 504, 507, 509, 510, 513, 515, 516, 517, 519, 521, 522, 524, 525, 527, 528, 529, 532, 539, 542, 544, 545, 546, 547, 549, 553, 554, 556, 559, 561, 563, 564, 566, 569, 574, 577, 579, 581, 582, 583, 586, 588, 589, 593, 594, 597, 599, 600, 601, 602, 603, 606, 608, 609, 610, 611, 612, 614, 616, 618, 620, 621, 624, 626, 627, 630, 633, 637, 638, 639, 641, 645, 647, 648, 653, 656, 660, 663, 666, 667, 671, 676, 679, 680, 682, 684, 686, 687, 689, 691, 695, 697, 703, 705, 707, 709, 712, 714, 716, 717, 719, 725, 726, 727, 729, 731, 732, 737, 738, 740, 745, 746, 750, 752, 754, 755, 756, 757, 758, 761, 764, 767, 768, 769, 770, 771, 775, 777, 778, 779, 780, 781, 784, 786, 787, 788, 791, 794, 795, 797, 799, 801, 802, 803, 805, 809, 810, 811, 812, 813, 814, 816, 817, 819, 820, 821, 822, 824, 827, 834, 836, 838, 840, 841, 842, 843, 844, 845, 848, 850, 852, 853, 855, 858, 859, 861, 862, 865, 866, 869, 870, 872, 874, 875, 877, 878, 879, 881, 883, 885, 887, 888, 890, 892, 893, 894, 896, 897, 899, 903, 904, 907, 909, 910, 911, 915, 920, 921, 922, 923, 926, 927, 929, 932, 937, 940, 942, 943, 946, 948, 949, 953, 956, 957, 958, 960, 962, 967, 969, 971, 972, 973, 976, 977, 983, 984, 985, 988, 990, 993, 997, 998, 1001, 1002, 1004, 1005, 1007, 1009, 1012, 1013, 1014, 1016, 1018, 1019, 1021, 1024, 1025, 1026, 1027, 1030, 1031, 1032, 1033, 1036, 1038, 1039, 1040, 1041, 1043, 1045, 1046, 1047, 1049, 1054, 1057, 1058, 1062, 1063, 1064, 1065, 1067, 1070, 1073, 1075, 1078, 1080, 1081, 1082, 1084, 1085, 1087, 1091, 1093, 1094, 1096, 1098, 1101, 1103, 1107, 1110, 1112, 1113, 1116, 1117, 1119, 1121, 1122, 1124, 1127, 1128, 1130, 1131, 1135, 1137, 1138, 1139, 1143, 1145, 1149, 1150, 1152, 1155, 1156, 1159, 1160, 1162, 1165, 1170, 1172, 1173, 1179, 1180, 1181, 1182, 1184, 1190, 1192, 1194, 1195, 1199, 1200, 1202, 1204, 1208, 1213, 1215, 1216, 1218, 1220, 1221, 1223, 1224, 1225, 1227, 1229, 1232, 1234, 1235, 1238, 1239, 1241, 1244, 1246, 1247, 1252, 1255, 1257, 1258, 1259, 1261, 1262, 1263, 1264, 1266, 1268, 1269, 1270, 1271, 1272, 1277, 1278, 1280, 1281, 1282, 1283, 1284, 1285, 1287, 1289, 1291, 1292, 1295, 1298, 1299, 1300, 1303, 1304, 1305, 1307, 1311, 1313, 1315, 1317, 1318, 1319, 1323, 1324, 1325, 1326, 1329, 1331, 1332, 1334, 1335, 1336, 1337, 1338, 1341, 1344, 1348, 1350, 1351, 1352, 1353, 1355, 1358, 1360, 1362, 1363, 1364, 1367, 1370, 1373, 1374, 1375, 1376, 1377, 1379, 1382, 1384, 1388, 1389, 1391, 1394, 1400, 1402, 1404, 1407, 1409, 1410, 1413, 1417, 1418, 1421, 1423, 1424, 1425, 1426, 1431, 1433, 1435, 1436, 1437, 1438, 1439, 1440, 1443, 1445, 1446, 1448, 1450, 1452, 1453, 1454, 1456, 1457, 1459, 1462, 1465, 1467, 1470, 1471, 1473, 1474, 1476, 1478, 1479, 1481, 1483, 1486, 1488, 1490, 1491, 1493, 1495, 1496, 1498, 1500, 1502, 1505, 1508, 1510, 1511, 1513, 1515, 1516, 1520, 1523, 1525, 1529, 1531, 1533, 1535, 1538, 1540, 1542, 1544, 1546, 1547, 1548, 1550, 1553, 1556, 1557, 1559, 1561, 1562, 1563, 1567, 1569, 1570, 1571, 1573, 1575, 1578, 1580, 1581, 1582, 1584, 1585, 1587, 1589, 1590, 1591, 1593, 1595, 1597, 1598, 1599, 1602, 1605, 1606, 1610, 1611, 1613, 1618, 1620, 1622, 1624, 1626, 1628, 1632, 1635, 1636, 1638, 1640, 1644, 1646, 1649, 1650, 1651, 1652, 1655, 1657, 1658, 1659, 1660, 1661, 1663, 1665, 1666, 1667, 1669, 1670, 1673, 1675, 1676, 1679, 1681, 1683, 1684, 1685, 1687, 1689, 1691, 1692, 1693, 1695, 1699, 1703, 1704, 1705, 1706, 1709, 1711, 1712, 1715, 1717, 1720, 1722, 1723, 1726, 1728, 1729, 1734, 1736, 1737, 1740, 1741, 1743, 1747, 1748, 1751, 1752, 1754, 1755, 1757, 1760, 1762, 1765, 1768, 1771, 1772, 1777, 1778, 1781, 1782, 1783, 1784, 1786, 1787, 1788, 1789, 1791, 1793, 1796, 1798, 1801, 1803, 1805, 1808, 1809, 1811, 1813, 1817, 1819, 1822, 1824, 1826, 1828, 1830, 1834, 1835, 1837, 1838, 1840, 1845, 1846, 1849, 1850, 1852, 1854, 1855, 1856, 1857, 1858, 1860, 1862, 1863, 1865, 1866, 1867, 1869, 1871, 1873, 1875, 1877, 1878, 1879, 1881, 1883, 1888, 1890, 1892, 1895, 1898, 1899, 1902, 1903, 1904, 1905, 1906, 1908, 1911, 1914, 1916, 1918, 1919, 1921, 1924, 1926, 1930, 1932, 1934, 1938, 1940, 1942, 1944, 1945, 1947, 1949, 1950, 1952, 1953, 1954, 1956, 1960, 1962, 1965, 1966, 1967, 1969, 1970, 1971, 1972, 1973, 1974, 1977, 1978, 1980, 1981, 1983, 1984, 1988, 1990, 1991, 1993, 1995, 1996, 1997, 1998, 1999], deadline = 2)
        configuration.add_task(name="Task3", identifier=3, period=7.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=3.07739, acet=3.07739, et_stddev=1.0257966666666667, deadline= 11)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "53")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "53")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "53")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "53")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task5", identifier=5, period=16.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.943353, et_stddev=0.314451 , list_activation_dates=[5, 23, 45, 91, 130, 165, 185, 209, 236, 291, 309, 346, 387, 407, 435, 491, 519, 537, 558, 611, 644, 686, 705, 733, 756, 775, 836, 856, 876, 916, 944, 978, 1005, 1055, 1091, 1108, 1146, 1163, 1192, 1236, 1255, 1274, 1307, 1331, 1349, 1401, 1478, 1529, 1552, 1582, 1609, 1634, 1672, 1698, 1779, 1815, 1851, 1883, 1908, 1929, 1947, 1964], deadline = 10)
        configuration.add_task(name="Task1", identifier=1, period=17.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=14.344011, acet=14.344011, et_stddev=4.781337, deadline= 16)
        configuration.add_task(name="Task6", identifier=6, period=30.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=6, acet=5.525419, et_stddev=1.8418063333333334 , list_activation_dates=[64, 110, 142, 172, 203, 252, 292, 372, 418, 460, 553, 739, 841, 896, 931, 961, 1028, 1140, 1188, 1238, 1270, 1323, 1356, 1431, 1479, 1549, 1658, 1774, 1839, 1887, 1928, 1963], deadline = 42)
        configuration.add_task(name="Task4", identifier=4, period=1.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.056859, et_stddev=0.018953 , list_activation_dates=[1, 3, 5, 6, 8, 9, 10, 12, 13, 14, 22, 24, 25, 28, 30, 33, 34, 35, 39, 41, 43, 44, 46, 48, 50, 51, 53, 55, 58, 62, 63, 65, 67, 69, 71, 74, 76, 77, 79, 81, 84, 85, 87, 88, 90, 91, 92, 94, 95, 97, 98, 100, 102, 104, 106, 107, 108, 110, 111, 115, 116, 117, 119, 121, 123, 124, 125, 127, 128, 130, 131, 132, 135, 137, 138, 140, 141, 142, 144, 147, 149, 150, 151, 155, 156, 158, 161, 162, 164, 165, 167, 169, 171, 174, 175, 177, 179, 181, 184, 187, 188, 190, 191, 194, 196, 199, 201, 204, 206, 208, 209, 211, 212, 213, 214, 215, 217, 219, 220, 221, 224, 227, 228, 230, 231, 232, 235, 237, 238, 240, 242, 243, 247, 249, 250, 252, 253, 254, 256, 257, 258, 260, 264, 266, 267, 268, 269, 271, 272, 273, 276, 278, 280, 281, 283, 286, 289, 292, 294, 296, 299, 300, 301, 303, 304, 305, 306, 307, 311, 312, 313, 314, 316, 317, 319, 320, 324, 326, 328, 332, 333, 335, 336, 339, 340, 342, 344, 345, 348, 353, 354, 356, 358, 360, 361, 362, 366, 369, 372, 379, 381, 382, 385, 387, 388, 390, 393, 394, 396, 399, 401, 405, 406, 411, 412, 413, 415, 416, 417, 418, 419, 421, 422, 424, 426, 427, 431, 433, 436, 438, 440, 441, 443, 445, 446, 448, 449, 452, 453, 455, 456, 458, 461, 462, 464, 465, 468, 469, 470, 474, 477, 478, 481, 483, 485, 490, 492, 493, 495, 498, 501, 502, 504, 505, 506, 507, 510, 511, 512, 514, 515, 516, 518, 521, 522, 524, 529, 532, 537, 539, 540, 541, 542, 543, 545, 547, 548, 550, 551, 555, 556, 560, 561, 562, 564, 568, 570, 571, 573, 574, 578, 580, 582, 584, 587, 590, 593, 594, 597, 600, 602, 605, 607, 609, 610, 613, 616, 618, 619, 620, 622, 623, 626, 633, 636, 638, 640, 642, 643, 644, 648, 650, 652, 653, 655, 656, 659, 662, 664, 667, 669, 671, 673, 676, 677, 678, 679, 680, 684, 686, 687, 690, 692, 693, 696, 699, 701, 703, 705, 707, 708, 711, 714, 716, 722, 723, 725, 726, 727, 729, 731, 733, 734, 736, 737, 739, 742, 743, 744, 746, 747, 748, 752, 753, 755, 756, 758, 759, 760, 761, 762, 765, 767, 768, 770, 773, 774, 776, 778, 780, 782, 784, 785, 790, 793, 795, 799, 800, 802, 803, 805, 808, 810, 811, 812, 813, 814, 817, 819, 822, 824, 825, 826, 827, 828, 830, 831, 833, 835, 837, 838, 840, 841, 842, 844, 847, 848, 852, 853, 855, 857, 858, 860, 862, 864, 865, 866, 868, 872, 874, 875, 879, 882, 884, 885, 887, 889, 890, 891, 894, 895, 896, 897, 898, 901, 903, 906, 908, 909, 914, 916, 917, 919, 925, 928, 930, 934, 935, 936, 938, 940, 942, 945, 947, 949, 950, 952, 954, 955, 957, 959, 961, 964, 966, 968, 970, 972, 974, 975, 976, 977, 978, 979, 982, 986, 993, 995, 998, 1000, 1001, 1003, 1005, 1006, 1007, 1009, 1010, 1013, 1015, 1019, 1021, 1023, 1024, 1026, 1028, 1029, 1030, 1031, 1035, 1036, 1038, 1039, 1041, 1043, 1044, 1045, 1049, 1051, 1053, 1056, 1057, 1058, 1059, 1062, 1063, 1066, 1067, 1069, 1070, 1073, 1074, 1076, 1079, 1081, 1082, 1084, 1085, 1086, 1088, 1089, 1090, 1092, 1093, 1096, 1097, 1098, 1099, 1100, 1103, 1104, 1105, 1106, 1107, 1109, 1112, 1113, 1117, 1119, 1121, 1123, 1125, 1127, 1128, 1130, 1131, 1132, 1133, 1134, 1135, 1138, 1139, 1140, 1141, 1143, 1146, 1150, 1153, 1154, 1155, 1159, 1161, 1164, 1165, 1169, 1170, 1172, 1173, 1176, 1178, 1182, 1183, 1185, 1188, 1190, 1192, 1196, 1198, 1199, 1203, 1204, 1205, 1207, 1209, 1210, 1211, 1212, 1214, 1216, 1218, 1219, 1221, 1223, 1225, 1228, 1230, 1231, 1234, 1235, 1237, 1238, 1241, 1243, 1244, 1245, 1247, 1249, 1252, 1253, 1254, 1256, 1260, 1261, 1263, 1265, 1268, 1270, 1272, 1273, 1275, 1276, 1277, 1279, 1281, 1283, 1284, 1287, 1289, 1290, 1291, 1293, 1295, 1296, 1298, 1299, 1301, 1305, 1306, 1309, 1312, 1313, 1314, 1317, 1318, 1321, 1323, 1325, 1327, 1328, 1330, 1332, 1334, 1336, 1339, 1341, 1343, 1346, 1349, 1352, 1353, 1355, 1357, 1361, 1362, 1364, 1369, 1371, 1372, 1378, 1379, 1381, 1382, 1384, 1385, 1387, 1393, 1396, 1398, 1400, 1402, 1403, 1405, 1409, 1411, 1412, 1414, 1416, 1418, 1419, 1420, 1421, 1425, 1427, 1429, 1431, 1432, 1436, 1437, 1439, 1441, 1444, 1449, 1450, 1452, 1454, 1455, 1458, 1459, 1461, 1463, 1465, 1466, 1468, 1469, 1470, 1472, 1473, 1474, 1477, 1478, 1480, 1482, 1484, 1485, 1486, 1487, 1489, 1491, 1493, 1495, 1497, 1498, 1499, 1501, 1503, 1505, 1507, 1509, 1510, 1513, 1515, 1517, 1519, 1522, 1523, 1525, 1526, 1531, 1534, 1535, 1538, 1540, 1546, 1547, 1549, 1550, 1553, 1555, 1557, 1559, 1560, 1563, 1566, 1568, 1570, 1575, 1577, 1578, 1580, 1584, 1585, 1587, 1590, 1592, 1595, 1596, 1598, 1599, 1601, 1602, 1604, 1606, 1607, 1610, 1612, 1613, 1615, 1616, 1617, 1618, 1619, 1621, 1624, 1625, 1626, 1629, 1630, 1633, 1634, 1636, 1638, 1642, 1645, 1646, 1648, 1649, 1650, 1652, 1655, 1657, 1659, 1660, 1661, 1662, 1663, 1665, 1667, 1672, 1675, 1677, 1679, 1680, 1681, 1683, 1684, 1685, 1686, 1689, 1690, 1692, 1695, 1697, 1698, 1700, 1701, 1707, 1709, 1712, 1713, 1715, 1717, 1720, 1724, 1725, 1727, 1728, 1734, 1738, 1740, 1741, 1742, 1745, 1746, 1749, 1751, 1753, 1755, 1757, 1758, 1761, 1762, 1763, 1764, 1765, 1766, 1767, 1769, 1772, 1773, 1774, 1776, 1777, 1782, 1783, 1785, 1786, 1788, 1789, 1791, 1793, 1796, 1797, 1799, 1800, 1802, 1804, 1805, 1806, 1808, 1810, 1812, 1814, 1815, 1819, 1820, 1822, 1824, 1825, 1826, 1827, 1829, 1833, 1834, 1836, 1837, 1838, 1839, 1841, 1842, 1844, 1847, 1848, 1850, 1851, 1853, 1854, 1855, 1857, 1861, 1862, 1865, 1866, 1868, 1870, 1872, 1873, 1874, 1877, 1878, 1879, 1880, 1881, 1882, 1883, 1884, 1885, 1887, 1888, 1890, 1891, 1892, 1894, 1895, 1897, 1900, 1903, 1906, 1909, 1911, 1914, 1916, 1917, 1921, 1924, 1925, 1932, 1935, 1937, 1940, 1943, 1944, 1950, 1951, 1952, 1954, 1955, 1958, 1961, 1962, 1963, 1966, 1970, 1971, 1973, 1974, 1976, 1977, 1981, 1983, 1984, 1985, 1987, 1988, 1990, 1991, 1994, 1995, 1996, 1997], deadline = 1)
        configuration.add_task(name="Task3", identifier=3, period=1.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=0.167131, acet=0.167131, et_stddev=0.055710333333333334, deadline= 2)
        configuration.add_task(name="Task2", identifier=2, period=1.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=0.589102, acet=0.589102, et_stddev=0.19636733333333334, deadline= 2)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "55")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "55")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "55")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "55")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task5", identifier=5, period=1.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.237693, et_stddev=0.079231 , list_activation_dates=[3, 4, 5, 7, 11, 13, 14, 15, 17, 20, 24, 27, 30, 31, 34, 36, 38, 40, 41, 46, 49, 53, 55, 57, 58, 61, 64, 68, 70, 72, 74, 76, 77, 81, 83, 85, 87, 90, 91, 93, 95, 97, 99, 101, 102, 104, 106, 107, 108, 109, 111, 113, 114, 116, 117, 121, 122, 123, 124, 126, 128, 130, 131, 133, 134, 135, 137, 138, 140, 142, 144, 147, 149, 150, 152, 154, 156, 157, 159, 161, 163, 164, 165, 166, 168, 169, 171, 174, 176, 177, 178, 180, 181, 182, 184, 185, 187, 189, 190, 192, 193, 195, 196, 197, 200, 204, 206, 208, 211, 213, 214, 216, 221, 222, 223, 225, 226, 228, 229, 231, 232, 233, 234, 235, 236, 237, 239, 240, 243, 245, 247, 248, 249, 250, 254, 256, 257, 261, 263, 265, 266, 268, 269, 270, 271, 272, 273, 274, 276, 279, 282, 284, 286, 287, 288, 291, 294, 295, 297, 299, 300, 302, 303, 306, 310, 312, 313, 316, 318, 320, 322, 324, 327, 329, 332, 334, 335, 338, 340, 341, 342, 345, 346, 347, 348, 349, 351, 352, 354, 356, 358, 359, 360, 361, 362, 363, 368, 372, 374, 376, 377, 379, 381, 382, 383, 384, 387, 390, 392, 395, 396, 398, 400, 402, 405, 407, 409, 410, 411, 412, 413, 415, 417, 418, 420, 422, 425, 426, 428, 432, 435, 436, 439, 440, 446, 448, 450, 451, 453, 454, 456, 458, 460, 463, 464, 466, 467, 468, 469, 472, 474, 476, 477, 478, 481, 483, 485, 487, 488, 489, 490, 491, 494, 496, 497, 501, 503, 506, 507, 512, 514, 518, 520, 521, 523, 524, 525, 527, 530, 531, 533, 536, 538, 540, 542, 543, 545, 547, 549, 551, 553, 554, 555, 558, 561, 563, 565, 569, 570, 571, 574, 575, 576, 579, 581, 584, 586, 587, 592, 593, 595, 597, 598, 601, 605, 607, 609, 611, 614, 615, 616, 618, 620, 621, 622, 623, 626, 629, 632, 636, 637, 638, 639, 641, 642, 643, 646, 647, 648, 649, 650, 651, 652, 653, 656, 658, 660, 662, 663, 664, 667, 668, 669, 670, 672, 673, 674, 676, 677, 678, 680, 681, 686, 688, 690, 692, 696, 697, 698, 699, 701, 704, 707, 709, 710, 712, 713, 714, 715, 717, 720, 725, 727, 728, 730, 732, 733, 737, 739, 740, 741, 745, 746, 747, 749, 751, 753, 755, 756, 757, 759, 763, 764, 765, 766, 767, 769, 770, 771, 772, 773, 776, 778, 780, 781, 783, 785, 786, 787, 790, 792, 795, 798, 800, 802, 804, 805, 806, 808, 809, 810, 812, 814, 815, 816, 819, 821, 822, 823, 825, 828, 830, 831, 835, 836, 839, 842, 844, 845, 846, 847, 849, 851, 853, 856, 859, 860, 862, 863, 865, 866, 868, 870, 872, 873, 874, 875, 877, 879, 881, 884, 885, 888, 890, 892, 894, 898, 901, 904, 907, 909, 910, 911, 913, 915, 920, 923, 924, 925, 926, 928, 933, 935, 936, 937, 940, 942, 945, 947, 950, 951, 954, 958, 960, 961, 962, 963, 964, 965, 966, 967, 969, 970, 971, 974, 979, 980, 981, 982, 983, 984, 985, 987, 989, 992, 994, 997, 998, 1001, 1004, 1007, 1010, 1011, 1012, 1015, 1016, 1019, 1021, 1022, 1023, 1025, 1028, 1029, 1030, 1032, 1033, 1036, 1038, 1040, 1044, 1045, 1047, 1048, 1049, 1050, 1052, 1054, 1056, 1059, 1061, 1066, 1067, 1068, 1069, 1070, 1071, 1072, 1074, 1080, 1082, 1084, 1085, 1087, 1091, 1092, 1093, 1095, 1097, 1098, 1099, 1101, 1102, 1107, 1108, 1111, 1112, 1113, 1115, 1116, 1117, 1120, 1122, 1124, 1126, 1128, 1130, 1132, 1138, 1139, 1140, 1141, 1143, 1145, 1148, 1149, 1151, 1153, 1155, 1156, 1158, 1159, 1161, 1164, 1167, 1168, 1170, 1172, 1176, 1178, 1179, 1181, 1183, 1184, 1186, 1187, 1191, 1193, 1195, 1196, 1198, 1199, 1201, 1203, 1204, 1205, 1207, 1210, 1211, 1212, 1216, 1217, 1220, 1221, 1223, 1225, 1227, 1229, 1230, 1232, 1234, 1236, 1238, 1239, 1240, 1242, 1245, 1249, 1251, 1252, 1254, 1258, 1260, 1261, 1263, 1264, 1268, 1270, 1271, 1274, 1275, 1276, 1278, 1281, 1282, 1284, 1286, 1289, 1290, 1291, 1293, 1296, 1299, 1301, 1303, 1304, 1309, 1310, 1314, 1316, 1318, 1320, 1321, 1323, 1326, 1328, 1330, 1332, 1333, 1334, 1335, 1337, 1338, 1341, 1345, 1346, 1348, 1349, 1350, 1351, 1354, 1358, 1359, 1361, 1363, 1365, 1367, 1368, 1369, 1370, 1373, 1377, 1378, 1380, 1382, 1383, 1385, 1390, 1392, 1393, 1395, 1398, 1400, 1403, 1404, 1406, 1407, 1412, 1414, 1416, 1417, 1418, 1420, 1421, 1422, 1425, 1427, 1428, 1429, 1431, 1432, 1434, 1436, 1439, 1440, 1441, 1442, 1444, 1447, 1449, 1451, 1452, 1453, 1455, 1459, 1460, 1461, 1462, 1463, 1466, 1468, 1470, 1472, 1473, 1475, 1478, 1481, 1483, 1484, 1486, 1492, 1494, 1496, 1499, 1501, 1503, 1504, 1506, 1507, 1510, 1511, 1514, 1517, 1519, 1521, 1522, 1523, 1524, 1526, 1527, 1531, 1532, 1533, 1535, 1537, 1539, 1540, 1541, 1543, 1544, 1545, 1548, 1550, 1551, 1555, 1556, 1558, 1559, 1562, 1566, 1568, 1569, 1570, 1571, 1573, 1574, 1576, 1580, 1581, 1582, 1585, 1586, 1589, 1590, 1594, 1596, 1597, 1598, 1600, 1602, 1603, 1604, 1608, 1610, 1613, 1615, 1617, 1620, 1621, 1623, 1629, 1630, 1632, 1633, 1634, 1638, 1639, 1644, 1647, 1650, 1653, 1657, 1663, 1664, 1666, 1667, 1668, 1670, 1671, 1674, 1675, 1678, 1680, 1681, 1682, 1684, 1688, 1690, 1692, 1695, 1697, 1699, 1700, 1702, 1705, 1707, 1708, 1709, 1712, 1713, 1714, 1715, 1718, 1720, 1721, 1724, 1728, 1732, 1735, 1736, 1737, 1738, 1740, 1743, 1746, 1749, 1750, 1751, 1752, 1753, 1754, 1756, 1758, 1759, 1761, 1763, 1764, 1768, 1771, 1775, 1776, 1779, 1780, 1781, 1782, 1784, 1787, 1789, 1794, 1798, 1802, 1803, 1804, 1806, 1807, 1808, 1810, 1812, 1814, 1816, 1818, 1819, 1822, 1825, 1827, 1829, 1831, 1833, 1838, 1843, 1845, 1847, 1848, 1850, 1852, 1854, 1861, 1863, 1865, 1867, 1869, 1870, 1872, 1873, 1874, 1877, 1878, 1882, 1883, 1884, 1886, 1888, 1889, 1891, 1893, 1895, 1897, 1898, 1899, 1900, 1902, 1904, 1905, 1907, 1908, 1909, 1911, 1913, 1914, 1916, 1917, 1919, 1920, 1923, 1927, 1928, 1932, 1935, 1936, 1938, 1940, 1943, 1944, 1945, 1948, 1950, 1952, 1954, 1955, 1957, 1960, 1961, 1962, 1964, 1967, 1970, 1971, 1974, 1977, 1979, 1981, 1984, 1987, 1989, 1992, 1993, 1994, 1995, 1996, 1998, 1999], deadline = 2)
        configuration.add_task(name="Task6", identifier=6, period=5.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.287287, et_stddev=0.09576233333333334 , list_activation_dates=[6, 12, 22, 27, 37, 50, 58, 64, 84, 94, 102, 112, 120, 132, 139, 146, 154, 164, 173, 182, 189, 201, 212, 219, 230, 244, 255, 268, 284, 291, 302, 314, 320, 327, 335, 340, 356, 364, 374, 380, 386, 395, 413, 426, 433, 443, 454, 466, 473, 489, 498, 505, 511, 517, 523, 528, 538, 546, 560, 571, 578, 589, 600, 609, 620, 633, 640, 651, 657, 662, 679, 686, 695, 713, 719, 729, 735, 743, 755, 761, 771, 780, 795, 812, 829, 836, 845, 857, 867, 878, 911, 922, 928, 938, 948, 954, 963, 968, 982, 989, 996, 1001, 1006, 1022, 1029, 1037, 1042, 1058, 1064, 1073, 1081, 1089, 1097, 1115, 1124, 1145, 1162, 1175, 1194, 1206, 1216, 1222, 1228, 1239, 1244, 1257, 1274, 1288, 1293, 1303, 1314, 1322, 1328, 1339, 1349, 1355, 1370, 1378, 1386, 1391, 1401, 1419, 1432, 1437, 1444, 1450, 1459, 1472, 1482, 1488, 1502, 1509, 1517, 1523, 1528, 1534, 1540, 1548, 1562, 1570, 1587, 1601, 1610, 1632, 1654, 1659, 1670, 1681, 1688, 1700, 1707, 1721, 1736, 1742, 1747, 1754, 1768, 1776, 1784, 1790, 1796, 1804, 1810, 1820, 1826, 1832, 1838, 1857, 1865, 1871, 1878, 1883, 1896, 1901, 1906, 1919, 1927, 1939, 1950, 1959, 1973, 1979, 1985, 1994, 2000], deadline = 2)
        configuration.add_task(name="Task2", identifier=2, period=2.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=0.530979, acet=0.530979, et_stddev=0.17699299999999998, deadline= 3)
        configuration.add_task(name="Task4", identifier=4, period=2.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.009698, et_stddev=0.0032326666666666667 , list_activation_dates=[1, 4, 13, 16, 19, 29, 32, 36, 41, 45, 50, 52, 54, 58, 61, 64, 72, 74, 76, 78, 81, 88, 91, 95, 97, 103, 107, 116, 121, 124, 127, 132, 135, 139, 143, 146, 150, 152, 155, 160, 163, 166, 168, 174, 179, 186, 189, 192, 194, 198, 200, 202, 206, 209, 212, 214, 218, 220, 223, 227, 229, 232, 234, 237, 242, 251, 253, 255, 257, 260, 264, 268, 271, 275, 283, 285, 288, 292, 296, 298, 302, 309, 312, 315, 323, 326, 329, 333, 336, 339, 345, 350, 354, 359, 366, 369, 374, 380, 383, 386, 389, 392, 395, 401, 404, 414, 416, 419, 421, 423, 427, 430, 432, 435, 439, 442, 445, 448, 450, 456, 463, 465, 468, 475, 479, 483, 487, 490, 496, 501, 504, 508, 515, 520, 522, 526, 528, 531, 535, 537, 540, 542, 545, 550, 552, 556, 558, 561, 568, 572, 577, 581, 585, 591, 594, 603, 609, 614, 616, 619, 632, 637, 639, 642, 646, 648, 662, 664, 667, 674, 676, 679, 684, 686, 689, 699, 701, 704, 706, 708, 715, 720, 725, 733, 737, 741, 743, 745, 748, 754, 757, 760, 763, 769, 774, 776, 778, 784, 787, 789, 791, 795, 798, 805, 808, 813, 824, 826, 835, 839, 841, 843, 850, 853, 862, 870, 873, 877, 879, 890, 893, 896, 899, 905, 912, 918, 921, 926, 928, 930, 937, 949, 955, 957, 960, 972, 974, 977, 979, 981, 983, 987, 989, 992, 997, 1002, 1004, 1010, 1017, 1021, 1024, 1027, 1032, 1034, 1036, 1038, 1042, 1045, 1048, 1056, 1058, 1064, 1069, 1071, 1086, 1092, 1094, 1097, 1102, 1107, 1111, 1113, 1117, 1120, 1124, 1126, 1130, 1133, 1135, 1140, 1145, 1152, 1154, 1157, 1163, 1165, 1168, 1171, 1173, 1176, 1178, 1180, 1186, 1188, 1191, 1196, 1200, 1202, 1208, 1214, 1220, 1222, 1231, 1237, 1244, 1246, 1252, 1258, 1261, 1265, 1270, 1278, 1285, 1288, 1293, 1297, 1299, 1302, 1305, 1307, 1311, 1315, 1318, 1321, 1327, 1332, 1335, 1344, 1347, 1350, 1354, 1356, 1359, 1363, 1366, 1369, 1373, 1375, 1379, 1382, 1386, 1389, 1397, 1400, 1402, 1406, 1411, 1413, 1418, 1422, 1426, 1429, 1431, 1434, 1436, 1443, 1445, 1450, 1452, 1457, 1459, 1467, 1476, 1479, 1481, 1484, 1486, 1494, 1497, 1501, 1503, 1506, 1511, 1515, 1520, 1527, 1530, 1535, 1538, 1541, 1544, 1546, 1548, 1550, 1555, 1558, 1561, 1567, 1570, 1573, 1577, 1588, 1590, 1595, 1597, 1600, 1604, 1607, 1610, 1612, 1615, 1619, 1624, 1631, 1633, 1640, 1643, 1645, 1652, 1654, 1656, 1658, 1661, 1664, 1673, 1676, 1679, 1682, 1685, 1687, 1689, 1693, 1700, 1705, 1709, 1712, 1715, 1718, 1721, 1729, 1733, 1738, 1740, 1745, 1749, 1754, 1761, 1766, 1769, 1771, 1775, 1777, 1781, 1785, 1794, 1796, 1799, 1801, 1803, 1811, 1818, 1823, 1828, 1832, 1835, 1839, 1841, 1843, 1846, 1855, 1857, 1859, 1863, 1868, 1871, 1873, 1877, 1882, 1887, 1892, 1895, 1902, 1912, 1915, 1919, 1923, 1925, 1933, 1937, 1941, 1944, 1949, 1955, 1959, 1963, 1965, 1967, 1978, 1981, 1983, 1986, 1992, 1995], deadline = 3)
        configuration.add_task(name="Task3", identifier=3, period=3.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=1.69721, acet=1.69721, et_stddev=0.5657366666666667, deadline= 2)
        configuration.add_task(name="Task1", identifier=1, period=6.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=4.612642, acet=4.612642, et_stddev=1.5375473333333334, deadline= 10)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "57")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "57")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "57")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "57")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task6", identifier=6, period=18.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.92556, et_stddev=0.30852 , list_activation_dates=[15, 48, 109, 184, 219, 280, 308, 332, 351, 379, 399, 419, 441, 467, 515, 540, 560, 602, 653, 696, 719, 744, 766, 786, 822, 865, 887, 924, 945, 971, 1003, 1021, 1056, 1108, 1127, 1146, 1174, 1215, 1235, 1262, 1311, 1353, 1402, 1430, 1466, 1484, 1509, 1530, 1558, 1597, 1621, 1660, 1695, 1730, 1769, 1799, 1824, 1853, 1872, 1923, 1972], deadline = 16)
        configuration.add_task(name="Task5", identifier=5, period=3.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.699355, et_stddev=0.23311833333333332 , list_activation_dates=[5, 10, 14, 35, 44, 48, 52, 60, 65, 68, 72, 76, 83, 86, 92, 95, 99, 103, 109, 117, 126, 140, 144, 147, 155, 162, 168, 172, 180, 184, 189, 196, 199, 205, 209, 215, 219, 223, 228, 232, 236, 242, 250, 253, 261, 266, 272, 280, 285, 291, 300, 303, 307, 311, 315, 326, 331, 336, 345, 352, 365, 376, 380, 385, 388, 392, 396, 402, 408, 412, 421, 424, 430, 436, 446, 449, 458, 462, 465, 475, 478, 483, 496, 501, 509, 520, 530, 533, 538, 546, 553, 556, 561, 565, 569, 576, 586, 600, 607, 612, 617, 633, 641, 644, 650, 653, 657, 663, 672, 679, 684, 687, 691, 713, 724, 728, 732, 738, 742, 747, 751, 756, 762, 768, 772, 776, 780, 787, 794, 802, 805, 813, 820, 826, 834, 839, 844, 848, 853, 862, 868, 871, 878, 886, 891, 894, 898, 904, 912, 920, 937, 940, 943, 952, 963, 967, 972, 975, 986, 991, 997, 1003, 1006, 1013, 1021, 1024, 1032, 1038, 1042, 1046, 1050, 1054, 1065, 1074, 1080, 1086, 1097, 1107, 1113, 1122, 1131, 1138, 1143, 1148, 1155, 1162, 1170, 1188, 1192, 1195, 1202, 1208, 1217, 1221, 1229, 1233, 1237, 1244, 1247, 1251, 1254, 1267, 1277, 1282, 1288, 1293, 1298, 1308, 1313, 1317, 1333, 1337, 1341, 1349, 1355, 1364, 1371, 1374, 1384, 1390, 1393, 1399, 1411, 1415, 1418, 1422, 1428, 1433, 1439, 1444, 1449, 1452, 1455, 1465, 1471, 1475, 1479, 1485, 1491, 1503, 1509, 1513, 1519, 1523, 1530, 1533, 1537, 1541, 1546, 1549, 1553, 1564, 1572, 1576, 1586, 1591, 1597, 1601, 1610, 1614, 1618, 1625, 1633, 1637, 1641, 1644, 1648, 1662, 1665, 1670, 1685, 1689, 1693, 1699, 1703, 1708, 1724, 1731, 1735, 1742, 1745, 1750, 1758, 1762, 1766, 1771, 1775, 1779, 1783, 1787, 1792, 1796, 1802, 1805, 1808, 1811, 1817, 1820, 1825, 1828, 1832, 1836, 1841, 1858, 1862, 1867, 1870, 1873, 1883, 1887, 1894, 1900, 1904, 1909, 1915, 1918, 1932, 1936, 1946, 1949, 1952, 1956, 1960, 1967, 1973, 1979, 1983, 1986, 1990, 1996], deadline = 3)
        configuration.add_task(name="Task2", identifier=2, period=7.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=5.015291, acet=5.015291, et_stddev=1.6717636666666669, deadline= 13)
        configuration.add_task(name="Task4", identifier=4, period=1.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.015461, et_stddev=0.005153666666666667 , list_activation_dates=[2, 3, 5, 9, 12, 13, 15, 17, 19, 22, 24, 27, 29, 31, 32, 34, 36, 40, 42, 44, 45, 50, 53, 54, 55, 56, 57, 58, 60, 61, 62, 63, 65, 67, 73, 74, 76, 78, 81, 84, 85, 87, 88, 91, 93, 94, 97, 100, 104, 106, 107, 109, 111, 113, 115, 117, 119, 121, 122, 123, 124, 125, 127, 129, 130, 133, 134, 135, 137, 138, 140, 142, 144, 145, 146, 148, 149, 151, 153, 156, 160, 163, 164, 168, 170, 172, 175, 176, 177, 178, 181, 183, 185, 188, 193, 194, 198, 199, 202, 203, 206, 209, 210, 213, 215, 216, 217, 220, 225, 228, 232, 234, 235, 236, 237, 239, 241, 244, 245, 246, 247, 249, 251, 252, 254, 256, 258, 262, 264, 265, 267, 269, 270, 274, 276, 278, 279, 280, 281, 283, 285, 287, 289, 292, 293, 296, 300, 302, 303, 304, 307, 309, 310, 312, 313, 316, 317, 320, 322, 323, 324, 329, 331, 333, 335, 337, 338, 339, 341, 342, 343, 344, 347, 349, 350, 351, 353, 355, 358, 359, 361, 365, 366, 368, 372, 375, 377, 378, 380, 385, 387, 388, 389, 390, 391, 393, 394, 395, 396, 397, 399, 400, 402, 403, 405, 406, 408, 410, 412, 413, 415, 416, 417, 419, 420, 423, 424, 428, 429, 431, 432, 435, 436, 437, 440, 441, 442, 444, 445, 447, 449, 451, 453, 455, 456, 458, 460, 461, 464, 466, 467, 469, 470, 474, 476, 478, 483, 485, 486, 488, 491, 495, 496, 498, 500, 502, 504, 508, 510, 512, 513, 514, 515, 517, 520, 521, 522, 524, 525, 527, 528, 530, 532, 533, 534, 539, 541, 545, 547, 548, 550, 551, 552, 553, 554, 556, 557, 558, 560, 561, 564, 566, 567, 568, 569, 570, 573, 575, 579, 582, 583, 584, 586, 588, 589, 590, 591, 593, 595, 596, 597, 600, 602, 603, 604, 606, 608, 611, 616, 618, 619, 622, 626, 629, 630, 632, 634, 636, 639, 643, 646, 647, 649, 651, 653, 655, 656, 657, 661, 663, 664, 667, 670, 671, 673, 675, 676, 677, 679, 680, 681, 683, 685, 688, 689, 692, 693, 695, 697, 701, 702, 705, 708, 709, 710, 713, 714, 716, 718, 720, 721, 726, 728, 729, 730, 732, 733, 734, 735, 738, 741, 742, 743, 746, 748, 750, 752, 756, 758, 760, 761, 763, 765, 766, 769, 771, 773, 778, 779, 781, 783, 787, 789, 791, 794, 795, 796, 798, 799, 801, 803, 805, 808, 811, 813, 816, 818, 821, 823, 824, 826, 828, 830, 831, 832, 834, 836, 838, 840, 841, 842, 843, 845, 847, 848, 851, 855, 857, 859, 863, 867, 870, 873, 874, 876, 877, 878, 879, 883, 886, 890, 891, 894, 897, 901, 902, 904, 905, 906, 908, 909, 910, 911, 913, 914, 916, 917, 919, 921, 923, 924, 926, 929, 931, 933, 935, 938, 939, 940, 941, 943, 944, 948, 949, 951, 954, 955, 957, 962, 963, 965, 967, 972, 973, 975, 977, 980, 985, 986, 987, 990, 991, 992, 994, 996, 999, 1000, 1001, 1002, 1003, 1004, 1006, 1007, 1010, 1011, 1013, 1015, 1016, 1018, 1020, 1022, 1026, 1027, 1029, 1030, 1032, 1033, 1034, 1037, 1040, 1043, 1044, 1045, 1046, 1047, 1048, 1050, 1051, 1054, 1055, 1058, 1060, 1062, 1064, 1066, 1068, 1070, 1071, 1072, 1073, 1075, 1077, 1083, 1084, 1090, 1091, 1094, 1096, 1098, 1102, 1104, 1106, 1108, 1109, 1110, 1112, 1114, 1116, 1120, 1122, 1123, 1124, 1125, 1128, 1129, 1132, 1135, 1139, 1141, 1143, 1147, 1148, 1150, 1151, 1156, 1157, 1158, 1160, 1167, 1169, 1172, 1173, 1174, 1176, 1178, 1180, 1181, 1182, 1185, 1187, 1188, 1189, 1190, 1192, 1195, 1196, 1202, 1203, 1205, 1208, 1209, 1212, 1214, 1216, 1217, 1219, 1223, 1225, 1226, 1228, 1230, 1231, 1233, 1236, 1239, 1241, 1242, 1245, 1247, 1248, 1252, 1254, 1258, 1263, 1264, 1265, 1266, 1270, 1271, 1273, 1275, 1277, 1279, 1282, 1283, 1285, 1287, 1291, 1293, 1297, 1298, 1299, 1302, 1303, 1305, 1306, 1307, 1308, 1310, 1311, 1313, 1316, 1317, 1318, 1320, 1323, 1324, 1326, 1328, 1329, 1330, 1333, 1334, 1337, 1338, 1340, 1342, 1343, 1345, 1346, 1348, 1350, 1353, 1354, 1355, 1356, 1361, 1362, 1364, 1366, 1368, 1369, 1371, 1376, 1377, 1378, 1380, 1382, 1384, 1385, 1386, 1387, 1388, 1390, 1392, 1393, 1394, 1398, 1399, 1402, 1404, 1405, 1407, 1412, 1415, 1418, 1420, 1422, 1423, 1426, 1427, 1428, 1429, 1432, 1434, 1435, 1437, 1438, 1439, 1441, 1442, 1444, 1445, 1446, 1448, 1450, 1451, 1457, 1460, 1461, 1463, 1464, 1466, 1469, 1471, 1475, 1476, 1478, 1480, 1482, 1485, 1486, 1488, 1491, 1492, 1493, 1494, 1496, 1499, 1501, 1502, 1504, 1505, 1509, 1513, 1514, 1515, 1517, 1521, 1522, 1526, 1528, 1529, 1531, 1537, 1539, 1542, 1543, 1545, 1547, 1549, 1550, 1555, 1556, 1560, 1561, 1563, 1565, 1567, 1568, 1573, 1577, 1578, 1580, 1582, 1584, 1586, 1587, 1590, 1591, 1593, 1594, 1596, 1597, 1598, 1600, 1602, 1604, 1606, 1608, 1609, 1613, 1615, 1621, 1622, 1625, 1627, 1631, 1633, 1634, 1636, 1638, 1640, 1641, 1643, 1645, 1647, 1649, 1652, 1654, 1655, 1657, 1659, 1660, 1661, 1662, 1665, 1666, 1667, 1670, 1673, 1674, 1675, 1677, 1678, 1680, 1681, 1684, 1685, 1687, 1689, 1693, 1696, 1698, 1699, 1700, 1702, 1703, 1704, 1709, 1712, 1713, 1714, 1715, 1717, 1718, 1720, 1721, 1723, 1724, 1726, 1728, 1729, 1731, 1733, 1734, 1735, 1739, 1742, 1744, 1746, 1749, 1750, 1751, 1755, 1756, 1759, 1760, 1761, 1763, 1765, 1768, 1769, 1770, 1771, 1772, 1774, 1776, 1777, 1779, 1780, 1781, 1783, 1787, 1788, 1789, 1791, 1792, 1794, 1796, 1798, 1799, 1802, 1804, 1805, 1807, 1809, 1811, 1812, 1813, 1815, 1816, 1819, 1821, 1823, 1825, 1826, 1827, 1830, 1831, 1833, 1836, 1838, 1842, 1844, 1846, 1849, 1851, 1853, 1855, 1857, 1863, 1867, 1869, 1870, 1871, 1872, 1874, 1877, 1879, 1880, 1882, 1884, 1886, 1887, 1888, 1891, 1895, 1897, 1898, 1901, 1904, 1906, 1907, 1909, 1912, 1913, 1916, 1918, 1920, 1922, 1923, 1925, 1927, 1928, 1930, 1931, 1933, 1934, 1935, 1937, 1938, 1940, 1945, 1947, 1949, 1952, 1958, 1961, 1964, 1969, 1972, 1974, 1975, 1978, 1980, 1981, 1982, 1983, 1984, 1987, 1991, 1992, 1994, 1996, 1998, 2000], deadline = 1)
        configuration.add_task(name="Task1", identifier=1, period=3.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=1.49635, acet=1.49635, et_stddev=0.49878333333333336, deadline= 3)
        configuration.add_task(name="Task3", identifier=3, period=16.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=6.155941, acet=6.155941, et_stddev=2.0519803333333333, deadline= 18)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "58")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "58")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "58")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "58")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task2", identifier=2, period=10.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=6.543171, acet=6.543171, et_stddev=2.181057, deadline= 8)
        configuration.add_task(name="Task5", identifier=5, period=2.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.205651, et_stddev=0.06855033333333334 , list_activation_dates=[6, 9, 11, 13, 16, 20, 23, 25, 30, 33, 37, 39, 42, 44, 48, 52, 54, 56, 59, 63, 66, 68, 70, 72, 76, 80, 85, 91, 94, 100, 104, 110, 115, 120, 122, 124, 127, 129, 131, 133, 136, 139, 142, 147, 151, 153, 163, 167, 169, 173, 176, 181, 186, 189, 192, 199, 202, 206, 209, 211, 214, 216, 220, 224, 234, 250, 254, 256, 258, 260, 263, 266, 269, 272, 275, 285, 292, 294, 299, 311, 320, 323, 327, 330, 339, 345, 348, 351, 354, 357, 359, 362, 366, 368, 370, 375, 379, 384, 388, 395, 397, 400, 402, 406, 410, 414, 418, 421, 424, 426, 432, 434, 441, 446, 449, 452, 457, 463, 466, 475, 478, 481, 487, 490, 495, 498, 502, 507, 510, 513, 516, 518, 520, 523, 529, 533, 536, 538, 543, 547, 549, 554, 558, 564, 567, 569, 577, 582, 586, 588, 591, 597, 604, 606, 609, 615, 618, 621, 624, 633, 635, 638, 643, 645, 648, 651, 654, 660, 663, 673, 675, 678, 680, 683, 688, 691, 693, 698, 709, 713, 716, 718, 724, 728, 731, 734, 736, 740, 745, 748, 758, 762, 764, 768, 773, 776, 781, 784, 793, 796, 804, 807, 809, 812, 819, 821, 823, 827, 832, 835, 838, 842, 845, 849, 852, 856, 860, 862, 868, 871, 876, 879, 882, 890, 894, 897, 902, 904, 907, 910, 913, 916, 919, 922, 925, 930, 933, 939, 942, 950, 953, 956, 959, 961, 964, 966, 969, 978, 986, 988, 991, 995, 1002, 1008, 1010, 1014, 1019, 1025, 1027, 1029, 1033, 1048, 1050, 1054, 1059, 1065, 1067, 1072, 1075, 1078, 1081, 1084, 1093, 1096, 1100, 1110, 1113, 1116, 1118, 1123, 1125, 1128, 1130, 1137, 1144, 1151, 1157, 1162, 1165, 1170, 1172, 1175, 1179, 1185, 1192, 1196, 1198, 1205, 1207, 1209, 1214, 1222, 1225, 1230, 1234, 1241, 1245, 1253, 1257, 1260, 1263, 1267, 1270, 1273, 1276, 1278, 1282, 1285, 1291, 1299, 1305, 1308, 1311, 1316, 1321, 1325, 1327, 1330, 1334, 1338, 1341, 1344, 1346, 1349, 1354, 1360, 1364, 1371, 1375, 1380, 1382, 1388, 1391, 1395, 1397, 1401, 1406, 1414, 1418, 1424, 1428, 1432, 1436, 1442, 1448, 1452, 1460, 1464, 1472, 1475, 1481, 1483, 1487, 1489, 1493, 1496, 1499, 1501, 1506, 1508, 1513, 1516, 1519, 1523, 1525, 1529, 1534, 1539, 1543, 1546, 1548, 1553, 1556, 1558, 1568, 1570, 1573, 1578, 1580, 1584, 1587, 1590, 1593, 1596, 1598, 1603, 1606, 1609, 1611, 1615, 1620, 1627, 1634, 1636, 1639, 1642, 1648, 1653, 1655, 1658, 1660, 1662, 1664, 1667, 1671, 1673, 1677, 1692, 1695, 1697, 1699, 1701, 1704, 1707, 1712, 1715, 1717, 1720, 1722, 1725, 1728, 1731, 1734, 1736, 1739, 1744, 1747, 1753, 1755, 1757, 1760, 1764, 1767, 1769, 1771, 1773, 1779, 1781, 1787, 1795, 1797, 1799, 1802, 1806, 1816, 1825, 1829, 1834, 1837, 1840, 1844, 1851, 1856, 1858, 1864, 1866, 1871, 1873, 1877, 1881, 1884, 1889, 1892, 1894, 1898, 1901, 1907, 1914, 1916, 1919, 1922, 1925, 1929, 1931, 1934, 1937, 1941, 1945, 1949, 1952, 1956, 1960, 1969, 1972, 1974, 1977, 1980, 1983, 1987, 2000], deadline = 2)
        configuration.add_task(name="Task1", identifier=1, period=41.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=15.950774, acet=15.950774, et_stddev=5.316924666666666, deadline= 44)
        configuration.add_task(name="Task4", identifier=4, period=6.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=2, acet=1.139039, et_stddev=0.37967966666666664 , list_activation_dates=[1, 9, 19, 25, 42, 51, 70, 81, 94, 103, 110, 117, 126, 145, 166, 172, 179, 197, 204, 212, 220, 226, 233, 245, 262, 277, 284, 290, 310, 319, 326, 340, 347, 354, 377, 383, 389, 396, 403, 411, 418, 437, 447, 463, 469, 476, 488, 498, 508, 529, 537, 543, 550, 565, 578, 590, 601, 633, 648, 655, 662, 670, 677, 688, 719, 729, 748, 754, 761, 770, 777, 784, 796, 825, 832, 846, 858, 870, 883, 889, 916, 929, 939, 953, 960, 970, 976, 983, 992, 1000, 1009, 1021, 1027, 1034, 1046, 1064, 1070, 1084, 1095, 1104, 1118, 1133, 1139, 1146, 1155, 1162, 1171, 1187, 1202, 1217, 1224, 1238, 1248, 1264, 1272, 1288, 1299, 1305, 1314, 1343, 1363, 1378, 1386, 1395, 1423, 1429, 1441, 1453, 1459, 1466, 1481, 1497, 1503, 1515, 1541, 1548, 1556, 1565, 1576, 1593, 1603, 1616, 1622, 1641, 1651, 1660, 1667, 1675, 1683, 1691, 1706, 1714, 1736, 1746, 1753, 1764, 1773, 1787, 1808, 1816, 1828, 1836, 1847, 1859, 1865, 1872, 1879, 1890, 1905, 1922, 1939, 1947, 1964, 1970, 1981, 1994], deadline = 10)
        configuration.add_task(name="Task6", identifier=6, period=4.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.029336, et_stddev=0.009778666666666666 , list_activation_dates=[23, 28, 35, 45, 50, 56, 63, 74, 80, 87, 92, 97, 103, 112, 122, 126, 134, 144, 152, 165, 171, 176, 186, 192, 199, 206, 216, 229, 242, 254, 259, 264, 268, 275, 279, 293, 300, 307, 313, 318, 330, 338, 344, 355, 369, 374, 386, 396, 402, 410, 418, 424, 430, 434, 441, 454, 462, 467, 474, 496, 501, 508, 514, 529, 540, 544, 548, 557, 561, 568, 578, 583, 588, 597, 609, 620, 628, 632, 639, 647, 654, 663, 669, 673, 678, 692, 698, 703, 708, 712, 718, 724, 733, 746, 758, 764, 777, 787, 797, 802, 815, 819, 824, 829, 835, 841, 848, 856, 866, 870, 880, 885, 895, 909, 914, 919, 926, 935, 951, 955, 977, 987, 997, 1004, 1012, 1019, 1026, 1037, 1050, 1056, 1062, 1071, 1078, 1082, 1088, 1096, 1100, 1105, 1109, 1116, 1121, 1125, 1140, 1153, 1159, 1165, 1171, 1190, 1200, 1206, 1210, 1228, 1235, 1260, 1271, 1276, 1281, 1289, 1296, 1308, 1315, 1320, 1328, 1341, 1347, 1357, 1364, 1369, 1377, 1381, 1392, 1397, 1411, 1427, 1442, 1446, 1450, 1456, 1470, 1475, 1483, 1488, 1492, 1496, 1500, 1515, 1520, 1528, 1535, 1539, 1543, 1549, 1558, 1562, 1575, 1584, 1591, 1596, 1605, 1615, 1620, 1624, 1631, 1636, 1644, 1649, 1654, 1660, 1665, 1671, 1679, 1687, 1695, 1700, 1705, 1712, 1726, 1733, 1737, 1742, 1748, 1753, 1758, 1766, 1777, 1781, 1786, 1792, 1804, 1809, 1813, 1819, 1825, 1829, 1834, 1840, 1847, 1861, 1865, 1883, 1899, 1906, 1911, 1917, 1924, 1932, 1936, 1947, 1959, 1967, 1972, 1980, 1989], deadline = 8)
        configuration.add_task(name="Task3", identifier=3, period=5.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=2.783197, acet=2.783197, et_stddev=0.9277323333333333, deadline= 10)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "59")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "59")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "59")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "59")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task3", identifier=3, period=39.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=33.31189, acet=33.31189, et_stddev=11.103963333333333, deadline= 55)
        configuration.add_task(name="Task5", identifier=5, period=8.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.001644, et_stddev=0.000548 , list_activation_dates=[5, 20, 37, 52, 82, 94, 106, 119, 132, 145, 168, 180, 190, 210, 227, 235, 251, 271, 279, 289, 300, 313, 323, 343, 357, 367, 375, 383, 393, 410, 422, 446, 459, 470, 482, 505, 529, 540, 559, 570, 581, 590, 598, 609, 633, 651, 681, 718, 729, 746, 766, 785, 805, 835, 846, 867, 876, 885, 906, 922, 932, 951, 968, 982, 992, 1002, 1016, 1026, 1036, 1046, 1075, 1085, 1097, 1117, 1129, 1138, 1155, 1167, 1176, 1193, 1204, 1219, 1258, 1295, 1306, 1333, 1356, 1366, 1376, 1390, 1409, 1421, 1433, 1446, 1455, 1463, 1489, 1504, 1515, 1524, 1533, 1546, 1591, 1609, 1623, 1636, 1646, 1657, 1667, 1676, 1685, 1701, 1710, 1719, 1735, 1744, 1755, 1766, 1779, 1788, 1805, 1829, 1877, 1898, 1913, 1929, 1948, 1961, 1977, 1987, 1998], deadline = 9)
        configuration.add_task(name="Task4", identifier=4, period=5.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.492202, et_stddev=0.16406733333333332 , list_activation_dates=[12, 19, 28, 34, 43, 55, 61, 71, 76, 99, 105, 117, 124, 132, 146, 152, 159, 165, 170, 182, 188, 193, 205, 222, 230, 252, 258, 265, 272, 286, 303, 313, 327, 333, 345, 352, 361, 372, 381, 388, 397, 406, 412, 423, 432, 444, 454, 463, 470, 477, 482, 489, 502, 516, 527, 534, 540, 549, 564, 572, 581, 600, 609, 615, 624, 630, 640, 646, 654, 663, 670, 675, 680, 699, 705, 714, 725, 742, 748, 754, 761, 775, 782, 791, 798, 806, 813, 818, 825, 831, 842, 863, 891, 901, 908, 919, 926, 938, 945, 957, 965, 973, 985, 1012, 1018, 1024, 1034, 1056, 1065, 1076, 1084, 1104, 1114, 1120, 1126, 1133, 1142, 1152, 1158, 1164, 1175, 1181, 1192, 1197, 1204, 1210, 1216, 1224, 1229, 1237, 1247, 1252, 1259, 1270, 1276, 1290, 1304, 1309, 1322, 1333, 1338, 1348, 1357, 1364, 1385, 1394, 1401, 1409, 1417, 1428, 1433, 1441, 1457, 1466, 1475, 1489, 1499, 1510, 1528, 1537, 1544, 1560, 1565, 1576, 1584, 1593, 1600, 1606, 1629, 1644, 1650, 1658, 1675, 1681, 1687, 1694, 1702, 1709, 1715, 1720, 1728, 1739, 1756, 1763, 1768, 1785, 1800, 1807, 1819, 1825, 1831, 1839, 1844, 1865, 1875, 1880, 1885, 1896, 1902, 1908, 1914, 1920, 1927, 1933, 1940, 1946, 1955, 1966, 1971, 1983, 1989, 1997], deadline = 8)
        configuration.add_task(name="Task2", identifier=2, period=2.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=0.719725, acet=0.719725, et_stddev=0.2399083333333333, deadline= 4)
        configuration.add_task(name="Task6", identifier=6, period=3.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.604062, et_stddev=0.201354 , list_activation_dates=[6, 9, 19, 23, 34, 44, 49, 58, 63, 69, 76, 80, 83, 89, 99, 104, 108, 112, 117, 122, 126, 137, 146, 150, 154, 164, 172, 176, 182, 191, 199, 209, 212, 220, 225, 231, 234, 245, 248, 268, 274, 279, 284, 287, 292, 295, 300, 303, 308, 320, 334, 337, 349, 355, 361, 368, 375, 380, 384, 389, 393, 397, 402, 406, 410, 414, 419, 427, 442, 449, 454, 457, 461, 465, 469, 473, 479, 482, 485, 489, 495, 499, 503, 513, 522, 529, 538, 544, 548, 553, 558, 568, 576, 582, 587, 591, 602, 606, 613, 617, 621, 626, 631, 640, 644, 647, 652, 662, 669, 673, 681, 688, 691, 695, 699, 703, 707, 712, 717, 725, 728, 731, 736, 740, 743, 747, 753, 760, 764, 769, 773, 779, 790, 795, 801, 807, 811, 815, 819, 828, 832, 837, 845, 849, 860, 864, 867, 871, 879, 883, 886, 895, 902, 913, 919, 923, 932, 936, 950, 954, 961, 966, 970, 979, 985, 989, 993, 1000, 1005, 1012, 1027, 1031, 1043, 1050, 1053, 1056, 1060, 1064, 1068, 1075, 1078, 1082, 1085, 1092, 1098, 1106, 1110, 1115, 1121, 1126, 1130, 1137, 1150, 1160, 1168, 1171, 1175, 1186, 1191, 1196, 1201, 1207, 1211, 1215, 1221, 1225, 1243, 1250, 1257, 1261, 1265, 1268, 1275, 1280, 1294, 1297, 1304, 1309, 1314, 1320, 1333, 1337, 1341, 1345, 1349, 1353, 1358, 1363, 1368, 1372, 1376, 1380, 1388, 1395, 1398, 1402, 1406, 1414, 1418, 1423, 1431, 1443, 1448, 1453, 1459, 1463, 1473, 1478, 1482, 1485, 1488, 1492, 1495, 1503, 1510, 1514, 1517, 1528, 1533, 1546, 1550, 1553, 1556, 1562, 1568, 1577, 1589, 1593, 1602, 1606, 1612, 1617, 1620, 1626, 1630, 1637, 1658, 1663, 1667, 1672, 1677, 1686, 1690, 1696, 1701, 1707, 1710, 1716, 1720, 1732, 1736, 1740, 1744, 1749, 1755, 1760, 1767, 1777, 1783, 1789, 1803, 1806, 1830, 1845, 1849, 1852, 1856, 1864, 1868, 1871, 1876, 1880, 1884, 1888, 1892, 1897, 1907, 1911, 1915, 1919, 1924, 1929, 1934, 1939, 1947, 1950, 1959, 1979, 1982, 1989, 1994, 1997], deadline = 2)
        configuration.add_task(name="Task1", identifier=1, period=25.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=9.649654, acet=9.649654, et_stddev=3.2165513333333333, deadline= 41)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "60")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "60")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "60")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "60")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task6", identifier=6, period=1.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.086797, et_stddev=0.028932333333333334 , list_activation_dates=[2, 3, 5, 10, 12, 13, 14, 18, 21, 22, 24, 26, 29, 30, 32, 33, 34, 36, 38, 40, 42, 43, 51, 53, 59, 62, 66, 69, 71, 73, 74, 75, 78, 79, 81, 82, 83, 84, 86, 87, 89, 91, 94, 95, 97, 98, 100, 102, 103, 104, 106, 107, 109, 112, 115, 118, 119, 121, 123, 124, 125, 126, 128, 130, 131, 133, 134, 135, 140, 141, 142, 145, 146, 147, 149, 150, 152, 154, 155, 156, 157, 159, 160, 161, 162, 163, 164, 166, 169, 171, 173, 177, 179, 180, 183, 184, 186, 189, 191, 195, 197, 200, 204, 207, 209, 212, 216, 218, 220, 221, 222, 224, 225, 227, 228, 229, 231, 234, 236, 239, 241, 242, 245, 247, 252, 253, 255, 260, 262, 263, 264, 265, 266, 267, 268, 269, 271, 274, 275, 279, 283, 285, 286, 288, 289, 290, 292, 293, 295, 300, 302, 304, 305, 307, 311, 313, 315, 317, 322, 323, 325, 327, 329, 331, 332, 333, 336, 338, 341, 342, 346, 349, 352, 355, 356, 357, 361, 363, 369, 371, 373, 375, 376, 380, 382, 384, 385, 386, 388, 389, 391, 392, 394, 396, 399, 400, 401, 402, 403, 405, 407, 410, 412, 414, 416, 417, 420, 424, 425, 428, 430, 432, 433, 435, 438, 440, 441, 442, 443, 445, 446, 448, 449, 451, 453, 454, 457, 461, 463, 465, 466, 468, 470, 471, 473, 475, 477, 479, 484, 485, 488, 490, 491, 495, 496, 497, 499, 501, 502, 508, 509, 510, 512, 514, 516, 517, 519, 521, 523, 524, 526, 528, 530, 533, 534, 536, 537, 539, 541, 543, 544, 546, 548, 549, 552, 553, 556, 557, 559, 561, 562, 567, 568, 570, 571, 574, 578, 579, 580, 583, 584, 586, 587, 590, 592, 593, 594, 596, 598, 599, 600, 601, 603, 604, 605, 607, 610, 612, 614, 616, 618, 621, 622, 625, 627, 631, 633, 635, 636, 637, 639, 641, 642, 644, 646, 652, 654, 655, 659, 663, 664, 665, 667, 669, 671, 673, 674, 676, 677, 678, 679, 682, 684, 686, 688, 690, 692, 694, 695, 698, 700, 701, 702, 704, 706, 707, 708, 709, 710, 714, 716, 718, 721, 722, 724, 726, 728, 732, 734, 736, 738, 739, 740, 741, 742, 743, 744, 745, 746, 748, 750, 752, 754, 755, 757, 759, 761, 763, 767, 768, 772, 774, 776, 777, 779, 780, 781, 782, 783, 786, 787, 790, 791, 792, 796, 797, 798, 799, 800, 801, 803, 804, 806, 810, 813, 814, 816, 817, 818, 819, 821, 822, 823, 828, 829, 830, 831, 834, 835, 838, 839, 840, 841, 844, 845, 846, 851, 853, 856, 858, 860, 862, 865, 867, 869, 871, 873, 874, 876, 877, 880, 883, 885, 886, 889, 890, 891, 893, 894, 895, 898, 900, 901, 902, 903, 904, 905, 906, 908, 909, 910, 913, 914, 917, 918, 919, 920, 921, 922, 924, 927, 929, 930, 933, 935, 937, 938, 939, 940, 941, 942, 943, 947, 949, 952, 954, 955, 959, 960, 962, 963, 964, 965, 966, 967, 968, 969, 973, 974, 976, 977, 978, 981, 983, 984, 986, 987, 988, 989, 991, 993, 994, 996, 997, 999, 1002, 1003, 1004, 1005, 1008, 1009, 1010, 1013, 1014, 1016, 1017, 1019, 1021, 1022, 1023, 1024, 1025, 1026, 1030, 1031, 1032, 1034, 1035, 1036, 1038, 1040, 1043, 1046, 1048, 1051, 1054, 1056, 1060, 1062, 1064, 1066, 1068, 1070, 1072, 1074, 1075, 1077, 1078, 1080, 1081, 1082, 1084, 1085, 1087, 1089, 1093, 1094, 1095, 1097, 1099, 1105, 1107, 1110, 1113, 1115, 1117, 1119, 1120, 1123, 1124, 1126, 1127, 1128, 1131, 1132, 1134, 1135, 1139, 1140, 1141, 1144, 1145, 1147, 1148, 1149, 1151, 1152, 1153, 1154, 1157, 1159, 1160, 1162, 1163, 1164, 1166, 1168, 1169, 1171, 1172, 1174, 1177, 1180, 1182, 1183, 1184, 1186, 1187, 1189, 1191, 1193, 1195, 1197, 1198, 1202, 1204, 1206, 1209, 1211, 1214, 1215, 1217, 1218, 1219, 1220, 1223, 1224, 1225, 1227, 1229, 1231, 1234, 1236, 1242, 1244, 1246, 1251, 1252, 1255, 1256, 1258, 1260, 1263, 1266, 1267, 1268, 1269, 1270, 1274, 1277, 1279, 1282, 1284, 1287, 1290, 1292, 1293, 1295, 1298, 1299, 1300, 1302, 1305, 1307, 1308, 1311, 1312, 1313, 1316, 1318, 1320, 1324, 1326, 1328, 1331, 1333, 1337, 1338, 1340, 1343, 1344, 1347, 1348, 1352, 1355, 1357, 1359, 1360, 1362, 1363, 1365, 1366, 1368, 1369, 1370, 1371, 1373, 1375, 1377, 1381, 1382, 1384, 1386, 1388, 1389, 1391, 1393, 1395, 1396, 1398, 1399, 1400, 1402, 1403, 1404, 1405, 1406, 1408, 1409, 1411, 1415, 1417, 1419, 1422, 1424, 1429, 1430, 1434, 1435, 1437, 1438, 1440, 1442, 1445, 1448, 1450, 1454, 1458, 1460, 1461, 1462, 1463, 1465, 1467, 1469, 1472, 1474, 1476, 1480, 1481, 1482, 1483, 1488, 1489, 1492, 1497, 1498, 1500, 1501, 1502, 1503, 1505, 1508, 1510, 1512, 1514, 1515, 1516, 1517, 1518, 1520, 1521, 1523, 1525, 1526, 1527, 1529, 1530, 1531, 1532, 1537, 1539, 1540, 1541, 1544, 1545, 1548, 1550, 1552, 1557, 1558, 1559, 1560, 1561, 1562, 1563, 1565, 1569, 1570, 1572, 1577, 1581, 1582, 1583, 1584, 1589, 1590, 1592, 1594, 1595, 1597, 1598, 1600, 1603, 1607, 1611, 1612, 1613, 1614, 1616, 1618, 1620, 1621, 1623, 1624, 1625, 1629, 1631, 1632, 1633, 1634, 1636, 1637, 1640, 1644, 1645, 1646, 1647, 1651, 1654, 1655, 1657, 1658, 1661, 1664, 1665, 1668, 1670, 1672, 1674, 1678, 1680, 1684, 1685, 1686, 1688, 1690, 1692, 1694, 1696, 1699, 1700, 1701, 1703, 1705, 1708, 1709, 1711, 1713, 1714, 1716, 1717, 1719, 1721, 1724, 1726, 1729, 1730, 1731, 1732, 1734, 1735, 1737, 1739, 1740, 1741, 1743, 1745, 1747, 1748, 1749, 1759, 1761, 1765, 1766, 1768, 1770, 1772, 1775, 1776, 1778, 1779, 1781, 1783, 1786, 1787, 1788, 1790, 1794, 1796, 1798, 1799, 1801, 1806, 1807, 1809, 1810, 1811, 1812, 1815, 1816, 1817, 1819, 1820, 1823, 1826, 1829, 1831, 1833, 1834, 1836, 1837, 1838, 1840, 1841, 1843, 1845, 1847, 1849, 1850, 1853, 1855, 1857, 1858, 1859, 1860, 1861, 1864, 1868, 1869, 1870, 1873, 1875, 1877, 1878, 1880, 1883, 1884, 1887, 1890, 1892, 1893, 1894, 1895, 1897, 1898, 1900, 1902, 1903, 1906, 1908, 1910, 1915, 1917, 1919, 1920, 1921, 1924, 1925, 1928, 1929, 1932, 1933, 1935, 1936, 1939, 1941, 1946, 1947, 1948, 1950, 1951, 1954, 1955, 1959, 1962, 1963, 1965, 1966, 1968, 1969, 1970, 1971, 1973, 1975, 1976, 1978, 1984, 1987, 1989, 1991, 1995, 1996, 1998, 1999], deadline = 1)
        configuration.add_task(name="Task4", identifier=4, period=3.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.405401, et_stddev=0.13513366666666668 , list_activation_dates=[3, 8, 12, 21, 29, 39, 47, 52, 69, 82, 90, 94, 103, 108, 113, 120, 127, 133, 137, 143, 147, 156, 161, 167, 172, 183, 186, 190, 194, 198, 201, 210, 220, 226, 229, 234, 238, 241, 258, 261, 265, 270, 276, 285, 289, 296, 300, 304, 310, 314, 318, 324, 335, 339, 348, 362, 368, 375, 378, 383, 386, 390, 394, 404, 408, 414, 417, 431, 437, 442, 451, 457, 463, 466, 469, 473, 479, 490, 496, 500, 505, 508, 513, 517, 524, 529, 533, 545, 556, 569, 574, 577, 583, 588, 594, 608, 615, 621, 633, 637, 644, 647, 653, 661, 665, 668, 671, 674, 680, 685, 695, 698, 703, 709, 713, 717, 721, 727, 733, 737, 740, 744, 748, 754, 764, 767, 773, 780, 784, 793, 796, 805, 809, 815, 818, 822, 828, 833, 838, 841, 847, 852, 858, 863, 866, 870, 873, 892, 897, 900, 903, 910, 914, 918, 924, 930, 937, 943, 949, 958, 966, 970, 975, 980, 986, 990, 1000, 1003, 1007, 1011, 1014, 1018, 1028, 1032, 1039, 1042, 1045, 1051, 1055, 1058, 1062, 1065, 1069, 1075, 1098, 1105, 1110, 1115, 1118, 1126, 1131, 1136, 1139, 1149, 1154, 1171, 1174, 1198, 1204, 1208, 1214, 1233, 1241, 1245, 1259, 1264, 1275, 1278, 1282, 1287, 1291, 1301, 1307, 1310, 1314, 1323, 1327, 1331, 1338, 1342, 1353, 1358, 1372, 1377, 1382, 1385, 1400, 1404, 1408, 1413, 1417, 1427, 1433, 1437, 1444, 1452, 1455, 1459, 1463, 1471, 1475, 1479, 1484, 1489, 1494, 1499, 1508, 1511, 1517, 1525, 1529, 1534, 1548, 1555, 1561, 1565, 1570, 1574, 1577, 1583, 1588, 1592, 1596, 1602, 1608, 1618, 1621, 1625, 1629, 1633, 1639, 1643, 1648, 1656, 1660, 1663, 1667, 1674, 1677, 1682, 1687, 1691, 1700, 1704, 1708, 1712, 1720, 1723, 1727, 1731, 1738, 1743, 1748, 1752, 1756, 1761, 1764, 1769, 1774, 1778, 1781, 1792, 1803, 1809, 1813, 1821, 1825, 1830, 1849, 1856, 1864, 1867, 1872, 1875, 1881, 1889, 1894, 1898, 1903, 1910, 1913, 1916, 1925, 1932, 1936, 1941, 1946, 1953, 1957, 1963, 1970, 1974, 1981, 1988, 1992, 1995, 1999], deadline = 4)
        configuration.add_task(name="Task1", identifier=1, period=1.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=0.623202, acet=0.623202, et_stddev=0.207734, deadline= 1)
        configuration.add_task(name="Task3", identifier=3, period=7.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=1.162692, acet=1.162692, et_stddev=0.387564, deadline= 12)
        configuration.add_task(name="Task2", identifier=2, period=4.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=3.242792, acet=3.242792, et_stddev=1.0809306666666667, deadline= 8)
        configuration.add_task(name="Task5", identifier=5, period=6.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.468408, et_stddev=0.156136 , list_activation_dates=[2, 10, 17, 29, 36, 52, 59, 71, 81, 88, 104, 113, 119, 128, 135, 144, 157, 164, 175, 182, 196, 203, 220, 227, 236, 244, 263, 272, 288, 299, 305, 314, 324, 344, 359, 371, 383, 390, 398, 413, 434, 442, 457, 471, 478, 494, 502, 514, 527, 540, 547, 553, 571, 583, 590, 606, 621, 630, 662, 668, 676, 690, 699, 710, 721, 727, 738, 750, 762, 776, 796, 807, 815, 826, 837, 851, 867, 888, 909, 920, 937, 970, 998, 1018, 1031, 1045, 1052, 1061, 1071, 1082, 1100, 1119, 1131, 1145, 1152, 1177, 1184, 1190, 1201, 1218, 1229, 1240, 1246, 1253, 1272, 1281, 1289, 1307, 1315, 1342, 1353, 1366, 1376, 1392, 1399, 1408, 1416, 1432, 1439, 1449, 1458, 1486, 1500, 1511, 1524, 1543, 1554, 1572, 1580, 1594, 1609, 1621, 1633, 1643, 1650, 1656, 1663, 1669, 1677, 1684, 1700, 1711, 1718, 1724, 1752, 1758, 1775, 1785, 1808, 1818, 1828, 1834, 1846, 1856, 1864, 1876, 1888, 1900, 1914, 1924, 1934, 1950, 1962, 1973, 1981, 1996], deadline = 1)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "61")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "61")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "61")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "61")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task1", identifier=1, period=21.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=5.594481, acet=5.594481, et_stddev=1.864827, deadline= 29)
        configuration.add_task(name="Task3", identifier=3, period=22.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=15.447661, acet=15.447661, et_stddev=5.149220333333333, deadline= 28)
        configuration.add_task(name="Task6", identifier=6, period=40.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.329681, et_stddev=0.10989366666666667 , list_activation_dates=[34, 95, 386, 490, 574, 618, 720, 785, 915, 973, 1064, 1106, 1201, 1256, 1375, 1421, 1495, 1551, 1655, 1785, 1851, 1953], deadline = 32)
        configuration.add_task(name="Task5", identifier=5, period=49.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=9, acet=8.696566, et_stddev=2.8988553333333336 , list_activation_dates=[113, 192, 261, 312, 457, 526, 739, 794, 851, 914, 970, 1020, 1187, 1316, 1425, 1480, 1544, 1597, 1660, 1718, 1853, 1925, 1975], deadline = 94)
        configuration.add_task(name="Task4", identifier=4, period=41.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=5, acet=4.685357, et_stddev=1.5617856666666665 , list_activation_dates=[147, 271, 345, 401, 577, 676, 763, 820, 876, 938, 989, 1051, 1129, 1196, 1263, 1311, 1362, 1439, 1581, 1642, 1749, 1882], deadline = 43)
        configuration.add_task(name="Task2", identifier=2, period=20.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=12.628593, acet=12.628593, et_stddev=4.209531, deadline= 37)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "62")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "62")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "62")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "62")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task6", identifier=6, period=1.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.06459, et_stddev=0.021529999999999997 , list_activation_dates=[2, 5, 6, 8, 10, 11, 12, 16, 17, 19, 23, 24, 25, 26, 28, 31, 33, 35, 36, 39, 40, 42, 45, 46, 49, 50, 52, 53, 54, 56, 57, 59, 60, 61, 62, 64, 65, 69, 70, 72, 73, 75, 77, 79, 80, 84, 85, 86, 88, 90, 92, 95, 97, 98, 100, 103, 105, 107, 109, 111, 112, 113, 116, 117, 119, 120, 122, 123, 125, 127, 129, 131, 132, 136, 137, 138, 141, 143, 145, 146, 150, 151, 154, 155, 157, 161, 163, 166, 171, 174, 175, 176, 179, 181, 183, 184, 188, 189, 190, 191, 194, 196, 199, 201, 202, 207, 209, 211, 213, 214, 217, 220, 221, 222, 224, 225, 227, 228, 229, 231, 233, 237, 240, 242, 243, 245, 246, 248, 249, 253, 255, 256, 257, 258, 260, 261, 262, 263, 265, 266, 270, 273, 276, 278, 279, 281, 283, 285, 287, 289, 291, 293, 295, 297, 299, 301, 302, 303, 304, 306, 310, 312, 313, 314, 316, 318, 319, 321, 322, 325, 327, 330, 332, 333, 335, 336, 337, 338, 339, 340, 341, 342, 343, 346, 348, 353, 355, 357, 359, 361, 363, 365, 366, 367, 368, 370, 371, 376, 377, 379, 380, 382, 383, 386, 388, 391, 392, 394, 395, 396, 398, 405, 406, 407, 408, 409, 411, 413, 415, 416, 417, 420, 422, 424, 425, 427, 429, 431, 432, 434, 435, 436, 437, 439, 441, 443, 444, 445, 451, 453, 454, 458, 459, 462, 463, 465, 466, 467, 471, 473, 475, 476, 478, 479, 481, 483, 484, 489, 491, 492, 494, 498, 500, 501, 502, 504, 505, 506, 508, 510, 512, 515, 517, 519, 521, 524, 528, 529, 530, 532, 533, 535, 539, 541, 543, 545, 547, 548, 550, 555, 558, 560, 561, 562, 563, 564, 565, 566, 568, 570, 571, 572, 573, 575, 577, 581, 584, 585, 588, 589, 590, 592, 593, 595, 597, 600, 601, 602, 605, 608, 610, 612, 613, 616, 618, 619, 622, 623, 628, 631, 632, 633, 634, 635, 638, 640, 642, 644, 645, 647, 651, 654, 655, 657, 659, 662, 664, 667, 673, 676, 678, 681, 683, 684, 686, 690, 691, 693, 696, 698, 700, 702, 704, 705, 706, 707, 711, 712, 714, 718, 719, 721, 722, 726, 730, 732, 736, 739, 740, 743, 745, 748, 750, 752, 754, 755, 756, 758, 760, 762, 763, 765, 767, 768, 770, 774, 775, 776, 778, 779, 781, 783, 785, 786, 789, 791, 792, 793, 794, 795, 796, 798, 801, 802, 804, 806, 808, 809, 811, 813, 814, 816, 817, 819, 821, 825, 827, 828, 829, 832, 833, 834, 836, 838, 844, 846, 847, 849, 850, 852, 853, 855, 857, 859, 862, 866, 867, 869, 870, 875, 876, 878, 880, 885, 886, 893, 894, 896, 897, 898, 901, 904, 906, 907, 908, 912, 915, 916, 917, 918, 920, 922, 928, 930, 933, 934, 936, 938, 945, 946, 948, 953, 955, 957, 959, 960, 961, 962, 963, 964, 965, 969, 970, 972, 973, 975, 977, 978, 982, 986, 987, 989, 991, 992, 994, 995, 998, 999, 1001, 1004, 1005, 1006, 1009, 1011, 1012, 1013, 1014, 1017, 1019, 1021, 1023, 1025, 1027, 1028, 1030, 1032, 1034, 1036, 1038, 1041, 1042, 1043, 1045, 1048, 1050, 1052, 1054, 1056, 1057, 1059, 1060, 1061, 1065, 1067, 1068, 1070, 1071, 1072, 1076, 1078, 1079, 1081, 1082, 1083, 1091, 1093, 1094, 1095, 1098, 1100, 1101, 1103, 1105, 1113, 1115, 1116, 1118, 1119, 1120, 1126, 1128, 1129, 1130, 1132, 1134, 1137, 1140, 1142, 1143, 1146, 1147, 1149, 1151, 1156, 1157, 1159, 1161, 1163, 1166, 1167, 1169, 1170, 1171, 1172, 1174, 1178, 1179, 1181, 1182, 1184, 1185, 1187, 1189, 1193, 1194, 1196, 1201, 1203, 1204, 1206, 1208, 1211, 1212, 1213, 1215, 1218, 1219, 1220, 1221, 1226, 1228, 1229, 1233, 1234, 1238, 1239, 1240, 1244, 1247, 1249, 1250, 1252, 1254, 1256, 1257, 1258, 1259, 1261, 1266, 1268, 1270, 1273, 1275, 1278, 1279, 1280, 1281, 1282, 1283, 1284, 1285, 1286, 1289, 1291, 1293, 1295, 1298, 1300, 1301, 1302, 1305, 1306, 1307, 1308, 1309, 1312, 1318, 1319, 1320, 1322, 1323, 1325, 1326, 1328, 1330, 1332, 1335, 1336, 1338, 1340, 1342, 1343, 1345, 1349, 1350, 1352, 1354, 1355, 1357, 1361, 1364, 1365, 1367, 1369, 1372, 1381, 1382, 1384, 1387, 1389, 1390, 1393, 1394, 1395, 1396, 1398, 1399, 1401, 1402, 1403, 1405, 1407, 1409, 1411, 1414, 1416, 1417, 1418, 1420, 1421, 1423, 1424, 1426, 1428, 1434, 1436, 1437, 1438, 1441, 1442, 1444, 1447, 1448, 1449, 1451, 1453, 1457, 1458, 1460, 1466, 1468, 1469, 1470, 1471, 1473, 1474, 1478, 1479, 1481, 1483, 1487, 1489, 1490, 1492, 1495, 1497, 1500, 1503, 1505, 1508, 1510, 1512, 1516, 1517, 1518, 1521, 1523, 1529, 1530, 1531, 1533, 1535, 1538, 1539, 1541, 1543, 1545, 1547, 1550, 1551, 1552, 1553, 1555, 1557, 1559, 1561, 1563, 1565, 1566, 1567, 1569, 1571, 1572, 1574, 1575, 1576, 1577, 1578, 1579, 1580, 1584, 1585, 1586, 1587, 1590, 1591, 1594, 1597, 1599, 1602, 1604, 1606, 1607, 1608, 1610, 1611, 1614, 1615, 1616, 1617, 1619, 1622, 1624, 1627, 1628, 1630, 1632, 1633, 1634, 1637, 1639, 1642, 1644, 1645, 1646, 1647, 1648, 1650, 1651, 1653, 1655, 1658, 1659, 1660, 1662, 1664, 1667, 1669, 1672, 1673, 1674, 1677, 1679, 1681, 1683, 1685, 1688, 1690, 1694, 1696, 1701, 1702, 1704, 1705, 1706, 1709, 1710, 1711, 1712, 1715, 1718, 1720, 1723, 1724, 1726, 1729, 1730, 1732, 1733, 1734, 1736, 1737, 1739, 1740, 1741, 1743, 1744, 1746, 1747, 1748, 1750, 1752, 1753, 1754, 1755, 1758, 1759, 1760, 1762, 1764, 1766, 1767, 1769, 1771, 1772, 1773, 1777, 1778, 1779, 1783, 1784, 1786, 1791, 1792, 1794, 1795, 1798, 1801, 1803, 1805, 1806, 1807, 1809, 1810, 1813, 1815, 1816, 1818, 1819, 1821, 1822, 1824, 1828, 1829, 1830, 1831, 1832, 1833, 1836, 1838, 1841, 1844, 1845, 1846, 1849, 1851, 1852, 1854, 1856, 1858, 1863, 1864, 1865, 1867, 1868, 1869, 1871, 1877, 1879, 1880, 1881, 1883, 1884, 1885, 1887, 1889, 1893, 1894, 1895, 1897, 1898, 1901, 1903, 1905, 1909, 1910, 1912, 1913, 1915, 1920, 1922, 1923, 1926, 1929, 1930, 1935, 1937, 1938, 1940, 1942, 1943, 1944, 1947, 1949, 1951, 1952, 1953, 1954, 1957, 1958, 1961, 1962, 1964, 1966, 1968, 1969, 1970, 1972, 1975, 1977, 1979, 1980, 1982, 1985, 1986, 1988, 1990, 1991, 1992, 1994, 1996, 1997], deadline = 1)
        configuration.add_task(name="Task1", identifier=1, period=22.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=6.196624, acet=6.196624, et_stddev=2.0655413333333335, deadline= 13)
        configuration.add_task(name="Task2", identifier=2, period=42.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=28.292366, acet=28.292366, et_stddev=9.430788666666666, deadline= 72)
        configuration.add_task(name="Task4", identifier=4, period=1.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.214665, et_stddev=0.071555 , list_activation_dates=[2, 4, 5, 6, 9, 10, 12, 14, 16, 18, 20, 23, 28, 29, 31, 34, 37, 38, 40, 42, 44, 46, 48, 50, 51, 53, 55, 57, 60, 62, 63, 65, 67, 69, 71, 74, 76, 78, 79, 85, 86, 88, 90, 91, 92, 94, 95, 96, 97, 99, 100, 103, 104, 107, 108, 109, 110, 111, 112, 113, 115, 117, 118, 121, 122, 124, 126, 128, 129, 130, 132, 133, 135, 137, 139, 140, 143, 144, 146, 151, 156, 160, 161, 162, 164, 168, 169, 170, 171, 172, 176, 179, 181, 183, 184, 186, 187, 188, 189, 191, 192, 193, 194, 196, 197, 198, 200, 202, 203, 204, 205, 207, 210, 212, 214, 215, 217, 219, 220, 222, 223, 224, 226, 228, 231, 233, 236, 238, 240, 241, 243, 246, 248, 250, 252, 255, 256, 257, 261, 262, 265, 266, 267, 269, 270, 273, 275, 276, 277, 280, 281, 283, 284, 285, 288, 291, 292, 294, 296, 299, 302, 304, 306, 307, 309, 310, 313, 314, 315, 318, 319, 321, 323, 325, 326, 330, 334, 336, 341, 342, 345, 348, 351, 352, 354, 355, 358, 359, 360, 364, 366, 367, 369, 370, 372, 374, 376, 377, 378, 380, 382, 383, 387, 389, 391, 393, 395, 396, 397, 399, 401, 404, 406, 407, 409, 411, 413, 414, 416, 418, 421, 422, 426, 428, 429, 432, 434, 437, 439, 440, 442, 443, 444, 446, 447, 448, 449, 450, 451, 453, 457, 458, 459, 461, 462, 464, 467, 468, 470, 471, 474, 475, 476, 479, 482, 484, 485, 486, 487, 489, 490, 493, 494, 495, 499, 501, 504, 505, 507, 509, 511, 512, 517, 519, 520, 524, 525, 528, 531, 532, 533, 535, 536, 540, 542, 543, 547, 548, 550, 551, 552, 553, 554, 556, 558, 559, 561, 562, 563, 564, 568, 569, 571, 572, 574, 576, 577, 579, 580, 581, 583, 585, 586, 588, 590, 591, 594, 597, 600, 601, 604, 606, 607, 609, 611, 613, 615, 617, 618, 620, 625, 626, 628, 629, 632, 633, 634, 637, 638, 639, 641, 646, 647, 649, 651, 652, 654, 655, 657, 658, 661, 665, 667, 668, 670, 675, 678, 680, 681, 683, 684, 688, 690, 692, 693, 694, 695, 697, 698, 699, 700, 701, 703, 704, 706, 707, 708, 709, 710, 712, 714, 717, 719, 720, 721, 722, 724, 725, 727, 728, 731, 734, 735, 737, 738, 739, 740, 741, 742, 744, 745, 747, 750, 752, 755, 756, 757, 759, 760, 762, 763, 764, 767, 768, 769, 771, 773, 775, 776, 778, 780, 782, 783, 788, 789, 791, 793, 794, 796, 798, 800, 801, 803, 805, 807, 809, 811, 815, 816, 817, 819, 821, 822, 823, 826, 827, 828, 832, 834, 836, 838, 839, 840, 842, 845, 846, 848, 850, 851, 852, 860, 861, 864, 865, 866, 869, 870, 872, 876, 877, 878, 879, 881, 882, 886, 888, 889, 891, 894, 897, 898, 899, 900, 901, 904, 906, 907, 908, 910, 911, 913, 915, 916, 918, 921, 922, 926, 928, 931, 933, 934, 936, 938, 939, 940, 943, 946, 949, 951, 952, 955, 959, 962, 964, 965, 966, 967, 971, 972, 974, 975, 977, 979, 983, 984, 985, 987, 988, 990, 992, 995, 998, 1000, 1003, 1005, 1006, 1008, 1010, 1011, 1013, 1014, 1017, 1018, 1020, 1022, 1023, 1024, 1025, 1026, 1027, 1028, 1030, 1032, 1034, 1036, 1040, 1042, 1043, 1045, 1047, 1049, 1050, 1052, 1055, 1056, 1057, 1059, 1062, 1063, 1065, 1066, 1067, 1069, 1070, 1072, 1074, 1075, 1077, 1078, 1079, 1083, 1084, 1088, 1091, 1093, 1095, 1097, 1098, 1100, 1101, 1103, 1104, 1107, 1108, 1109, 1110, 1112, 1113, 1114, 1115, 1117, 1119, 1120, 1121, 1122, 1126, 1127, 1128, 1130, 1131, 1133, 1134, 1136, 1138, 1139, 1145, 1147, 1148, 1150, 1152, 1153, 1154, 1155, 1157, 1160, 1161, 1165, 1166, 1168, 1169, 1170, 1172, 1174, 1175, 1179, 1180, 1184, 1185, 1187, 1189, 1190, 1191, 1194, 1195, 1198, 1202, 1208, 1209, 1210, 1211, 1213, 1214, 1215, 1216, 1219, 1220, 1221, 1224, 1227, 1232, 1233, 1234, 1236, 1238, 1239, 1240, 1241, 1242, 1244, 1245, 1247, 1248, 1249, 1250, 1252, 1253, 1255, 1257, 1258, 1260, 1261, 1263, 1265, 1267, 1268, 1270, 1271, 1274, 1276, 1278, 1280, 1281, 1283, 1285, 1286, 1289, 1290, 1292, 1294, 1299, 1300, 1302, 1303, 1305, 1308, 1310, 1312, 1313, 1314, 1316, 1318, 1320, 1321, 1323, 1325, 1327, 1329, 1330, 1331, 1333, 1340, 1341, 1343, 1345, 1347, 1348, 1349, 1350, 1353, 1355, 1357, 1358, 1359, 1360, 1361, 1364, 1366, 1369, 1371, 1372, 1373, 1375, 1376, 1377, 1381, 1382, 1384, 1385, 1386, 1387, 1388, 1390, 1391, 1393, 1394, 1396, 1397, 1399, 1401, 1403, 1404, 1406, 1407, 1408, 1415, 1416, 1419, 1420, 1423, 1426, 1430, 1435, 1437, 1438, 1439, 1440, 1441, 1443, 1445, 1447, 1450, 1452, 1454, 1457, 1458, 1459, 1460, 1463, 1465, 1467, 1469, 1472, 1474, 1475, 1477, 1479, 1480, 1482, 1484, 1488, 1489, 1491, 1495, 1497, 1498, 1499, 1502, 1504, 1506, 1509, 1510, 1512, 1514, 1515, 1516, 1518, 1521, 1523, 1524, 1526, 1527, 1528, 1530, 1532, 1534, 1535, 1536, 1539, 1542, 1543, 1545, 1546, 1547, 1548, 1549, 1550, 1551, 1552, 1558, 1559, 1561, 1562, 1564, 1565, 1570, 1573, 1574, 1576, 1577, 1579, 1584, 1589, 1591, 1592, 1594, 1595, 1596, 1599, 1600, 1601, 1602, 1604, 1607, 1608, 1609, 1610, 1612, 1614, 1617, 1622, 1624, 1625, 1626, 1628, 1630, 1632, 1633, 1635, 1636, 1641, 1642, 1644, 1645, 1646, 1648, 1650, 1651, 1652, 1656, 1658, 1659, 1660, 1661, 1662, 1665, 1669, 1671, 1674, 1675, 1677, 1678, 1679, 1682, 1684, 1686, 1690, 1693, 1695, 1697, 1700, 1701, 1703, 1705, 1706, 1708, 1709, 1710, 1711, 1713, 1715, 1717, 1718, 1720, 1721, 1724, 1725, 1727, 1729, 1730, 1731, 1734, 1737, 1739, 1740, 1741, 1742, 1744, 1746, 1747, 1749, 1750, 1751, 1753, 1756, 1758, 1759, 1761, 1762, 1763, 1764, 1766, 1768, 1770, 1771, 1773, 1776, 1777, 1779, 1781, 1783, 1784, 1785, 1787, 1788, 1789, 1791, 1792, 1794, 1797, 1798, 1799, 1801, 1805, 1808, 1809, 1811, 1812, 1814, 1817, 1819, 1820, 1821, 1822, 1823, 1828, 1831, 1833, 1836, 1839, 1841, 1844, 1845, 1847, 1849, 1851, 1857, 1860, 1862, 1863, 1868, 1869, 1871, 1873, 1874, 1876, 1878, 1880, 1882, 1883, 1888, 1890, 1892, 1894, 1895, 1896, 1897, 1899, 1901, 1903, 1906, 1907, 1909, 1910, 1913, 1914, 1916, 1918, 1920, 1923, 1925, 1926, 1927, 1929, 1932, 1934, 1936, 1938, 1940, 1941, 1944, 1945, 1946, 1947, 1948, 1950, 1951, 1954, 1956, 1957, 1958, 1959, 1960, 1966, 1967, 1969, 1971, 1975, 1977, 1978, 1983, 1985, 1986, 1987, 1988, 1993, 1996, 1997, 1999], deadline = 2)
        configuration.add_task(name="Task3", identifier=3, period=18.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=11.604734, acet=11.604734, et_stddev=3.868244666666667, deadline= 16)
        configuration.add_task(name="Task5", identifier=5, period=9.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.186693, et_stddev=0.062231 , list_activation_dates=[3, 18, 33, 58, 91, 104, 125, 134, 146, 162, 184, 198, 211, 230, 276, 289, 303, 343, 366, 386, 400, 415, 426, 436, 466, 476, 493, 513, 529, 547, 574, 601, 627, 643, 666, 680, 699, 711, 736, 764, 775, 799, 809, 828, 851, 870, 891, 903, 925, 950, 962, 980, 992, 1019, 1052, 1061, 1072, 1083, 1099, 1116, 1129, 1139, 1148, 1159, 1170, 1197, 1212, 1225, 1240, 1251, 1262, 1279, 1289, 1308, 1330, 1352, 1363, 1389, 1404, 1418, 1437, 1449, 1474, 1484, 1520, 1537, 1547, 1566, 1586, 1596, 1608, 1621, 1630, 1639, 1655, 1686, 1733, 1748, 1758, 1767, 1785, 1796, 1837, 1865, 1874, 1885, 1907, 1919, 1951, 1967, 1982], deadline = 3)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "64")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "64")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "64")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "64")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task2", identifier=2, period=4.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=3.763414, acet=3.763414, et_stddev=1.2544713333333333, deadline= 5)
        configuration.add_task(name="Task1", identifier=1, period=8.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=0.499761, acet=0.499761, et_stddev=0.166587, deadline= 16)
        configuration.add_task(name="Task6", identifier=6, period=3.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.086522, et_stddev=0.028840666666666667 , list_activation_dates=[2, 5, 12, 16, 24, 31, 36, 42, 48, 52, 57, 72, 76, 81, 85, 91, 94, 98, 102, 107, 116, 119, 123, 128, 132, 136, 145, 151, 158, 162, 166, 170, 173, 177, 182, 187, 190, 193, 197, 202, 208, 214, 217, 225, 229, 232, 237, 242, 250, 254, 257, 261, 267, 271, 276, 289, 294, 299, 302, 309, 317, 320, 325, 329, 337, 341, 346, 351, 356, 360, 368, 374, 380, 383, 387, 390, 394, 410, 415, 427, 436, 440, 445, 451, 456, 461, 466, 470, 474, 477, 481, 484, 491, 495, 500, 503, 506, 514, 520, 528, 531, 536, 539, 545, 548, 555, 562, 566, 569, 575, 580, 587, 599, 604, 609, 617, 621, 627, 632, 637, 651, 656, 660, 665, 673, 677, 681, 690, 694, 698, 709, 714, 719, 728, 735, 741, 752, 757, 763, 771, 774, 780, 783, 790, 794, 802, 811, 822, 835, 839, 842, 846, 853, 856, 860, 869, 873, 879, 882, 888, 893, 903, 906, 910, 914, 921, 924, 932, 936, 944, 949, 952, 956, 960, 966, 969, 973, 980, 984, 988, 993, 996, 1001, 1008, 1015, 1021, 1025, 1031, 1036, 1040, 1044, 1051, 1057, 1061, 1065, 1075, 1081, 1089, 1095, 1100, 1104, 1109, 1121, 1130, 1140, 1149, 1152, 1161, 1165, 1168, 1173, 1191, 1200, 1208, 1215, 1220, 1226, 1232, 1238, 1243, 1253, 1266, 1273, 1279, 1284, 1288, 1295, 1302, 1307, 1312, 1318, 1324, 1332, 1337, 1345, 1348, 1352, 1361, 1365, 1374, 1379, 1388, 1392, 1396, 1411, 1414, 1422, 1428, 1444, 1452, 1457, 1476, 1484, 1487, 1491, 1494, 1498, 1502, 1514, 1517, 1522, 1532, 1537, 1543, 1546, 1549, 1552, 1561, 1568, 1576, 1580, 1584, 1588, 1597, 1606, 1617, 1620, 1623, 1628, 1633, 1641, 1645, 1648, 1652, 1655, 1666, 1672, 1677, 1682, 1687, 1693, 1696, 1711, 1722, 1729, 1739, 1744, 1751, 1757, 1763, 1770, 1779, 1785, 1789, 1796, 1804, 1810, 1820, 1826, 1835, 1839, 1842, 1845, 1851, 1854, 1863, 1869, 1872, 1879, 1882, 1894, 1898, 1909, 1912, 1918, 1926, 1930, 1936, 1940, 1944, 1951, 1974, 1978, 1983, 1989, 1999], deadline = 5)
        configuration.add_task(name="Task5", identifier=5, period=20.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=5, acet=4.541215, et_stddev=1.5137383333333334 , list_activation_dates=[51, 120, 149, 170, 191, 263, 288, 336, 380, 415, 435, 476, 511, 545, 603, 629, 666, 691, 717, 740, 763, 793, 850, 871, 910, 959, 986, 1040, 1062, 1090, 1118, 1146, 1180, 1210, 1255, 1294, 1326, 1347, 1379, 1439, 1472, 1511, 1534, 1678, 1728, 1759, 1805, 1844, 1876, 1898, 1925, 1954, 1978], deadline = 35)
        configuration.add_task(name="Task4", identifier=4, period=1.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.044098, et_stddev=0.014699333333333333 , list_activation_dates=[2, 4, 5, 8, 9, 10, 12, 14, 15, 18, 21, 23, 25, 28, 29, 32, 33, 36, 40, 42, 44, 45, 46, 47, 49, 52, 53, 54, 55, 56, 57, 58, 59, 61, 65, 66, 67, 68, 70, 71, 73, 75, 79, 81, 82, 84, 86, 87, 88, 90, 91, 94, 96, 97, 99, 101, 102, 103, 104, 106, 107, 108, 110, 113, 114, 115, 116, 118, 120, 122, 124, 126, 127, 129, 131, 132, 134, 136, 138, 139, 140, 142, 146, 147, 149, 153, 154, 156, 158, 160, 161, 162, 163, 164, 167, 169, 172, 173, 174, 175, 178, 181, 183, 187, 189, 191, 192, 193, 194, 196, 200, 201, 203, 205, 207, 208, 212, 214, 215, 217, 218, 219, 222, 226, 229, 231, 235, 237, 239, 241, 243, 245, 246, 249, 250, 251, 253, 256, 258, 263, 264, 266, 267, 268, 272, 273, 274, 276, 278, 279, 280, 281, 284, 285, 288, 290, 291, 293, 294, 296, 298, 300, 302, 304, 306, 307, 308, 311, 312, 314, 316, 318, 320, 322, 323, 324, 326, 328, 329, 331, 336, 341, 343, 345, 348, 349, 350, 352, 354, 356, 361, 362, 364, 366, 368, 369, 370, 373, 374, 376, 381, 382, 383, 387, 389, 391, 392, 393, 394, 397, 399, 402, 403, 408, 410, 412, 414, 416, 418, 419, 420, 422, 424, 428, 429, 430, 433, 435, 437, 439, 440, 441, 442, 444, 446, 448, 450, 451, 452, 457, 459, 461, 462, 464, 466, 467, 469, 470, 479, 480, 482, 483, 486, 487, 488, 492, 494, 497, 498, 499, 502, 504, 505, 506, 508, 509, 511, 513, 515, 518, 519, 521, 522, 526, 528, 530, 531, 532, 534, 535, 536, 537, 539, 540, 544, 546, 548, 550, 551, 553, 555, 556, 558, 560, 562, 565, 567, 568, 569, 573, 576, 578, 580, 582, 584, 585, 588, 590, 591, 595, 596, 598, 599, 600, 601, 604, 605, 606, 607, 610, 613, 614, 615, 616, 617, 619, 620, 621, 622, 624, 625, 626, 629, 632, 633, 635, 636, 637, 639, 641, 642, 644, 645, 647, 650, 651, 654, 655, 656, 657, 658, 659, 663, 664, 665, 666, 668, 670, 672, 674, 676, 677, 678, 680, 681, 683, 684, 685, 687, 690, 692, 693, 695, 696, 698, 702, 704, 705, 706, 708, 709, 713, 715, 717, 719, 721, 722, 723, 724, 726, 727, 728, 730, 732, 733, 734, 736, 737, 738, 740, 742, 745, 747, 748, 749, 750, 752, 755, 756, 758, 759, 760, 762, 766, 767, 769, 770, 773, 775, 777, 780, 781, 782, 784, 786, 787, 788, 790, 792, 794, 800, 802, 803, 804, 807, 810, 813, 814, 816, 818, 819, 820, 823, 827, 828, 829, 831, 833, 834, 836, 837, 840, 841, 842, 847, 848, 850, 852, 853, 856, 858, 860, 862, 864, 865, 866, 868, 872, 874, 876, 878, 880, 881, 882, 885, 886, 888, 889, 890, 894, 895, 896, 897, 899, 900, 901, 902, 903, 905, 906, 910, 911, 912, 913, 914, 916, 918, 919, 921, 923, 925, 928, 930, 932, 933, 935, 937, 941, 942, 943, 944, 947, 948, 950, 951, 952, 954, 955, 957, 958, 959, 960, 961, 962, 964, 966, 968, 970, 971, 972, 973, 975, 977, 979, 981, 982, 984, 986, 988, 991, 993, 994, 996, 998, 1000, 1002, 1003, 1006, 1009, 1011, 1012, 1013, 1015, 1016, 1017, 1018, 1019, 1020, 1021, 1023, 1024, 1028, 1030, 1032, 1033, 1038, 1039, 1041, 1044, 1045, 1047, 1050, 1051, 1053, 1055, 1057, 1058, 1060, 1064, 1065, 1067, 1069, 1072, 1074, 1076, 1078, 1080, 1081, 1082, 1085, 1087, 1088, 1090, 1092, 1094, 1097, 1098, 1100, 1102, 1104, 1109, 1110, 1112, 1113, 1115, 1119, 1121, 1124, 1126, 1127, 1128, 1130, 1132, 1133, 1134, 1136, 1138, 1139, 1141, 1142, 1143, 1145, 1147, 1149, 1150, 1152, 1154, 1155, 1157, 1162, 1163, 1166, 1167, 1169, 1172, 1173, 1174, 1177, 1179, 1180, 1181, 1184, 1185, 1187, 1191, 1195, 1199, 1200, 1201, 1202, 1204, 1205, 1207, 1209, 1211, 1212, 1214, 1215, 1217, 1222, 1224, 1225, 1227, 1229, 1232, 1233, 1235, 1237, 1238, 1239, 1241, 1243, 1244, 1246, 1247, 1248, 1250, 1252, 1253, 1254, 1255, 1256, 1260, 1264, 1266, 1267, 1268, 1270, 1271, 1272, 1277, 1278, 1282, 1283, 1285, 1288, 1290, 1291, 1293, 1295, 1297, 1299, 1300, 1301, 1302, 1304, 1307, 1311, 1314, 1319, 1320, 1322, 1323, 1324, 1325, 1327, 1328, 1330, 1332, 1334, 1335, 1336, 1338, 1340, 1342, 1344, 1348, 1351, 1354, 1355, 1356, 1358, 1359, 1360, 1362, 1363, 1365, 1366, 1367, 1368, 1369, 1371, 1374, 1376, 1378, 1380, 1381, 1382, 1384, 1386, 1387, 1390, 1392, 1393, 1394, 1395, 1397, 1398, 1400, 1403, 1404, 1405, 1406, 1409, 1410, 1411, 1413, 1415, 1416, 1417, 1418, 1421, 1425, 1427, 1431, 1432, 1434, 1435, 1438, 1440, 1442, 1443, 1445, 1446, 1448, 1450, 1451, 1452, 1455, 1456, 1458, 1460, 1462, 1463, 1466, 1468, 1470, 1472, 1473, 1475, 1477, 1481, 1483, 1484, 1486, 1488, 1489, 1490, 1493, 1494, 1495, 1497, 1500, 1502, 1503, 1505, 1506, 1509, 1510, 1511, 1512, 1513, 1515, 1516, 1518, 1519, 1521, 1525, 1527, 1528, 1529, 1530, 1531, 1533, 1534, 1535, 1537, 1539, 1541, 1542, 1543, 1544, 1546, 1547, 1551, 1552, 1554, 1555, 1558, 1560, 1561, 1562, 1563, 1566, 1567, 1569, 1572, 1574, 1576, 1578, 1579, 1581, 1583, 1584, 1588, 1590, 1591, 1592, 1593, 1595, 1597, 1600, 1603, 1607, 1611, 1612, 1615, 1617, 1620, 1621, 1622, 1624, 1625, 1627, 1629, 1630, 1633, 1635, 1637, 1638, 1639, 1640, 1642, 1643, 1646, 1647, 1651, 1653, 1655, 1657, 1658, 1659, 1662, 1663, 1665, 1667, 1670, 1673, 1674, 1677, 1678, 1679, 1681, 1684, 1688, 1690, 1691, 1692, 1693, 1694, 1698, 1699, 1701, 1702, 1704, 1707, 1710, 1712, 1714, 1717, 1718, 1719, 1722, 1724, 1727, 1730, 1731, 1733, 1734, 1735, 1737, 1738, 1741, 1745, 1747, 1748, 1750, 1752, 1753, 1756, 1758, 1761, 1762, 1766, 1767, 1770, 1772, 1775, 1776, 1777, 1781, 1785, 1787, 1788, 1790, 1795, 1799, 1801, 1802, 1804, 1805, 1808, 1813, 1814, 1815, 1819, 1820, 1821, 1823, 1825, 1827, 1829, 1830, 1832, 1835, 1837, 1838, 1842, 1845, 1846, 1848, 1850, 1853, 1854, 1856, 1858, 1859, 1860, 1862, 1865, 1866, 1867, 1868, 1870, 1876, 1877, 1878, 1879, 1881, 1882, 1885, 1887, 1888, 1889, 1891, 1893, 1895, 1896, 1898, 1899, 1901, 1902, 1906, 1908, 1910, 1912, 1915, 1917, 1918, 1919, 1922, 1923, 1924, 1927, 1928, 1931, 1932, 1934, 1938, 1940, 1942, 1944, 1945, 1946, 1948, 1952, 1954, 1957, 1958, 1960, 1962, 1963, 1966, 1969, 1971, 1973, 1974, 1975, 1976, 1978, 1980, 1982, 1983, 1985, 1986, 1988, 1994, 1995, 1996, 1997, 1998, 1999, 2000], deadline = 2)
        configuration.add_task(name="Task3", identifier=3, period=1.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=0.596676, acet=0.596676, et_stddev=0.19889199999999999, deadline= 2)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "65")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "65")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "65")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "65")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task5", identifier=5, period=6.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.030342, et_stddev=0.010114 , list_activation_dates=[17, 24, 34, 52, 66, 82, 89, 96, 108, 122, 139, 152, 163, 171, 177, 186, 194, 201, 209, 220, 228, 236, 243, 251, 270, 278, 291, 298, 305, 314, 329, 346, 355, 364, 380, 390, 398, 405, 421, 436, 442, 455, 471, 479, 491, 500, 508, 518, 528, 541, 561, 576, 584, 602, 619, 637, 647, 659, 682, 698, 706, 715, 744, 759, 767, 778, 788, 796, 810, 828, 847, 859, 865, 873, 883, 894, 905, 919, 940, 948, 959, 966, 975, 996, 1010, 1020, 1027, 1033, 1048, 1054, 1068, 1074, 1084, 1091, 1098, 1116, 1124, 1132, 1142, 1152, 1164, 1180, 1187, 1196, 1208, 1216, 1230, 1239, 1247, 1264, 1273, 1284, 1294, 1300, 1310, 1335, 1342, 1354, 1361, 1373, 1381, 1394, 1408, 1424, 1434, 1440, 1446, 1452, 1458, 1467, 1475, 1483, 1489, 1501, 1508, 1516, 1525, 1534, 1544, 1554, 1570, 1579, 1590, 1597, 1609, 1626, 1635, 1650, 1657, 1677, 1687, 1693, 1700, 1708, 1719, 1725, 1732, 1742, 1753, 1770, 1776, 1783, 1793, 1804, 1821, 1836, 1863, 1879, 1888, 1898, 1916, 1925, 1946, 1959, 1969, 1977, 1988], deadline = 7)
        configuration.add_task(name="Task6", identifier=6, period=16.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=4, acet=3.770488, et_stddev=1.2568293333333334 , list_activation_dates=[16, 61, 91, 119, 136, 172, 198, 225, 243, 285, 319, 343, 361, 382, 426, 461, 481, 512, 538, 562, 585, 602, 628, 659, 714, 736, 755, 782, 807, 838, 860, 883, 916, 942, 963, 1000, 1031, 1050, 1077, 1101, 1119, 1138, 1190, 1246, 1276, 1333, 1362, 1453, 1470, 1526, 1543, 1562, 1600, 1651, 1687, 1708, 1738, 1761, 1801, 1821, 1838, 1873, 1908, 1946, 1993], deadline = 24)
        configuration.add_task(name="Task2", identifier=2, period=3.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=0.84856, acet=0.84856, et_stddev=0.28285333333333335, deadline= 4)
        configuration.add_task(name="Task1", identifier=1, period=25.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=22.128118, acet=22.128118, et_stddev=7.376039333333334, deadline= 48)
        configuration.add_task(name="Task4", identifier=4, period=5.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.296436, et_stddev=0.098812 , list_activation_dates=[24, 36, 46, 57, 65, 92, 104, 117, 130, 151, 161, 167, 174, 184, 192, 203, 210, 216, 227, 238, 252, 260, 278, 296, 301, 313, 320, 329, 341, 349, 361, 375, 380, 392, 404, 421, 426, 441, 449, 468, 489, 495, 507, 512, 526, 531, 543, 548, 556, 563, 570, 578, 589, 605, 612, 625, 654, 667, 676, 685, 698, 703, 730, 737, 744, 751, 756, 763, 770, 776, 791, 799, 812, 819, 825, 834, 840, 846, 859, 878, 886, 906, 911, 916, 921, 929, 942, 956, 971, 979, 987, 993, 999, 1004, 1011, 1020, 1026, 1042, 1047, 1057, 1069, 1074, 1080, 1087, 1099, 1116, 1127, 1145, 1152, 1158, 1174, 1183, 1194, 1200, 1208, 1215, 1234, 1242, 1261, 1267, 1318, 1324, 1341, 1352, 1361, 1368, 1374, 1380, 1391, 1404, 1411, 1417, 1425, 1441, 1457, 1466, 1471, 1478, 1484, 1491, 1499, 1511, 1518, 1525, 1543, 1552, 1578, 1599, 1609, 1622, 1629, 1635, 1641, 1648, 1658, 1665, 1677, 1683, 1693, 1698, 1705, 1721, 1727, 1739, 1751, 1757, 1764, 1769, 1774, 1781, 1787, 1793, 1799, 1807, 1817, 1825, 1840, 1852, 1859, 1871, 1883, 1896, 1902, 1912, 1930, 1950, 1963, 1969, 1974, 1980, 1985, 1992], deadline = 2)
        configuration.add_task(name="Task3", identifier=3, period=1.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=0.432021, acet=0.432021, et_stddev=0.144007, deadline= 1)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "66")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "66")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "66")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "66")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task5", identifier=5, period=16.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=2, acet=1.091327, et_stddev=0.36377566666666666 , list_activation_dates=[3, 36, 53, 75, 102, 123, 167, 209, 231, 270, 287, 400, 436, 463, 496, 516, 551, 578, 609, 688, 705, 727, 743, 761, 783, 809, 829, 855, 897, 924, 945, 968, 986, 1024, 1044, 1060, 1079, 1096, 1116, 1177, 1214, 1255, 1288, 1333, 1357, 1374, 1404, 1433, 1451, 1481, 1508, 1527, 1576, 1605, 1629, 1679, 1703, 1739, 1764, 1802, 1836, 1855, 1876, 1917, 1938, 1984], deadline = 16)
        configuration.add_task(name="Task6", identifier=6, period=5.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.611059, et_stddev=0.20368633333333333 , list_activation_dates=[14, 30, 48, 57, 71, 76, 85, 92, 101, 108, 116, 128, 137, 144, 159, 165, 182, 189, 198, 208, 213, 232, 240, 248, 254, 261, 266, 273, 294, 299, 305, 313, 323, 340, 351, 369, 376, 381, 387, 394, 402, 411, 418, 425, 430, 445, 451, 462, 470, 476, 483, 496, 502, 508, 524, 541, 548, 557, 563, 570, 579, 595, 601, 606, 611, 619, 633, 640, 645, 652, 663, 674, 680, 691, 700, 712, 728, 736, 741, 753, 758, 765, 774, 782, 788, 796, 802, 810, 827, 838, 852, 860, 868, 876, 882, 900, 907, 918, 932, 940, 949, 961, 971, 979, 986, 996, 1002, 1008, 1014, 1031, 1047, 1052, 1059, 1065, 1071, 1083, 1093, 1105, 1113, 1123, 1129, 1144, 1155, 1163, 1180, 1196, 1206, 1224, 1236, 1257, 1264, 1273, 1281, 1296, 1311, 1323, 1330, 1337, 1345, 1352, 1367, 1381, 1386, 1393, 1399, 1405, 1411, 1420, 1429, 1437, 1443, 1465, 1470, 1479, 1485, 1499, 1510, 1519, 1553, 1559, 1564, 1579, 1598, 1609, 1620, 1630, 1640, 1647, 1653, 1658, 1665, 1672, 1679, 1720, 1726, 1732, 1737, 1742, 1752, 1759, 1785, 1790, 1802, 1814, 1819, 1829, 1835, 1841, 1849, 1860, 1868, 1873, 1884, 1891, 1902, 1907, 1913, 1925, 1932, 1940, 1950, 1957, 1966, 1972, 1981, 1999], deadline = 2)
        configuration.add_task(name="Task3", identifier=3, period=1.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=0.252375, acet=0.252375, et_stddev=0.084125, deadline= 1)
        configuration.add_task(name="Task4", identifier=4, period=2.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.21916, et_stddev=0.07305333333333333 , list_activation_dates=[1, 5, 8, 11, 15, 18, 22, 24, 27, 30, 35, 37, 39, 41, 44, 50, 53, 57, 62, 65, 73, 78, 81, 85, 87, 94, 97, 100, 103, 106, 111, 115, 118, 120, 122, 125, 129, 141, 145, 147, 152, 154, 157, 162, 170, 172, 175, 178, 181, 186, 192, 200, 204, 209, 214, 219, 225, 228, 234, 238, 240, 244, 247, 250, 254, 258, 261, 263, 266, 268, 270, 273, 278, 283, 287, 294, 298, 300, 307, 314, 318, 321, 324, 333, 335, 337, 341, 344, 347, 352, 355, 357, 361, 364, 371, 374, 377, 384, 390, 392, 396, 399, 402, 404, 411, 414, 416, 418, 420, 425, 432, 437, 440, 443, 449, 453, 456, 459, 462, 465, 467, 472, 474, 486, 489, 494, 503, 507, 511, 513, 517, 519, 523, 526, 528, 531, 534, 539, 543, 545, 557, 560, 563, 566, 570, 575, 579, 590, 595, 597, 604, 609, 613, 615, 619, 622, 628, 640, 642, 647, 651, 655, 658, 664, 668, 671, 673, 682, 684, 686, 688, 690, 693, 696, 701, 703, 705, 710, 713, 717, 721, 724, 727, 729, 731, 739, 744, 750, 752, 754, 757, 760, 764, 766, 768, 771, 774, 778, 781, 787, 795, 802, 805, 808, 814, 818, 820, 828, 832, 840, 845, 847, 849, 855, 862, 864, 866, 870, 875, 882, 888, 892, 895, 903, 906, 908, 912, 916, 920, 926, 931, 934, 938, 942, 947, 950, 955, 969, 972, 974, 979, 982, 987, 990, 993, 996, 999, 1002, 1007, 1011, 1015, 1026, 1028, 1031, 1034, 1037, 1040, 1047, 1050, 1056, 1058, 1061, 1066, 1069, 1075, 1078, 1081, 1083, 1086, 1091, 1094, 1097, 1100, 1103, 1106, 1111, 1114, 1119, 1125, 1130, 1135, 1139, 1144, 1146, 1152, 1154, 1157, 1164, 1169, 1176, 1179, 1181, 1183, 1186, 1191, 1195, 1198, 1201, 1204, 1207, 1209, 1212, 1214, 1217, 1221, 1224, 1226, 1228, 1236, 1241, 1244, 1247, 1252, 1256, 1260, 1270, 1272, 1275, 1281, 1283, 1287, 1289, 1292, 1294, 1297, 1299, 1301, 1305, 1308, 1312, 1316, 1322, 1326, 1332, 1337, 1342, 1348, 1355, 1357, 1359, 1362, 1364, 1372, 1378, 1380, 1385, 1388, 1392, 1397, 1400, 1402, 1404, 1409, 1411, 1414, 1421, 1425, 1427, 1431, 1433, 1435, 1441, 1445, 1447, 1449, 1453, 1455, 1462, 1468, 1472, 1474, 1478, 1487, 1493, 1496, 1498, 1500, 1503, 1506, 1511, 1516, 1518, 1521, 1524, 1530, 1532, 1535, 1538, 1541, 1544, 1548, 1564, 1567, 1573, 1576, 1578, 1580, 1582, 1584, 1589, 1591, 1595, 1597, 1600, 1603, 1610, 1619, 1621, 1626, 1634, 1638, 1642, 1647, 1651, 1653, 1656, 1660, 1662, 1666, 1671, 1676, 1679, 1682, 1684, 1689, 1692, 1696, 1698, 1703, 1706, 1708, 1712, 1716, 1720, 1722, 1725, 1728, 1731, 1733, 1738, 1743, 1751, 1755, 1758, 1760, 1762, 1768, 1771, 1774, 1786, 1790, 1793, 1797, 1803, 1808, 1810, 1812, 1815, 1817, 1819, 1822, 1824, 1826, 1828, 1833, 1836, 1839, 1843, 1848, 1851, 1857, 1861, 1869, 1871, 1873, 1880, 1883, 1886, 1888, 1890, 1894, 1896, 1898, 1903, 1907, 1911, 1917, 1922, 1930, 1933, 1937, 1939, 1946, 1951, 1953, 1957, 1959, 1962, 1971, 1973, 1978, 1980, 1983, 1988, 1994, 1996], deadline = 1)
        configuration.add_task(name="Task1", identifier=1, period=1.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=0.438366, acet=0.438366, et_stddev=0.146122, deadline= 1)
        configuration.add_task(name="Task2", identifier=2, period=14.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=12.729617, acet=12.729617, et_stddev=4.243205666666666, deadline= 24)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "67")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "67")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "67")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "67")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task6", identifier=6, period=2.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.046715, et_stddev=0.015571666666666666 , list_activation_dates=[3, 9, 11, 17, 20, 25, 28, 33, 39, 42, 47, 55, 58, 60, 62, 65, 69, 72, 75, 77, 81, 83, 87, 90, 93, 98, 101, 104, 111, 116, 120, 125, 127, 132, 135, 138, 143, 148, 152, 160, 163, 166, 169, 171, 174, 177, 183, 191, 196, 201, 206, 208, 213, 215, 217, 219, 223, 228, 231, 235, 240, 248, 254, 256, 262, 266, 269, 271, 275, 277, 288, 290, 294, 296, 298, 300, 303, 308, 312, 319, 322, 324, 330, 334, 336, 338, 342, 346, 349, 352, 355, 359, 361, 365, 368, 371, 375, 380, 382, 384, 386, 390, 393, 401, 405, 412, 414, 417, 421, 426, 431, 437, 440, 442, 444, 451, 454, 457, 460, 464, 469, 471, 473, 475, 477, 481, 484, 488, 491, 494, 497, 499, 505, 508, 511, 516, 522, 528, 532, 534, 537, 539, 541, 548, 554, 557, 565, 570, 573, 577, 579, 582, 585, 592, 595, 597, 599, 603, 606, 610, 614, 617, 621, 624, 628, 630, 643, 646, 649, 652, 654, 657, 660, 664, 667, 673, 680, 683, 687, 695, 697, 700, 702, 705, 708, 712, 716, 718, 720, 726, 729, 732, 738, 740, 745, 750, 753, 755, 758, 763, 767, 770, 774, 779, 782, 787, 791, 794, 798, 800, 804, 808, 811, 813, 819, 822, 825, 829, 834, 837, 841, 846, 848, 854, 856, 864, 867, 870, 874, 878, 881, 886, 891, 893, 897, 900, 903, 907, 910, 914, 920, 923, 927, 931, 936, 942, 947, 949, 951, 954, 956, 967, 974, 976, 979, 983, 986, 988, 993, 996, 1002, 1007, 1010, 1013, 1019, 1021, 1024, 1029, 1032, 1034, 1037, 1041, 1045, 1047, 1050, 1053, 1055, 1063, 1066, 1069, 1072, 1076, 1079, 1081, 1086, 1088, 1092, 1094, 1097, 1102, 1108, 1112, 1116, 1120, 1123, 1129, 1132, 1138, 1142, 1149, 1153, 1156, 1159, 1161, 1165, 1168, 1172, 1175, 1181, 1185, 1187, 1190, 1193, 1199, 1213, 1218, 1221, 1227, 1231, 1234, 1237, 1239, 1242, 1247, 1251, 1256, 1259, 1261, 1263, 1265, 1267, 1272, 1274, 1277, 1279, 1287, 1289, 1294, 1297, 1303, 1305, 1309, 1313, 1315, 1319, 1324, 1327, 1334, 1337, 1341, 1343, 1349, 1351, 1353, 1357, 1360, 1364, 1366, 1369, 1380, 1384, 1388, 1395, 1398, 1401, 1403, 1406, 1411, 1414, 1417, 1420, 1422, 1426, 1428, 1434, 1439, 1443, 1449, 1452, 1456, 1458, 1461, 1463, 1466, 1468, 1472, 1474, 1477, 1479, 1488, 1493, 1496, 1500, 1503, 1511, 1514, 1519, 1523, 1526, 1532, 1537, 1542, 1545, 1547, 1552, 1554, 1560, 1562, 1568, 1574, 1578, 1588, 1590, 1592, 1595, 1598, 1601, 1603, 1605, 1609, 1614, 1617, 1622, 1625, 1630, 1633, 1635, 1638, 1641, 1643, 1645, 1650, 1652, 1654, 1657, 1660, 1665, 1667, 1673, 1676, 1681, 1684, 1686, 1693, 1695, 1703, 1707, 1715, 1717, 1728, 1733, 1737, 1739, 1743, 1751, 1755, 1759, 1765, 1768, 1771, 1777, 1779, 1781, 1783, 1787, 1790, 1793, 1795, 1799, 1803, 1806, 1808, 1810, 1816, 1822, 1824, 1827, 1833, 1835, 1842, 1846, 1848, 1854, 1857, 1860, 1864, 1868, 1872, 1878, 1880, 1884, 1888, 1891, 1893, 1897, 1899, 1902, 1908, 1912, 1915, 1919, 1922, 1926, 1928, 1931, 1934, 1936, 1940, 1946, 1949, 1953, 1956, 1959, 1961, 1971, 1974, 1977, 1979, 1981, 1984, 1987, 1990, 1993], deadline = 3)
        configuration.add_task(name="Task4", identifier=4, period=10.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=2, acet=1.621577, et_stddev=0.5405256666666667 , list_activation_dates=[13, 29, 43, 65, 83, 93, 105, 121, 142, 161, 172, 184, 209, 224, 236, 251, 273, 284, 299, 327, 342, 353, 374, 392, 420, 437, 451, 482, 504, 517, 529, 539, 565, 603, 635, 648, 660, 674, 691, 710, 731, 743, 757, 775, 802, 821, 846, 860, 875, 890, 911, 923, 945, 956, 967, 979, 990, 1006, 1017, 1040, 1051, 1061, 1080, 1100, 1129, 1141, 1160, 1204, 1218, 1230, 1249, 1265, 1298, 1318, 1330, 1352, 1368, 1397, 1422, 1433, 1451, 1466, 1478, 1499, 1522, 1534, 1544, 1555, 1577, 1612, 1637, 1648, 1661, 1681, 1697, 1714, 1749, 1763, 1776, 1808, 1819, 1829, 1846, 1859, 1872, 1890, 1923, 1934, 1952, 1968, 1978, 2000], deadline = 18)
        configuration.add_task(name="Task3", identifier=3, period=4.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=1.342873, acet=1.342873, et_stddev=0.44762433333333335, deadline= 7)
        configuration.add_task(name="Task2", identifier=2, period=4.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=3.978784, acet=3.978784, et_stddev=1.3262613333333333, deadline= 5)
        configuration.add_task(name="Task5", identifier=5, period=6.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.686906, et_stddev=0.22896866666666668 , list_activation_dates=[3, 12, 20, 32, 42, 50, 68, 82, 107, 114, 120, 128, 138, 147, 163, 179, 185, 191, 200, 207, 215, 225, 235, 245, 252, 265, 273, 281, 301, 316, 323, 341, 354, 371, 383, 392, 412, 419, 432, 449, 458, 466, 496, 502, 512, 536, 543, 557, 588, 610, 621, 634, 643, 655, 665, 677, 702, 723, 738, 747, 772, 783, 790, 797, 803, 824, 830, 838, 853, 866, 874, 885, 905, 917, 927, 936, 944, 955, 967, 975, 994, 1002, 1016, 1027, 1034, 1043, 1051, 1068, 1078, 1085, 1109, 1126, 1141, 1160, 1167, 1173, 1190, 1208, 1226, 1241, 1256, 1265, 1273, 1304, 1311, 1317, 1330, 1337, 1343, 1352, 1372, 1378, 1386, 1408, 1416, 1424, 1433, 1441, 1448, 1458, 1468, 1490, 1528, 1537, 1548, 1557, 1568, 1577, 1584, 1591, 1612, 1625, 1639, 1649, 1665, 1682, 1690, 1697, 1705, 1713, 1724, 1746, 1765, 1773, 1781, 1796, 1806, 1817, 1841, 1866, 1873, 1888, 1901, 1910, 1919, 1926, 1945, 1952, 1958, 1965, 1976, 1985, 1992, 1998], deadline = 5)
        configuration.add_task(name="Task1", identifier=1, period=3.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=0.808756, acet=0.808756, et_stddev=0.26958533333333334, deadline= 4)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "68")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "68")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "68")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "68")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task1", identifier=1, period=1.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=0.886274, acet=0.886274, et_stddev=0.29542466666666667, deadline= 2)
        configuration.add_task(name="Task5", identifier=5, period=6.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=2, acet=1.176744, et_stddev=0.392248 , list_activation_dates=[9, 16, 24, 31, 50, 60, 69, 85, 97, 123, 132, 145, 155, 168, 175, 184, 193, 201, 208, 217, 250, 258, 267, 276, 296, 305, 338, 345, 351, 359, 365, 378, 396, 406, 429, 438, 444, 455, 461, 467, 479, 486, 504, 530, 538, 558, 573, 584, 599, 606, 618, 631, 639, 646, 655, 669, 686, 695, 707, 719, 736, 748, 755, 767, 777, 789, 795, 802, 817, 825, 837, 869, 887, 899, 909, 917, 928, 935, 954, 1002, 1012, 1019, 1033, 1062, 1084, 1093, 1101, 1114, 1124, 1136, 1160, 1167, 1176, 1186, 1199, 1205, 1212, 1232, 1239, 1246, 1256, 1262, 1271, 1277, 1291, 1344, 1356, 1366, 1387, 1397, 1411, 1425, 1432, 1440, 1448, 1465, 1488, 1500, 1509, 1530, 1538, 1547, 1553, 1561, 1568, 1576, 1584, 1591, 1598, 1607, 1616, 1624, 1630, 1637, 1644, 1653, 1668, 1679, 1706, 1725, 1732, 1740, 1752, 1762, 1770, 1780, 1791, 1801, 1817, 1846, 1873, 1886, 1897, 1906, 1920, 1930, 1944, 1951, 1966, 1977, 1995], deadline = 3)
        configuration.add_task(name="Task2", identifier=2, period=6.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=4.219004, acet=4.219004, et_stddev=1.4063346666666667, deadline= 11)
        configuration.add_task(name="Task6", identifier=6, period=6.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.186705, et_stddev=0.062235000000000006 , list_activation_dates=[15, 22, 36, 52, 62, 70, 79, 111, 124, 133, 141, 157, 165, 181, 189, 196, 205, 212, 227, 243, 251, 263, 275, 302, 313, 340, 349, 356, 368, 383, 394, 414, 430, 437, 452, 459, 489, 496, 507, 514, 520, 530, 545, 563, 577, 584, 608, 616, 624, 631, 649, 655, 663, 671, 681, 693, 700, 708, 720, 742, 749, 759, 772, 784, 791, 800, 815, 831, 839, 848, 854, 870, 880, 887, 920, 927, 938, 949, 956, 963, 969, 981, 989, 1000, 1019, 1026, 1035, 1042, 1062, 1093, 1108, 1117, 1123, 1143, 1153, 1160, 1182, 1189, 1196, 1204, 1217, 1225, 1238, 1255, 1268, 1276, 1307, 1314, 1322, 1328, 1337, 1352, 1360, 1367, 1374, 1381, 1389, 1396, 1408, 1427, 1434, 1443, 1450, 1456, 1463, 1469, 1478, 1493, 1506, 1518, 1544, 1553, 1559, 1571, 1578, 1586, 1599, 1608, 1616, 1626, 1637, 1661, 1673, 1681, 1706, 1714, 1724, 1741, 1754, 1774, 1786, 1803, 1814, 1829, 1837, 1843, 1866, 1886, 1897, 1905, 1918, 1927, 1942, 1953, 1964, 1975, 1991, 1998], deadline = 12)
        configuration.add_task(name="Task3", identifier=3, period=8.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=0.084465, acet=0.084465, et_stddev=0.028155, deadline= 16)
        configuration.add_task(name="Task4", identifier=4, period=11.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.80034, et_stddev=0.26678 , list_activation_dates=[2, 24, 47, 92, 114, 127, 144, 166, 179, 197, 233, 250, 261, 294, 319, 332, 354, 373, 394, 408, 432, 489, 501, 528, 542, 559, 574, 596, 626, 645, 658, 693, 708, 732, 768, 794, 816, 864, 887, 900, 928, 939, 968, 996, 1009, 1028, 1084, 1109, 1126, 1155, 1174, 1190, 1203, 1216, 1231, 1243, 1266, 1304, 1332, 1351, 1363, 1376, 1396, 1410, 1435, 1452, 1466, 1480, 1504, 1517, 1563, 1575, 1594, 1608, 1619, 1645, 1661, 1685, 1698, 1715, 1767, 1778, 1807, 1843, 1859, 1871, 1902, 1920, 1954, 1985, 1997], deadline = 6)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "69")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "69")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "69")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "69")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task5", identifier=5, period=45.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=2, acet=1.108075, et_stddev=0.3693583333333333 , list_activation_dates=[26, 130, 207, 253, 305, 364, 413, 477, 533, 592, 668, 719, 870, 932, 980, 1105, 1178, 1256, 1435, 1510, 1562, 1642, 1689, 1737, 1802, 1870, 1960], deadline = 76)
        configuration.add_task(name="Task3", identifier=3, period=39.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=32.281083, acet=32.281083, et_stddev=10.760361000000001, deadline= 66)
        configuration.add_task(name="Task1", identifier=1, period=28.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=0.006829, acet=0.006829, et_stddev=0.0022763333333333333, deadline= 50)
        configuration.add_task(name="Task2", identifier=2, period=2.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=1.544071, acet=1.544071, et_stddev=0.5146903333333334, deadline= 4)
        configuration.add_task(name="Task4", identifier=4, period=9.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=3, acet=2.019198, et_stddev=0.6730659999999999 , list_activation_dates=[1, 17, 31, 42, 57, 75, 96, 105, 117, 136, 150, 161, 174, 192, 211, 235, 256, 279, 293, 317, 336, 348, 365, 378, 391, 402, 421, 433, 466, 483, 503, 518, 537, 550, 586, 602, 614, 629, 640, 665, 678, 693, 704, 714, 725, 742, 752, 775, 790, 802, 812, 829, 841, 861, 884, 912, 938, 947, 982, 1015, 1028, 1046, 1083, 1109, 1121, 1162, 1187, 1202, 1213, 1238, 1255, 1277, 1300, 1312, 1331, 1345, 1361, 1386, 1396, 1408, 1425, 1450, 1482, 1497, 1513, 1563, 1587, 1598, 1622, 1633, 1642, 1665, 1686, 1716, 1732, 1751, 1763, 1774, 1800, 1813, 1829, 1864, 1879, 1889, 1928, 1938, 1947, 1960, 1979], deadline = 18)
        configuration.add_task(name="Task6", identifier=6, period=1.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.05102, et_stddev=0.017006666666666666 , list_activation_dates=[2, 4, 5, 7, 9, 12, 13, 15, 18, 19, 20, 22, 25, 26, 30, 32, 33, 38, 39, 41, 43, 44, 45, 47, 48, 55, 56, 58, 59, 62, 64, 66, 67, 69, 71, 73, 77, 78, 80, 82, 83, 85, 86, 88, 91, 92, 94, 96, 100, 101, 102, 105, 107, 111, 114, 117, 119, 120, 122, 124, 125, 127, 128, 129, 131, 133, 134, 136, 138, 141, 143, 145, 146, 147, 150, 152, 153, 158, 159, 160, 161, 162, 164, 165, 167, 168, 169, 172, 174, 178, 180, 183, 185, 186, 189, 191, 193, 194, 195, 197, 198, 199, 200, 202, 203, 204, 205, 207, 209, 210, 212, 213, 214, 217, 218, 220, 222, 226, 230, 231, 233, 234, 236, 239, 240, 242, 243, 246, 248, 249, 250, 252, 254, 255, 257, 259, 260, 264, 266, 267, 268, 270, 272, 273, 275, 277, 278, 282, 283, 285, 288, 289, 290, 293, 295, 298, 299, 301, 302, 304, 306, 308, 309, 313, 314, 315, 318, 321, 322, 327, 331, 332, 333, 334, 337, 339, 340, 343, 345, 346, 348, 349, 350, 351, 353, 356, 359, 363, 368, 371, 374, 375, 377, 379, 382, 387, 389, 390, 391, 393, 395, 398, 400, 402, 404, 406, 410, 413, 414, 416, 418, 419, 420, 423, 424, 426, 430, 431, 433, 436, 438, 439, 442, 445, 446, 447, 449, 450, 453, 454, 455, 456, 458, 460, 465, 466, 467, 469, 471, 472, 474, 478, 481, 482, 483, 485, 487, 490, 491, 492, 494, 495, 497, 498, 500, 503, 505, 507, 511, 512, 516, 518, 520, 522, 526, 528, 531, 533, 534, 535, 538, 540, 541, 542, 544, 546, 548, 551, 553, 557, 559, 562, 563, 566, 568, 570, 571, 574, 575, 576, 579, 581, 582, 584, 585, 588, 589, 590, 594, 596, 597, 599, 600, 603, 605, 606, 610, 612, 613, 616, 618, 620, 626, 628, 631, 632, 633, 635, 638, 641, 642, 646, 648, 649, 650, 652, 653, 655, 657, 658, 660, 661, 662, 664, 665, 669, 670, 672, 674, 675, 677, 679, 680, 682, 683, 684, 686, 690, 691, 694, 696, 699, 700, 701, 703, 704, 706, 707, 709, 712, 713, 715, 717, 719, 720, 723, 725, 727, 730, 732, 734, 737, 739, 742, 744, 747, 749, 750, 751, 753, 757, 758, 761, 762, 764, 767, 769, 770, 772, 774, 776, 779, 780, 782, 783, 785, 787, 790, 792, 793, 794, 797, 799, 801, 803, 804, 806, 807, 808, 810, 812, 816, 817, 820, 822, 824, 826, 827, 829, 830, 831, 832, 833, 837, 840, 843, 845, 851, 852, 854, 856, 858, 860, 863, 865, 866, 867, 868, 869, 873, 875, 877, 878, 879, 881, 888, 890, 894, 895, 899, 902, 904, 906, 909, 910, 911, 913, 914, 916, 917, 919, 925, 928, 931, 932, 937, 938, 939, 940, 943, 946, 947, 948, 951, 953, 954, 958, 959, 963, 965, 967, 969, 970, 973, 975, 977, 978, 979, 981, 983, 984, 985, 988, 991, 993, 997, 998, 1000, 1001, 1004, 1006, 1008, 1009, 1011, 1014, 1015, 1017, 1021, 1022, 1023, 1028, 1029, 1031, 1035, 1038, 1040, 1043, 1045, 1046, 1049, 1052, 1053, 1056, 1058, 1059, 1060, 1062, 1064, 1066, 1067, 1069, 1070, 1071, 1072, 1078, 1081, 1083, 1085, 1087, 1089, 1091, 1093, 1096, 1097, 1099, 1100, 1103, 1104, 1105, 1107, 1112, 1115, 1117, 1121, 1122, 1124, 1125, 1127, 1134, 1135, 1136, 1137, 1138, 1140, 1141, 1142, 1145, 1146, 1147, 1149, 1153, 1155, 1157, 1159, 1161, 1163, 1165, 1167, 1168, 1170, 1172, 1173, 1175, 1180, 1181, 1182, 1183, 1185, 1186, 1188, 1189, 1196, 1197, 1199, 1201, 1202, 1206, 1208, 1210, 1212, 1213, 1216, 1219, 1221, 1225, 1226, 1228, 1231, 1233, 1235, 1239, 1240, 1241, 1243, 1245, 1247, 1249, 1250, 1252, 1253, 1256, 1258, 1260, 1263, 1266, 1268, 1270, 1272, 1274, 1275, 1277, 1281, 1283, 1286, 1288, 1290, 1293, 1295, 1296, 1299, 1300, 1301, 1303, 1305, 1307, 1309, 1311, 1314, 1315, 1316, 1318, 1322, 1324, 1326, 1328, 1330, 1332, 1334, 1335, 1342, 1345, 1346, 1348, 1350, 1351, 1352, 1353, 1355, 1358, 1359, 1361, 1362, 1363, 1367, 1369, 1370, 1373, 1374, 1378, 1379, 1381, 1382, 1384, 1386, 1389, 1391, 1393, 1395, 1396, 1397, 1399, 1400, 1401, 1403, 1404, 1405, 1406, 1407, 1409, 1412, 1413, 1414, 1417, 1418, 1420, 1422, 1423, 1425, 1428, 1430, 1431, 1432, 1434, 1436, 1438, 1441, 1443, 1444, 1445, 1447, 1450, 1452, 1454, 1456, 1458, 1460, 1465, 1467, 1468, 1469, 1471, 1474, 1477, 1478, 1480, 1481, 1482, 1485, 1487, 1489, 1490, 1494, 1495, 1496, 1498, 1499, 1500, 1502, 1504, 1506, 1508, 1511, 1514, 1516, 1519, 1521, 1522, 1526, 1531, 1532, 1534, 1536, 1538, 1540, 1542, 1543, 1545, 1547, 1549, 1552, 1554, 1555, 1558, 1559, 1560, 1563, 1564, 1565, 1567, 1568, 1570, 1571, 1572, 1575, 1577, 1580, 1581, 1583, 1587, 1588, 1593, 1596, 1599, 1603, 1605, 1607, 1610, 1612, 1614, 1616, 1618, 1620, 1621, 1622, 1625, 1627, 1629, 1630, 1632, 1635, 1636, 1640, 1642, 1643, 1646, 1648, 1649, 1651, 1653, 1656, 1657, 1659, 1661, 1664, 1665, 1666, 1667, 1668, 1670, 1678, 1679, 1680, 1681, 1682, 1683, 1685, 1687, 1689, 1690, 1692, 1694, 1696, 1702, 1704, 1706, 1707, 1711, 1712, 1715, 1716, 1718, 1720, 1722, 1724, 1727, 1729, 1730, 1732, 1733, 1734, 1736, 1737, 1739, 1740, 1743, 1745, 1746, 1747, 1750, 1751, 1752, 1754, 1755, 1757, 1759, 1762, 1763, 1765, 1766, 1769, 1770, 1772, 1773, 1775, 1777, 1780, 1781, 1782, 1783, 1785, 1787, 1789, 1791, 1794, 1796, 1797, 1799, 1802, 1808, 1810, 1812, 1813, 1814, 1815, 1818, 1819, 1821, 1822, 1823, 1826, 1827, 1830, 1832, 1835, 1836, 1837, 1838, 1840, 1841, 1846, 1848, 1852, 1853, 1855, 1856, 1858, 1859, 1862, 1864, 1866, 1867, 1869, 1870, 1871, 1873, 1878, 1882, 1884, 1885, 1888, 1889, 1892, 1893, 1895, 1897, 1899, 1900, 1901, 1903, 1905, 1908, 1909, 1911, 1912, 1915, 1917, 1918, 1920, 1924, 1925, 1927, 1929, 1930, 1933, 1936, 1938, 1940, 1941, 1943, 1945, 1947, 1948, 1952, 1954, 1956, 1960, 1962, 1963, 1965, 1966, 1971, 1973, 1976, 1978, 1981, 1982, 1984, 1985, 1987, 1988, 1990, 1993, 1994, 1995, 1997, 1999], deadline = 2)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "71")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "71")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "71")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "71")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)