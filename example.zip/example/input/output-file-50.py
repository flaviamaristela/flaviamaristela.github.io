

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task2", identifier=2, period=40.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=9.245565, acet=9.245565, et_stddev=3.0818549999999996, deadline= 57)
        configuration.add_task(name="Task6", identifier=6, period=32.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.691762, et_stddev=0.23058733333333334 , list_activation_dates=[77, 130, 223, 295, 403, 468, 550, 597, 639, 694, 741, 806, 844, 877, 912, 974, 1026, 1188, 1328, 1383, 1428, 1476, 1510, 1553, 1642, 1680, 1732, 1818, 1853, 1894, 1953, 1989], deadline = 33)
        configuration.add_task(name="Task5", identifier=5, period=6.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.604072, et_stddev=0.20135733333333336 , list_activation_dates=[11, 28, 40, 47, 58, 67, 83, 100, 107, 139, 154, 168, 175, 190, 196, 209, 219, 231, 240, 254, 291, 301, 309, 316, 323, 339, 350, 361, 370, 377, 389, 397, 406, 416, 424, 436, 449, 460, 496, 504, 511, 524, 531, 546, 553, 570, 577, 591, 602, 615, 622, 643, 654, 663, 669, 683, 701, 713, 720, 736, 749, 760, 767, 784, 792, 798, 805, 821, 839, 853, 862, 882, 902, 911, 925, 942, 961, 975, 985, 1015, 1024, 1033, 1045, 1060, 1081, 1088, 1098, 1105, 1114, 1123, 1133, 1139, 1149, 1162, 1169, 1178, 1185, 1193, 1205, 1214, 1222, 1241, 1250, 1281, 1292, 1314, 1322, 1330, 1337, 1365, 1372, 1378, 1386, 1395, 1406, 1418, 1431, 1448, 1460, 1480, 1490, 1499, 1534, 1546, 1560, 1569, 1577, 1590, 1596, 1616, 1626, 1637, 1645, 1670, 1679, 1685, 1693, 1701, 1733, 1745, 1756, 1769, 1776, 1783, 1795, 1809, 1829, 1844, 1857, 1866, 1895, 1906, 1914, 1948, 1959, 1967, 1976, 1983, 1993], deadline = 5)
        configuration.add_task(name="Task4", identifier=4, period=21.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=2, acet=1.631776, et_stddev=0.5439253333333333 , list_activation_dates=[22, 61, 96, 127, 157, 214, 273, 347, 369, 395, 428, 456, 510, 536, 566, 640, 667, 748, 827, 862, 885, 915, 951, 975, 1000, 1021, 1083, 1112, 1147, 1168, 1224, 1306, 1332, 1368, 1424, 1458, 1508, 1549, 1608, 1633, 1656, 1686, 1759, 1817, 1856, 1896, 1935, 1960, 1984], deadline = 5)
        configuration.add_task(name="Task1", identifier=1, period=2.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=1.321279, acet=1.321279, et_stddev=0.44042633333333336, deadline= 3)
        configuration.add_task(name="Task3", identifier=3, period=2.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=1.416442, acet=1.416442, et_stddev=0.4721473333333333, deadline= 3)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "1")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "1")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "1")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "1")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task4", identifier=4, period=21.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.472353, et_stddev=0.157451 , list_activation_dates=[5, 36, 61, 96, 119, 140, 163, 190, 224, 268, 344, 368, 404, 430, 478, 510, 552, 578, 677, 719, 748, 772, 795, 823, 852, 877, 923, 961, 983, 1021, 1044, 1086, 1118, 1147, 1169, 1203, 1254, 1292, 1332, 1377, 1422, 1469, 1563, 1596, 1627, 1685, 1733, 1770, 1793, 1843, 1897, 1941, 1966], deadline = 9)
        configuration.add_task(name="Task1", identifier=1, period=2.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=0.495367, acet=0.495367, et_stddev=0.16512233333333334, deadline= 3)
        configuration.add_task(name="Task3", identifier=3, period=3.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=1.375762, acet=1.375762, et_stddev=0.4585873333333333, deadline= 5)
        configuration.add_task(name="Task6", identifier=6, period=4.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.243484, et_stddev=0.08116133333333334 , list_activation_dates=[3, 11, 19, 24, 33, 44, 49, 59, 63, 69, 75, 81, 85, 100, 108, 116, 121, 126, 132, 145, 152, 166, 175, 179, 183, 193, 201, 209, 216, 234, 242, 259, 264, 269, 274, 281, 305, 314, 341, 346, 351, 357, 362, 370, 376, 380, 387, 399, 404, 408, 414, 420, 429, 435, 446, 454, 463, 470, 479, 484, 488, 492, 497, 506, 516, 522, 535, 549, 554, 569, 578, 584, 588, 596, 602, 608, 613, 621, 625, 640, 644, 651, 657, 663, 671, 678, 687, 705, 722, 726, 732, 740, 745, 750, 767, 772, 780, 789, 795, 809, 814, 819, 826, 832, 838, 842, 850, 855, 864, 873, 884, 899, 905, 910, 915, 920, 925, 931, 936, 943, 953, 961, 975, 980, 987, 993, 997, 1011, 1017, 1022, 1028, 1034, 1042, 1054, 1059, 1064, 1072, 1080, 1085, 1089, 1095, 1120, 1136, 1141, 1150, 1156, 1160, 1165, 1169, 1184, 1193, 1219, 1223, 1236, 1243, 1254, 1265, 1272, 1280, 1289, 1293, 1297, 1302, 1314, 1322, 1331, 1339, 1348, 1353, 1358, 1372, 1376, 1381, 1392, 1399, 1410, 1418, 1431, 1438, 1445, 1450, 1455, 1476, 1484, 1495, 1503, 1518, 1523, 1531, 1540, 1547, 1558, 1570, 1574, 1582, 1587, 1592, 1599, 1606, 1610, 1618, 1622, 1646, 1654, 1668, 1675, 1681, 1688, 1695, 1701, 1718, 1737, 1744, 1752, 1760, 1765, 1775, 1779, 1796, 1804, 1810, 1818, 1824, 1834, 1840, 1864, 1875, 1884, 1889, 1894, 1900, 1913, 1917, 1922, 1927, 1942, 1953, 1960, 1965, 1979, 1985, 1992], deadline = 2)
        configuration.add_task(name="Task5", identifier=5, period=17.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=2, acet=1.982809, et_stddev=0.6609363333333333 , list_activation_dates=[8, 40, 102, 122, 145, 164, 190, 207, 227, 249, 286, 339, 362, 415, 438, 463, 526, 569, 624, 688, 726, 773, 797, 817, 841, 867, 910, 930, 968, 989, 1010, 1044, 1073, 1097, 1147, 1242, 1265, 1327, 1345, 1363, 1393, 1460, 1485, 1519, 1542, 1561, 1585, 1675, 1763, 1798, 1898, 1922, 1959, 1977], deadline = 21)
        configuration.add_task(name="Task2", identifier=2, period=10.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=8.937284, acet=8.937284, et_stddev=2.9790946666666667, deadline= 9)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "2")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "2")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "2")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "2")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task3", identifier=3, period=6.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=1.315307, acet=1.315307, et_stddev=0.43843566666666667, deadline= 11)
        configuration.add_task(name="Task5", identifier=5, period=24.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=5, acet=4.372426, et_stddev=1.4574753333333332 , list_activation_dates=[5, 34, 79, 108, 187, 228, 256, 312, 369, 405, 435, 485, 509, 544, 580, 608, 636, 708, 738, 818, 860, 908, 961, 993, 1030, 1069, 1118, 1143, 1169, 1194, 1221, 1259, 1307, 1362, 1397, 1458, 1531, 1556, 1602, 1636, 1668, 1728, 1765, 1792, 1825, 1863, 1891, 1923, 1958], deadline = 28)
        configuration.add_task(name="Task1", identifier=1, period=2.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=1.637228, acet=1.637228, et_stddev=0.5457426666666666, deadline= 2)
        configuration.add_task(name="Task2", identifier=2, period=14.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=7.870353, acet=7.870353, et_stddev=2.6234509999999998, deadline= 10)
        configuration.add_task(name="Task4", identifier=4, period=12.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.078479, et_stddev=0.026159666666666664 , list_activation_dates=[2, 15, 32, 62, 88, 112, 125, 173, 203, 290, 302, 344, 360, 384, 405, 450, 463, 476, 507, 523, 535, 551, 563, 580, 601, 625, 640, 657, 677, 714, 731, 751, 772, 794, 858, 873, 890, 915, 938, 964, 981, 994, 1012, 1032, 1107, 1133, 1157, 1170, 1191, 1206, 1231, 1296, 1324, 1358, 1380, 1406, 1419, 1445, 1462, 1479, 1495, 1511, 1550, 1577, 1596, 1612, 1627, 1641, 1656, 1693, 1707, 1728, 1746, 1779, 1800, 1818, 1842, 1863, 1909, 1936, 1954, 1970, 1983], deadline = 22)
        configuration.add_task(name="Task6", identifier=6, period=5.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.056377, et_stddev=0.01879233333333333 , list_activation_dates=[2, 11, 17, 31, 38, 51, 67, 86, 94, 99, 111, 121, 128, 135, 142, 172, 178, 184, 194, 200, 210, 216, 222, 265, 275, 284, 292, 299, 308, 314, 321, 327, 332, 338, 351, 364, 376, 384, 395, 407, 420, 428, 437, 449, 455, 469, 474, 488, 498, 504, 518, 530, 537, 543, 549, 556, 566, 587, 608, 614, 629, 638, 645, 666, 679, 685, 691, 698, 709, 714, 732, 739, 746, 759, 764, 780, 791, 800, 821, 826, 843, 849, 882, 890, 900, 915, 922, 928, 952, 958, 965, 971, 980, 994, 1001, 1006, 1018, 1024, 1030, 1036, 1048, 1053, 1061, 1067, 1079, 1095, 1102, 1109, 1118, 1124, 1129, 1143, 1150, 1157, 1162, 1177, 1193, 1205, 1210, 1220, 1229, 1241, 1248, 1258, 1265, 1275, 1281, 1287, 1293, 1301, 1313, 1319, 1330, 1336, 1349, 1362, 1369, 1378, 1385, 1390, 1408, 1419, 1431, 1441, 1450, 1457, 1467, 1481, 1488, 1493, 1498, 1508, 1513, 1519, 1528, 1547, 1554, 1560, 1571, 1576, 1581, 1588, 1594, 1605, 1617, 1624, 1633, 1644, 1649, 1657, 1663, 1669, 1690, 1695, 1707, 1713, 1721, 1726, 1733, 1744, 1756, 1763, 1777, 1784, 1801, 1812, 1820, 1832, 1837, 1842, 1848, 1853, 1860, 1866, 1874, 1880, 1888, 1915, 1924, 1930, 1941, 1946, 1953, 1969, 1975, 1983, 2000], deadline = 5)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "3")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "3")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "3")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "3")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task5", identifier=5, period=27.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.382222, et_stddev=0.12740733333333334 , list_activation_dates=[45, 106, 136, 166, 218, 251, 295, 358, 391, 472, 520, 555, 608, 637, 685, 761, 885, 922, 973, 1002, 1030, 1079, 1198, 1265, 1293, 1320, 1367, 1417, 1508, 1573, 1625, 1755, 1819, 1859, 1952, 1979], deadline = 17)
        configuration.add_task(name="Task2", identifier=2, period=2.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=1.852809, acet=1.852809, et_stddev=0.617603, deadline= 2)
        configuration.add_task(name="Task4", identifier=4, period=25.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=2, acet=1.196481, et_stddev=0.398827 , list_activation_dates=[18, 101, 128, 189, 219, 296, 323, 420, 472, 498, 548, 579, 635, 676, 703, 738, 803, 864, 902, 977, 1005, 1065, 1156, 1262, 1291, 1328, 1389, 1439, 1469, 1535, 1602, 1633, 1659, 1690, 1782, 1807, 1847, 1923, 1957], deadline = 19)
        configuration.add_task(name="Task3", identifier=3, period=48.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=9.98285, acet=9.98285, et_stddev=3.3276166666666662, deadline= 54)
        configuration.add_task(name="Task6", identifier=6, period=46.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=7, acet=6.347279, et_stddev=2.115759666666667 , list_activation_dates=[83, 183, 371, 452, 499, 550, 654, 793, 856, 902, 987, 1046, 1209, 1287, 1362, 1470, 1527, 1585, 1728, 1781, 1863, 1991], deadline = 33)
        configuration.add_task(name="Task1", identifier=1, period=36.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=16.762287, acet=16.762287, et_stddev=5.587429, deadline= 29)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "5")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "5")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "5")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "5")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task1", identifier=1, period=24.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=10.912888, acet=10.912888, et_stddev=3.6376293333333334, deadline= 15)
        configuration.add_task(name="Task2", identifier=2, period=1.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=0.808653, acet=0.808653, et_stddev=0.269551, deadline= 2)
        configuration.add_task(name="Task4", identifier=4, period=2.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.101228, et_stddev=0.033742666666666664 , list_activation_dates=[4, 11, 17, 20, 23, 26, 30, 36, 41, 45, 50, 52, 54, 56, 58, 61, 64, 67, 72, 77, 80, 84, 87, 89, 92, 101, 110, 112, 115, 124, 127, 129, 131, 133, 136, 139, 142, 149, 152, 156, 159, 161, 164, 170, 175, 177, 180, 182, 187, 190, 193, 197, 202, 206, 208, 210, 218, 221, 224, 227, 230, 232, 236, 242, 247, 253, 258, 260, 267, 275, 280, 282, 285, 290, 293, 295, 297, 299, 301, 305, 311, 315, 319, 329, 334, 337, 340, 342, 344, 346, 350, 352, 355, 360, 362, 364, 367, 369, 374, 377, 380, 383, 386, 390, 394, 396, 398, 401, 404, 409, 412, 416, 426, 429, 434, 437, 440, 442, 445, 448, 452, 460, 466, 469, 472, 479, 483, 487, 493, 496, 500, 503, 506, 511, 515, 519, 522, 524, 529, 535, 537, 539, 541, 545, 550, 553, 557, 559, 563, 565, 568, 572, 576, 579, 582, 585, 591, 594, 600, 602, 606, 612, 615, 618, 621, 623, 629, 631, 637, 646, 651, 654, 657, 660, 664, 667, 672, 676, 679, 683, 685, 688, 691, 693, 696, 698, 701, 706, 710, 714, 717, 725, 727, 730, 734, 737, 739, 744, 748, 752, 754, 756, 761, 765, 768, 774, 780, 783, 785, 787, 790, 793, 796, 799, 803, 806, 808, 810, 815, 822, 824, 827, 833, 835, 837, 842, 845, 850, 853, 857, 861, 866, 868, 870, 873, 877, 881, 885, 888, 890, 892, 895, 898, 901, 907, 910, 915, 917, 924, 928, 932, 935, 937, 940, 943, 945, 951, 957, 959, 961, 964, 969, 973, 978, 981, 986, 988, 991, 998, 1005, 1009, 1011, 1016, 1019, 1022, 1026, 1030, 1032, 1035, 1039, 1041, 1049, 1054, 1059, 1076, 1079, 1092, 1096, 1098, 1102, 1108, 1110, 1112, 1117, 1119, 1128, 1131, 1136, 1140, 1143, 1146, 1149, 1152, 1155, 1158, 1160, 1164, 1166, 1168, 1171, 1176, 1180, 1185, 1188, 1191, 1194, 1197, 1203, 1205, 1214, 1217, 1221, 1224, 1226, 1233, 1236, 1241, 1246, 1252, 1254, 1259, 1262, 1267, 1270, 1285, 1289, 1292, 1295, 1302, 1306, 1311, 1316, 1322, 1326, 1329, 1334, 1338, 1343, 1348, 1351, 1354, 1357, 1363, 1366, 1368, 1371, 1376, 1382, 1386, 1388, 1391, 1397, 1400, 1405, 1407, 1409, 1411, 1417, 1420, 1423, 1428, 1431, 1435, 1437, 1440, 1443, 1448, 1451, 1453, 1460, 1464, 1467, 1474, 1478, 1481, 1485, 1488, 1490, 1494, 1499, 1501, 1504, 1512, 1515, 1522, 1531, 1535, 1545, 1548, 1550, 1556, 1558, 1561, 1565, 1570, 1574, 1580, 1582, 1584, 1586, 1591, 1596, 1601, 1605, 1609, 1619, 1621, 1625, 1633, 1637, 1645, 1649, 1653, 1658, 1670, 1673, 1675, 1678, 1680, 1682, 1685, 1688, 1694, 1705, 1708, 1710, 1713, 1715, 1720, 1730, 1735, 1738, 1742, 1747, 1760, 1763, 1766, 1769, 1773, 1775, 1777, 1782, 1785, 1788, 1795, 1797, 1801, 1810, 1814, 1816, 1823, 1826, 1829, 1834, 1841, 1844, 1848, 1852, 1856, 1860, 1863, 1865, 1869, 1874, 1878, 1882, 1890, 1892, 1907, 1909, 1916, 1919, 1922, 1925, 1931, 1934, 1937, 1941, 1943, 1945, 1947, 1958, 1963, 1965, 1969, 1971, 1974, 1979, 1981, 1986, 1989, 1993, 1997, 2000], deadline = 4)
        configuration.add_task(name="Task6", identifier=6, period=17.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.073439, et_stddev=0.024479666666666667 , list_activation_dates=[1, 23, 52, 80, 130, 157, 174, 208, 236, 260, 283, 329, 363, 383, 406, 440, 482, 520, 558, 600, 636, 664, 682, 712, 733, 752, 771, 789, 819, 878, 899, 923, 945, 991, 1025, 1050, 1075, 1119, 1137, 1188, 1226, 1264, 1299, 1326, 1374, 1393, 1420, 1472, 1497, 1528, 1553, 1574, 1620, 1643, 1681, 1700, 1735, 1757, 1778, 1800, 1819, 1837, 1914, 1935, 1972], deadline = 2)
        configuration.add_task(name="Task5", identifier=5, period=2.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.290131, et_stddev=0.09671033333333333 , list_activation_dates=[2, 8, 11, 14, 18, 20, 22, 26, 34, 36, 38, 47, 51, 55, 58, 64, 66, 70, 72, 76, 78, 81, 88, 92, 96, 103, 108, 111, 113, 118, 121, 129, 132, 134, 139, 143, 146, 150, 156, 159, 162, 166, 173, 178, 184, 187, 191, 196, 198, 203, 207, 210, 213, 221, 225, 227, 230, 233, 236, 239, 245, 248, 255, 260, 265, 269, 271, 276, 279, 287, 290, 294, 298, 301, 304, 315, 327, 330, 333, 338, 340, 343, 348, 350, 353, 356, 361, 364, 370, 372, 376, 380, 383, 385, 387, 389, 394, 397, 401, 405, 409, 411, 416, 419, 424, 428, 432, 440, 443, 447, 452, 456, 463, 467, 470, 474, 481, 488, 495, 497, 499, 502, 506, 508, 515, 521, 523, 526, 530, 533, 536, 538, 542, 544, 548, 550, 554, 558, 565, 567, 570, 573, 576, 578, 585, 593, 600, 605, 612, 614, 617, 623, 626, 629, 632, 635, 637, 641, 645, 647, 652, 658, 660, 663, 668, 674, 676, 680, 684, 686, 689, 695, 699, 705, 708, 713, 716, 720, 723, 738, 742, 745, 750, 752, 755, 758, 765, 768, 772, 779, 783, 785, 788, 790, 794, 798, 804, 808, 811, 814, 817, 819, 823, 825, 827, 833, 843, 851, 853, 869, 877, 881, 887, 889, 893, 901, 907, 914, 916, 918, 923, 929, 932, 936, 938, 943, 946, 951, 960, 963, 966, 970, 981, 983, 987, 991, 1000, 1003, 1007, 1013, 1016, 1020, 1025, 1032, 1036, 1040, 1044, 1046, 1050, 1053, 1056, 1060, 1062, 1064, 1067, 1069, 1072, 1075, 1078, 1081, 1088, 1094, 1097, 1100, 1102, 1104, 1107, 1109, 1111, 1119, 1122, 1126, 1130, 1132, 1136, 1139, 1144, 1149, 1153, 1156, 1159, 1162, 1168, 1171, 1175, 1179, 1185, 1189, 1196, 1200, 1206, 1210, 1218, 1223, 1227, 1229, 1238, 1240, 1243, 1246, 1251, 1255, 1258, 1262, 1266, 1272, 1274, 1277, 1281, 1285, 1288, 1290, 1294, 1297, 1300, 1302, 1305, 1307, 1309, 1312, 1318, 1322, 1330, 1333, 1336, 1344, 1346, 1349, 1355, 1361, 1368, 1372, 1376, 1382, 1385, 1388, 1395, 1402, 1404, 1406, 1411, 1413, 1416, 1420, 1424, 1426, 1430, 1435, 1439, 1444, 1447, 1455, 1458, 1461, 1467, 1472, 1476, 1479, 1482, 1484, 1488, 1497, 1501, 1505, 1507, 1509, 1520, 1523, 1526, 1529, 1533, 1536, 1543, 1549, 1556, 1559, 1563, 1568, 1570, 1577, 1582, 1584, 1591, 1594, 1596, 1600, 1606, 1609, 1612, 1618, 1622, 1624, 1633, 1644, 1646, 1648, 1651, 1658, 1664, 1671, 1674, 1679, 1682, 1690, 1697, 1699, 1704, 1708, 1712, 1715, 1720, 1725, 1728, 1732, 1736, 1743, 1746, 1751, 1755, 1759, 1766, 1770, 1778, 1780, 1785, 1787, 1790, 1793, 1795, 1801, 1804, 1808, 1810, 1814, 1817, 1821, 1824, 1828, 1833, 1836, 1839, 1846, 1850, 1861, 1863, 1872, 1874, 1878, 1881, 1883, 1887, 1889, 1893, 1895, 1897, 1906, 1912, 1916, 1920, 1922, 1926, 1931, 1933, 1937, 1943, 1947, 1951, 1955, 1958, 1965, 1973, 1975, 1978, 1980, 1984, 1986, 1992, 1996, 1999], deadline = 2)
        configuration.add_task(name="Task3", identifier=3, period=3.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=1.009927, acet=1.009927, et_stddev=0.3366423333333333, deadline= 2)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "6")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "6")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "6")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "6")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task3", identifier=3, period=9.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=2.130179, acet=2.130179, et_stddev=0.7100596666666666, deadline= 6)
        configuration.add_task(name="Task5", identifier=5, period=19.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.091752, et_stddev=0.030584 , list_activation_dates=[33, 60, 163, 206, 259, 280, 309, 353, 374, 394, 420, 472, 494, 513, 542, 580, 617, 670, 692, 725, 756, 793, 815, 872, 920, 960, 1020, 1082, 1138, 1246, 1297, 1323, 1349, 1414, 1476, 1515, 1593, 1670, 1700, 1783, 1827, 1861, 1896, 1946, 1970], deadline = 6)
        configuration.add_task(name="Task6", identifier=6, period=27.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=5, acet=4.684237, et_stddev=1.5614123333333334 , list_activation_dates=[109, 189, 249, 281, 322, 431, 466, 502, 537, 573, 634, 686, 721, 779, 897, 957, 987, 1045, 1102, 1139, 1176, 1210, 1291, 1338, 1416, 1456, 1501, 1603, 1716, 1774, 1812, 1860, 1890, 1934], deadline = 14)
        configuration.add_task(name="Task1", identifier=1, period=4.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=2.753034, acet=2.753034, et_stddev=0.917678, deadline= 3)
        configuration.add_task(name="Task2", identifier=2, period=11.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=7.425603, acet=7.425603, et_stddev=2.4752009999999998, deadline= 16)
        configuration.add_task(name="Task4", identifier=4, period=1.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.02168, et_stddev=0.007226666666666667 , list_activation_dates=[1, 3, 5, 9, 10, 12, 13, 14, 16, 18, 19, 22, 24, 25, 26, 29, 33, 34, 35, 38, 43, 44, 45, 47, 48, 50, 52, 55, 57, 58, 63, 65, 69, 70, 72, 73, 74, 76, 81, 83, 85, 90, 91, 93, 96, 100, 104, 108, 111, 114, 115, 116, 118, 121, 123, 124, 126, 127, 129, 130, 132, 133, 135, 139, 140, 141, 146, 148, 149, 154, 155, 156, 157, 158, 160, 162, 163, 166, 169, 170, 172, 173, 176, 179, 180, 182, 183, 186, 190, 191, 193, 195, 196, 201, 203, 207, 209, 210, 211, 213, 215, 216, 217, 219, 220, 221, 222, 223, 225, 226, 229, 234, 235, 237, 239, 241, 242, 243, 244, 246, 247, 248, 250, 253, 255, 258, 261, 263, 265, 266, 270, 271, 274, 275, 277, 278, 281, 282, 283, 284, 285, 287, 290, 292, 294, 298, 300, 301, 302, 303, 304, 307, 309, 311, 313, 315, 316, 317, 321, 323, 324, 326, 330, 335, 336, 341, 342, 345, 346, 348, 350, 352, 354, 356, 358, 359, 361, 363, 364, 366, 368, 369, 371, 373, 374, 376, 377, 378, 379, 381, 384, 386, 387, 389, 390, 391, 392, 393, 395, 396, 399, 400, 401, 402, 403, 406, 407, 408, 411, 413, 414, 416, 421, 422, 423, 426, 428, 431, 434, 435, 437, 439, 441, 443, 445, 446, 448, 450, 452, 456, 461, 462, 463, 466, 469, 470, 472, 476, 478, 481, 482, 486, 489, 490, 493, 496, 500, 502, 505, 507, 509, 510, 511, 514, 517, 518, 521, 524, 525, 529, 531, 534, 536, 537, 540, 544, 546, 550, 551, 552, 554, 556, 557, 558, 562, 564, 565, 566, 567, 570, 571, 573, 574, 576, 578, 580, 581, 584, 585, 587, 589, 590, 591, 594, 596, 597, 598, 599, 600, 601, 603, 604, 605, 606, 608, 609, 614, 615, 617, 618, 621, 625, 626, 629, 634, 636, 637, 639, 641, 644, 646, 647, 649, 651, 653, 656, 657, 658, 660, 665, 668, 669, 671, 673, 675, 676, 677, 678, 679, 683, 686, 689, 692, 696, 697, 698, 701, 703, 704, 705, 708, 709, 710, 712, 713, 716, 718, 719, 721, 722, 725, 727, 728, 729, 730, 732, 734, 736, 738, 741, 744, 746, 747, 749, 752, 754, 758, 760, 762, 764, 766, 767, 768, 770, 771, 772, 774, 775, 778, 779, 781, 783, 785, 786, 788, 790, 791, 792, 794, 798, 800, 804, 807, 810, 812, 814, 817, 819, 821, 824, 825, 829, 830, 832, 834, 835, 837, 838, 845, 846, 847, 848, 849, 851, 852, 856, 857, 859, 861, 864, 865, 869, 870, 872, 873, 875, 876, 880, 882, 884, 886, 889, 891, 892, 893, 894, 895, 896, 900, 901, 904, 906, 907, 909, 911, 912, 914, 915, 916, 919, 921, 923, 924, 925, 927, 928, 929, 930, 931, 932, 935, 940, 945, 946, 947, 949, 951, 953, 954, 956, 957, 959, 960, 961, 963, 965, 966, 968, 970, 972, 973, 976, 978, 980, 983, 984, 986, 988, 994, 999, 1001, 1002, 1006, 1011, 1015, 1016, 1017, 1019, 1022, 1023, 1024, 1026, 1028, 1030, 1033, 1034, 1037, 1039, 1040, 1042, 1043, 1044, 1045, 1048, 1050, 1052, 1054, 1055, 1058, 1060, 1062, 1064, 1065, 1067, 1069, 1070, 1071, 1072, 1073, 1074, 1075, 1076, 1079, 1081, 1082, 1083, 1085, 1086, 1089, 1091, 1093, 1095, 1096, 1097, 1102, 1103, 1105, 1108, 1109, 1110, 1112, 1115, 1116, 1118, 1122, 1124, 1127, 1128, 1129, 1136, 1138, 1143, 1145, 1146, 1147, 1149, 1151, 1156, 1157, 1160, 1161, 1163, 1164, 1166, 1169, 1171, 1172, 1174, 1175, 1179, 1180, 1181, 1184, 1185, 1186, 1187, 1189, 1190, 1193, 1197, 1199, 1202, 1204, 1207, 1209, 1210, 1212, 1213, 1214, 1215, 1216, 1218, 1219, 1221, 1222, 1225, 1227, 1230, 1231, 1232, 1236, 1237, 1238, 1241, 1243, 1245, 1246, 1247, 1249, 1252, 1253, 1254, 1256, 1257, 1259, 1261, 1263, 1264, 1266, 1267, 1268, 1272, 1273, 1276, 1279, 1281, 1283, 1285, 1289, 1291, 1293, 1294, 1297, 1299, 1300, 1304, 1306, 1307, 1308, 1309, 1312, 1313, 1316, 1318, 1320, 1321, 1322, 1328, 1331, 1332, 1338, 1339, 1341, 1345, 1346, 1347, 1349, 1350, 1352, 1354, 1356, 1358, 1360, 1363, 1367, 1370, 1372, 1376, 1378, 1380, 1381, 1382, 1384, 1385, 1386, 1387, 1388, 1390, 1392, 1393, 1395, 1396, 1398, 1402, 1404, 1407, 1408, 1409, 1411, 1413, 1415, 1417, 1421, 1425, 1426, 1427, 1429, 1430, 1432, 1434, 1436, 1441, 1443, 1444, 1446, 1453, 1455, 1456, 1459, 1461, 1462, 1463, 1465, 1467, 1471, 1472, 1473, 1475, 1477, 1478, 1479, 1481, 1482, 1484, 1485, 1486, 1488, 1491, 1492, 1493, 1494, 1495, 1496, 1498, 1500, 1504, 1506, 1509, 1512, 1516, 1518, 1520, 1522, 1523, 1530, 1531, 1533, 1534, 1537, 1539, 1540, 1542, 1545, 1550, 1553, 1555, 1557, 1559, 1560, 1561, 1564, 1567, 1568, 1571, 1573, 1575, 1576, 1578, 1585, 1588, 1590, 1591, 1592, 1593, 1597, 1598, 1599, 1603, 1605, 1608, 1609, 1610, 1613, 1614, 1616, 1617, 1619, 1621, 1626, 1627, 1630, 1633, 1634, 1637, 1638, 1640, 1642, 1643, 1646, 1648, 1649, 1653, 1654, 1656, 1657, 1659, 1660, 1662, 1664, 1665, 1667, 1669, 1671, 1673, 1675, 1677, 1682, 1684, 1685, 1687, 1689, 1690, 1691, 1693, 1694, 1697, 1699, 1701, 1703, 1705, 1706, 1711, 1713, 1716, 1717, 1719, 1720, 1722, 1723, 1725, 1728, 1729, 1730, 1732, 1735, 1737, 1738, 1739, 1740, 1746, 1747, 1749, 1751, 1753, 1756, 1761, 1763, 1764, 1766, 1770, 1772, 1773, 1777, 1778, 1780, 1781, 1782, 1783, 1784, 1787, 1789, 1790, 1791, 1793, 1794, 1800, 1802, 1803, 1804, 1807, 1808, 1809, 1810, 1811, 1813, 1815, 1819, 1820, 1822, 1823, 1826, 1828, 1831, 1833, 1834, 1835, 1838, 1839, 1841, 1842, 1845, 1847, 1848, 1850, 1851, 1853, 1855, 1858, 1859, 1861, 1863, 1865, 1869, 1870, 1871, 1873, 1876, 1879, 1881, 1882, 1885, 1887, 1888, 1889, 1891, 1895, 1896, 1900, 1901, 1905, 1906, 1907, 1908, 1911, 1912, 1914, 1915, 1917, 1918, 1920, 1921, 1922, 1924, 1927, 1928, 1929, 1931, 1932, 1934, 1937, 1940, 1942, 1943, 1946, 1948, 1949, 1954, 1955, 1957, 1958, 1960, 1961, 1962, 1964, 1966, 1967, 1968, 1970, 1972, 1973, 1974, 1976, 1978, 1979, 1980, 1982, 1983, 1987, 1991, 1993, 1995, 1997], deadline = 2)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "7")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "7")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "7")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "7")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task1", identifier=1, period=48.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=11.695618, acet=11.695618, et_stddev=3.8985393333333334, deadline= 72)
        configuration.add_task(name="Task5", identifier=5, period=3.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.01158, et_stddev=0.00386 , list_activation_dates=[8, 15, 21, 27, 31, 35, 38, 53, 60, 66, 71, 78, 83, 86, 93, 101, 106, 116, 119, 125, 131, 138, 145, 150, 154, 164, 169, 180, 183, 187, 196, 212, 222, 227, 234, 239, 244, 249, 254, 258, 261, 264, 268, 271, 283, 286, 290, 297, 307, 315, 318, 321, 326, 331, 335, 339, 347, 351, 356, 366, 371, 375, 380, 388, 393, 406, 409, 412, 417, 422, 426, 429, 432, 435, 441, 444, 451, 458, 463, 477, 485, 491, 501, 505, 509, 515, 520, 527, 536, 540, 543, 548, 551, 554, 558, 562, 565, 573, 578, 583, 586, 590, 596, 601, 605, 613, 622, 629, 633, 637, 644, 650, 670, 674, 679, 686, 691, 701, 721, 729, 737, 744, 748, 751, 754, 758, 764, 771, 776, 779, 783, 790, 797, 801, 804, 808, 817, 820, 827, 833, 838, 848, 853, 858, 862, 869, 873, 877, 882, 886, 889, 893, 903, 909, 912, 917, 924, 929, 935, 940, 948, 953, 962, 966, 972, 975, 978, 983, 987, 992, 998, 1001, 1014, 1027, 1031, 1039, 1053, 1057, 1064, 1069, 1072, 1086, 1090, 1093, 1098, 1107, 1125, 1131, 1134, 1139, 1156, 1160, 1165, 1169, 1175, 1182, 1190, 1196, 1200, 1213, 1217, 1221, 1234, 1240, 1245, 1251, 1256, 1262, 1268, 1275, 1281, 1286, 1294, 1298, 1309, 1314, 1325, 1330, 1337, 1341, 1347, 1350, 1355, 1361, 1367, 1371, 1377, 1380, 1387, 1397, 1404, 1411, 1415, 1423, 1432, 1435, 1439, 1443, 1448, 1452, 1458, 1465, 1481, 1485, 1490, 1494, 1501, 1512, 1517, 1522, 1527, 1537, 1548, 1552, 1559, 1568, 1571, 1574, 1579, 1582, 1589, 1594, 1597, 1601, 1609, 1613, 1619, 1626, 1629, 1632, 1636, 1639, 1648, 1651, 1656, 1660, 1676, 1680, 1684, 1692, 1695, 1705, 1718, 1725, 1733, 1736, 1742, 1745, 1753, 1757, 1786, 1790, 1795, 1798, 1802, 1808, 1814, 1821, 1828, 1831, 1838, 1844, 1847, 1851, 1859, 1862, 1869, 1876, 1879, 1883, 1887, 1893, 1898, 1908, 1912, 1916, 1919, 1929, 1939, 1943, 1961, 1970, 1977, 1986, 1998], deadline = 3)
        configuration.add_task(name="Task6", identifier=6, period=4.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.489472, et_stddev=0.16315733333333335 , list_activation_dates=[10, 15, 22, 37, 52, 57, 62, 76, 92, 99, 104, 122, 127, 134, 142, 159, 170, 184, 188, 196, 203, 211, 218, 223, 228, 233, 238, 245, 254, 260, 278, 287, 295, 307, 313, 320, 325, 344, 348, 352, 356, 372, 382, 390, 396, 400, 405, 413, 429, 434, 442, 446, 452, 458, 463, 476, 485, 494, 500, 511, 517, 524, 532, 537, 543, 550, 556, 562, 574, 582, 592, 604, 612, 620, 625, 631, 635, 640, 646, 651, 679, 708, 715, 725, 733, 740, 746, 750, 760, 767, 777, 784, 788, 792, 798, 803, 813, 826, 836, 841, 849, 854, 859, 865, 870, 882, 886, 892, 898, 911, 916, 922, 935, 939, 944, 949, 957, 961, 968, 986, 995, 1007, 1011, 1017, 1022, 1032, 1045, 1051, 1061, 1079, 1089, 1095, 1099, 1103, 1108, 1121, 1126, 1130, 1138, 1147, 1152, 1157, 1169, 1183, 1188, 1193, 1199, 1204, 1217, 1223, 1232, 1237, 1243, 1248, 1259, 1263, 1268, 1273, 1283, 1290, 1296, 1301, 1309, 1316, 1323, 1331, 1335, 1342, 1348, 1353, 1358, 1362, 1366, 1373, 1380, 1389, 1395, 1404, 1420, 1426, 1435, 1440, 1445, 1457, 1466, 1470, 1474, 1479, 1483, 1497, 1516, 1521, 1527, 1532, 1544, 1563, 1572, 1581, 1587, 1600, 1619, 1627, 1635, 1651, 1659, 1664, 1669, 1676, 1695, 1700, 1707, 1712, 1716, 1725, 1733, 1737, 1743, 1747, 1759, 1769, 1777, 1783, 1789, 1799, 1805, 1811, 1815, 1820, 1832, 1837, 1841, 1846, 1859, 1878, 1884, 1891, 1898, 1904, 1913, 1928, 1934, 1940, 1947, 1955, 1965, 1970, 1976, 1982, 1988, 1996], deadline = 2)
        configuration.add_task(name="Task2", identifier=2, period=3.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=1.482432, acet=1.482432, et_stddev=0.49414399999999997, deadline= 2)
        configuration.add_task(name="Task4", identifier=4, period=43.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=4, acet=3.172176, et_stddev=1.0573919999999999 , list_activation_dates=[2, 150, 207, 278, 407, 503, 599, 651, 704, 794, 888, 979, 1035, 1125, 1201, 1259, 1357, 1562, 1642, 1712], deadline = 34)
        configuration.add_task(name="Task3", identifier=3, period=4.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=3.448788, acet=3.448788, et_stddev=1.149596, deadline= 8)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "8")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "8")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "8")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "8")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task6", identifier=6, period=16.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.419155, et_stddev=0.13971833333333333 , list_activation_dates=[4, 20, 44, 65, 90, 118, 162, 197, 249, 275, 300, 317, 347, 372, 425, 443, 474, 492, 528, 558, 581, 621, 645, 678, 712, 732, 764, 784, 806, 829, 852, 884, 904, 931, 964, 983, 1025, 1062, 1088, 1115, 1134, 1172, 1192, 1215, 1241, 1262, 1285, 1308, 1334, 1369, 1431, 1451, 1470, 1503, 1534, 1551, 1570, 1587, 1632, 1664, 1695, 1737, 1788, 1813, 1858, 1877, 1902, 1925, 1955, 1972, 1993], deadline = 21)
        configuration.add_task(name="Task5", identifier=5, period=7.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.95161, et_stddev=0.31720333333333334 , list_activation_dates=[37, 46, 61, 70, 95, 102, 111, 120, 135, 142, 151, 162, 171, 179, 199, 217, 225, 242, 255, 266, 275, 288, 296, 308, 323, 336, 349, 362, 379, 387, 414, 421, 459, 496, 505, 521, 535, 546, 566, 573, 593, 610, 633, 643, 657, 675, 685, 694, 706, 713, 735, 769, 787, 807, 814, 824, 832, 841, 853, 861, 874, 882, 890, 898, 944, 952, 969, 1006, 1023, 1032, 1048, 1092, 1101, 1110, 1118, 1136, 1156, 1163, 1177, 1184, 1193, 1224, 1235, 1243, 1301, 1309, 1316, 1325, 1356, 1371, 1381, 1399, 1416, 1432, 1444, 1453, 1467, 1474, 1482, 1492, 1502, 1516, 1524, 1533, 1545, 1555, 1564, 1572, 1590, 1602, 1610, 1622, 1635, 1643, 1654, 1666, 1678, 1685, 1696, 1705, 1713, 1737, 1749, 1774, 1791, 1804, 1812, 1831, 1840, 1857, 1866, 1874, 1891, 1900, 1907, 1915, 1924, 1933, 1946, 1960, 1970, 1996], deadline = 3)
        configuration.add_task(name="Task2", identifier=2, period=32.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=27.98796, acet=27.98796, et_stddev=9.329320000000001, deadline= 41)
        configuration.add_task(name="Task4", identifier=4, period=11.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.416442, et_stddev=0.138814 , list_activation_dates=[28, 48, 93, 104, 117, 142, 155, 183, 205, 221, 273, 288, 301, 319, 333, 347, 358, 373, 433, 488, 505, 519, 550, 567, 579, 616, 631, 661, 691, 703, 727, 747, 760, 774, 785, 805, 827, 844, 863, 879, 901, 925, 1003, 1016, 1033, 1045, 1064, 1105, 1129, 1175, 1187, 1208, 1222, 1240, 1251, 1273, 1284, 1297, 1311, 1328, 1343, 1355, 1373, 1387, 1403, 1423, 1441, 1459, 1476, 1488, 1523, 1540, 1552, 1567, 1584, 1610, 1642, 1655, 1685, 1703, 1726, 1755, 1794, 1808, 1829, 1853, 1868, 1887, 1904, 1934, 1968], deadline = 18)
        configuration.add_task(name="Task3", identifier=3, period=2.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=0.402442, acet=0.402442, et_stddev=0.13414733333333334, deadline= 4)
        configuration.add_task(name="Task1", identifier=1, period=3.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=1.572465, acet=1.572465, et_stddev=0.524155, deadline= 6)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "9")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "9")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "9")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "9")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task4", identifier=4, period=7.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.16281, et_stddev=0.054270000000000006 , list_activation_dates=[1, 15, 27, 45, 53, 60, 90, 98, 116, 128, 141, 155, 171, 182, 189, 215, 226, 260, 273, 280, 287, 297, 313, 320, 343, 355, 366, 383, 404, 451, 468, 489, 504, 516, 531, 539, 560, 582, 593, 610, 622, 642, 658, 667, 679, 695, 712, 723, 765, 775, 784, 801, 812, 824, 834, 854, 862, 871, 881, 896, 907, 923, 937, 946, 959, 973, 991, 1011, 1024, 1040, 1075, 1099, 1112, 1121, 1129, 1141, 1150, 1166, 1192, 1210, 1228, 1240, 1247, 1254, 1285, 1300, 1312, 1329, 1338, 1349, 1357, 1374, 1386, 1393, 1413, 1423, 1433, 1443, 1472, 1498, 1509, 1532, 1543, 1560, 1568, 1575, 1592, 1609, 1618, 1628, 1644, 1657, 1675, 1684, 1696, 1706, 1716, 1732, 1741, 1748, 1765, 1781, 1798, 1818, 1830, 1837, 1864, 1876, 1883, 1892, 1900, 1910, 1919, 1931, 1939, 1950, 1977, 1988, 1995], deadline = 13)
        configuration.add_task(name="Task3", identifier=3, period=2.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=1.10148, acet=1.10148, et_stddev=0.36716, deadline= 4)
        configuration.add_task(name="Task5", identifier=5, period=9.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.248329, et_stddev=0.08277633333333333 , list_activation_dates=[8, 18, 28, 44, 54, 63, 97, 108, 118, 135, 145, 164, 185, 204, 214, 249, 274, 285, 295, 316, 342, 378, 390, 417, 447, 466, 488, 502, 518, 529, 574, 597, 655, 664, 675, 712, 726, 740, 763, 776, 792, 804, 815, 844, 856, 866, 878, 903, 914, 923, 933, 960, 970, 980, 989, 1006, 1017, 1027, 1049, 1070, 1080, 1106, 1122, 1134, 1145, 1158, 1168, 1177, 1196, 1207, 1217, 1226, 1240, 1254, 1280, 1290, 1300, 1318, 1340, 1352, 1415, 1429, 1448, 1460, 1471, 1498, 1515, 1532, 1543, 1563, 1577, 1590, 1618, 1654, 1664, 1691, 1722, 1742, 1765, 1778, 1794, 1804, 1815, 1833, 1850, 1860, 1872, 1886, 1902, 1921, 1949, 1963, 1978], deadline = 7)
        configuration.add_task(name="Task2", identifier=2, period=4.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=3.360587, acet=3.360587, et_stddev=1.1201956666666668, deadline= 5)
        configuration.add_task(name="Task6", identifier=6, period=2.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.298298, et_stddev=0.09943266666666667 , list_activation_dates=[1, 5, 8, 18, 20, 24, 30, 34, 36, 38, 40, 43, 47, 53, 56, 61, 66, 80, 84, 86, 88, 91, 93, 96, 103, 108, 114, 117, 121, 126, 129, 132, 135, 138, 141, 148, 153, 155, 158, 169, 171, 173, 176, 178, 181, 184, 187, 189, 193, 196, 202, 204, 209, 212, 216, 224, 229, 233, 236, 242, 248, 257, 266, 268, 273, 278, 280, 285, 288, 295, 301, 306, 310, 313, 316, 318, 320, 324, 326, 328, 341, 343, 345, 350, 353, 355, 359, 369, 373, 380, 383, 385, 388, 390, 394, 397, 401, 404, 406, 411, 415, 419, 422, 426, 430, 440, 445, 448, 451, 453, 456, 461, 465, 468, 472, 478, 480, 488, 490, 492, 495, 499, 503, 506, 510, 513, 517, 521, 524, 528, 532, 539, 542, 544, 550, 556, 558, 561, 567, 571, 574, 577, 579, 581, 584, 587, 590, 594, 596, 598, 601, 603, 608, 612, 614, 617, 626, 633, 636, 643, 647, 656, 659, 664, 667, 672, 674, 677, 680, 684, 688, 692, 695, 697, 700, 702, 706, 710, 714, 716, 721, 723, 726, 728, 730, 732, 736, 738, 741, 744, 748, 751, 754, 757, 763, 766, 769, 771, 773, 775, 779, 783, 786, 790, 794, 799, 801, 809, 814, 818, 821, 827, 831, 834, 836, 839, 843, 846, 855, 858, 864, 867, 869, 872, 876, 882, 885, 890, 893, 895, 901, 909, 911, 916, 919, 922, 925, 933, 936, 938, 943, 946, 949, 953, 957, 959, 964, 967, 970, 972, 978, 982, 985, 988, 999, 1003, 1007, 1009, 1011, 1016, 1020, 1022, 1025, 1029, 1034, 1037, 1039, 1041, 1044, 1048, 1050, 1054, 1058, 1060, 1063, 1066, 1071, 1073, 1079, 1086, 1088, 1091, 1094, 1096, 1099, 1103, 1108, 1115, 1118, 1125, 1127, 1132, 1136, 1139, 1142, 1152, 1155, 1159, 1161, 1163, 1167, 1171, 1173, 1176, 1178, 1183, 1186, 1189, 1192, 1196, 1199, 1202, 1207, 1210, 1213, 1215, 1218, 1220, 1224, 1227, 1231, 1234, 1243, 1246, 1252, 1255, 1257, 1259, 1263, 1270, 1272, 1276, 1278, 1284, 1286, 1289, 1291, 1294, 1299, 1304, 1307, 1309, 1312, 1319, 1321, 1326, 1330, 1334, 1337, 1339, 1347, 1352, 1359, 1364, 1373, 1377, 1379, 1384, 1388, 1390, 1393, 1396, 1400, 1405, 1409, 1413, 1416, 1425, 1431, 1435, 1444, 1447, 1449, 1453, 1458, 1460, 1464, 1468, 1470, 1473, 1475, 1478, 1483, 1489, 1494, 1497, 1499, 1504, 1508, 1512, 1516, 1518, 1521, 1523, 1526, 1529, 1532, 1534, 1539, 1541, 1544, 1547, 1550, 1553, 1556, 1560, 1562, 1565, 1568, 1571, 1579, 1588, 1594, 1596, 1599, 1602, 1604, 1607, 1611, 1617, 1620, 1623, 1625, 1628, 1631, 1633, 1640, 1645, 1649, 1655, 1658, 1661, 1665, 1668, 1670, 1672, 1674, 1677, 1682, 1689, 1691, 1694, 1696, 1699, 1704, 1706, 1716, 1719, 1721, 1726, 1735, 1739, 1750, 1753, 1757, 1772, 1775, 1778, 1784, 1787, 1790, 1794, 1796, 1800, 1805, 1808, 1811, 1815, 1817, 1820, 1823, 1826, 1830, 1835, 1837, 1840, 1846, 1848, 1851, 1854, 1862, 1866, 1871, 1875, 1880, 1884, 1887, 1889, 1894, 1896, 1898, 1901, 1904, 1911, 1916, 1919, 1922, 1933, 1939, 1949, 1951, 1955, 1960, 1965, 1970, 1972, 1974, 1979, 1982, 1985, 1989, 1991, 1996, 1999], deadline = 1)
        configuration.add_task(name="Task1", identifier=1, period=47.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=9.828302, acet=9.828302, et_stddev=3.2761006666666668, deadline= 22)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "10")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "10")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "10")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "10")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task5", identifier=5, period=2.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.355942, et_stddev=0.11864733333333333 , list_activation_dates=[7, 10, 13, 16, 19, 22, 24, 30, 33, 37, 40, 44, 47, 53, 56, 59, 61, 65, 67, 72, 75, 79, 82, 87, 89, 95, 98, 101, 103, 106, 109, 111, 114, 123, 126, 130, 134, 136, 140, 143, 147, 154, 156, 158, 164, 168, 179, 182, 185, 187, 193, 197, 210, 213, 218, 227, 232, 236, 241, 247, 251, 254, 256, 258, 264, 267, 273, 275, 280, 288, 293, 295, 303, 305, 312, 318, 320, 326, 332, 336, 338, 341, 350, 352, 359, 362, 365, 368, 375, 377, 380, 384, 390, 397, 400, 404, 409, 412, 415, 427, 429, 446, 449, 451, 455, 458, 462, 464, 468, 471, 476, 478, 482, 484, 487, 489, 491, 494, 496, 498, 500, 504, 507, 521, 523, 526, 531, 534, 538, 540, 546, 549, 551, 554, 556, 558, 560, 563, 571, 574, 578, 582, 585, 587, 591, 598, 601, 604, 608, 611, 617, 619, 624, 629, 633, 640, 644, 649, 652, 655, 662, 665, 671, 677, 684, 686, 689, 697, 701, 705, 707, 710, 713, 715, 720, 722, 724, 726, 730, 732, 735, 738, 742, 744, 747, 750, 755, 758, 761, 765, 768, 771, 779, 781, 784, 787, 799, 806, 808, 811, 814, 819, 822, 824, 829, 831, 835, 838, 846, 850, 853, 856, 859, 861, 864, 868, 875, 877, 881, 884, 890, 892, 899, 901, 908, 911, 917, 920, 922, 926, 928, 933, 937, 940, 944, 950, 953, 958, 960, 964, 967, 972, 974, 978, 981, 983, 990, 994, 1005, 1011, 1013, 1015, 1018, 1026, 1029, 1031, 1035, 1040, 1043, 1047, 1050, 1056, 1058, 1060, 1063, 1071, 1074, 1077, 1081, 1086, 1092, 1097, 1099, 1101, 1103, 1105, 1108, 1111, 1117, 1120, 1122, 1125, 1129, 1132, 1136, 1138, 1143, 1150, 1154, 1156, 1158, 1164, 1167, 1169, 1173, 1177, 1180, 1184, 1197, 1201, 1204, 1216, 1219, 1221, 1224, 1226, 1228, 1230, 1233, 1235, 1238, 1245, 1255, 1259, 1263, 1269, 1275, 1281, 1284, 1289, 1292, 1294, 1296, 1299, 1302, 1307, 1311, 1315, 1321, 1324, 1329, 1333, 1336, 1340, 1344, 1347, 1349, 1354, 1360, 1364, 1366, 1369, 1373, 1388, 1396, 1401, 1407, 1410, 1417, 1425, 1428, 1432, 1440, 1442, 1446, 1450, 1456, 1458, 1462, 1464, 1469, 1472, 1478, 1483, 1485, 1487, 1492, 1494, 1499, 1504, 1509, 1515, 1517, 1520, 1523, 1526, 1532, 1537, 1541, 1544, 1549, 1556, 1561, 1564, 1567, 1571, 1575, 1582, 1585, 1588, 1591, 1594, 1601, 1608, 1612, 1615, 1621, 1623, 1625, 1627, 1630, 1633, 1636, 1639, 1641, 1646, 1652, 1654, 1660, 1664, 1670, 1672, 1674, 1677, 1686, 1688, 1700, 1705, 1711, 1718, 1722, 1726, 1729, 1734, 1736, 1738, 1741, 1744, 1746, 1750, 1755, 1760, 1763, 1773, 1775, 1779, 1781, 1784, 1786, 1789, 1792, 1794, 1798, 1800, 1803, 1808, 1811, 1816, 1819, 1823, 1828, 1830, 1833, 1836, 1842, 1846, 1848, 1851, 1855, 1858, 1860, 1862, 1865, 1870, 1875, 1877, 1881, 1885, 1888, 1895, 1901, 1905, 1908, 1910, 1918, 1920, 1925, 1929, 1933, 1937, 1945, 1950, 1952, 1955, 1961, 1963, 1968, 1971, 1976, 1978, 1980, 1984, 1990, 1993, 1995, 1997, 2000], deadline = 4)
        configuration.add_task(name="Task1", identifier=1, period=12.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=5.517816, acet=5.517816, et_stddev=1.839272, deadline= 7)
        configuration.add_task(name="Task2", identifier=2, period=26.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=7.578654, acet=7.578654, et_stddev=2.526218, deadline= 31)
        configuration.add_task(name="Task6", identifier=6, period=2.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.021093, et_stddev=0.007031 , list_activation_dates=[2, 5, 11, 13, 18, 29, 34, 40, 43, 46, 50, 53, 57, 60, 67, 71, 75, 79, 84, 88, 91, 98, 101, 109, 113, 115, 118, 123, 128, 131, 138, 147, 151, 153, 156, 158, 163, 165, 169, 172, 177, 182, 184, 187, 190, 194, 197, 199, 201, 203, 206, 210, 214, 218, 220, 223, 227, 230, 232, 235, 241, 243, 247, 252, 255, 257, 259, 263, 265, 268, 273, 276, 278, 281, 284, 286, 293, 295, 300, 304, 308, 311, 314, 316, 319, 326, 330, 333, 336, 340, 342, 345, 347, 354, 369, 373, 376, 378, 386, 389, 393, 396, 399, 401, 404, 407, 411, 414, 423, 427, 430, 434, 437, 440, 442, 445, 447, 449, 453, 455, 457, 463, 466, 470, 472, 477, 481, 484, 492, 497, 502, 505, 507, 514, 517, 523, 527, 532, 535, 539, 543, 546, 550, 560, 563, 566, 573, 577, 579, 584, 588, 590, 593, 597, 601, 604, 608, 611, 618, 622, 626, 628, 630, 633, 635, 638, 641, 645, 648, 651, 653, 655, 659, 663, 667, 671, 674, 680, 687, 696, 702, 706, 710, 712, 717, 720, 722, 728, 732, 736, 740, 744, 748, 751, 753, 756, 758, 762, 764, 773, 775, 785, 791, 799, 804, 810, 813, 816, 818, 825, 827, 829, 831, 833, 836, 841, 844, 849, 861, 865, 868, 872, 876, 880, 886, 892, 895, 902, 904, 908, 915, 917, 920, 922, 929, 932, 934, 936, 939, 941, 944, 949, 952, 954, 962, 966, 969, 973, 981, 988, 990, 996, 1001, 1008, 1012, 1015, 1018, 1020, 1026, 1030, 1033, 1035, 1040, 1043, 1047, 1049, 1052, 1057, 1059, 1062, 1067, 1070, 1072, 1076, 1080, 1094, 1097, 1101, 1103, 1108, 1110, 1113, 1118, 1120, 1123, 1126, 1133, 1137, 1140, 1143, 1146, 1152, 1155, 1157, 1161, 1165, 1169, 1171, 1174, 1176, 1178, 1183, 1186, 1189, 1191, 1194, 1199, 1201, 1208, 1210, 1214, 1217, 1220, 1227, 1233, 1235, 1238, 1241, 1244, 1247, 1251, 1256, 1262, 1265, 1269, 1273, 1278, 1284, 1287, 1294, 1303, 1306, 1308, 1311, 1313, 1318, 1326, 1329, 1331, 1333, 1338, 1340, 1344, 1346, 1350, 1353, 1358, 1361, 1365, 1367, 1370, 1374, 1378, 1382, 1385, 1387, 1390, 1395, 1399, 1408, 1411, 1413, 1416, 1421, 1428, 1435, 1438, 1441, 1443, 1445, 1450, 1457, 1459, 1462, 1467, 1470, 1476, 1478, 1481, 1484, 1488, 1493, 1497, 1502, 1506, 1511, 1513, 1517, 1520, 1526, 1531, 1537, 1542, 1545, 1549, 1556, 1558, 1560, 1562, 1565, 1568, 1575, 1579, 1582, 1590, 1593, 1595, 1597, 1604, 1610, 1613, 1618, 1622, 1626, 1630, 1632, 1634, 1639, 1644, 1646, 1649, 1652, 1654, 1656, 1658, 1661, 1667, 1669, 1671, 1675, 1678, 1681, 1685, 1689, 1694, 1698, 1705, 1721, 1725, 1730, 1732, 1734, 1737, 1740, 1747, 1750, 1752, 1754, 1758, 1761, 1764, 1766, 1773, 1775, 1778, 1781, 1783, 1785, 1787, 1790, 1794, 1796, 1799, 1802, 1805, 1818, 1820, 1828, 1831, 1838, 1845, 1847, 1850, 1853, 1856, 1858, 1861, 1863, 1867, 1875, 1879, 1882, 1884, 1889, 1892, 1897, 1903, 1913, 1918, 1922, 1935, 1937, 1943, 1949, 1951, 1954, 1961, 1963, 1965, 1970, 1974, 1976, 1982, 1984, 1987, 1990, 1993, 1998], deadline = 2)
        configuration.add_task(name="Task4", identifier=4, period=13.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.149261, et_stddev=0.04975366666666667 , list_activation_dates=[6, 24, 46, 67, 102, 141, 169, 203, 241, 270, 283, 305, 334, 351, 369, 428, 452, 482, 498, 556, 590, 616, 632, 651, 672, 689, 706, 720, 740, 754, 781, 823, 857, 904, 920, 947, 981, 995, 1020, 1036, 1060, 1080, 1098, 1133, 1153, 1208, 1222, 1239, 1273, 1290, 1323, 1344, 1367, 1393, 1414, 1435, 1456, 1471, 1491, 1508, 1523, 1546, 1583, 1603, 1626, 1651, 1669, 1696, 1715, 1738, 1768, 1801, 1818, 1832, 1851, 1870, 1918, 1933, 1957, 1977, 1992], deadline = 11)
        configuration.add_task(name="Task3", identifier=3, period=5.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=4.243476, acet=4.243476, et_stddev=1.414492, deadline= 9)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "11")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "11")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "11")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "11")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task2", identifier=2, period=1.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=0.310928, acet=0.310928, et_stddev=0.10364266666666666, deadline= 2)
        configuration.add_task(name="Task3", identifier=3, period=33.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=23.737311, acet=23.737311, et_stddev=7.912437, deadline= 62)
        configuration.add_task(name="Task4", identifier=4, period=3.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.444222, et_stddev=0.148074 , list_activation_dates=[1, 6, 11, 17, 34, 41, 52, 56, 59, 62, 65, 71, 75, 83, 87, 94, 98, 104, 108, 111, 116, 122, 125, 131, 137, 141, 146, 153, 158, 165, 170, 176, 182, 185, 194, 202, 209, 219, 226, 234, 244, 258, 263, 270, 278, 289, 293, 302, 306, 313, 316, 325, 329, 333, 341, 347, 355, 359, 365, 368, 374, 379, 388, 392, 400, 403, 411, 419, 423, 427, 436, 441, 447, 456, 459, 462, 466, 472, 476, 479, 488, 493, 498, 505, 509, 513, 516, 522, 530, 538, 543, 546, 552, 555, 563, 566, 577, 585, 589, 595, 598, 601, 608, 611, 619, 623, 632, 638, 642, 646, 649, 657, 669, 673, 676, 691, 695, 699, 703, 706, 718, 721, 725, 729, 735, 739, 749, 757, 762, 771, 778, 786, 790, 795, 798, 802, 809, 813, 820, 825, 836, 839, 848, 852, 862, 868, 876, 879, 883, 886, 890, 897, 902, 913, 917, 924, 929, 935, 948, 960, 963, 968, 975, 984, 990, 1005, 1014, 1018, 1022, 1027, 1032, 1041, 1044, 1051, 1058, 1062, 1067, 1074, 1081, 1085, 1088, 1101, 1105, 1108, 1114, 1120, 1131, 1142, 1156, 1161, 1167, 1171, 1174, 1179, 1183, 1190, 1194, 1199, 1204, 1210, 1214, 1219, 1224, 1231, 1235, 1246, 1252, 1256, 1262, 1274, 1278, 1282, 1288, 1293, 1296, 1300, 1305, 1310, 1320, 1330, 1334, 1342, 1350, 1355, 1361, 1369, 1375, 1382, 1386, 1390, 1394, 1398, 1403, 1410, 1413, 1417, 1421, 1427, 1433, 1442, 1448, 1453, 1457, 1463, 1467, 1472, 1477, 1485, 1491, 1504, 1510, 1516, 1521, 1524, 1527, 1532, 1535, 1538, 1542, 1546, 1552, 1558, 1574, 1579, 1585, 1589, 1593, 1606, 1613, 1619, 1623, 1627, 1630, 1634, 1639, 1642, 1647, 1650, 1653, 1662, 1666, 1670, 1674, 1679, 1685, 1697, 1700, 1703, 1711, 1714, 1719, 1726, 1739, 1747, 1751, 1755, 1760, 1772, 1777, 1781, 1789, 1801, 1809, 1813, 1816, 1821, 1824, 1829, 1834, 1840, 1845, 1852, 1856, 1860, 1865, 1876, 1882, 1891, 1896, 1913, 1918, 1922, 1925, 1931, 1936, 1942, 1949, 1955, 1962, 1968, 1971, 1976, 1982, 1985, 1988], deadline = 4)
        configuration.add_task(name="Task6", identifier=6, period=2.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.045117, et_stddev=0.015038999999999999 , list_activation_dates=[1, 4, 6, 10, 13, 21, 26, 29, 31, 33, 36, 40, 42, 45, 47, 51, 54, 58, 60, 63, 65, 68, 72, 75, 79, 82, 88, 90, 95, 97, 104, 106, 110, 116, 119, 121, 125, 127, 132, 134, 137, 140, 143, 147, 151, 160, 162, 165, 169, 176, 179, 184, 189, 191, 195, 198, 201, 204, 206, 210, 214, 217, 219, 222, 228, 230, 235, 239, 241, 246, 250, 254, 261, 269, 274, 277, 279, 283, 287, 291, 297, 300, 304, 306, 308, 311, 314, 322, 325, 330, 333, 335, 342, 348, 352, 358, 362, 369, 373, 376, 380, 383, 385, 387, 389, 392, 394, 398, 402, 405, 409, 413, 417, 423, 426, 432, 436, 439, 442, 444, 446, 448, 450, 458, 463, 470, 473, 476, 479, 484, 487, 490, 492, 499, 502, 506, 508, 510, 516, 518, 522, 526, 528, 533, 535, 538, 543, 546, 549, 552, 557, 567, 571, 574, 578, 584, 586, 590, 593, 597, 599, 602, 606, 613, 618, 631, 635, 638, 643, 651, 655, 659, 661, 664, 667, 670, 679, 681, 684, 688, 690, 694, 696, 700, 709, 711, 716, 725, 730, 732, 735, 742, 746, 766, 770, 773, 777, 780, 787, 791, 796, 800, 803, 805, 808, 816, 819, 822, 826, 836, 843, 847, 852, 854, 858, 860, 863, 869, 873, 879, 888, 890, 893, 897, 902, 905, 908, 912, 915, 918, 921, 926, 929, 932, 938, 942, 945, 947, 950, 954, 959, 963, 966, 968, 970, 980, 985, 988, 990, 993, 997, 1000, 1004, 1012, 1015, 1018, 1020, 1022, 1025, 1028, 1034, 1036, 1041, 1043, 1049, 1051, 1053, 1055, 1058, 1065, 1069, 1072, 1074, 1078, 1082, 1084, 1089, 1092, 1097, 1100, 1107, 1110, 1115, 1118, 1120, 1126, 1128, 1132, 1134, 1136, 1138, 1142, 1144, 1148, 1155, 1162, 1164, 1169, 1171, 1175, 1178, 1182, 1189, 1193, 1196, 1201, 1204, 1208, 1211, 1218, 1221, 1223, 1226, 1229, 1232, 1236, 1238, 1241, 1243, 1246, 1250, 1254, 1257, 1260, 1264, 1272, 1275, 1279, 1281, 1283, 1285, 1287, 1290, 1295, 1301, 1305, 1308, 1311, 1319, 1321, 1323, 1326, 1334, 1337, 1339, 1343, 1347, 1352, 1354, 1357, 1359, 1362, 1365, 1370, 1382, 1387, 1390, 1393, 1399, 1405, 1407, 1414, 1417, 1420, 1424, 1428, 1432, 1435, 1437, 1442, 1448, 1459, 1461, 1466, 1470, 1473, 1476, 1479, 1485, 1488, 1491, 1493, 1498, 1501, 1507, 1510, 1515, 1521, 1525, 1529, 1532, 1535, 1543, 1546, 1548, 1553, 1559, 1561, 1565, 1569, 1571, 1573, 1577, 1581, 1585, 1590, 1592, 1596, 1599, 1604, 1610, 1612, 1618, 1624, 1631, 1634, 1637, 1641, 1647, 1651, 1653, 1662, 1664, 1666, 1672, 1674, 1677, 1680, 1682, 1684, 1691, 1693, 1696, 1699, 1701, 1705, 1707, 1710, 1712, 1717, 1721, 1726, 1733, 1735, 1737, 1743, 1750, 1753, 1764, 1766, 1768, 1770, 1773, 1781, 1785, 1788, 1790, 1792, 1794, 1796, 1799, 1803, 1807, 1812, 1815, 1818, 1824, 1827, 1832, 1837, 1839, 1842, 1848, 1851, 1854, 1858, 1862, 1864, 1867, 1870, 1876, 1879, 1882, 1886, 1892, 1900, 1903, 1905, 1907, 1915, 1923, 1926, 1930, 1936, 1939, 1943, 1947, 1949, 1952, 1954, 1957, 1959, 1963, 1969, 1972, 1976, 1981, 1983, 1987, 1989, 1992, 1994], deadline = 2)
        configuration.add_task(name="Task5", identifier=5, period=8.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.234937, et_stddev=0.07831233333333333 , list_activation_dates=[5, 28, 44, 55, 79, 95, 115, 142, 158, 192, 206, 253, 273, 288, 303, 313, 346, 362, 379, 391, 400, 415, 427, 456, 477, 489, 518, 529, 538, 560, 580, 592, 621, 638, 684, 705, 715, 740, 755, 765, 795, 814, 836, 848, 861, 890, 899, 908, 926, 937, 952, 973, 985, 1001, 1015, 1036, 1044, 1052, 1061, 1071, 1082, 1117, 1130, 1138, 1152, 1162, 1171, 1190, 1228, 1256, 1290, 1307, 1318, 1371, 1398, 1421, 1437, 1458, 1469, 1494, 1541, 1557, 1574, 1583, 1596, 1615, 1625, 1633, 1645, 1655, 1666, 1679, 1703, 1713, 1728, 1741, 1760, 1783, 1806, 1831, 1847, 1861, 1874, 1886, 1896, 1911, 1919, 1933, 1942, 1969, 1987], deadline = 16)
        configuration.add_task(name="Task1", identifier=1, period=12.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=6.837103, acet=6.837103, et_stddev=2.279034333333333, deadline= 8)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "12")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "12")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "12")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "12")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task4", identifier=4, period=31.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=4, acet=3.545589, et_stddev=1.181863 , list_activation_dates=[4, 54, 88, 158, 238, 274, 318, 382, 498, 539, 585, 661, 722, 818, 865, 899, 945, 983, 1054, 1151, 1222, 1260, 1296, 1373, 1414, 1459, 1499, 1597, 1738, 1793, 1845, 1890], deadline = 7)
        configuration.add_task(name="Task3", identifier=3, period=28.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=13.937471, acet=13.937471, et_stddev=4.645823666666667, deadline= 15)
        configuration.add_task(name="Task2", identifier=2, period=2.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=1.124611, acet=1.124611, et_stddev=0.37487033333333336, deadline= 4)
        configuration.add_task(name="Task5", identifier=5, period=46.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=2, acet=1.419698, et_stddev=0.47323266666666663 , list_activation_dates=[45, 114, 175, 269, 355, 418, 467, 612, 724, 780, 908, 976, 1111, 1164, 1227, 1335, 1467, 1520, 1605, 1689, 1762, 1864, 2000], deadline = 88)
        configuration.add_task(name="Task1", identifier=1, period=4.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=2.15971, acet=2.15971, et_stddev=0.7199033333333333, deadline= 4)
        configuration.add_task(name="Task6", identifier=6, period=3.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.164289, et_stddev=0.054763 , list_activation_dates=[2, 12, 18, 31, 39, 44, 53, 59, 64, 76, 81, 89, 95, 103, 107, 113, 117, 121, 127, 134, 144, 151, 157, 164, 168, 172, 176, 180, 185, 190, 193, 197, 202, 206, 217, 227, 232, 236, 240, 244, 254, 257, 260, 264, 267, 275, 282, 288, 294, 303, 309, 312, 317, 325, 328, 336, 340, 344, 348, 353, 357, 360, 373, 380, 387, 392, 399, 402, 406, 422, 426, 430, 440, 444, 453, 458, 464, 468, 474, 479, 483, 488, 493, 498, 506, 511, 516, 525, 536, 541, 545, 548, 553, 557, 563, 571, 574, 586, 592, 596, 601, 609, 615, 619, 624, 627, 630, 635, 638, 666, 670, 676, 686, 689, 699, 714, 720, 730, 733, 745, 749, 757, 763, 770, 773, 779, 786, 789, 793, 800, 806, 813, 822, 826, 832, 837, 844, 853, 857, 860, 864, 869, 872, 881, 884, 888, 898, 902, 907, 912, 915, 919, 924, 927, 931, 935, 946, 949, 956, 959, 962, 970, 973, 977, 988, 996, 1000, 1011, 1025, 1028, 1031, 1040, 1044, 1047, 1055, 1062, 1065, 1068, 1072, 1085, 1088, 1107, 1112, 1127, 1130, 1136, 1149, 1161, 1167, 1177, 1190, 1197, 1204, 1213, 1216, 1222, 1227, 1231, 1235, 1239, 1245, 1252, 1256, 1262, 1267, 1274, 1280, 1283, 1286, 1292, 1298, 1303, 1306, 1311, 1318, 1321, 1325, 1329, 1332, 1336, 1339, 1346, 1350, 1353, 1357, 1366, 1375, 1380, 1385, 1390, 1400, 1407, 1413, 1417, 1421, 1427, 1436, 1441, 1449, 1454, 1460, 1464, 1471, 1474, 1484, 1491, 1494, 1499, 1504, 1508, 1515, 1520, 1526, 1540, 1549, 1554, 1562, 1566, 1570, 1573, 1588, 1592, 1599, 1603, 1606, 1616, 1629, 1633, 1653, 1657, 1661, 1667, 1670, 1677, 1683, 1688, 1692, 1696, 1702, 1711, 1720, 1725, 1733, 1741, 1744, 1748, 1752, 1755, 1762, 1766, 1769, 1772, 1776, 1780, 1787, 1791, 1794, 1797, 1800, 1805, 1815, 1819, 1825, 1830, 1838, 1841, 1845, 1851, 1858, 1872, 1878, 1882, 1889, 1903, 1907, 1912, 1926, 1930, 1940, 1944, 1951, 1970, 1977, 1987, 1993, 2000], deadline = 2)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "13")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "13")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "13")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "13")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task1", identifier=1, period=4.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=0.994427, acet=0.994427, et_stddev=0.33147566666666667, deadline= 6)
        configuration.add_task(name="Task5", identifier=5, period=18.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=2, acet=1.095669, et_stddev=0.365223 , list_activation_dates=[37, 59, 77, 106, 151, 179, 198, 216, 265, 286, 309, 336, 368, 393, 418, 448, 467, 509, 528, 549, 567, 607, 658, 692, 751, 783, 816, 837, 876, 902, 923, 947, 996, 1029, 1049, 1116, 1139, 1208, 1254, 1304, 1332, 1372, 1448, 1482, 1533, 1556, 1589, 1617, 1638, 1670, 1696, 1719, 1749, 1802, 1851, 1869, 1897, 1918, 1948, 1966], deadline = 18)
        configuration.add_task(name="Task3", identifier=3, period=9.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=8.213124, acet=8.213124, et_stddev=2.737708, deadline= 11)
        configuration.add_task(name="Task6", identifier=6, period=6.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.559517, et_stddev=0.18650566666666668 , list_activation_dates=[3, 30, 48, 63, 75, 88, 96, 117, 134, 146, 162, 170, 177, 191, 210, 220, 230, 238, 254, 279, 291, 302, 310, 330, 337, 348, 371, 378, 393, 405, 414, 424, 435, 449, 462, 471, 480, 500, 509, 518, 526, 536, 550, 559, 574, 587, 595, 602, 608, 616, 627, 636, 647, 668, 688, 699, 710, 727, 742, 752, 767, 782, 790, 796, 814, 822, 835, 845, 853, 863, 874, 890, 901, 908, 929, 936, 952, 958, 966, 978, 987, 998, 1009, 1017, 1039, 1049, 1057, 1069, 1075, 1090, 1105, 1112, 1119, 1125, 1152, 1159, 1169, 1180, 1188, 1195, 1206, 1217, 1231, 1241, 1250, 1257, 1268, 1283, 1307, 1324, 1352, 1360, 1367, 1373, 1382, 1389, 1399, 1412, 1419, 1430, 1439, 1448, 1461, 1469, 1480, 1486, 1503, 1513, 1535, 1543, 1562, 1584, 1591, 1597, 1615, 1622, 1630, 1637, 1643, 1655, 1676, 1705, 1716, 1731, 1739, 1745, 1753, 1760, 1769, 1783, 1797, 1809, 1818, 1825, 1836, 1858, 1865, 1873, 1894, 1914, 1931, 1945, 1952, 1973, 1984, 1994], deadline = 5)
        configuration.add_task(name="Task2", identifier=2, period=18.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=7.898827, acet=7.898827, et_stddev=2.6329423333333333, deadline= 34)
        configuration.add_task(name="Task4", identifier=4, period=18.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.825778, et_stddev=0.27525933333333336 , list_activation_dates=[5, 39, 58, 107, 131, 192, 242, 308, 354, 375, 401, 479, 503, 557, 598, 655, 680, 709, 741, 776, 812, 831, 850, 881, 900, 922, 944, 972, 999, 1026, 1047, 1094, 1139, 1158, 1177, 1211, 1243, 1263, 1289, 1316, 1366, 1414, 1450, 1470, 1510, 1541, 1560, 1586, 1607, 1637, 1660, 1689, 1709, 1727, 1753, 1773, 1799, 1819, 1840, 1868, 1890, 1924, 1971], deadline = 7)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "14")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "14")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "14")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "14")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task3", identifier=3, period=3.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=1.045644, acet=1.045644, et_stddev=0.348548, deadline= 6)
        configuration.add_task(name="Task6", identifier=6, period=2.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.025701, et_stddev=0.008567 , list_activation_dates=[6, 8, 13, 16, 20, 22, 26, 35, 40, 42, 51, 55, 58, 60, 62, 65, 68, 73, 75, 78, 81, 84, 89, 92, 95, 99, 102, 105, 110, 117, 121, 128, 132, 140, 142, 144, 150, 152, 155, 157, 161, 166, 170, 174, 177, 179, 187, 190, 193, 196, 199, 203, 209, 215, 217, 222, 236, 244, 247, 250, 253, 256, 258, 261, 264, 269, 272, 274, 277, 280, 289, 293, 297, 300, 303, 307, 312, 315, 317, 320, 324, 328, 332, 335, 338, 340, 349, 357, 360, 364, 367, 371, 379, 382, 389, 391, 393, 395, 398, 401, 404, 406, 415, 417, 425, 430, 437, 440, 444, 448, 453, 457, 459, 464, 466, 468, 476, 479, 484, 487, 492, 496, 502, 504, 508, 516, 520, 524, 529, 532, 535, 540, 547, 551, 556, 561, 567, 570, 573, 577, 580, 584, 592, 594, 598, 605, 612, 615, 618, 620, 623, 626, 629, 634, 639, 641, 643, 646, 649, 652, 655, 659, 662, 666, 669, 673, 677, 684, 686, 688, 691, 696, 709, 713, 715, 718, 723, 729, 734, 738, 740, 744, 746, 749, 753, 758, 761, 764, 766, 769, 771, 780, 783, 790, 792, 794, 797, 801, 805, 810, 813, 818, 821, 823, 827, 831, 835, 837, 840, 842, 845, 849, 852, 857, 859, 863, 866, 870, 874, 876, 881, 885, 891, 895, 898, 902, 904, 912, 918, 920, 924, 927, 929, 931, 934, 936, 939, 941, 944, 947, 953, 956, 964, 967, 977, 981, 984, 986, 988, 994, 997, 1007, 1012, 1019, 1022, 1025, 1027, 1032, 1038, 1043, 1046, 1053, 1059, 1064, 1066, 1071, 1073, 1076, 1083, 1085, 1089, 1091, 1096, 1098, 1102, 1106, 1111, 1114, 1117, 1121, 1125, 1129, 1132, 1134, 1140, 1143, 1145, 1152, 1155, 1158, 1164, 1166, 1170, 1172, 1185, 1188, 1193, 1198, 1200, 1206, 1216, 1218, 1221, 1225, 1230, 1232, 1235, 1237, 1241, 1243, 1248, 1250, 1252, 1259, 1263, 1267, 1272, 1274, 1278, 1280, 1282, 1284, 1286, 1297, 1300, 1303, 1307, 1310, 1315, 1318, 1321, 1324, 1327, 1329, 1332, 1334, 1336, 1340, 1344, 1349, 1352, 1355, 1359, 1364, 1367, 1371, 1373, 1376, 1383, 1391, 1401, 1405, 1410, 1412, 1414, 1416, 1418, 1421, 1424, 1428, 1431, 1433, 1441, 1450, 1454, 1456, 1459, 1463, 1467, 1469, 1471, 1476, 1479, 1481, 1483, 1489, 1494, 1497, 1500, 1506, 1513, 1520, 1526, 1529, 1532, 1537, 1540, 1544, 1546, 1551, 1554, 1557, 1564, 1574, 1577, 1579, 1585, 1587, 1591, 1595, 1603, 1607, 1609, 1611, 1615, 1618, 1620, 1623, 1630, 1634, 1636, 1639, 1644, 1646, 1649, 1657, 1661, 1665, 1668, 1670, 1675, 1680, 1682, 1685, 1688, 1692, 1695, 1698, 1700, 1704, 1708, 1711, 1713, 1717, 1720, 1728, 1730, 1732, 1735, 1737, 1742, 1747, 1749, 1751, 1756, 1759, 1762, 1766, 1772, 1777, 1779, 1784, 1788, 1792, 1795, 1798, 1801, 1811, 1817, 1823, 1826, 1828, 1831, 1834, 1836, 1839, 1843, 1846, 1849, 1851, 1856, 1860, 1862, 1865, 1870, 1875, 1878, 1881, 1884, 1886, 1891, 1895, 1901, 1906, 1916, 1928, 1931, 1933, 1937, 1939, 1943, 1949, 1954, 1958, 1963, 1966, 1969, 1972, 1974, 1977, 1980, 1982, 1986, 1988, 1991, 1993, 1999], deadline = 4)
        configuration.add_task(name="Task1", identifier=1, period=9.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=5.352484, acet=5.352484, et_stddev=1.7841613333333333, deadline= 14)
        configuration.add_task(name="Task4", identifier=4, period=1.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.168082, et_stddev=0.05602733333333334 , list_activation_dates=[1, 2, 4, 10, 11, 12, 13, 14, 15, 16, 18, 20, 22, 24, 27, 29, 31, 33, 34, 35, 37, 38, 39, 41, 43, 44, 48, 51, 53, 54, 55, 56, 58, 60, 62, 65, 70, 72, 73, 75, 78, 80, 82, 84, 85, 86, 88, 90, 93, 95, 96, 98, 99, 100, 101, 103, 105, 107, 111, 114, 116, 118, 120, 121, 123, 125, 127, 128, 129, 130, 134, 136, 138, 139, 140, 143, 145, 146, 148, 150, 151, 153, 154, 155, 157, 161, 163, 164, 168, 169, 173, 174, 175, 176, 182, 183, 185, 187, 189, 192, 193, 194, 195, 196, 198, 201, 205, 208, 210, 211, 212, 213, 216, 217, 220, 227, 232, 235, 237, 241, 242, 243, 246, 251, 252, 254, 255, 260, 262, 264, 265, 267, 268, 271, 274, 275, 277, 279, 281, 282, 287, 288, 289, 292, 293, 295, 298, 299, 301, 302, 304, 305, 310, 312, 314, 317, 318, 322, 324, 325, 330, 331, 333, 334, 335, 337, 343, 345, 347, 349, 351, 353, 356, 358, 360, 362, 364, 366, 368, 371, 372, 374, 375, 376, 379, 380, 383, 384, 387, 388, 390, 391, 394, 397, 401, 405, 406, 410, 412, 414, 415, 417, 418, 420, 423, 425, 426, 427, 429, 431, 432, 433, 436, 440, 442, 446, 448, 449, 451, 455, 457, 460, 461, 463, 464, 466, 468, 470, 473, 474, 475, 476, 478, 480, 481, 482, 483, 485, 490, 491, 493, 496, 499, 500, 501, 503, 506, 508, 510, 513, 515, 517, 518, 520, 522, 523, 527, 528, 530, 534, 535, 536, 538, 540, 542, 546, 548, 549, 550, 553, 555, 557, 558, 559, 560, 563, 565, 568, 569, 571, 573, 574, 576, 578, 579, 583, 584, 585, 586, 587, 588, 590, 591, 592, 593, 594, 596, 600, 601, 603, 605, 608, 611, 613, 615, 618, 619, 622, 626, 627, 629, 630, 635, 637, 638, 639, 641, 642, 644, 646, 647, 648, 649, 651, 655, 657, 659, 661, 663, 664, 665, 669, 671, 674, 675, 678, 681, 684, 685, 688, 689, 690, 693, 695, 698, 699, 702, 705, 707, 709, 713, 714, 715, 719, 724, 727, 728, 729, 732, 734, 735, 740, 741, 743, 745, 748, 749, 750, 752, 754, 757, 759, 761, 762, 767, 773, 774, 777, 778, 779, 781, 784, 786, 789, 790, 791, 793, 795, 799, 800, 802, 803, 804, 805, 807, 810, 811, 814, 815, 817, 818, 819, 821, 825, 826, 828, 830, 831, 832, 833, 835, 837, 838, 839, 842, 845, 847, 853, 856, 858, 859, 861, 862, 863, 865, 868, 870, 872, 875, 876, 881, 883, 885, 886, 890, 892, 893, 895, 897, 898, 900, 902, 904, 908, 910, 911, 912, 914, 915, 917, 921, 924, 926, 928, 929, 930, 932, 933, 935, 936, 938, 940, 943, 944, 946, 947, 949, 952, 955, 956, 960, 961, 962, 964, 965, 969, 973, 976, 977, 979, 981, 982, 986, 987, 989, 991, 994, 996, 997, 1000, 1001, 1002, 1004, 1005, 1006, 1011, 1014, 1015, 1017, 1019, 1021, 1022, 1024, 1025, 1026, 1027, 1028, 1029, 1031, 1035, 1036, 1037, 1041, 1044, 1046, 1050, 1052, 1054, 1055, 1057, 1059, 1061, 1063, 1066, 1067, 1069, 1070, 1072, 1073, 1074, 1075, 1076, 1077, 1081, 1082, 1085, 1087, 1088, 1090, 1093, 1094, 1095, 1101, 1102, 1103, 1106, 1107, 1110, 1112, 1113, 1116, 1117, 1119, 1121, 1124, 1127, 1129, 1132, 1134, 1135, 1137, 1138, 1139, 1141, 1142, 1145, 1146, 1148, 1150, 1152, 1153, 1158, 1159, 1160, 1162, 1165, 1167, 1168, 1169, 1171, 1173, 1175, 1178, 1180, 1182, 1184, 1186, 1188, 1189, 1191, 1195, 1197, 1198, 1201, 1203, 1205, 1206, 1208, 1209, 1210, 1211, 1213, 1215, 1217, 1219, 1223, 1224, 1225, 1227, 1228, 1231, 1232, 1234, 1237, 1241, 1243, 1245, 1247, 1249, 1252, 1254, 1256, 1258, 1260, 1262, 1263, 1264, 1265, 1269, 1271, 1275, 1277, 1279, 1283, 1285, 1287, 1288, 1291, 1294, 1295, 1297, 1298, 1301, 1302, 1303, 1306, 1307, 1308, 1311, 1313, 1314, 1315, 1317, 1319, 1321, 1323, 1325, 1327, 1328, 1330, 1333, 1334, 1336, 1337, 1339, 1342, 1343, 1345, 1347, 1348, 1349, 1351, 1354, 1356, 1357, 1359, 1361, 1362, 1364, 1367, 1368, 1370, 1371, 1373, 1374, 1375, 1377, 1378, 1383, 1384, 1386, 1388, 1390, 1391, 1392, 1394, 1398, 1401, 1403, 1404, 1406, 1407, 1410, 1411, 1413, 1414, 1415, 1416, 1417, 1418, 1421, 1422, 1424, 1425, 1426, 1428, 1430, 1431, 1433, 1434, 1436, 1437, 1438, 1439, 1440, 1443, 1445, 1449, 1450, 1451, 1453, 1455, 1456, 1457, 1458, 1460, 1461, 1464, 1467, 1468, 1470, 1473, 1475, 1477, 1479, 1480, 1482, 1485, 1487, 1488, 1490, 1491, 1492, 1498, 1501, 1503, 1504, 1505, 1507, 1509, 1512, 1514, 1518, 1519, 1520, 1521, 1522, 1525, 1527, 1529, 1531, 1532, 1533, 1535, 1536, 1537, 1543, 1546, 1548, 1549, 1550, 1552, 1555, 1556, 1558, 1560, 1561, 1562, 1564, 1566, 1568, 1569, 1571, 1574, 1576, 1578, 1581, 1582, 1584, 1586, 1588, 1589, 1590, 1591, 1592, 1593, 1594, 1596, 1598, 1600, 1601, 1602, 1604, 1608, 1609, 1611, 1613, 1616, 1619, 1622, 1623, 1625, 1630, 1634, 1635, 1639, 1641, 1642, 1643, 1645, 1647, 1649, 1652, 1654, 1655, 1656, 1657, 1659, 1661, 1663, 1665, 1667, 1671, 1672, 1675, 1676, 1677, 1679, 1681, 1682, 1685, 1688, 1691, 1692, 1697, 1699, 1700, 1701, 1702, 1703, 1704, 1706, 1707, 1709, 1711, 1713, 1715, 1716, 1718, 1719, 1721, 1724, 1726, 1727, 1728, 1730, 1732, 1735, 1737, 1739, 1740, 1742, 1743, 1744, 1746, 1748, 1749, 1751, 1752, 1754, 1756, 1760, 1762, 1763, 1764, 1765, 1767, 1769, 1770, 1774, 1776, 1778, 1780, 1781, 1782, 1783, 1785, 1787, 1790, 1791, 1792, 1793, 1796, 1797, 1799, 1801, 1803, 1804, 1806, 1808, 1812, 1814, 1816, 1821, 1824, 1826, 1828, 1830, 1836, 1840, 1845, 1846, 1849, 1851, 1852, 1854, 1856, 1858, 1859, 1861, 1863, 1865, 1867, 1869, 1870, 1871, 1874, 1875, 1877, 1879, 1880, 1882, 1883, 1884, 1885, 1886, 1888, 1889, 1891, 1892, 1893, 1895, 1899, 1901, 1903, 1905, 1906, 1907, 1909, 1910, 1912, 1914, 1915, 1917, 1918, 1919, 1920, 1922, 1924, 1926, 1927, 1930, 1932, 1935, 1938, 1939, 1941, 1943, 1945, 1947, 1948, 1949, 1951, 1952, 1953, 1954, 1955, 1956, 1957, 1958, 1961, 1963, 1964, 1966, 1971, 1972, 1974, 1976, 1979, 1981, 1983, 1986, 1987, 1989, 1991, 1992, 1994, 1995, 1997, 1998, 1999, 2000], deadline = 1)
        configuration.add_task(name="Task2", identifier=2, period=3.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=1.970193, acet=1.970193, et_stddev=0.6567310000000001, deadline= 2)
        configuration.add_task(name="Task5", identifier=5, period=1.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.019066, et_stddev=0.0063553333333333335 , list_activation_dates=[3, 5, 6, 9, 11, 14, 16, 18, 21, 22, 23, 25, 26, 27, 28, 31, 33, 35, 38, 39, 41, 43, 44, 49, 52, 53, 55, 56, 57, 59, 61, 62, 65, 67, 69, 71, 73, 74, 76, 77, 78, 79, 80, 82, 84, 85, 88, 92, 93, 98, 100, 102, 103, 106, 108, 110, 113, 115, 116, 117, 118, 120, 122, 123, 126, 128, 131, 133, 137, 141, 143, 145, 146, 151, 152, 155, 156, 157, 159, 160, 165, 167, 168, 169, 173, 176, 180, 182, 183, 186, 188, 189, 193, 194, 195, 197, 200, 202, 203, 209, 210, 212, 213, 214, 217, 218, 220, 222, 223, 225, 226, 228, 229, 234, 238, 239, 240, 241, 243, 244, 247, 249, 251, 254, 256, 257, 260, 262, 264, 265, 267, 269, 270, 273, 276, 279, 283, 284, 286, 287, 288, 289, 292, 294, 296, 297, 303, 304, 305, 307, 309, 310, 311, 314, 315, 317, 319, 321, 322, 324, 327, 329, 331, 333, 337, 339, 343, 344, 347, 350, 351, 354, 356, 360, 361, 362, 364, 365, 366, 367, 368, 369, 372, 373, 375, 376, 377, 379, 380, 382, 384, 385, 387, 389, 390, 392, 397, 399, 401, 402, 406, 408, 409, 411, 413, 414, 415, 416, 418, 420, 421, 422, 423, 424, 426, 429, 430, 432, 435, 436, 438, 440, 443, 446, 447, 448, 449, 451, 455, 459, 461, 463, 464, 466, 467, 468, 469, 470, 472, 473, 477, 479, 480, 482, 483, 484, 485, 487, 489, 492, 494, 497, 500, 502, 503, 504, 505, 507, 508, 509, 510, 513, 516, 518, 519, 520, 521, 523, 525, 528, 530, 532, 533, 535, 536, 538, 540, 542, 547, 548, 549, 550, 551, 552, 556, 560, 561, 562, 563, 565, 566, 567, 569, 571, 573, 575, 577, 580, 584, 585, 587, 588, 590, 592, 595, 597, 599, 602, 603, 604, 605, 606, 609, 611, 615, 617, 620, 622, 623, 626, 630, 631, 634, 635, 637, 641, 642, 644, 646, 649, 650, 652, 658, 661, 662, 664, 666, 668, 669, 673, 675, 678, 679, 680, 683, 686, 688, 690, 691, 693, 694, 695, 696, 699, 701, 704, 706, 708, 710, 711, 714, 717, 718, 721, 723, 724, 725, 727, 729, 731, 733, 735, 737, 740, 745, 747, 749, 750, 751, 753, 755, 756, 757, 758, 759, 762, 763, 768, 770, 772, 775, 776, 779, 780, 782, 783, 785, 787, 789, 790, 795, 797, 799, 800, 801, 803, 804, 805, 806, 808, 812, 816, 817, 818, 819, 820, 822, 824, 826, 828, 830, 835, 836, 838, 839, 842, 844, 846, 847, 850, 855, 857, 859, 862, 863, 865, 868, 869, 870, 871, 872, 875, 876, 878, 880, 881, 884, 888, 889, 891, 893, 895, 896, 897, 898, 899, 900, 902, 903, 905, 907, 911, 912, 914, 918, 921, 923, 925, 927, 928, 932, 933, 935, 937, 939, 941, 942, 943, 944, 946, 947, 950, 951, 954, 956, 959, 961, 965, 967, 968, 970, 972, 974, 976, 979, 980, 982, 984, 985, 986, 988, 990, 992, 993, 995, 996, 997, 998, 999, 1002, 1007, 1008, 1015, 1020, 1022, 1024, 1025, 1027, 1028, 1030, 1032, 1035, 1037, 1038, 1039, 1040, 1042, 1043, 1044, 1046, 1048, 1050, 1051, 1052, 1053, 1056, 1057, 1059, 1060, 1061, 1062, 1064, 1066, 1069, 1071, 1073, 1074, 1077, 1082, 1084, 1086, 1088, 1090, 1092, 1093, 1094, 1096, 1100, 1101, 1103, 1104, 1105, 1108, 1109, 1113, 1115, 1117, 1120, 1122, 1125, 1127, 1129, 1131, 1135, 1137, 1140, 1142, 1145, 1148, 1150, 1151, 1152, 1153, 1154, 1155, 1156, 1157, 1159, 1161, 1162, 1165, 1166, 1167, 1168, 1169, 1170, 1171, 1172, 1174, 1175, 1177, 1178, 1179, 1182, 1184, 1185, 1187, 1189, 1192, 1194, 1198, 1200, 1205, 1206, 1208, 1210, 1214, 1217, 1221, 1222, 1224, 1225, 1226, 1228, 1230, 1233, 1235, 1236, 1238, 1240, 1242, 1245, 1247, 1251, 1253, 1255, 1256, 1259, 1261, 1262, 1266, 1267, 1270, 1271, 1272, 1273, 1274, 1275, 1276, 1277, 1279, 1281, 1283, 1285, 1288, 1289, 1293, 1295, 1297, 1299, 1300, 1304, 1307, 1308, 1309, 1310, 1313, 1314, 1316, 1318, 1321, 1323, 1324, 1327, 1330, 1332, 1336, 1340, 1342, 1344, 1346, 1347, 1351, 1353, 1355, 1356, 1358, 1361, 1366, 1367, 1371, 1373, 1376, 1377, 1379, 1380, 1381, 1382, 1385, 1387, 1391, 1393, 1394, 1396, 1397, 1399, 1400, 1403, 1405, 1407, 1408, 1409, 1411, 1412, 1415, 1416, 1418, 1420, 1421, 1423, 1424, 1425, 1426, 1429, 1431, 1432, 1433, 1436, 1438, 1440, 1441, 1443, 1446, 1449, 1452, 1453, 1457, 1458, 1459, 1460, 1463, 1465, 1466, 1467, 1470, 1472, 1473, 1474, 1475, 1477, 1479, 1480, 1481, 1485, 1486, 1487, 1489, 1494, 1496, 1497, 1498, 1500, 1501, 1502, 1506, 1507, 1508, 1509, 1510, 1514, 1515, 1516, 1518, 1521, 1528, 1529, 1531, 1532, 1534, 1535, 1536, 1538, 1541, 1542, 1544, 1546, 1548, 1549, 1550, 1551, 1553, 1554, 1556, 1557, 1559, 1561, 1563, 1565, 1568, 1569, 1571, 1573, 1576, 1577, 1579, 1580, 1581, 1583, 1584, 1586, 1588, 1591, 1592, 1594, 1597, 1600, 1601, 1604, 1606, 1612, 1613, 1614, 1617, 1618, 1620, 1622, 1623, 1626, 1628, 1633, 1635, 1636, 1638, 1642, 1643, 1644, 1647, 1649, 1650, 1652, 1654, 1656, 1657, 1659, 1660, 1661, 1662, 1663, 1664, 1665, 1666, 1667, 1669, 1671, 1672, 1674, 1676, 1678, 1680, 1682, 1684, 1687, 1688, 1691, 1692, 1693, 1695, 1696, 1697, 1698, 1700, 1703, 1705, 1708, 1709, 1711, 1712, 1714, 1715, 1717, 1718, 1719, 1720, 1724, 1726, 1729, 1730, 1732, 1734, 1736, 1738, 1739, 1740, 1741, 1743, 1744, 1746, 1747, 1749, 1751, 1752, 1755, 1759, 1760, 1762, 1763, 1764, 1765, 1766, 1768, 1770, 1771, 1773, 1775, 1776, 1778, 1783, 1784, 1785, 1786, 1787, 1791, 1793, 1795, 1796, 1798, 1803, 1805, 1806, 1808, 1809, 1810, 1812, 1814, 1815, 1817, 1818, 1819, 1822, 1824, 1827, 1828, 1829, 1830, 1834, 1837, 1839, 1840, 1841, 1843, 1847, 1849, 1850, 1854, 1855, 1856, 1858, 1860, 1862, 1864, 1865, 1867, 1870, 1876, 1879, 1881, 1882, 1884, 1885, 1891, 1893, 1895, 1897, 1898, 1899, 1900, 1904, 1906, 1909, 1910, 1911, 1913, 1916, 1918, 1919, 1924, 1928, 1929, 1930, 1931, 1932, 1933, 1934, 1935, 1936, 1937, 1938, 1939, 1940, 1942, 1943, 1945, 1948, 1950, 1952, 1953, 1955, 1957, 1959, 1960, 1965, 1968, 1973, 1975, 1978, 1980, 1981, 1982, 1984, 1986, 1987, 1989, 1991, 1993, 1994, 1996, 1997, 2000], deadline = 1)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "15")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "15")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "15")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "15")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task3", identifier=3, period=6.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=5.394653, acet=5.394653, et_stddev=1.7982176666666667, deadline= 12)
        configuration.add_task(name="Task6", identifier=6, period=1.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.019342, et_stddev=0.0064473333333333336 , list_activation_dates=[2, 5, 7, 8, 10, 11, 16, 17, 18, 22, 23, 27, 29, 34, 38, 42, 44, 46, 48, 54, 56, 58, 59, 61, 63, 64, 66, 67, 69, 71, 73, 75, 77, 78, 79, 82, 83, 85, 87, 89, 91, 92, 94, 96, 98, 101, 103, 104, 106, 107, 109, 110, 111, 113, 114, 115, 118, 120, 122, 126, 128, 130, 133, 134, 136, 138, 144, 145, 147, 148, 149, 150, 151, 152, 155, 156, 157, 158, 159, 161, 162, 163, 165, 168, 170, 171, 174, 179, 183, 185, 186, 187, 189, 191, 194, 197, 199, 201, 203, 204, 206, 208, 211, 213, 215, 216, 217, 218, 219, 221, 222, 223, 225, 227, 231, 233, 234, 235, 238, 241, 247, 250, 252, 253, 257, 260, 262, 264, 265, 266, 268, 269, 271, 273, 274, 275, 276, 277, 278, 280, 282, 283, 284, 285, 288, 291, 293, 294, 296, 300, 302, 304, 306, 309, 310, 312, 315, 316, 318, 321, 323, 324, 326, 329, 330, 332, 333, 336, 337, 339, 341, 344, 346, 349, 351, 353, 355, 356, 357, 359, 361, 363, 364, 367, 371, 372, 373, 374, 376, 377, 380, 382, 384, 385, 386, 388, 390, 391, 393, 394, 395, 397, 399, 401, 403, 404, 406, 408, 409, 411, 413, 415, 417, 419, 420, 421, 426, 428, 431, 433, 436, 437, 439, 441, 446, 447, 449, 451, 452, 454, 457, 462, 464, 467, 473, 474, 476, 479, 480, 481, 483, 486, 488, 489, 495, 496, 498, 502, 505, 506, 508, 514, 517, 519, 520, 521, 522, 523, 524, 526, 528, 529, 532, 533, 537, 540, 542, 544, 545, 550, 552, 554, 556, 557, 562, 564, 565, 566, 568, 569, 571, 574, 577, 578, 579, 581, 582, 584, 587, 590, 592, 594, 596, 597, 598, 602, 607, 608, 609, 611, 612, 614, 618, 619, 620, 622, 624, 625, 626, 628, 629, 631, 633, 635, 636, 640, 642, 645, 647, 649, 650, 652, 654, 656, 657, 659, 660, 664, 666, 667, 668, 671, 673, 674, 676, 677, 679, 682, 684, 685, 687, 690, 693, 694, 698, 700, 702, 703, 707, 711, 713, 715, 718, 720, 724, 725, 727, 729, 730, 731, 734, 735, 736, 740, 741, 743, 745, 747, 751, 753, 758, 761, 763, 765, 767, 768, 769, 771, 772, 774, 775, 781, 783, 785, 787, 790, 795, 796, 798, 799, 802, 804, 806, 807, 808, 811, 813, 814, 819, 821, 822, 823, 825, 827, 831, 832, 833, 834, 835, 836, 837, 840, 841, 843, 845, 846, 847, 849, 850, 855, 857, 861, 865, 867, 872, 874, 875, 876, 878, 879, 881, 882, 883, 887, 888, 891, 896, 897, 898, 899, 900, 901, 903, 905, 908, 910, 911, 912, 913, 914, 915, 916, 920, 922, 925, 929, 931, 933, 935, 939, 941, 944, 946, 947, 952, 953, 954, 958, 959, 960, 962, 964, 966, 969, 970, 971, 973, 974, 977, 980, 982, 983, 987, 991, 996, 998, 999, 1001, 1002, 1003, 1006, 1008, 1009, 1010, 1011, 1012, 1013, 1014, 1016, 1017, 1019, 1022, 1023, 1025, 1027, 1028, 1029, 1031, 1034, 1037, 1038, 1040, 1042, 1043, 1044, 1045, 1047, 1048, 1050, 1051, 1053, 1054, 1056, 1057, 1059, 1060, 1064, 1065, 1066, 1069, 1071, 1073, 1076, 1079, 1081, 1082, 1083, 1084, 1085, 1086, 1087, 1090, 1092, 1093, 1095, 1096, 1097, 1098, 1101, 1103, 1104, 1108, 1109, 1110, 1111, 1112, 1115, 1118, 1119, 1120, 1122, 1126, 1129, 1130, 1133, 1134, 1135, 1136, 1138, 1139, 1144, 1146, 1147, 1149, 1151, 1154, 1157, 1159, 1160, 1161, 1164, 1166, 1168, 1170, 1171, 1172, 1174, 1176, 1178, 1180, 1181, 1184, 1186, 1188, 1189, 1191, 1194, 1196, 1199, 1200, 1202, 1204, 1207, 1208, 1209, 1213, 1214, 1218, 1220, 1221, 1222, 1224, 1227, 1228, 1230, 1231, 1235, 1236, 1238, 1240, 1242, 1244, 1248, 1250, 1253, 1255, 1257, 1259, 1260, 1263, 1264, 1266, 1267, 1269, 1270, 1272, 1273, 1276, 1278, 1279, 1282, 1283, 1284, 1285, 1286, 1288, 1289, 1290, 1291, 1293, 1294, 1297, 1300, 1301, 1302, 1303, 1304, 1307, 1309, 1310, 1311, 1315, 1316, 1317, 1319, 1321, 1323, 1325, 1327, 1329, 1331, 1333, 1334, 1337, 1339, 1341, 1343, 1346, 1348, 1351, 1353, 1354, 1357, 1365, 1366, 1368, 1369, 1375, 1377, 1378, 1379, 1383, 1385, 1387, 1389, 1390, 1392, 1393, 1394, 1396, 1398, 1399, 1401, 1405, 1406, 1408, 1412, 1416, 1417, 1419, 1421, 1423, 1425, 1426, 1427, 1430, 1432, 1433, 1436, 1438, 1439, 1443, 1444, 1446, 1449, 1451, 1453, 1455, 1456, 1457, 1458, 1460, 1462, 1465, 1467, 1468, 1469, 1471, 1474, 1475, 1476, 1478, 1479, 1480, 1481, 1484, 1486, 1487, 1488, 1492, 1493, 1495, 1496, 1498, 1499, 1502, 1503, 1505, 1506, 1511, 1512, 1517, 1520, 1522, 1523, 1525, 1527, 1529, 1530, 1532, 1535, 1537, 1539, 1541, 1542, 1544, 1552, 1554, 1557, 1558, 1559, 1561, 1562, 1564, 1565, 1567, 1568, 1569, 1575, 1577, 1578, 1580, 1581, 1583, 1585, 1587, 1591, 1593, 1594, 1596, 1598, 1599, 1601, 1603, 1605, 1610, 1611, 1612, 1614, 1617, 1619, 1623, 1625, 1626, 1628, 1630, 1633, 1634, 1635, 1637, 1638, 1641, 1643, 1645, 1647, 1648, 1650, 1653, 1655, 1657, 1659, 1660, 1662, 1664, 1665, 1666, 1667, 1668, 1669, 1671, 1673, 1677, 1678, 1679, 1681, 1683, 1684, 1685, 1686, 1687, 1689, 1690, 1693, 1695, 1698, 1700, 1702, 1708, 1710, 1713, 1715, 1716, 1717, 1721, 1723, 1725, 1726, 1728, 1729, 1730, 1731, 1733, 1735, 1736, 1738, 1742, 1744, 1746, 1748, 1749, 1751, 1753, 1757, 1759, 1760, 1762, 1765, 1768, 1770, 1771, 1773, 1776, 1777, 1781, 1784, 1786, 1788, 1790, 1792, 1793, 1795, 1797, 1799, 1802, 1804, 1807, 1809, 1810, 1813, 1814, 1816, 1817, 1819, 1820, 1821, 1823, 1827, 1831, 1833, 1834, 1835, 1836, 1838, 1839, 1841, 1843, 1844, 1847, 1849, 1851, 1852, 1854, 1856, 1858, 1860, 1861, 1863, 1864, 1867, 1869, 1870, 1872, 1873, 1877, 1878, 1881, 1883, 1884, 1885, 1889, 1892, 1894, 1897, 1898, 1902, 1904, 1905, 1907, 1908, 1911, 1913, 1914, 1919, 1920, 1924, 1926, 1929, 1930, 1934, 1942, 1943, 1946, 1947, 1949, 1952, 1955, 1956, 1960, 1963, 1967, 1968, 1969, 1970, 1972, 1973, 1975, 1976, 1978, 1980, 1982, 1985, 1987, 1988, 1989, 1991, 1992, 1993, 1995, 1997, 1999], deadline = 2)
        configuration.add_task(name="Task4", identifier=4, period=11.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=2, acet=1.836113, et_stddev=0.6120376666666667 , list_activation_dates=[18, 67, 90, 116, 138, 154, 180, 216, 228, 244, 274, 298, 319, 338, 386, 397, 408, 424, 446, 458, 471, 512, 529, 550, 570, 595, 629, 660, 673, 686, 711, 723, 736, 772, 789, 825, 844, 857, 875, 887, 907, 926, 964, 975, 1004, 1018, 1050, 1069, 1086, 1106, 1134, 1166, 1195, 1207, 1224, 1247, 1262, 1278, 1323, 1341, 1367, 1387, 1423, 1451, 1464, 1481, 1493, 1512, 1524, 1546, 1558, 1576, 1594, 1610, 1624, 1644, 1657, 1671, 1713, 1732, 1763, 1787, 1804, 1815, 1846, 1864, 1880, 1944, 1956, 1984], deadline = 15)
        configuration.add_task(name="Task2", identifier=2, period=1.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=0.138991, acet=0.138991, et_stddev=0.046330333333333334, deadline= 1)
        configuration.add_task(name="Task1", identifier=1, period=3.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=1.685697, acet=1.685697, et_stddev=0.561899, deadline= 5)
        configuration.add_task(name="Task5", identifier=5, period=3.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.041214, et_stddev=0.013738 , list_activation_dates=[3, 7, 12, 17, 24, 27, 32, 36, 39, 43, 50, 56, 60, 73, 77, 81, 85, 89, 103, 107, 112, 125, 129, 134, 139, 148, 156, 160, 165, 168, 172, 176, 184, 191, 194, 200, 203, 211, 215, 219, 224, 232, 236, 242, 248, 255, 260, 267, 278, 287, 293, 299, 305, 309, 325, 329, 335, 343, 347, 362, 370, 376, 379, 383, 386, 404, 407, 415, 419, 423, 427, 432, 436, 439, 443, 447, 456, 464, 471, 479, 488, 493, 499, 503, 507, 511, 517, 520, 528, 535, 538, 544, 547, 565, 577, 584, 593, 597, 601, 616, 624, 629, 632, 637, 648, 651, 654, 667, 670, 677, 682, 690, 694, 699, 705, 711, 715, 718, 721, 726, 732, 737, 743, 748, 753, 757, 769, 776, 779, 785, 789, 798, 807, 812, 824, 830, 838, 841, 848, 851, 858, 862, 867, 870, 875, 880, 884, 892, 895, 904, 907, 911, 914, 918, 924, 930, 935, 940, 943, 947, 955, 958, 962, 967, 971, 980, 985, 989, 995, 1002, 1005, 1010, 1015, 1019, 1024, 1029, 1034, 1037, 1045, 1051, 1055, 1058, 1062, 1068, 1071, 1076, 1080, 1087, 1092, 1097, 1110, 1117, 1126, 1129, 1133, 1137, 1142, 1147, 1155, 1160, 1163, 1176, 1179, 1185, 1189, 1193, 1197, 1202, 1207, 1213, 1223, 1228, 1240, 1245, 1249, 1253, 1257, 1265, 1269, 1273, 1281, 1288, 1306, 1310, 1315, 1320, 1323, 1331, 1337, 1340, 1343, 1351, 1356, 1360, 1364, 1370, 1373, 1378, 1386, 1390, 1393, 1396, 1403, 1410, 1426, 1436, 1440, 1444, 1447, 1455, 1467, 1471, 1476, 1490, 1494, 1497, 1503, 1507, 1511, 1514, 1518, 1521, 1531, 1542, 1546, 1554, 1560, 1567, 1573, 1579, 1584, 1591, 1594, 1598, 1603, 1606, 1610, 1615, 1622, 1626, 1632, 1641, 1646, 1649, 1656, 1660, 1664, 1669, 1675, 1678, 1683, 1687, 1692, 1703, 1706, 1715, 1720, 1723, 1728, 1735, 1739, 1746, 1755, 1758, 1761, 1766, 1772, 1776, 1781, 1787, 1793, 1798, 1803, 1809, 1817, 1822, 1827, 1832, 1835, 1840, 1844, 1850, 1854, 1861, 1866, 1872, 1880, 1890, 1894, 1898, 1902, 1910, 1914, 1920, 1931, 1934, 1938, 1943, 1947, 1959, 1963, 1969, 1972, 1991, 1994, 1998], deadline = 3)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "17")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "17")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "17")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "17")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)


import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task3", identifier=3, period=9.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=7.212465, acet=7.212465, et_stddev=2.404155, deadline= 10)
        configuration.add_task(name="Task2", identifier=2, period=4.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=2.490024, acet=2.490024, et_stddev=0.830008, deadline= 8)
        configuration.add_task(name="Task5", identifier=5, period=2.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.057107, et_stddev=0.019035666666666666 , list_activation_dates=[2, 4, 6, 12, 18, 26, 28, 31, 33, 36, 40, 44, 48, 50, 53, 57, 59, 63, 68, 71, 73, 76, 81, 88, 102, 114, 119, 121, 123, 126, 128, 132, 134, 138, 141, 143, 147, 150, 153, 157, 161, 164, 170, 173, 176, 182, 187, 191, 199, 201, 210, 212, 214, 218, 221, 225, 230, 233, 238, 240, 246, 250, 252, 256, 259, 263, 268, 271, 273, 281, 286, 288, 290, 296, 300, 307, 314, 316, 320, 325, 327, 334, 339, 341, 344, 346, 351, 354, 357, 368, 372, 376, 380, 383, 387, 393, 396, 400, 406, 408, 412, 417, 421, 426, 431, 434, 440, 445, 450, 453, 455, 459, 461, 468, 472, 474, 476, 478, 481, 485, 487, 489, 491, 495, 497, 499, 503, 507, 514, 519, 522, 525, 533, 536, 539, 542, 545, 547, 551, 553, 558, 560, 565, 572, 577, 580, 593, 596, 603, 606, 609, 614, 621, 623, 626, 629, 632, 640, 642, 647, 650, 653, 656, 662, 666, 669, 676, 679, 684, 687, 690, 700, 703, 705, 707, 710, 715, 721, 725, 728, 730, 732, 735, 740, 753, 759, 764, 770, 772, 776, 779, 782, 786, 789, 795, 799, 802, 804, 807, 809, 813, 816, 819, 822, 825, 828, 831, 838, 842, 846, 854, 857, 859, 867, 873, 877, 881, 883, 889, 893, 895, 899, 902, 905, 907, 909, 912, 917, 919, 922, 930, 932, 936, 942, 951, 953, 955, 961, 977, 981, 984, 987, 993, 1001, 1006, 1012, 1017, 1021, 1024, 1027, 1035, 1037, 1044, 1051, 1054, 1060, 1066, 1069, 1071, 1075, 1081, 1084, 1086, 1089, 1091, 1094, 1096, 1099, 1106, 1111, 1114, 1121, 1129, 1133, 1135, 1138, 1143, 1147, 1154, 1158, 1161, 1167, 1170, 1173, 1178, 1182, 1186, 1188, 1190, 1192, 1196, 1205, 1209, 1213, 1216, 1219, 1222, 1225, 1228, 1230, 1232, 1237, 1240, 1242, 1244, 1246, 1252, 1255, 1257, 1260, 1264, 1269, 1272, 1275, 1278, 1282, 1284, 1287, 1289, 1291, 1294, 1298, 1303, 1305, 1315, 1319, 1322, 1326, 1329, 1334, 1338, 1341, 1347, 1355, 1362, 1368, 1371, 1375, 1378, 1381, 1385, 1387, 1392, 1395, 1398, 1402, 1407, 1409, 1414, 1418, 1423, 1426, 1428, 1432, 1435, 1440, 1443, 1447, 1450, 1452, 1456, 1460, 1462, 1468, 1470, 1475, 1479, 1486, 1492, 1494, 1497, 1499, 1501, 1509, 1513, 1517, 1519, 1523, 1525, 1527, 1530, 1533, 1536, 1539, 1542, 1545, 1549, 1552, 1556, 1561, 1565, 1567, 1569, 1578, 1585, 1588, 1594, 1597, 1601, 1605, 1608, 1615, 1623, 1627, 1630, 1632, 1635, 1644, 1647, 1650, 1654, 1656, 1660, 1666, 1669, 1671, 1674, 1678, 1682, 1685, 1694, 1704, 1709, 1714, 1716, 1721, 1724, 1726, 1736, 1740, 1744, 1749, 1751, 1755, 1759, 1766, 1769, 1775, 1777, 1779, 1782, 1788, 1790, 1797, 1800, 1805, 1813, 1816, 1820, 1822, 1824, 1827, 1830, 1832, 1835, 1838, 1842, 1846, 1850, 1854, 1860, 1863, 1865, 1874, 1876, 1878, 1884, 1887, 1890, 1898, 1901, 1903, 1905, 1908, 1914, 1916, 1918, 1922, 1928, 1931, 1935, 1939, 1946, 1948, 1955, 1959, 1962, 1965, 1969, 1974, 1978, 1980, 1982, 1988, 1991, 1994], deadline = 4)
        configuration.add_task(name="Task4", identifier=4, period=2.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.127862, et_stddev=0.04262066666666667 , list_activation_dates=[4, 7, 15, 24, 29, 36, 41, 44, 48, 51, 54, 58, 61, 64, 66, 71, 75, 79, 82, 86, 91, 93, 96, 98, 100, 104, 107, 110, 117, 119, 121, 125, 131, 134, 143, 146, 149, 154, 159, 164, 167, 169, 171, 174, 178, 180, 183, 190, 193, 197, 204, 208, 211, 222, 225, 228, 230, 233, 241, 246, 248, 253, 255, 265, 270, 272, 274, 278, 282, 284, 286, 289, 295, 300, 305, 307, 312, 321, 324, 328, 335, 341, 345, 347, 351, 362, 370, 373, 375, 379, 382, 386, 393, 396, 399, 403, 409, 412, 415, 420, 423, 430, 432, 437, 442, 450, 453, 456, 461, 464, 467, 469, 473, 476, 480, 484, 486, 488, 491, 494, 497, 500, 502, 505, 509, 512, 516, 521, 524, 528, 536, 540, 543, 547, 551, 556, 560, 562, 566, 571, 576, 580, 583, 592, 594, 596, 598, 602, 604, 608, 614, 617, 620, 622, 629, 633, 636, 640, 646, 650, 654, 657, 662, 664, 671, 676, 680, 682, 686, 688, 696, 699, 704, 707, 710, 713, 716, 718, 721, 726, 729, 732, 736, 742, 747, 754, 756, 764, 768, 771, 776, 779, 785, 796, 802, 804, 808, 810, 814, 816, 819, 823, 826, 830, 839, 842, 845, 850, 853, 855, 857, 860, 866, 868, 873, 875, 877, 884, 886, 889, 892, 894, 897, 900, 902, 905, 909, 911, 915, 917, 925, 929, 932, 937, 939, 942, 950, 952, 959, 962, 966, 969, 978, 981, 983, 987, 990, 994, 997, 999, 1003, 1007, 1009, 1012, 1014, 1018, 1021, 1024, 1027, 1032, 1036, 1041, 1049, 1051, 1053, 1056, 1058, 1060, 1069, 1079, 1084, 1088, 1092, 1097, 1103, 1108, 1113, 1116, 1122, 1134, 1138, 1140, 1144, 1148, 1151, 1157, 1163, 1166, 1174, 1177, 1180, 1190, 1194, 1197, 1199, 1208, 1210, 1212, 1215, 1224, 1226, 1229, 1235, 1237, 1239, 1248, 1250, 1252, 1256, 1258, 1261, 1264, 1271, 1273, 1278, 1282, 1287, 1291, 1294, 1297, 1300, 1305, 1308, 1310, 1315, 1319, 1324, 1330, 1339, 1343, 1345, 1347, 1352, 1357, 1360, 1363, 1369, 1374, 1379, 1384, 1387, 1390, 1394, 1397, 1400, 1403, 1408, 1412, 1416, 1418, 1420, 1423, 1425, 1440, 1449, 1453, 1458, 1462, 1464, 1467, 1472, 1476, 1480, 1483, 1490, 1495, 1498, 1502, 1505, 1508, 1510, 1514, 1522, 1525, 1529, 1532, 1539, 1543, 1546, 1549, 1551, 1553, 1556, 1561, 1564, 1566, 1574, 1577, 1579, 1583, 1585, 1588, 1591, 1594, 1596, 1599, 1602, 1609, 1613, 1621, 1630, 1641, 1644, 1649, 1651, 1655, 1657, 1662, 1670, 1674, 1678, 1681, 1683, 1686, 1689, 1695, 1697, 1702, 1704, 1709, 1714, 1716, 1721, 1725, 1728, 1732, 1735, 1745, 1753, 1755, 1761, 1764, 1767, 1769, 1772, 1777, 1779, 1782, 1786, 1789, 1793, 1795, 1800, 1809, 1813, 1816, 1819, 1822, 1824, 1826, 1839, 1842, 1847, 1850, 1863, 1866, 1869, 1872, 1876, 1880, 1882, 1884, 1888, 1891, 1901, 1908, 1912, 1915, 1919, 1925, 1928, 1930, 1933, 1936, 1941, 1943, 1946, 1954, 1957, 1967, 1970, 1974, 1978, 1982, 1985, 1994, 2000], deadline = 2)
        configuration.add_task(name="Task6", identifier=6, period=18.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=2, acet=1.935267, et_stddev=0.645089 , list_activation_dates=[5, 28, 72, 92, 111, 146, 164, 194, 246, 266, 293, 364, 385, 405, 433, 493, 571, 604, 635, 662, 685, 707, 770, 799, 823, 852, 878, 901, 962, 993, 1034, 1058, 1126, 1166, 1185, 1211, 1263, 1286, 1343, 1366, 1389, 1430, 1453, 1473, 1493, 1511, 1530, 1555, 1591, 1610, 1655, 1701, 1756, 1792, 1831, 1869, 1888, 1925, 1958], deadline = 20)
        configuration.add_task(name="Task1", identifier=1, period=1.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=0.176108, acet=0.176108, et_stddev=0.05870266666666666, deadline= 2)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "19")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "19")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "19")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "19")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task5", identifier=5, period=2.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.067571, et_stddev=0.022523666666666668 , list_activation_dates=[4, 7, 9, 12, 15, 19, 21, 26, 28, 31, 35, 40, 42, 44, 48, 51, 61, 69, 71, 79, 81, 85, 87, 89, 94, 97, 102, 107, 109, 111, 113, 115, 120, 124, 127, 130, 133, 139, 143, 146, 151, 153, 156, 159, 161, 164, 167, 170, 174, 177, 182, 184, 189, 191, 194, 196, 202, 204, 208, 213, 216, 220, 223, 226, 229, 231, 235, 241, 243, 246, 252, 254, 263, 266, 271, 279, 290, 298, 301, 304, 306, 311, 313, 315, 318, 326, 329, 332, 334, 342, 345, 348, 355, 359, 361, 364, 366, 370, 373, 376, 380, 386, 393, 398, 403, 406, 409, 412, 414, 417, 420, 422, 425, 429, 431, 433, 437, 440, 444, 448, 452, 457, 459, 462, 469, 472, 475, 479, 482, 486, 489, 493, 498, 502, 506, 509, 512, 515, 517, 522, 530, 534, 536, 539, 542, 544, 550, 552, 556, 561, 565, 570, 577, 579, 586, 591, 595, 597, 602, 606, 609, 612, 617, 620, 623, 626, 631, 633, 639, 641, 643, 646, 650, 654, 659, 664, 669, 673, 675, 678, 680, 682, 688, 690, 695, 698, 700, 703, 705, 707, 709, 714, 717, 720, 722, 724, 727, 734, 741, 751, 753, 756, 758, 761, 763, 767, 770, 772, 779, 782, 787, 790, 797, 799, 802, 809, 818, 821, 826, 831, 833, 835, 839, 842, 844, 850, 857, 861, 864, 866, 870, 872, 875, 877, 879, 883, 890, 897, 900, 902, 908, 910, 916, 919, 924, 927, 931, 934, 936, 939, 941, 950, 953, 957, 960, 962, 969, 974, 977, 979, 985, 987, 989, 996, 999, 1001, 1003, 1006, 1011, 1020, 1022, 1026, 1030, 1033, 1039, 1042, 1045, 1048, 1053, 1057, 1068, 1072, 1076, 1080, 1082, 1085, 1088, 1091, 1097, 1103, 1109, 1113, 1117, 1126, 1129, 1132, 1136, 1139, 1142, 1148, 1154, 1158, 1160, 1162, 1165, 1169, 1173, 1175, 1179, 1183, 1187, 1189, 1194, 1198, 1202, 1209, 1213, 1215, 1219, 1224, 1230, 1233, 1235, 1243, 1246, 1248, 1251, 1254, 1256, 1259, 1263, 1267, 1270, 1273, 1280, 1283, 1287, 1290, 1293, 1298, 1304, 1309, 1311, 1313, 1320, 1323, 1327, 1331, 1334, 1336, 1344, 1347, 1350, 1354, 1358, 1362, 1366, 1368, 1372, 1376, 1379, 1382, 1385, 1391, 1394, 1400, 1404, 1407, 1410, 1418, 1421, 1428, 1430, 1435, 1440, 1444, 1447, 1450, 1454, 1457, 1459, 1463, 1471, 1475, 1478, 1480, 1482, 1485, 1488, 1491, 1493, 1496, 1500, 1503, 1505, 1510, 1512, 1514, 1517, 1525, 1528, 1531, 1540, 1543, 1547, 1551, 1561, 1574, 1577, 1579, 1581, 1583, 1585, 1593, 1601, 1604, 1609, 1612, 1620, 1624, 1627, 1632, 1641, 1643, 1647, 1650, 1657, 1666, 1672, 1675, 1680, 1683, 1685, 1688, 1695, 1697, 1699, 1701, 1703, 1705, 1710, 1715, 1717, 1726, 1728, 1732, 1734, 1746, 1749, 1757, 1760, 1765, 1768, 1771, 1773, 1776, 1780, 1782, 1786, 1792, 1798, 1804, 1807, 1812, 1816, 1819, 1824, 1830, 1832, 1836, 1839, 1841, 1846, 1849, 1853, 1857, 1861, 1864, 1867, 1870, 1873, 1876, 1878, 1883, 1886, 1889, 1892, 1901, 1903, 1907, 1909, 1915, 1918, 1921, 1926, 1928, 1932, 1937, 1939, 1943, 1950, 1955, 1957, 1959, 1965, 1975, 1977, 1980, 1982, 1985, 1989, 1993, 1995], deadline = 1)
        configuration.add_task(name="Task2", identifier=2, period=2.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=1.396438, acet=1.396438, et_stddev=0.46547933333333336, deadline= 2)
        configuration.add_task(name="Task3", identifier=3, period=32.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=3.153756, acet=3.153756, et_stddev=1.051252, deadline= 39)
        configuration.add_task(name="Task6", identifier=6, period=11.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=2, acet=1.534913, et_stddev=0.5116376666666667 , list_activation_dates=[6, 22, 68, 85, 96, 126, 151, 169, 182, 201, 227, 239, 257, 298, 310, 328, 346, 363, 390, 402, 418, 430, 460, 480, 491, 505, 530, 553, 565, 591, 605, 648, 660, 676, 688, 701, 716, 738, 751, 775, 797, 828, 866, 894, 939, 960, 980, 997, 1011, 1024, 1044, 1061, 1085, 1104, 1152, 1173, 1197, 1218, 1233, 1249, 1274, 1291, 1313, 1328, 1361, 1378, 1394, 1412, 1425, 1440, 1460, 1475, 1487, 1506, 1563, 1577, 1591, 1607, 1657, 1672, 1683, 1699, 1710, 1735, 1752, 1776, 1794, 1829, 1844, 1857, 1883, 1895, 1910, 1924, 1935, 1951, 1965, 1979], deadline = 3)
        configuration.add_task(name="Task4", identifier=4, period=2.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.053353, et_stddev=0.017784333333333333 , list_activation_dates=[4, 8, 11, 14, 16, 20, 26, 32, 35, 38, 43, 45, 51, 54, 57, 63, 66, 73, 78, 81, 84, 87, 90, 96, 101, 105, 108, 113, 117, 126, 129, 132, 141, 145, 150, 156, 164, 168, 170, 173, 181, 184, 187, 191, 195, 202, 205, 209, 211, 217, 219, 223, 226, 229, 238, 246, 249, 253, 256, 259, 267, 271, 274, 277, 285, 287, 290, 292, 295, 297, 302, 306, 308, 312, 316, 320, 323, 326, 328, 333, 339, 341, 348, 352, 356, 360, 362, 365, 368, 370, 376, 384, 391, 395, 399, 415, 417, 420, 424, 431, 433, 435, 437, 440, 443, 445, 449, 452, 455, 459, 463, 469, 477, 480, 483, 487, 492, 497, 502, 505, 508, 510, 513, 517, 519, 525, 529, 532, 535, 538, 546, 550, 554, 559, 565, 571, 573, 577, 582, 585, 587, 591, 595, 597, 601, 604, 608, 610, 616, 618, 626, 631, 635, 639, 643, 647, 650, 654, 657, 666, 670, 677, 680, 683, 686, 690, 694, 698, 702, 707, 709, 712, 716, 720, 722, 726, 729, 734, 737, 739, 741, 751, 757, 761, 765, 769, 772, 775, 777, 780, 782, 789, 795, 801, 804, 808, 812, 814, 818, 821, 825, 832, 837, 844, 848, 850, 852, 854, 856, 860, 863, 868, 872, 875, 880, 886, 888, 892, 898, 902, 904, 909, 912, 916, 919, 923, 926, 929, 932, 935, 944, 948, 950, 952, 955, 957, 959, 962, 965, 968, 971, 974, 977, 981, 985, 988, 992, 995, 998, 1003, 1007, 1014, 1017, 1022, 1029, 1033, 1041, 1044, 1047, 1050, 1053, 1061, 1066, 1069, 1075, 1083, 1088, 1093, 1099, 1110, 1112, 1119, 1121, 1123, 1125, 1128, 1132, 1135, 1137, 1140, 1143, 1150, 1152, 1155, 1158, 1160, 1162, 1165, 1167, 1176, 1178, 1182, 1186, 1189, 1193, 1195, 1201, 1204, 1208, 1212, 1214, 1220, 1224, 1226, 1230, 1233, 1235, 1241, 1244, 1252, 1254, 1256, 1259, 1262, 1265, 1270, 1273, 1277, 1281, 1284, 1289, 1292, 1295, 1300, 1302, 1305, 1309, 1311, 1313, 1315, 1318, 1321, 1329, 1332, 1336, 1339, 1342, 1344, 1347, 1351, 1355, 1362, 1370, 1373, 1377, 1382, 1385, 1387, 1394, 1396, 1399, 1405, 1407, 1410, 1413, 1418, 1421, 1423, 1426, 1429, 1434, 1438, 1442, 1445, 1451, 1453, 1456, 1458, 1460, 1463, 1468, 1475, 1478, 1481, 1484, 1487, 1494, 1496, 1500, 1506, 1510, 1513, 1519, 1526, 1536, 1538, 1541, 1544, 1548, 1553, 1561, 1565, 1568, 1573, 1575, 1578, 1582, 1586, 1591, 1595, 1599, 1602, 1605, 1608, 1616, 1622, 1626, 1629, 1631, 1639, 1642, 1645, 1648, 1655, 1658, 1661, 1679, 1690, 1694, 1697, 1701, 1703, 1711, 1717, 1719, 1726, 1730, 1733, 1737, 1742, 1745, 1749, 1752, 1757, 1759, 1761, 1764, 1767, 1770, 1779, 1792, 1796, 1799, 1805, 1807, 1809, 1812, 1816, 1819, 1823, 1826, 1829, 1834, 1836, 1838, 1841, 1844, 1847, 1850, 1852, 1858, 1863, 1867, 1870, 1875, 1879, 1886, 1889, 1892, 1899, 1906, 1908, 1910, 1916, 1919, 1923, 1926, 1932, 1936, 1939, 1945, 1951, 1958, 1966, 1971, 1975, 1978, 1983, 1986, 1989, 1991, 1994, 1997, 1999], deadline = 1)
        configuration.add_task(name="Task1", identifier=1, period=4.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=3.212903, acet=3.212903, et_stddev=1.0709676666666665, deadline= 4)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "20")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "20")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "20")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "20")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task4", identifier=4, period=5.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.608435, et_stddev=0.20281166666666664 , list_activation_dates=[1, 14, 27, 36, 46, 54, 60, 65, 72, 90, 100, 108, 113, 118, 127, 132, 138, 145, 155, 163, 168, 173, 187, 198, 215, 221, 233, 239, 247, 257, 271, 276, 287, 293, 300, 307, 312, 319, 339, 346, 357, 368, 374, 389, 398, 414, 425, 433, 449, 459, 471, 476, 489, 530, 547, 560, 566, 573, 585, 607, 623, 628, 634, 640, 646, 652, 661, 673, 681, 694, 700, 718, 724, 733, 742, 748, 759, 768, 776, 788, 799, 805, 811, 818, 824, 833, 843, 862, 876, 891, 919, 930, 936, 945, 951, 965, 971, 980, 989, 994, 999, 1015, 1044, 1054, 1062, 1071, 1081, 1089, 1105, 1136, 1147, 1154, 1177, 1190, 1201, 1207, 1213, 1221, 1227, 1236, 1248, 1255, 1261, 1270, 1283, 1294, 1305, 1320, 1325, 1334, 1340, 1350, 1356, 1364, 1384, 1390, 1397, 1411, 1418, 1428, 1434, 1445, 1453, 1465, 1472, 1481, 1500, 1505, 1518, 1533, 1539, 1547, 1555, 1566, 1579, 1586, 1598, 1603, 1611, 1619, 1627, 1636, 1642, 1648, 1655, 1661, 1666, 1672, 1688, 1693, 1715, 1720, 1733, 1738, 1747, 1759, 1772, 1792, 1801, 1812, 1819, 1824, 1831, 1890, 1896, 1915, 1921, 1940, 1946, 1952, 1971, 1977, 1983, 1989, 1997], deadline = 4)
        configuration.add_task(name="Task2", identifier=2, period=17.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=0.502873, acet=0.502873, et_stddev=0.16762433333333335, deadline= 19)
        configuration.add_task(name="Task3", identifier=3, period=44.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=39.389438, acet=39.389438, et_stddev=13.129812666666666, deadline= 43)
        configuration.add_task(name="Task1", identifier=1, period=2.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=1.350409, acet=1.350409, et_stddev=0.4501363333333333, deadline= 2)
        configuration.add_task(name="Task6", identifier=6, period=2.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.11704, et_stddev=0.03901333333333334 , list_activation_dates=[1, 5, 8, 11, 13, 16, 20, 25, 28, 37, 39, 41, 54, 57, 59, 63, 73, 75, 81, 83, 86, 88, 94, 98, 100, 104, 114, 116, 119, 123, 125, 130, 133, 136, 140, 144, 148, 150, 154, 164, 167, 170, 175, 179, 182, 184, 186, 189, 191, 194, 197, 200, 203, 207, 211, 216, 220, 226, 228, 231, 238, 241, 244, 250, 253, 255, 259, 262, 267, 269, 271, 273, 280, 282, 284, 290, 292, 294, 299, 305, 308, 315, 317, 327, 330, 333, 336, 341, 350, 352, 354, 356, 360, 362, 365, 368, 371, 380, 383, 385, 387, 392, 394, 397, 401, 405, 408, 412, 418, 420, 422, 425, 427, 430, 435, 438, 440, 443, 452, 455, 466, 468, 471, 475, 481, 485, 491, 496, 504, 508, 510, 514, 517, 519, 523, 525, 527, 529, 533, 536, 541, 546, 550, 556, 559, 563, 572, 575, 579, 582, 589, 594, 598, 602, 604, 607, 609, 617, 621, 625, 628, 631, 639, 642, 650, 653, 658, 664, 668, 674, 676, 679, 682, 684, 686, 689, 691, 700, 704, 707, 710, 713, 717, 719, 722, 726, 732, 734, 737, 740, 746, 750, 756, 758, 761, 766, 768, 770, 772, 776, 779, 787, 791, 793, 795, 798, 801, 804, 808, 817, 822, 826, 830, 834, 843, 848, 856, 860, 863, 869, 873, 876, 882, 888, 891, 894, 898, 901, 903, 916, 923, 926, 928, 932, 935, 941, 944, 949, 953, 956, 959, 962, 967, 971, 973, 976, 984, 987, 989, 992, 995, 999, 1003, 1005, 1008, 1011, 1016, 1019, 1024, 1028, 1033, 1035, 1037, 1039, 1043, 1046, 1048, 1050, 1054, 1058, 1060, 1063, 1067, 1072, 1074, 1079, 1082, 1091, 1095, 1101, 1109, 1117, 1120, 1123, 1125, 1129, 1131, 1136, 1139, 1142, 1145, 1148, 1151, 1154, 1162, 1173, 1177, 1180, 1184, 1187, 1190, 1193, 1199, 1203, 1205, 1209, 1216, 1234, 1237, 1240, 1244, 1246, 1249, 1251, 1254, 1256, 1260, 1264, 1268, 1272, 1278, 1282, 1285, 1290, 1296, 1299, 1309, 1312, 1316, 1319, 1322, 1324, 1331, 1335, 1347, 1350, 1355, 1359, 1362, 1364, 1371, 1375, 1378, 1381, 1384, 1392, 1403, 1408, 1410, 1416, 1419, 1422, 1425, 1430, 1433, 1437, 1442, 1444, 1448, 1453, 1456, 1459, 1463, 1467, 1469, 1472, 1477, 1479, 1488, 1492, 1494, 1503, 1505, 1507, 1515, 1517, 1520, 1523, 1526, 1529, 1533, 1538, 1541, 1544, 1550, 1559, 1561, 1565, 1576, 1578, 1583, 1586, 1590, 1604, 1606, 1608, 1610, 1616, 1618, 1621, 1624, 1627, 1629, 1631, 1635, 1639, 1642, 1648, 1651, 1657, 1661, 1664, 1669, 1672, 1675, 1678, 1682, 1685, 1690, 1692, 1697, 1700, 1704, 1711, 1715, 1718, 1725, 1729, 1733, 1735, 1740, 1749, 1751, 1757, 1760, 1764, 1769, 1781, 1783, 1785, 1797, 1802, 1804, 1810, 1815, 1818, 1824, 1827, 1832, 1836, 1839, 1841, 1844, 1852, 1865, 1870, 1876, 1882, 1884, 1886, 1889, 1893, 1900, 1906, 1909, 1911, 1915, 1918, 1920, 1923, 1926, 1932, 1934, 1936, 1942, 1947, 1949, 1957, 1959, 1961, 1972, 1975, 1978, 1980, 1982, 1985, 1991, 1995, 1998], deadline = 4)
        configuration.add_task(name="Task5", identifier=5, period=7.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.13855, et_stddev=0.04618333333333333 , list_activation_dates=[3, 23, 32, 40, 65, 74, 93, 105, 115, 125, 141, 159, 167, 187, 195, 211, 230, 239, 263, 295, 305, 318, 339, 351, 365, 377, 391, 415, 441, 451, 462, 475, 484, 497, 513, 520, 527, 545, 558, 569, 578, 586, 595, 615, 629, 642, 659, 668, 680, 696, 712, 734, 766, 779, 789, 803, 812, 836, 844, 866, 874, 891, 905, 915, 936, 949, 964, 973, 985, 1003, 1014, 1023, 1031, 1043, 1053, 1063, 1085, 1096, 1117, 1125, 1138, 1149, 1162, 1179, 1199, 1210, 1221, 1260, 1270, 1291, 1309, 1319, 1331, 1341, 1352, 1363, 1371, 1381, 1393, 1401, 1413, 1428, 1437, 1445, 1456, 1469, 1480, 1493, 1501, 1510, 1527, 1539, 1547, 1557, 1566, 1588, 1608, 1618, 1629, 1636, 1644, 1658, 1669, 1679, 1687, 1695, 1705, 1713, 1723, 1741, 1757, 1769, 1782, 1790, 1798, 1809, 1817, 1827, 1844, 1864, 1873, 1894, 1905, 1915, 1924, 1936, 1943, 1955, 1967, 1975, 2000], deadline = 7)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "21")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "21")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "21")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "21")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task3", identifier=3, period=10.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=4.803451, acet=4.803451, et_stddev=1.6011503333333332, deadline= 6)
        configuration.add_task(name="Task6", identifier=6, period=3.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.366674, et_stddev=0.12222466666666666 , list_activation_dates=[3, 6, 11, 16, 22, 26, 30, 33, 40, 45, 50, 55, 58, 70, 74, 80, 87, 91, 95, 98, 103, 108, 113, 129, 134, 140, 150, 156, 164, 168, 178, 182, 188, 196, 203, 206, 210, 214, 219, 224, 228, 232, 236, 239, 246, 250, 256, 260, 264, 269, 272, 276, 284, 288, 297, 308, 326, 331, 339, 349, 357, 364, 367, 372, 377, 389, 397, 402, 407, 415, 422, 429, 445, 457, 461, 467, 472, 477, 487, 490, 493, 496, 511, 517, 521, 527, 533, 537, 541, 552, 558, 566, 571, 578, 582, 587, 590, 593, 598, 603, 614, 620, 628, 635, 639, 646, 650, 654, 658, 663, 676, 680, 687, 691, 694, 698, 704, 730, 740, 744, 749, 754, 757, 760, 767, 773, 778, 783, 787, 791, 803, 809, 814, 820, 824, 828, 837, 841, 845, 848, 854, 857, 861, 878, 882, 885, 890, 897, 900, 903, 911, 918, 922, 926, 932, 938, 948, 951, 959, 967, 973, 977, 982, 992, 1002, 1006, 1010, 1017, 1023, 1027, 1034, 1043, 1049, 1059, 1063, 1066, 1070, 1074, 1079, 1083, 1090, 1102, 1129, 1138, 1142, 1145, 1161, 1164, 1172, 1177, 1184, 1190, 1196, 1202, 1206, 1211, 1214, 1220, 1247, 1253, 1259, 1266, 1277, 1280, 1283, 1286, 1291, 1299, 1308, 1312, 1318, 1321, 1330, 1339, 1344, 1347, 1352, 1363, 1369, 1374, 1379, 1389, 1392, 1397, 1400, 1404, 1410, 1414, 1425, 1428, 1433, 1439, 1442, 1449, 1453, 1460, 1483, 1488, 1492, 1507, 1513, 1516, 1531, 1536, 1541, 1549, 1553, 1558, 1563, 1569, 1574, 1578, 1582, 1592, 1598, 1602, 1609, 1614, 1622, 1627, 1633, 1637, 1641, 1650, 1655, 1659, 1667, 1670, 1675, 1681, 1687, 1692, 1698, 1703, 1711, 1717, 1722, 1735, 1738, 1742, 1748, 1753, 1760, 1766, 1769, 1773, 1776, 1781, 1789, 1797, 1803, 1809, 1813, 1817, 1821, 1824, 1829, 1834, 1843, 1848, 1853, 1858, 1864, 1868, 1874, 1879, 1885, 1889, 1897, 1901, 1905, 1909, 1914, 1920, 1934, 1942, 1949, 1955, 1961, 1968, 1975, 1987, 1992, 1997], deadline = 6)
        configuration.add_task(name="Task1", identifier=1, period=8.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=2.073839, acet=2.073839, et_stddev=0.6912796666666666, deadline= 12)
        configuration.add_task(name="Task5", identifier=5, period=7.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.385021, et_stddev=0.12834033333333333 , list_activation_dates=[26, 38, 47, 54, 64, 73, 83, 94, 104, 115, 127, 142, 163, 171, 189, 200, 221, 250, 261, 271, 282, 290, 303, 312, 322, 334, 345, 360, 370, 377, 393, 402, 424, 437, 447, 459, 470, 488, 501, 514, 523, 537, 551, 566, 594, 606, 631, 666, 678, 687, 718, 735, 744, 759, 778, 789, 799, 817, 830, 842, 851, 861, 871, 882, 894, 902, 917, 929, 941, 960, 968, 978, 992, 1001, 1020, 1035, 1044, 1060, 1070, 1083, 1096, 1104, 1114, 1135, 1145, 1154, 1166, 1173, 1201, 1209, 1235, 1255, 1265, 1272, 1289, 1296, 1304, 1314, 1326, 1336, 1363, 1373, 1380, 1389, 1396, 1426, 1438, 1454, 1475, 1491, 1513, 1528, 1556, 1568, 1581, 1588, 1600, 1611, 1634, 1647, 1671, 1689, 1700, 1714, 1722, 1733, 1744, 1752, 1764, 1779, 1794, 1805, 1823, 1833, 1844, 1852, 1859, 1875, 1889, 1904, 1911, 1923, 1949, 1974, 1992], deadline = 14)
        configuration.add_task(name="Task2", identifier=2, period=16.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=13.766798, acet=13.766798, et_stddev=4.5889326666666665, deadline= 24)
        configuration.add_task(name="Task4", identifier=4, period=36.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.819793, et_stddev=0.27326433333333333 , list_activation_dates=[23, 86, 130, 221, 279, 370, 429, 487, 547, 608, 677, 732, 769, 814, 983, 1049, 1086, 1158, 1199, 1298, 1343, 1392, 1638, 1719, 1823], deadline = 28)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "22")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "22")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "22")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "22")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task2", identifier=2, period=47.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=30.681569, acet=30.681569, et_stddev=10.227189666666666, deadline= 50)
        configuration.add_task(name="Task3", identifier=3, period=4.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=3.37093, acet=3.37093, et_stddev=1.1236433333333333, deadline= 8)
        configuration.add_task(name="Task5", identifier=5, period=12.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=2, acet=1.363166, et_stddev=0.4543886666666667 , list_activation_dates=[8, 28, 46, 106, 120, 134, 147, 160, 174, 198, 213, 244, 266, 288, 303, 325, 346, 364, 399, 411, 425, 442, 472, 495, 507, 528, 546, 571, 589, 607, 649, 675, 689, 717, 741, 756, 775, 788, 805, 848, 865, 886, 899, 917, 936, 968, 1032, 1055, 1067, 1103, 1118, 1131, 1151, 1168, 1189, 1208, 1234, 1249, 1270, 1283, 1297, 1309, 1336, 1352, 1365, 1385, 1405, 1451, 1471, 1517, 1530, 1542, 1596, 1610, 1627, 1654, 1667, 1682, 1713, 1738, 1772, 1796, 1831, 1852, 1874, 1895, 1911, 1926, 1939, 1968, 1982], deadline = 15)
        configuration.add_task(name="Task1", identifier=1, period=3.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=0.313404, acet=0.313404, et_stddev=0.104468, deadline= 1)
        configuration.add_task(name="Task6", identifier=6, period=27.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.679009, et_stddev=0.22633633333333333 , list_activation_dates=[9, 56, 89, 160, 202, 244, 315, 403, 434, 467, 520, 586, 639, 706, 760, 832, 888, 946, 983, 1031, 1060, 1095, 1132, 1183, 1223, 1263, 1304, 1366, 1397, 1443, 1473, 1503, 1564, 1598, 1645, 1731, 1759, 1803, 1879, 1948, 1993], deadline = 11)
        configuration.add_task(name="Task4", identifier=4, period=20.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=2, acet=1.225086, et_stddev=0.40836199999999995 , list_activation_dates=[10, 81, 120, 163, 184, 228, 250, 294, 325, 359, 385, 425, 496, 547, 584, 623, 644, 722, 755, 821, 863, 909, 958, 1024, 1064, 1092, 1153, 1210, 1237, 1292, 1313, 1374, 1422, 1483, 1512, 1556, 1618, 1650, 1674, 1751, 1782, 1826, 1868, 1914, 1979], deadline = 37)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "23")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "23")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "23")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "23")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task6", identifier=6, period=15.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=3, acet=2.243181, et_stddev=0.7477269999999999 , list_activation_dates=[71, 88, 103, 147, 181, 283, 300, 319, 367, 408, 431, 451, 473, 503, 532, 579, 600, 623, 653, 673, 689, 737, 753, 769, 793, 809, 830, 850, 906, 938, 968, 1008, 1026, 1066, 1083, 1113, 1138, 1221, 1236, 1252, 1294, 1315, 1363, 1405, 1447, 1485, 1573, 1601, 1639, 1656, 1678, 1719, 1741, 1758, 1786, 1824, 1847, 1894, 1928, 1944, 1964], deadline = 19)
        configuration.add_task(name="Task1", identifier=1, period=19.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=5.438532, acet=5.438532, et_stddev=1.8128440000000001, deadline= 36)
        configuration.add_task(name="Task4", identifier=4, period=24.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.573838, et_stddev=0.19127933333333333 , list_activation_dates=[2, 40, 109, 138, 167, 220, 254, 309, 340, 380, 404, 457, 514, 544, 571, 609, 689, 735, 762, 795, 822, 874, 909, 965, 991, 1018, 1066, 1094, 1144, 1246, 1281, 1306, 1341, 1440, 1469, 1493, 1535, 1559, 1601, 1638, 1674, 1701, 1743, 1802, 1852, 1910, 1988], deadline = 25)
        configuration.add_task(name="Task5", identifier=5, period=40.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=2, acet=1.061786, et_stddev=0.3539286666666666 , list_activation_dates=[2, 116, 177, 222, 292, 332, 397, 476, 547, 593, 668, 783, 825, 883, 959, 1009, 1091, 1144, 1246, 1345, 1403, 1457, 1528, 1603, 1685, 1815, 1920, 1980], deadline = 20)
        configuration.add_task(name="Task3", identifier=3, period=8.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=7.463282, acet=7.463282, et_stddev=2.487760666666667, deadline= 10)
        configuration.add_task(name="Task2", identifier=2, period=8.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=3.046809, acet=3.046809, et_stddev=1.015603, deadline= 11)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "24")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "24")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "24")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "24")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task1", identifier=1, period=17.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=16.45625, acet=16.45625, et_stddev=5.485416666666667, deadline= 20)
        configuration.add_task(name="Task2", identifier=2, period=11.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=2.086033, acet=2.086033, et_stddev=0.6953443333333333, deadline= 12)
        configuration.add_task(name="Task5", identifier=5, period=1.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.008781, et_stddev=0.0029270000000000003 , list_activation_dates=[4, 5, 6, 7, 9, 10, 12, 13, 15, 17, 18, 19, 21, 23, 25, 26, 28, 33, 34, 36, 38, 39, 41, 42, 45, 47, 51, 52, 54, 57, 59, 62, 63, 64, 66, 67, 69, 71, 72, 73, 74, 78, 83, 85, 86, 88, 89, 90, 92, 95, 96, 100, 102, 103, 106, 109, 110, 111, 113, 114, 115, 116, 120, 123, 124, 125, 127, 129, 131, 132, 138, 139, 140, 143, 146, 147, 152, 154, 156, 157, 159, 163, 164, 166, 167, 168, 171, 172, 173, 176, 179, 180, 183, 184, 186, 188, 190, 191, 193, 196, 198, 199, 200, 202, 203, 204, 206, 207, 208, 210, 213, 215, 216, 218, 221, 223, 224, 226, 227, 229, 232, 236, 237, 238, 239, 241, 243, 245, 248, 249, 252, 254, 256, 258, 260, 262, 266, 267, 269, 273, 274, 275, 277, 278, 280, 284, 285, 286, 288, 290, 293, 295, 298, 300, 302, 305, 306, 309, 311, 314, 316, 319, 320, 322, 323, 327, 328, 329, 330, 331, 332, 334, 335, 336, 338, 341, 343, 345, 346, 352, 354, 356, 359, 369, 371, 372, 373, 375, 377, 378, 379, 381, 385, 387, 388, 389, 391, 393, 394, 396, 397, 398, 402, 404, 407, 415, 416, 419, 420, 422, 423, 426, 427, 429, 431, 432, 434, 435, 438, 439, 440, 441, 443, 446, 448, 450, 453, 454, 455, 457, 459, 460, 467, 468, 472, 474, 475, 476, 477, 478, 481, 484, 486, 488, 489, 492, 493, 495, 496, 497, 498, 500, 501, 502, 504, 506, 510, 512, 513, 516, 517, 519, 520, 522, 523, 525, 526, 529, 532, 533, 535, 537, 539, 540, 542, 544, 546, 549, 550, 551, 552, 555, 556, 558, 559, 562, 565, 567, 569, 570, 573, 575, 579, 580, 581, 582, 586, 588, 589, 591, 595, 597, 599, 602, 605, 606, 609, 611, 612, 614, 617, 618, 620, 622, 623, 626, 627, 629, 631, 633, 636, 637, 639, 640, 642, 644, 645, 647, 648, 649, 650, 653, 654, 655, 657, 660, 662, 663, 664, 666, 667, 668, 670, 671, 673, 674, 677, 680, 681, 682, 683, 685, 686, 687, 691, 693, 696, 698, 704, 708, 709, 711, 712, 713, 715, 722, 724, 725, 727, 730, 733, 737, 739, 741, 742, 743, 746, 747, 749, 750, 753, 754, 756, 758, 760, 762, 764, 765, 766, 768, 770, 771, 772, 774, 775, 777, 778, 779, 780, 781, 783, 788, 790, 793, 794, 796, 797, 800, 805, 807, 808, 809, 811, 812, 813, 815, 816, 817, 819, 822, 826, 828, 831, 834, 836, 838, 839, 842, 843, 848, 850, 851, 853, 854, 855, 856, 857, 858, 859, 861, 863, 864, 869, 871, 872, 873, 876, 877, 880, 882, 883, 888, 890, 894, 898, 902, 904, 905, 909, 912, 916, 917, 919, 921, 924, 927, 930, 931, 932, 934, 936, 943, 945, 947, 950, 954, 955, 956, 958, 960, 962, 963, 964, 967, 970, 972, 974, 977, 980, 982, 984, 986, 987, 989, 991, 992, 993, 995, 998, 1000, 1001, 1002, 1005, 1007, 1010, 1013, 1015, 1018, 1019, 1021, 1022, 1023, 1024, 1026, 1030, 1033, 1035, 1038, 1040, 1043, 1044, 1049, 1051, 1056, 1058, 1059, 1060, 1062, 1064, 1066, 1068, 1069, 1071, 1072, 1074, 1075, 1078, 1079, 1081, 1085, 1086, 1088, 1089, 1091, 1092, 1093, 1096, 1098, 1100, 1101, 1102, 1104, 1105, 1107, 1109, 1111, 1113, 1115, 1116, 1118, 1123, 1124, 1126, 1129, 1132, 1133, 1135, 1136, 1137, 1138, 1139, 1140, 1141, 1142, 1144, 1146, 1148, 1149, 1150, 1151, 1153, 1155, 1158, 1159, 1161, 1164, 1166, 1168, 1169, 1172, 1173, 1175, 1176, 1178, 1179, 1180, 1182, 1183, 1186, 1190, 1192, 1193, 1195, 1196, 1199, 1201, 1203, 1205, 1206, 1207, 1211, 1212, 1213, 1215, 1218, 1219, 1225, 1227, 1228, 1231, 1232, 1234, 1235, 1238, 1239, 1240, 1242, 1243, 1244, 1246, 1249, 1251, 1252, 1254, 1256, 1258, 1259, 1261, 1263, 1265, 1267, 1269, 1271, 1272, 1274, 1276, 1278, 1279, 1280, 1282, 1285, 1286, 1287, 1290, 1292, 1296, 1297, 1298, 1299, 1300, 1301, 1304, 1306, 1310, 1314, 1316, 1318, 1321, 1326, 1327, 1329, 1331, 1334, 1335, 1337, 1339, 1341, 1344, 1347, 1351, 1355, 1356, 1360, 1362, 1363, 1366, 1368, 1370, 1372, 1376, 1378, 1380, 1389, 1390, 1391, 1392, 1393, 1394, 1395, 1396, 1398, 1399, 1400, 1401, 1402, 1404, 1406, 1409, 1411, 1413, 1414, 1416, 1418, 1419, 1420, 1422, 1424, 1428, 1430, 1433, 1434, 1437, 1439, 1440, 1441, 1443, 1444, 1446, 1447, 1449, 1451, 1454, 1456, 1458, 1461, 1462, 1466, 1467, 1469, 1471, 1473, 1475, 1476, 1479, 1482, 1484, 1485, 1486, 1487, 1490, 1492, 1495, 1498, 1499, 1501, 1503, 1505, 1508, 1510, 1512, 1514, 1515, 1518, 1519, 1521, 1523, 1526, 1528, 1529, 1530, 1534, 1535, 1538, 1541, 1543, 1544, 1546, 1547, 1550, 1553, 1557, 1560, 1562, 1564, 1565, 1567, 1568, 1575, 1577, 1578, 1579, 1580, 1581, 1582, 1583, 1586, 1587, 1588, 1589, 1591, 1593, 1594, 1595, 1597, 1599, 1602, 1603, 1604, 1607, 1608, 1610, 1612, 1613, 1615, 1616, 1617, 1619, 1621, 1622, 1623, 1624, 1626, 1629, 1631, 1632, 1633, 1634, 1636, 1638, 1640, 1642, 1643, 1645, 1648, 1650, 1653, 1654, 1656, 1657, 1658, 1659, 1661, 1664, 1667, 1668, 1669, 1671, 1675, 1676, 1678, 1679, 1681, 1683, 1684, 1685, 1687, 1688, 1690, 1695, 1696, 1697, 1698, 1701, 1703, 1704, 1706, 1708, 1711, 1713, 1716, 1718, 1720, 1724, 1727, 1728, 1730, 1731, 1733, 1737, 1739, 1743, 1745, 1747, 1748, 1750, 1752, 1754, 1755, 1760, 1761, 1762, 1764, 1765, 1767, 1768, 1769, 1771, 1772, 1773, 1775, 1777, 1778, 1779, 1780, 1784, 1785, 1787, 1790, 1791, 1792, 1793, 1795, 1796, 1800, 1802, 1803, 1805, 1806, 1808, 1812, 1813, 1815, 1816, 1818, 1821, 1822, 1825, 1829, 1832, 1836, 1839, 1840, 1841, 1843, 1845, 1847, 1850, 1851, 1853, 1854, 1855, 1858, 1859, 1860, 1861, 1862, 1865, 1868, 1869, 1870, 1871, 1874, 1876, 1877, 1878, 1880, 1886, 1888, 1890, 1891, 1893, 1894, 1895, 1898, 1902, 1904, 1907, 1908, 1911, 1913, 1914, 1916, 1919, 1920, 1924, 1926, 1928, 1931, 1934, 1935, 1936, 1937, 1938, 1939, 1941, 1946, 1951, 1952, 1954, 1956, 1957, 1958, 1960, 1961, 1963, 1965, 1968, 1970, 1972, 1973, 1975, 1979, 1981, 1982, 1987, 1988, 1990, 1992, 1994, 1996, 1998], deadline = 1)
        configuration.add_task(name="Task4", identifier=4, period=2.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.373898, et_stddev=0.12463266666666667 , list_activation_dates=[1, 9, 16, 18, 21, 25, 30, 32, 35, 39, 41, 44, 47, 49, 51, 53, 56, 60, 65, 76, 79, 84, 86, 89, 91, 94, 97, 100, 105, 107, 110, 113, 120, 123, 125, 130, 137, 139, 147, 150, 163, 167, 170, 179, 181, 183, 185, 187, 189, 195, 199, 202, 208, 211, 220, 225, 228, 230, 233, 235, 238, 241, 248, 250, 252, 254, 259, 263, 266, 270, 273, 275, 280, 283, 286, 288, 295, 300, 303, 312, 316, 322, 326, 331, 333, 339, 341, 344, 350, 353, 357, 368, 374, 376, 379, 382, 386, 392, 397, 400, 402, 407, 412, 420, 425, 428, 431, 439, 447, 449, 456, 461, 464, 467, 470, 474, 479, 483, 485, 488, 490, 495, 497, 501, 504, 511, 520, 528, 535, 539, 543, 547, 553, 555, 562, 568, 571, 574, 577, 580, 583, 586, 593, 603, 605, 609, 612, 615, 618, 621, 623, 625, 628, 631, 637, 643, 645, 649, 654, 660, 663, 671, 673, 683, 685, 689, 691, 697, 705, 708, 712, 714, 717, 727, 729, 734, 736, 738, 740, 744, 751, 753, 757, 764, 768, 771, 777, 779, 781, 787, 789, 793, 802, 805, 807, 812, 818, 820, 823, 826, 829, 833, 836, 841, 844, 846, 848, 854, 856, 860, 864, 871, 873, 879, 882, 885, 890, 897, 901, 907, 910, 916, 920, 924, 930, 932, 934, 939, 945, 951, 955, 957, 959, 962, 968, 976, 979, 981, 983, 985, 987, 989, 994, 1005, 1009, 1013, 1015, 1018, 1022, 1025, 1028, 1035, 1041, 1043, 1047, 1051, 1056, 1060, 1063, 1068, 1073, 1077, 1080, 1087, 1094, 1098, 1102, 1106, 1109, 1114, 1117, 1122, 1125, 1131, 1137, 1139, 1142, 1145, 1148, 1152, 1154, 1156, 1160, 1162, 1165, 1168, 1170, 1173, 1177, 1187, 1190, 1194, 1198, 1203, 1205, 1209, 1212, 1216, 1219, 1222, 1226, 1229, 1234, 1236, 1240, 1244, 1249, 1252, 1257, 1259, 1268, 1271, 1275, 1278, 1283, 1285, 1289, 1292, 1296, 1298, 1301, 1306, 1309, 1315, 1319, 1324, 1328, 1333, 1336, 1340, 1342, 1347, 1350, 1356, 1362, 1367, 1371, 1374, 1383, 1385, 1390, 1393, 1398, 1400, 1402, 1409, 1412, 1417, 1421, 1426, 1428, 1431, 1433, 1436, 1441, 1444, 1447, 1452, 1456, 1459, 1466, 1469, 1472, 1474, 1479, 1482, 1487, 1490, 1492, 1494, 1499, 1503, 1505, 1508, 1511, 1515, 1518, 1521, 1524, 1529, 1531, 1538, 1541, 1544, 1546, 1551, 1558, 1560, 1566, 1574, 1577, 1580, 1590, 1592, 1597, 1599, 1606, 1609, 1611, 1622, 1625, 1630, 1634, 1640, 1643, 1646, 1648, 1651, 1661, 1664, 1668, 1671, 1674, 1681, 1688, 1690, 1694, 1696, 1702, 1711, 1714, 1718, 1726, 1733, 1738, 1742, 1749, 1752, 1755, 1760, 1764, 1766, 1772, 1778, 1783, 1794, 1798, 1800, 1802, 1805, 1811, 1815, 1820, 1822, 1824, 1827, 1830, 1834, 1837, 1840, 1843, 1848, 1862, 1865, 1867, 1873, 1875, 1878, 1881, 1885, 1888, 1893, 1898, 1912, 1916, 1920, 1923, 1926, 1931, 1934, 1937, 1939, 1944, 1947, 1950, 1952, 1958, 1961, 1965, 1968, 1972, 1975, 1978, 1983, 1985, 1989, 1999], deadline = 4)
        configuration.add_task(name="Task6", identifier=6, period=30.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.128072, et_stddev=0.04269066666666666 , list_activation_dates=[32, 65, 97, 136, 206, 256, 290, 374, 472, 516, 601, 659, 700, 734, 771, 803, 886, 983, 1038, 1072, 1193, 1230, 1346, 1380, 1492, 1536, 1722, 1777, 1850, 1914], deadline = 44)
        configuration.add_task(name="Task3", identifier=3, period=27.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=11.943338, acet=11.943338, et_stddev=3.9811126666666667, deadline= 24)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "25")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "25")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "25")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "25")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task4", identifier=4, period=5.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.384531, et_stddev=0.128177 , list_activation_dates=[2, 8, 17, 26, 34, 40, 45, 62, 77, 117, 130, 141, 157, 165, 188, 196, 201, 209, 215, 221, 229, 236, 256, 266, 290, 304, 309, 320, 326, 333, 342, 351, 359, 366, 388, 397, 405, 413, 433, 444, 450, 462, 470, 480, 487, 513, 526, 544, 549, 555, 561, 566, 572, 580, 586, 592, 602, 610, 615, 621, 628, 638, 651, 666, 684, 700, 705, 717, 722, 733, 754, 762, 784, 795, 801, 806, 818, 825, 831, 839, 847, 856, 871, 882, 888, 894, 902, 916, 932, 952, 961, 972, 979, 990, 997, 1003, 1008, 1022, 1031, 1039, 1052, 1059, 1076, 1085, 1092, 1107, 1127, 1136, 1141, 1155, 1178, 1183, 1199, 1206, 1220, 1232, 1242, 1268, 1275, 1284, 1290, 1296, 1304, 1316, 1329, 1334, 1340, 1349, 1355, 1360, 1366, 1371, 1378, 1400, 1407, 1415, 1429, 1442, 1448, 1458, 1464, 1472, 1487, 1496, 1502, 1517, 1523, 1537, 1544, 1553, 1558, 1567, 1579, 1585, 1591, 1600, 1605, 1612, 1623, 1633, 1639, 1653, 1658, 1665, 1673, 1681, 1696, 1703, 1710, 1720, 1734, 1744, 1750, 1756, 1779, 1784, 1793, 1799, 1808, 1813, 1826, 1831, 1836, 1844, 1854, 1862, 1869, 1888, 1895, 1900, 1908, 1914, 1922, 1929, 1935, 1941, 1952, 1959, 1968, 1974, 1984, 1999], deadline = 5)
        configuration.add_task(name="Task3", identifier=3, period=6.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=4.595786, acet=4.595786, et_stddev=1.5319286666666667, deadline= 6)
        configuration.add_task(name="Task1", identifier=1, period=2.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=0.670253, acet=0.670253, et_stddev=0.22341766666666665, deadline= 3)
        configuration.add_task(name="Task6", identifier=6, period=4.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.461692, et_stddev=0.15389733333333333 , list_activation_dates=[8, 12, 17, 21, 28, 41, 54, 62, 70, 77, 86, 96, 102, 118, 124, 136, 143, 150, 155, 163, 171, 177, 183, 189, 197, 205, 211, 215, 222, 238, 248, 253, 259, 271, 275, 282, 291, 298, 307, 312, 326, 336, 340, 349, 353, 369, 376, 381, 390, 398, 403, 407, 414, 420, 435, 443, 450, 457, 461, 473, 480, 492, 496, 503, 508, 516, 521, 529, 540, 554, 559, 565, 571, 591, 600, 614, 619, 623, 628, 633, 637, 642, 652, 658, 662, 668, 676, 684, 704, 710, 724, 728, 736, 742, 753, 759, 767, 774, 784, 802, 815, 830, 841, 847, 857, 864, 873, 880, 891, 900, 910, 923, 927, 940, 946, 954, 959, 965, 970, 976, 985, 1005, 1016, 1022, 1032, 1037, 1042, 1048, 1059, 1070, 1077, 1085, 1095, 1103, 1111, 1121, 1129, 1140, 1146, 1152, 1160, 1168, 1176, 1186, 1193, 1199, 1203, 1209, 1216, 1229, 1243, 1253, 1259, 1264, 1274, 1279, 1287, 1297, 1302, 1309, 1316, 1324, 1332, 1338, 1351, 1358, 1363, 1368, 1372, 1381, 1389, 1394, 1399, 1405, 1413, 1417, 1424, 1437, 1449, 1454, 1460, 1468, 1479, 1485, 1500, 1511, 1515, 1526, 1531, 1538, 1545, 1550, 1558, 1566, 1572, 1577, 1584, 1589, 1604, 1610, 1622, 1630, 1634, 1642, 1650, 1654, 1659, 1674, 1698, 1704, 1712, 1722, 1729, 1742, 1746, 1755, 1772, 1783, 1789, 1812, 1824, 1829, 1846, 1851, 1864, 1868, 1894, 1903, 1908, 1913, 1919, 1925, 1931, 1936, 1941, 1945, 1950, 1962, 1970, 1977, 1983, 1994], deadline = 6)
        configuration.add_task(name="Task2", identifier=2, period=35.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=17.461813, acet=17.461813, et_stddev=5.820604333333333, deadline= 59)
        configuration.add_task(name="Task5", identifier=5, period=35.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.268473, et_stddev=0.089491 , list_activation_dates=[3, 88, 131, 201, 286, 360, 414, 545, 601, 644, 688, 760, 907, 1022, 1063, 1117, 1172, 1239, 1301, 1350, 1403, 1464, 1507, 1575, 1639, 1691, 1779, 1838, 1876, 1919], deadline = 16)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "26")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "26")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "26")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "26")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task5", identifier=5, period=9.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.336631, et_stddev=0.11221033333333334 , list_activation_dates=[4, 20, 38, 48, 63, 75, 108, 128, 143, 155, 172, 207, 229, 261, 278, 296, 322, 347, 357, 368, 379, 398, 413, 427, 440, 460, 496, 515, 530, 548, 564, 581, 601, 614, 631, 645, 656, 667, 681, 712, 728, 741, 763, 777, 813, 834, 855, 907, 924, 937, 949, 965, 981, 993, 1010, 1045, 1062, 1071, 1084, 1110, 1136, 1146, 1172, 1186, 1203, 1223, 1241, 1257, 1268, 1285, 1295, 1310, 1346, 1355, 1391, 1404, 1424, 1443, 1461, 1476, 1485, 1496, 1506, 1529, 1540, 1552, 1563, 1572, 1584, 1615, 1651, 1680, 1713, 1722, 1735, 1748, 1766, 1779, 1790, 1805, 1817, 1836, 1849, 1862, 1873, 1907, 1917, 1929, 1938, 1950, 1964, 1987, 1998], deadline = 6)
        configuration.add_task(name="Task4", identifier=4, period=9.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=2, acet=1.262226, et_stddev=0.420742 , list_activation_dates=[7, 43, 76, 94, 105, 115, 126, 145, 159, 174, 188, 197, 208, 220, 236, 253, 279, 290, 314, 338, 356, 371, 386, 396, 421, 435, 444, 458, 476, 485, 501, 524, 536, 551, 569, 594, 613, 623, 646, 658, 668, 692, 708, 719, 736, 745, 766, 794, 818, 831, 850, 864, 875, 904, 924, 938, 950, 963, 996, 1010, 1020, 1031, 1044, 1063, 1073, 1085, 1104, 1117, 1133, 1150, 1162, 1178, 1187, 1198, 1213, 1231, 1244, 1264, 1303, 1315, 1337, 1349, 1369, 1383, 1397, 1418, 1429, 1448, 1457, 1466, 1483, 1501, 1517, 1530, 1551, 1568, 1578, 1614, 1623, 1662, 1680, 1696, 1707, 1747, 1758, 1770, 1786, 1800, 1809, 1841, 1855, 1865, 1879, 1901, 1913, 1926, 1952, 1969, 1992], deadline = 11)
        configuration.add_task(name="Task3", identifier=3, period=14.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=8.587018, acet=8.587018, et_stddev=2.8623393333333333, deadline= 26)
        configuration.add_task(name="Task6", identifier=6, period=2.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.044698, et_stddev=0.014899333333333334 , list_activation_dates=[4, 7, 12, 17, 20, 24, 29, 34, 37, 39, 42, 45, 53, 55, 59, 61, 66, 74, 82, 87, 94, 100, 110, 114, 117, 126, 130, 132, 135, 137, 140, 143, 147, 153, 158, 162, 166, 169, 173, 175, 180, 187, 191, 195, 200, 206, 209, 213, 216, 218, 220, 223, 229, 232, 234, 242, 244, 248, 250, 254, 260, 264, 268, 270, 272, 274, 279, 282, 286, 290, 293, 297, 299, 301, 305, 308, 312, 317, 319, 325, 328, 332, 336, 338, 344, 347, 351, 354, 357, 362, 365, 367, 371, 380, 383, 386, 397, 399, 402, 404, 407, 411, 415, 419, 421, 424, 426, 431, 436, 438, 441, 444, 447, 450, 458, 464, 468, 470, 477, 479, 482, 486, 488, 492, 496, 498, 501, 506, 508, 514, 517, 519, 522, 526, 528, 530, 533, 541, 543, 548, 555, 557, 563, 566, 572, 575, 581, 586, 589, 591, 596, 602, 605, 610, 614, 617, 620, 623, 629, 635, 637, 640, 645, 649, 651, 654, 657, 661, 664, 668, 672, 675, 677, 680, 687, 695, 699, 705, 708, 710, 714, 718, 722, 725, 727, 729, 731, 734, 737, 740, 745, 748, 751, 755, 761, 765, 769, 772, 774, 777, 780, 783, 786, 789, 791, 793, 800, 803, 809, 811, 813, 817, 823, 835, 839, 844, 847, 852, 858, 864, 870, 875, 879, 890, 892, 894, 901, 903, 907, 910, 916, 918, 922, 929, 931, 935, 943, 947, 950, 952, 955, 959, 963, 965, 968, 970, 979, 982, 984, 988, 992, 994, 996, 999, 1002, 1006, 1011, 1014, 1016, 1018, 1021, 1028, 1034, 1039, 1043, 1047, 1050, 1053, 1057, 1060, 1063, 1066, 1068, 1071, 1073, 1080, 1085, 1089, 1092, 1094, 1098, 1102, 1105, 1111, 1113, 1117, 1127, 1130, 1134, 1138, 1149, 1153, 1156, 1165, 1168, 1171, 1176, 1181, 1184, 1189, 1191, 1196, 1199, 1204, 1215, 1223, 1226, 1229, 1234, 1236, 1239, 1242, 1245, 1247, 1250, 1253, 1260, 1263, 1274, 1276, 1284, 1286, 1289, 1294, 1298, 1303, 1306, 1309, 1320, 1326, 1336, 1343, 1346, 1349, 1351, 1356, 1359, 1369, 1371, 1376, 1378, 1381, 1386, 1391, 1394, 1400, 1403, 1407, 1410, 1416, 1420, 1423, 1425, 1428, 1431, 1435, 1439, 1441, 1443, 1450, 1452, 1456, 1458, 1463, 1467, 1470, 1474, 1480, 1484, 1489, 1494, 1496, 1499, 1504, 1506, 1509, 1514, 1517, 1519, 1523, 1527, 1530, 1534, 1538, 1540, 1542, 1546, 1550, 1553, 1556, 1558, 1561, 1565, 1571, 1579, 1592, 1600, 1602, 1607, 1609, 1611, 1618, 1624, 1628, 1631, 1633, 1635, 1638, 1640, 1644, 1647, 1651, 1655, 1658, 1666, 1670, 1673, 1678, 1684, 1692, 1696, 1699, 1702, 1705, 1707, 1710, 1713, 1715, 1717, 1720, 1723, 1725, 1727, 1730, 1732, 1737, 1740, 1742, 1746, 1748, 1752, 1754, 1757, 1760, 1764, 1766, 1770, 1772, 1776, 1781, 1784, 1788, 1790, 1796, 1800, 1802, 1811, 1817, 1821, 1824, 1830, 1832, 1835, 1837, 1842, 1844, 1852, 1855, 1860, 1864, 1868, 1872, 1875, 1881, 1887, 1894, 1902, 1905, 1907, 1910, 1913, 1915, 1919, 1923, 1931, 1934, 1936, 1943, 1949, 1951, 1954, 1956, 1959, 1961, 1963, 1968, 1972, 1976, 1983, 1990, 1992, 1995, 1998], deadline = 1)
        configuration.add_task(name="Task2", identifier=2, period=15.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=1.443015, acet=1.443015, et_stddev=0.48100499999999996, deadline= 29)
        configuration.add_task(name="Task1", identifier=1, period=7.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=6.233083, acet=6.233083, et_stddev=2.077694333333333, deadline= 9)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "27")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "27")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "27")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "27")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task6", identifier=6, period=1.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.003742, et_stddev=0.0012473333333333334 , list_activation_dates=[3, 5, 7, 8, 9, 10, 14, 15, 17, 18, 20, 22, 24, 25, 30, 31, 33, 34, 38, 41, 43, 44, 46, 48, 51, 52, 53, 55, 56, 58, 60, 61, 62, 63, 67, 69, 72, 74, 76, 78, 79, 80, 81, 83, 86, 88, 89, 90, 91, 94, 95, 97, 98, 100, 101, 104, 106, 107, 109, 111, 113, 118, 121, 122, 125, 129, 130, 131, 136, 137, 138, 140, 144, 145, 149, 150, 152, 153, 154, 156, 158, 160, 161, 167, 169, 172, 175, 177, 179, 181, 186, 187, 188, 189, 191, 194, 196, 197, 200, 201, 203, 204, 205, 208, 210, 211, 213, 215, 216, 217, 218, 219, 220, 221, 223, 226, 227, 228, 230, 232, 233, 235, 236, 239, 240, 241, 244, 246, 248, 249, 252, 253, 254, 257, 258, 259, 261, 263, 264, 265, 269, 270, 272, 273, 275, 276, 278, 279, 280, 282, 284, 287, 292, 294, 296, 297, 298, 300, 301, 303, 306, 307, 309, 311, 314, 317, 318, 319, 321, 323, 324, 327, 328, 329, 330, 332, 335, 337, 338, 340, 342, 343, 344, 345, 347, 348, 350, 354, 355, 357, 359, 360, 361, 362, 364, 366, 367, 369, 371, 373, 375, 377, 378, 380, 382, 383, 384, 387, 388, 389, 393, 395, 396, 398, 400, 404, 407, 409, 410, 411, 414, 415, 417, 420, 421, 423, 425, 427, 428, 429, 430, 432, 433, 434, 435, 436, 440, 443, 445, 446, 448, 450, 452, 456, 457, 459, 463, 465, 469, 473, 474, 475, 476, 477, 478, 479, 481, 482, 484, 486, 487, 488, 489, 491, 492, 494, 496, 499, 500, 502, 505, 506, 508, 510, 512, 514, 515, 517, 519, 521, 522, 524, 526, 527, 529, 530, 535, 537, 538, 541, 543, 546, 547, 549, 553, 556, 559, 560, 561, 562, 564, 565, 566, 568, 571, 572, 574, 576, 578, 580, 581, 584, 585, 588, 589, 591, 592, 593, 594, 596, 599, 601, 602, 604, 606, 608, 609, 611, 615, 618, 622, 623, 624, 627, 628, 630, 632, 633, 635, 636, 639, 641, 643, 645, 646, 651, 654, 656, 660, 663, 665, 667, 669, 670, 672, 676, 679, 682, 683, 684, 685, 688, 690, 692, 695, 697, 699, 701, 702, 703, 704, 706, 708, 709, 713, 716, 719, 722, 724, 726, 731, 733, 735, 736, 738, 740, 744, 747, 748, 751, 753, 754, 756, 757, 760, 764, 765, 769, 770, 772, 775, 777, 779, 782, 783, 785, 786, 790, 794, 798, 800, 802, 804, 805, 806, 808, 809, 813, 817, 818, 820, 821, 822, 824, 825, 827, 828, 831, 834, 835, 838, 840, 847, 849, 850, 852, 854, 856, 860, 862, 863, 864, 866, 868, 869, 872, 874, 876, 878, 880, 882, 884, 885, 887, 888, 889, 892, 894, 896, 898, 901, 903, 904, 906, 908, 910, 911, 914, 917, 919, 920, 922, 924, 925, 927, 929, 930, 932, 934, 935, 937, 939, 941, 943, 945, 949, 951, 952, 954, 956, 958, 960, 962, 963, 965, 966, 967, 968, 971, 972, 974, 975, 978, 980, 982, 984, 986, 987, 989, 991, 993, 994, 995, 999, 1000, 1005, 1007, 1008, 1011, 1013, 1014, 1016, 1017, 1018, 1022, 1027, 1033, 1035, 1039, 1042, 1044, 1049, 1051, 1052, 1053, 1055, 1057, 1059, 1061, 1062, 1063, 1066, 1071, 1072, 1075, 1077, 1079, 1081, 1082, 1083, 1087, 1089, 1094, 1096, 1098, 1099, 1101, 1102, 1105, 1107, 1109, 1111, 1113, 1115, 1118, 1119, 1125, 1126, 1127, 1128, 1129, 1130, 1133, 1135, 1137, 1139, 1141, 1142, 1143, 1144, 1148, 1150, 1151, 1153, 1155, 1157, 1159, 1161, 1163, 1164, 1165, 1167, 1170, 1173, 1175, 1177, 1180, 1181, 1182, 1184, 1186, 1187, 1189, 1194, 1196, 1199, 1203, 1204, 1205, 1207, 1209, 1211, 1212, 1214, 1217, 1220, 1221, 1222, 1224, 1226, 1229, 1231, 1233, 1234, 1236, 1238, 1240, 1241, 1242, 1244, 1245, 1248, 1250, 1252, 1255, 1258, 1260, 1261, 1262, 1263, 1265, 1266, 1269, 1271, 1272, 1274, 1276, 1277, 1280, 1281, 1282, 1283, 1286, 1289, 1290, 1291, 1292, 1293, 1295, 1297, 1301, 1303, 1305, 1307, 1311, 1312, 1313, 1314, 1316, 1317, 1318, 1320, 1321, 1322, 1323, 1325, 1326, 1328, 1329, 1330, 1332, 1333, 1334, 1335, 1337, 1338, 1339, 1341, 1342, 1343, 1344, 1347, 1350, 1352, 1354, 1356, 1359, 1361, 1364, 1366, 1369, 1370, 1371, 1372, 1374, 1376, 1377, 1379, 1380, 1382, 1384, 1385, 1386, 1388, 1390, 1392, 1394, 1396, 1398, 1402, 1404, 1405, 1407, 1408, 1409, 1411, 1413, 1414, 1417, 1420, 1422, 1424, 1427, 1428, 1430, 1431, 1436, 1438, 1440, 1442, 1446, 1448, 1449, 1452, 1454, 1455, 1456, 1457, 1459, 1460, 1462, 1464, 1468, 1470, 1473, 1475, 1477, 1478, 1482, 1483, 1486, 1487, 1488, 1490, 1494, 1495, 1497, 1500, 1501, 1504, 1506, 1507, 1509, 1511, 1514, 1516, 1517, 1519, 1521, 1523, 1525, 1526, 1527, 1529, 1531, 1533, 1534, 1536, 1539, 1540, 1541, 1543, 1546, 1549, 1551, 1553, 1555, 1557, 1561, 1563, 1564, 1570, 1571, 1572, 1573, 1575, 1577, 1578, 1582, 1584, 1586, 1588, 1589, 1595, 1596, 1597, 1601, 1602, 1604, 1605, 1608, 1609, 1611, 1612, 1615, 1616, 1619, 1621, 1626, 1629, 1631, 1633, 1638, 1639, 1641, 1646, 1647, 1648, 1650, 1651, 1655, 1659, 1661, 1663, 1664, 1665, 1666, 1667, 1670, 1671, 1672, 1677, 1678, 1681, 1683, 1684, 1687, 1689, 1691, 1694, 1696, 1699, 1700, 1702, 1705, 1709, 1712, 1713, 1714, 1716, 1718, 1719, 1721, 1724, 1726, 1727, 1730, 1732, 1733, 1735, 1739, 1741, 1742, 1743, 1744, 1746, 1748, 1751, 1755, 1756, 1757, 1758, 1761, 1762, 1763, 1765, 1769, 1773, 1775, 1776, 1777, 1778, 1780, 1782, 1784, 1788, 1790, 1793, 1794, 1796, 1797, 1798, 1800, 1801, 1802, 1803, 1806, 1808, 1809, 1811, 1813, 1815, 1819, 1822, 1823, 1826, 1828, 1830, 1832, 1833, 1834, 1836, 1838, 1840, 1841, 1843, 1846, 1848, 1849, 1852, 1854, 1856, 1858, 1861, 1863, 1865, 1868, 1870, 1871, 1872, 1877, 1878, 1879, 1880, 1881, 1884, 1887, 1889, 1891, 1892, 1893, 1895, 1897, 1900, 1901, 1904, 1905, 1906, 1910, 1911, 1913, 1916, 1917, 1918, 1919, 1921, 1924, 1925, 1927, 1928, 1929, 1932, 1935, 1937, 1939, 1944, 1945, 1947, 1949, 1953, 1954, 1955, 1957, 1958, 1959, 1962, 1963, 1964, 1967, 1969, 1971, 1973, 1976, 1977, 1978, 1979, 1981, 1982, 1984, 1985, 1986, 1990, 1993, 1994, 1995, 1998], deadline = 1)
        configuration.add_task(name="Task5", identifier=5, period=1.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.064935, et_stddev=0.021645 , list_activation_dates=[1, 4, 7, 9, 11, 13, 15, 18, 19, 23, 26, 29, 30, 31, 32, 33, 34, 35, 38, 40, 42, 45, 46, 47, 50, 51, 52, 55, 56, 57, 58, 60, 61, 63, 64, 68, 70, 73, 76, 77, 78, 79, 81, 82, 84, 88, 91, 94, 97, 101, 102, 104, 106, 107, 109, 112, 114, 116, 118, 119, 121, 122, 124, 126, 127, 129, 133, 134, 136, 137, 138, 141, 145, 147, 149, 150, 152, 153, 154, 157, 158, 159, 162, 164, 165, 166, 170, 171, 172, 176, 177, 179, 181, 182, 184, 186, 190, 192, 195, 196, 197, 198, 199, 201, 202, 204, 207, 208, 211, 217, 221, 224, 226, 228, 229, 230, 232, 234, 236, 240, 242, 243, 244, 247, 250, 252, 254, 255, 256, 257, 260, 265, 266, 268, 270, 272, 273, 275, 277, 279, 280, 284, 286, 288, 289, 292, 294, 296, 298, 300, 301, 302, 303, 304, 306, 307, 309, 311, 315, 318, 321, 322, 324, 325, 328, 331, 332, 333, 335, 337, 338, 340, 344, 346, 349, 350, 353, 355, 358, 360, 364, 366, 367, 368, 369, 370, 372, 373, 374, 376, 377, 379, 380, 381, 382, 387, 392, 394, 396, 403, 407, 410, 411, 414, 417, 418, 419, 422, 424, 425, 427, 428, 431, 433, 435, 436, 437, 438, 441, 442, 445, 447, 448, 449, 450, 453, 457, 458, 460, 462, 465, 469, 471, 472, 473, 475, 476, 477, 480, 482, 483, 484, 486, 487, 490, 493, 495, 496, 498, 500, 503, 505, 507, 509, 511, 513, 515, 518, 520, 523, 526, 529, 531, 532, 535, 536, 537, 538, 539, 544, 548, 549, 550, 554, 556, 557, 558, 559, 561, 564, 566, 568, 569, 572, 573, 574, 577, 581, 583, 585, 587, 590, 592, 594, 595, 596, 598, 600, 601, 602, 603, 606, 608, 609, 611, 613, 615, 617, 619, 621, 622, 624, 626, 630, 632, 633, 636, 639, 640, 643, 645, 647, 649, 651, 652, 654, 656, 658, 659, 660, 661, 663, 664, 666, 667, 669, 671, 672, 673, 674, 676, 677, 679, 680, 681, 682, 684, 685, 686, 688, 690, 691, 693, 695, 697, 699, 700, 703, 705, 707, 711, 712, 714, 718, 719, 721, 726, 727, 728, 729, 731, 732, 735, 737, 740, 742, 743, 744, 747, 748, 752, 754, 758, 760, 763, 764, 766, 767, 768, 769, 770, 771, 772, 773, 774, 777, 779, 780, 782, 784, 786, 787, 788, 790, 791, 793, 797, 798, 800, 802, 804, 805, 806, 809, 810, 811, 814, 815, 816, 817, 820, 823, 824, 828, 829, 830, 833, 835, 838, 841, 842, 844, 846, 848, 850, 854, 856, 857, 859, 862, 865, 866, 868, 870, 874, 877, 880, 882, 883, 884, 886, 888, 892, 895, 897, 898, 900, 902, 903, 906, 908, 909, 911, 912, 914, 916, 917, 921, 923, 924, 926, 928, 929, 932, 934, 936, 941, 943, 945, 946, 948, 951, 953, 955, 957, 959, 960, 963, 965, 966, 969, 972, 974, 977, 979, 981, 982, 985, 989, 990, 992, 994, 996, 997, 998, 999, 1001, 1005, 1008, 1010, 1012, 1013, 1014, 1015, 1017, 1019, 1021, 1023, 1027, 1028, 1029, 1030, 1032, 1034, 1037, 1039, 1041, 1042, 1044, 1047, 1049, 1050, 1053, 1055, 1057, 1059, 1060, 1062, 1065, 1070, 1071, 1072, 1075, 1076, 1078, 1080, 1082, 1083, 1084, 1087, 1089, 1091, 1093, 1094, 1096, 1098, 1101, 1103, 1105, 1107, 1109, 1110, 1112, 1114, 1115, 1119, 1121, 1125, 1128, 1130, 1131, 1134, 1138, 1140, 1141, 1142, 1143, 1144, 1145, 1147, 1149, 1150, 1152, 1154, 1155, 1156, 1158, 1160, 1161, 1162, 1165, 1168, 1169, 1172, 1174, 1178, 1179, 1182, 1185, 1189, 1190, 1191, 1192, 1194, 1195, 1197, 1198, 1201, 1203, 1205, 1206, 1209, 1210, 1212, 1215, 1217, 1218, 1220, 1222, 1224, 1225, 1226, 1228, 1230, 1232, 1234, 1237, 1239, 1242, 1244, 1245, 1248, 1251, 1252, 1255, 1256, 1257, 1260, 1261, 1262, 1265, 1266, 1267, 1268, 1271, 1274, 1275, 1277, 1278, 1279, 1284, 1286, 1289, 1291, 1296, 1297, 1299, 1303, 1304, 1306, 1308, 1310, 1311, 1312, 1314, 1315, 1316, 1317, 1319, 1320, 1321, 1323, 1324, 1328, 1330, 1334, 1335, 1338, 1339, 1342, 1345, 1349, 1353, 1355, 1356, 1357, 1358, 1360, 1361, 1362, 1365, 1366, 1368, 1369, 1370, 1372, 1375, 1378, 1382, 1383, 1385, 1387, 1389, 1391, 1395, 1396, 1397, 1398, 1399, 1401, 1403, 1404, 1406, 1407, 1410, 1411, 1414, 1415, 1417, 1422, 1424, 1429, 1431, 1432, 1434, 1438, 1440, 1441, 1444, 1445, 1450, 1452, 1453, 1454, 1456, 1460, 1462, 1463, 1464, 1465, 1466, 1468, 1470, 1473, 1474, 1475, 1477, 1478, 1481, 1485, 1487, 1488, 1489, 1491, 1492, 1494, 1496, 1498, 1501, 1503, 1504, 1506, 1508, 1511, 1512, 1513, 1514, 1515, 1518, 1519, 1522, 1524, 1526, 1528, 1530, 1531, 1534, 1535, 1537, 1538, 1541, 1542, 1544, 1546, 1550, 1552, 1554, 1556, 1557, 1558, 1560, 1562, 1564, 1567, 1568, 1573, 1577, 1579, 1581, 1584, 1586, 1587, 1589, 1595, 1597, 1598, 1599, 1600, 1603, 1605, 1606, 1611, 1615, 1617, 1620, 1621, 1622, 1624, 1625, 1627, 1629, 1631, 1633, 1635, 1637, 1639, 1641, 1643, 1645, 1646, 1647, 1651, 1652, 1653, 1655, 1656, 1657, 1659, 1661, 1663, 1665, 1667, 1668, 1669, 1670, 1672, 1675, 1677, 1679, 1681, 1683, 1685, 1686, 1687, 1689, 1690, 1692, 1699, 1703, 1705, 1706, 1707, 1714, 1716, 1718, 1722, 1726, 1727, 1729, 1732, 1734, 1735, 1740, 1742, 1743, 1744, 1745, 1747, 1748, 1750, 1753, 1754, 1756, 1758, 1759, 1760, 1761, 1763, 1765, 1769, 1771, 1774, 1777, 1780, 1783, 1785, 1786, 1787, 1789, 1794, 1795, 1797, 1798, 1799, 1800, 1801, 1804, 1806, 1807, 1809, 1810, 1811, 1813, 1815, 1816, 1817, 1819, 1824, 1826, 1829, 1832, 1833, 1837, 1838, 1841, 1843, 1845, 1846, 1849, 1852, 1853, 1855, 1860, 1863, 1865, 1868, 1870, 1872, 1874, 1876, 1878, 1880, 1883, 1884, 1885, 1887, 1889, 1891, 1893, 1895, 1897, 1899, 1900, 1901, 1902, 1904, 1906, 1909, 1911, 1912, 1913, 1914, 1915, 1917, 1918, 1924, 1926, 1928, 1930, 1931, 1933, 1934, 1935, 1937, 1939, 1940, 1942, 1944, 1946, 1947, 1949, 1950, 1952, 1954, 1967, 1970, 1973, 1975, 1976, 1978, 1981, 1983, 1984, 1986, 1988, 1989, 1993, 1994, 1995, 1997, 2000], deadline = 1)
        configuration.add_task(name="Task3", identifier=3, period=1.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=0.072397, acet=0.072397, et_stddev=0.024132333333333335, deadline= 1)
        configuration.add_task(name="Task1", identifier=1, period=17.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=12.124449, acet=12.124449, et_stddev=4.041483, deadline= 34)
        configuration.add_task(name="Task2", identifier=2, period=2.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=1.628798, acet=1.628798, et_stddev=0.5429326666666666, deadline= 2)
        configuration.add_task(name="Task4", identifier=4, period=13.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=2, acet=1.707178, et_stddev=0.5690593333333334 , list_activation_dates=[7, 23, 44, 67, 89, 112, 127, 184, 210, 249, 265, 291, 308, 328, 354, 372, 396, 414, 428, 445, 477, 491, 514, 532, 549, 583, 597, 614, 658, 685, 706, 728, 760, 778, 831, 852, 866, 885, 907, 939, 959, 974, 1000, 1024, 1047, 1063, 1098, 1116, 1148, 1174, 1233, 1249, 1266, 1289, 1349, 1369, 1392, 1407, 1444, 1462, 1501, 1519, 1565, 1583, 1619, 1662, 1683, 1721, 1738, 1795, 1824, 1856, 1870, 1896, 1929, 1953], deadline = 23)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "28")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "28")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "28")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "28")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task2", identifier=2, period=2.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=1.770015, acet=1.770015, et_stddev=0.590005, deadline= 2)
        configuration.add_task(name="Task6", identifier=6, period=4.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.007734, et_stddev=0.002578 , list_activation_dates=[5, 17, 23, 42, 57, 62, 68, 74, 78, 87, 91, 95, 101, 110, 122, 131, 139, 146, 153, 165, 170, 181, 186, 193, 205, 216, 222, 230, 235, 242, 248, 253, 259, 273, 283, 287, 292, 299, 304, 309, 319, 324, 330, 341, 350, 362, 366, 371, 382, 390, 405, 409, 420, 428, 434, 453, 458, 463, 467, 480, 487, 495, 500, 510, 515, 523, 529, 535, 546, 550, 557, 562, 574, 578, 582, 589, 602, 611, 616, 622, 626, 633, 640, 644, 648, 653, 665, 670, 674, 682, 689, 705, 715, 732, 736, 746, 758, 767, 787, 798, 803, 816, 820, 829, 836, 849, 857, 865, 870, 875, 880, 885, 889, 894, 902, 911, 915, 921, 929, 940, 945, 950, 956, 961, 975, 981, 995, 1000, 1008, 1014, 1021, 1026, 1037, 1048, 1052, 1064, 1070, 1076, 1080, 1104, 1113, 1118, 1125, 1129, 1135, 1140, 1147, 1165, 1170, 1177, 1185, 1192, 1199, 1207, 1212, 1227, 1236, 1243, 1254, 1261, 1269, 1280, 1287, 1296, 1308, 1315, 1328, 1340, 1346, 1350, 1363, 1368, 1372, 1376, 1384, 1390, 1397, 1410, 1415, 1428, 1438, 1442, 1459, 1467, 1479, 1483, 1488, 1493, 1501, 1505, 1514, 1521, 1526, 1536, 1542, 1554, 1563, 1572, 1576, 1582, 1587, 1593, 1604, 1609, 1614, 1621, 1625, 1631, 1637, 1641, 1646, 1653, 1662, 1677, 1681, 1687, 1691, 1711, 1719, 1726, 1730, 1736, 1742, 1749, 1753, 1758, 1769, 1775, 1781, 1785, 1807, 1811, 1823, 1827, 1835, 1840, 1846, 1853, 1872, 1878, 1884, 1891, 1898, 1910, 1915, 1922, 1941, 1947, 1952, 1956, 1965, 1971, 1975, 1983, 1990, 1996], deadline = 1)
        configuration.add_task(name="Task5", identifier=5, period=45.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=7, acet=6.838082, et_stddev=2.279360666666667 , list_activation_dates=[104, 186, 265, 508, 555, 788, 843, 946, 993, 1040, 1107, 1304, 1562, 1688, 1744, 1815, 1897, 1942], deadline = 55)
        configuration.add_task(name="Task3", identifier=3, period=34.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=20.292879, acet=20.292879, et_stddev=6.7642929999999994, deadline= 31)
        configuration.add_task(name="Task4", identifier=4, period=1.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.046109, et_stddev=0.015369666666666665 , list_activation_dates=[2, 3, 6, 7, 8, 9, 12, 15, 16, 17, 18, 20, 21, 22, 25, 27, 29, 32, 34, 35, 36, 37, 40, 43, 44, 50, 52, 53, 55, 56, 58, 59, 60, 62, 63, 65, 67, 69, 72, 73, 78, 80, 82, 83, 85, 87, 90, 93, 94, 96, 98, 100, 103, 104, 107, 108, 109, 110, 113, 114, 115, 116, 118, 119, 120, 121, 122, 123, 125, 126, 129, 132, 133, 136, 140, 143, 145, 149, 153, 155, 157, 158, 159, 160, 164, 166, 168, 169, 171, 172, 175, 177, 179, 180, 181, 183, 186, 188, 189, 192, 193, 197, 198, 200, 201, 203, 204, 205, 206, 208, 209, 210, 212, 214, 216, 218, 219, 221, 222, 224, 225, 226, 227, 228, 229, 231, 233, 236, 237, 238, 239, 240, 241, 242, 245, 247, 248, 249, 252, 254, 255, 257, 258, 259, 260, 263, 266, 267, 268, 270, 272, 275, 276, 277, 282, 284, 286, 288, 289, 293, 295, 296, 298, 300, 301, 302, 306, 308, 309, 310, 312, 313, 314, 315, 319, 322, 323, 324, 326, 327, 328, 329, 331, 333, 335, 336, 337, 338, 339, 340, 342, 343, 345, 346, 350, 354, 358, 360, 362, 364, 365, 367, 368, 372, 373, 375, 376, 378, 379, 381, 382, 383, 385, 388, 391, 394, 396, 398, 400, 402, 403, 404, 407, 409, 410, 412, 415, 417, 418, 420, 421, 423, 425, 426, 428, 430, 431, 432, 433, 434, 436, 439, 441, 442, 444, 445, 447, 448, 449, 452, 457, 459, 463, 467, 470, 475, 477, 479, 481, 485, 488, 490, 492, 493, 495, 496, 498, 500, 503, 504, 507, 509, 510, 512, 515, 517, 518, 519, 520, 522, 523, 527, 528, 530, 531, 533, 535, 537, 539, 542, 543, 544, 546, 547, 549, 551, 553, 555, 557, 559, 564, 568, 569, 570, 572, 573, 574, 576, 578, 580, 582, 583, 585, 588, 590, 592, 596, 599, 600, 603, 605, 606, 610, 614, 615, 617, 620, 621, 622, 623, 624, 626, 627, 628, 629, 631, 635, 636, 641, 645, 647, 648, 651, 652, 654, 655, 657, 658, 661, 662, 663, 664, 665, 668, 674, 676, 680, 683, 684, 686, 687, 688, 689, 694, 697, 698, 700, 703, 706, 710, 711, 713, 715, 717, 718, 720, 722, 723, 727, 728, 731, 733, 735, 736, 737, 738, 739, 740, 742, 743, 744, 746, 747, 749, 751, 752, 753, 754, 757, 758, 759, 762, 763, 764, 765, 769, 772, 774, 775, 778, 780, 782, 784, 786, 787, 789, 790, 792, 794, 796, 799, 801, 804, 805, 806, 807, 808, 811, 812, 813, 815, 817, 820, 821, 822, 824, 826, 829, 831, 832, 836, 837, 839, 840, 842, 843, 845, 847, 848, 849, 851, 854, 855, 856, 859, 863, 866, 870, 871, 872, 873, 874, 876, 879, 882, 885, 886, 888, 893, 894, 897, 898, 899, 901, 904, 907, 909, 913, 914, 916, 917, 918, 919, 921, 922, 925, 926, 928, 930, 931, 933, 936, 937, 939, 941, 944, 946, 949, 951, 952, 955, 957, 958, 960, 963, 965, 968, 970, 971, 972, 973, 975, 977, 978, 980, 983, 986, 989, 991, 992, 995, 997, 1000, 1001, 1002, 1003, 1004, 1008, 1010, 1012, 1014, 1016, 1018, 1019, 1020, 1024, 1025, 1026, 1027, 1028, 1029, 1033, 1035, 1037, 1038, 1041, 1042, 1043, 1044, 1046, 1049, 1050, 1051, 1053, 1058, 1061, 1062, 1064, 1065, 1067, 1068, 1071, 1074, 1077, 1078, 1079, 1082, 1084, 1085, 1088, 1090, 1091, 1093, 1095, 1096, 1099, 1101, 1103, 1107, 1108, 1112, 1115, 1120, 1122, 1123, 1125, 1126, 1128, 1129, 1131, 1132, 1137, 1139, 1140, 1141, 1142, 1143, 1144, 1145, 1147, 1149, 1152, 1153, 1154, 1156, 1158, 1161, 1163, 1165, 1167, 1170, 1171, 1172, 1174, 1175, 1176, 1179, 1182, 1186, 1188, 1191, 1192, 1193, 1195, 1198, 1200, 1202, 1207, 1210, 1211, 1212, 1214, 1216, 1217, 1218, 1219, 1220, 1223, 1224, 1225, 1227, 1229, 1234, 1235, 1236, 1238, 1240, 1241, 1244, 1246, 1247, 1249, 1250, 1251, 1252, 1254, 1255, 1259, 1260, 1261, 1262, 1263, 1266, 1268, 1269, 1271, 1273, 1274, 1276, 1278, 1280, 1281, 1282, 1284, 1286, 1288, 1290, 1293, 1294, 1297, 1301, 1302, 1305, 1307, 1308, 1310, 1312, 1313, 1314, 1316, 1317, 1318, 1320, 1321, 1323, 1325, 1326, 1330, 1332, 1333, 1335, 1336, 1338, 1340, 1342, 1343, 1345, 1347, 1348, 1349, 1350, 1352, 1354, 1355, 1356, 1358, 1360, 1364, 1368, 1369, 1372, 1374, 1376, 1377, 1379, 1381, 1382, 1384, 1386, 1387, 1388, 1390, 1391, 1393, 1396, 1400, 1401, 1402, 1404, 1405, 1406, 1408, 1412, 1414, 1416, 1418, 1419, 1421, 1423, 1424, 1425, 1426, 1428, 1430, 1434, 1435, 1437, 1439, 1442, 1443, 1445, 1446, 1447, 1448, 1449, 1451, 1452, 1454, 1456, 1459, 1461, 1463, 1464, 1466, 1467, 1468, 1472, 1473, 1475, 1477, 1479, 1481, 1483, 1484, 1486, 1488, 1490, 1493, 1495, 1496, 1497, 1498, 1499, 1500, 1501, 1503, 1506, 1507, 1509, 1510, 1511, 1518, 1520, 1521, 1523, 1525, 1527, 1528, 1529, 1530, 1531, 1532, 1534, 1538, 1543, 1545, 1546, 1547, 1548, 1550, 1552, 1553, 1555, 1560, 1561, 1562, 1564, 1566, 1568, 1570, 1571, 1576, 1578, 1579, 1580, 1582, 1583, 1585, 1586, 1587, 1588, 1589, 1594, 1595, 1597, 1599, 1600, 1602, 1604, 1605, 1610, 1614, 1615, 1616, 1619, 1623, 1625, 1627, 1629, 1631, 1633, 1636, 1637, 1638, 1640, 1642, 1643, 1646, 1647, 1650, 1656, 1658, 1660, 1662, 1663, 1665, 1667, 1670, 1671, 1672, 1676, 1677, 1679, 1680, 1682, 1684, 1685, 1687, 1689, 1691, 1693, 1694, 1696, 1699, 1703, 1704, 1705, 1708, 1712, 1715, 1716, 1718, 1719, 1721, 1722, 1725, 1726, 1727, 1732, 1734, 1737, 1738, 1739, 1740, 1742, 1743, 1746, 1749, 1750, 1752, 1753, 1754, 1756, 1758, 1759, 1760, 1761, 1763, 1765, 1768, 1769, 1771, 1773, 1774, 1776, 1778, 1781, 1783, 1784, 1785, 1786, 1788, 1789, 1790, 1791, 1794, 1796, 1798, 1799, 1800, 1803, 1806, 1807, 1808, 1809, 1810, 1812, 1815, 1816, 1817, 1819, 1822, 1825, 1827, 1828, 1831, 1832, 1833, 1836, 1840, 1842, 1846, 1850, 1852, 1853, 1855, 1856, 1857, 1858, 1860, 1861, 1862, 1863, 1864, 1866, 1868, 1871, 1873, 1875, 1876, 1878, 1880, 1882, 1883, 1885, 1887, 1889, 1891, 1895, 1902, 1905, 1908, 1912, 1918, 1920, 1922, 1924, 1925, 1927, 1930, 1934, 1935, 1938, 1944, 1945, 1946, 1948, 1949, 1951, 1952, 1954, 1957, 1959, 1960, 1962, 1963, 1965, 1966, 1968, 1970, 1971, 1972, 1973, 1974, 1975, 1976, 1977, 1984, 1986, 1987, 1988, 1990, 1993, 1996, 1999, 2000], deadline = 1)
        configuration.add_task(name="Task1", identifier=1, period=7.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=0.827, acet=0.827, et_stddev=0.27566666666666667, deadline= 8)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "30")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "30")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "30")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "30")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task4", identifier=4, period=10.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=2, acet=1.138118, et_stddev=0.37937266666666664 , list_activation_dates=[10, 31, 55, 67, 79, 118, 149, 179, 212, 231, 242, 259, 271, 298, 359, 376, 409, 420, 451, 473, 486, 516, 528, 581, 608, 631, 645, 660, 672, 702, 714, 738, 750, 764, 782, 806, 824, 847, 865, 889, 899, 916, 939, 957, 970, 993, 1010, 1052, 1081, 1100, 1111, 1135, 1149, 1162, 1174, 1186, 1252, 1265, 1278, 1292, 1306, 1329, 1344, 1357, 1377, 1392, 1423, 1440, 1451, 1464, 1478, 1494, 1513, 1523, 1538, 1550, 1560, 1610, 1653, 1665, 1690, 1704, 1715, 1729, 1758, 1774, 1790, 1802, 1815, 1835, 1860, 1883, 1917, 1934, 1951, 1977, 1991], deadline = 7)
        configuration.add_task(name="Task1", identifier=1, period=41.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=0.748269, acet=0.748269, et_stddev=0.24942299999999998, deadline= 76)
        configuration.add_task(name="Task5", identifier=5, period=6.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.36496, et_stddev=0.12165333333333334 , list_activation_dates=[22, 32, 45, 62, 74, 81, 101, 107, 132, 139, 146, 154, 168, 174, 189, 207, 214, 222, 230, 240, 247, 262, 269, 277, 296, 308, 315, 351, 360, 374, 384, 402, 410, 443, 450, 456, 468, 478, 488, 501, 517, 527, 545, 553, 567, 575, 592, 601, 614, 622, 637, 647, 665, 689, 701, 707, 716, 724, 732, 743, 751, 763, 778, 809, 834, 842, 850, 857, 866, 873, 884, 913, 937, 954, 960, 969, 981, 997, 1005, 1012, 1020, 1028, 1034, 1055, 1066, 1096, 1107, 1136, 1142, 1159, 1165, 1180, 1194, 1203, 1221, 1229, 1236, 1243, 1255, 1275, 1282, 1290, 1297, 1308, 1317, 1326, 1340, 1349, 1366, 1377, 1387, 1397, 1411, 1421, 1437, 1445, 1453, 1461, 1467, 1478, 1507, 1522, 1539, 1548, 1558, 1569, 1587, 1599, 1606, 1618, 1626, 1643, 1685, 1691, 1705, 1711, 1721, 1727, 1734, 1742, 1760, 1769, 1776, 1785, 1805, 1813, 1826, 1846, 1853, 1862, 1872, 1901, 1909, 1919, 1930, 1939, 1946, 1952, 1964, 1975, 1985, 1992], deadline = 6)
        configuration.add_task(name="Task3", identifier=3, period=16.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=9.438221, acet=9.438221, et_stddev=3.1460736666666667, deadline= 12)
        configuration.add_task(name="Task2", identifier=2, period=23.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=22.812796, acet=22.812796, et_stddev=7.604265333333333, deadline= 29)
        configuration.add_task(name="Task6", identifier=6, period=2.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.050722, et_stddev=0.016907333333333333 , list_activation_dates=[1, 8, 13, 16, 19, 21, 31, 34, 37, 42, 47, 50, 53, 56, 59, 62, 64, 66, 72, 77, 82, 91, 99, 101, 104, 108, 112, 115, 118, 122, 126, 129, 131, 135, 138, 140, 142, 145, 150, 154, 159, 165, 168, 174, 177, 180, 184, 186, 191, 194, 199, 203, 210, 212, 221, 235, 237, 240, 244, 248, 250, 252, 254, 258, 261, 263, 267, 269, 277, 280, 284, 289, 291, 293, 295, 297, 301, 304, 308, 311, 316, 318, 320, 323, 327, 335, 338, 346, 350, 353, 356, 358, 366, 371, 375, 378, 385, 391, 393, 395, 399, 402, 405, 408, 412, 415, 419, 422, 424, 429, 432, 438, 443, 446, 449, 455, 457, 460, 462, 465, 470, 473, 475, 477, 480, 485, 489, 493, 495, 497, 501, 503, 505, 512, 516, 521, 527, 530, 536, 539, 541, 546, 555, 559, 566, 570, 572, 574, 577, 588, 591, 594, 598, 602, 604, 607, 613, 623, 628, 630, 632, 638, 644, 646, 650, 653, 656, 660, 664, 670, 676, 680, 685, 688, 693, 696, 698, 703, 705, 712, 715, 717, 721, 725, 729, 737, 742, 745, 747, 751, 764, 766, 772, 776, 780, 783, 790, 792, 795, 799, 803, 806, 809, 812, 817, 819, 822, 824, 831, 835, 839, 842, 844, 848, 851, 855, 859, 862, 865, 867, 870, 875, 880, 883, 886, 888, 894, 897, 902, 904, 906, 912, 914, 921, 924, 929, 933, 941, 945, 948, 952, 955, 960, 962, 965, 967, 970, 978, 981, 983, 986, 989, 995, 998, 1001, 1004, 1007, 1010, 1012, 1016, 1019, 1021, 1025, 1029, 1032, 1034, 1037, 1040, 1044, 1047, 1053, 1055, 1058, 1062, 1066, 1071, 1078, 1081, 1084, 1086, 1090, 1092, 1094, 1096, 1100, 1102, 1105, 1107, 1110, 1112, 1115, 1122, 1127, 1129, 1132, 1135, 1141, 1148, 1152, 1154, 1156, 1159, 1162, 1170, 1172, 1176, 1186, 1188, 1191, 1196, 1202, 1204, 1210, 1220, 1224, 1227, 1229, 1232, 1235, 1238, 1241, 1244, 1247, 1252, 1256, 1262, 1265, 1276, 1282, 1285, 1289, 1292, 1295, 1298, 1303, 1306, 1315, 1320, 1323, 1325, 1328, 1331, 1334, 1339, 1342, 1349, 1353, 1356, 1359, 1361, 1365, 1367, 1372, 1378, 1382, 1386, 1393, 1396, 1399, 1409, 1411, 1424, 1429, 1433, 1436, 1438, 1442, 1450, 1454, 1458, 1461, 1463, 1470, 1472, 1476, 1483, 1485, 1493, 1497, 1499, 1503, 1507, 1509, 1515, 1518, 1520, 1525, 1528, 1531, 1533, 1539, 1541, 1544, 1546, 1550, 1553, 1557, 1563, 1571, 1573, 1576, 1581, 1585, 1593, 1596, 1599, 1604, 1608, 1610, 1614, 1620, 1623, 1626, 1631, 1634, 1636, 1640, 1643, 1655, 1657, 1659, 1661, 1664, 1667, 1670, 1672, 1677, 1679, 1682, 1686, 1688, 1690, 1692, 1696, 1702, 1706, 1710, 1714, 1717, 1719, 1722, 1724, 1732, 1736, 1739, 1742, 1745, 1750, 1753, 1755, 1758, 1761, 1771, 1776, 1783, 1786, 1790, 1792, 1795, 1800, 1803, 1808, 1817, 1820, 1825, 1828, 1831, 1840, 1849, 1852, 1855, 1858, 1861, 1863, 1867, 1870, 1875, 1882, 1885, 1887, 1889, 1892, 1896, 1899, 1902, 1908, 1914, 1917, 1919, 1922, 1924, 1926, 1928, 1931, 1937, 1942, 1945, 1951, 1956, 1960, 1963, 1965, 1967, 1970, 1975, 1979, 1984, 1987, 1989, 1991, 1993, 1996, 1999], deadline = 4)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "31")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "31")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "31")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "31")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task1", identifier=1, period=2.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=0.740828, acet=0.740828, et_stddev=0.24694266666666667, deadline= 3)
        configuration.add_task(name="Task5", identifier=5, period=3.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.022661, et_stddev=0.007553666666666667 , list_activation_dates=[12, 16, 19, 30, 35, 41, 52, 57, 64, 68, 74, 79, 83, 86, 90, 93, 97, 100, 107, 113, 116, 122, 131, 143, 150, 157, 168, 178, 183, 187, 194, 199, 203, 221, 225, 235, 240, 245, 250, 256, 259, 266, 273, 278, 283, 293, 299, 304, 307, 315, 319, 323, 328, 334, 337, 341, 344, 349, 352, 359, 362, 371, 374, 378, 385, 390, 394, 398, 402, 408, 411, 414, 418, 422, 426, 432, 436, 441, 449, 455, 461, 467, 470, 476, 481, 487, 490, 495, 502, 508, 511, 517, 521, 526, 535, 540, 547, 554, 558, 569, 575, 582, 588, 593, 600, 608, 611, 616, 627, 630, 634, 642, 646, 651, 654, 663, 669, 682, 691, 703, 708, 713, 716, 722, 725, 732, 735, 750, 755, 765, 769, 773, 783, 788, 791, 801, 815, 820, 824, 827, 835, 848, 861, 869, 891, 896, 901, 904, 908, 912, 916, 920, 923, 930, 937, 940, 944, 948, 953, 956, 960, 974, 982, 987, 993, 996, 999, 1004, 1009, 1018, 1026, 1033, 1038, 1044, 1051, 1056, 1060, 1065, 1071, 1075, 1083, 1092, 1096, 1105, 1109, 1122, 1130, 1134, 1139, 1147, 1155, 1162, 1166, 1171, 1175, 1180, 1188, 1192, 1197, 1201, 1206, 1217, 1224, 1229, 1240, 1244, 1252, 1256, 1264, 1268, 1271, 1277, 1284, 1289, 1293, 1300, 1304, 1309, 1316, 1322, 1327, 1333, 1339, 1347, 1351, 1357, 1360, 1364, 1369, 1372, 1378, 1382, 1385, 1393, 1412, 1416, 1421, 1429, 1433, 1437, 1440, 1446, 1450, 1454, 1461, 1471, 1477, 1484, 1492, 1496, 1505, 1508, 1512, 1515, 1519, 1524, 1530, 1533, 1541, 1546, 1550, 1559, 1563, 1567, 1572, 1575, 1579, 1585, 1591, 1601, 1608, 1616, 1621, 1626, 1635, 1638, 1641, 1644, 1647, 1650, 1653, 1665, 1669, 1672, 1676, 1682, 1685, 1690, 1694, 1697, 1706, 1711, 1716, 1722, 1734, 1737, 1749, 1754, 1757, 1765, 1770, 1774, 1783, 1788, 1792, 1796, 1800, 1803, 1807, 1813, 1818, 1822, 1826, 1832, 1836, 1840, 1843, 1848, 1854, 1861, 1864, 1869, 1874, 1877, 1883, 1894, 1899, 1902, 1911, 1916, 1924, 1933, 1936, 1941, 1948, 1957, 1962, 1967, 1970, 1974, 1980, 1988], deadline = 6)
        configuration.add_task(name="Task3", identifier=3, period=4.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=2.129791, acet=2.129791, et_stddev=0.7099303333333333, deadline= 7)
        configuration.add_task(name="Task6", identifier=6, period=4.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.263944, et_stddev=0.08798133333333334 , list_activation_dates=[4, 13, 17, 23, 30, 36, 46, 66, 75, 80, 89, 93, 103, 108, 116, 123, 128, 133, 138, 144, 149, 159, 169, 174, 180, 188, 197, 203, 208, 215, 224, 233, 242, 248, 261, 265, 271, 275, 282, 296, 303, 307, 314, 319, 324, 329, 339, 344, 355, 365, 369, 385, 390, 407, 412, 422, 426, 430, 441, 445, 450, 459, 481, 485, 495, 503, 507, 516, 521, 525, 541, 554, 563, 567, 573, 580, 585, 589, 596, 600, 611, 627, 632, 658, 662, 668, 672, 678, 686, 695, 705, 717, 721, 728, 732, 741, 750, 755, 761, 767, 773, 781, 787, 793, 797, 805, 812, 819, 826, 836, 849, 854, 862, 866, 873, 878, 883, 897, 901, 912, 934, 938, 944, 949, 957, 963, 968, 993, 1002, 1014, 1021, 1026, 1033, 1047, 1051, 1056, 1061, 1067, 1074, 1080, 1086, 1092, 1100, 1119, 1124, 1128, 1133, 1138, 1146, 1151, 1156, 1167, 1176, 1182, 1186, 1190, 1198, 1202, 1208, 1213, 1219, 1225, 1232, 1237, 1250, 1257, 1264, 1274, 1280, 1289, 1297, 1303, 1310, 1317, 1322, 1327, 1335, 1342, 1349, 1353, 1358, 1367, 1374, 1380, 1385, 1392, 1401, 1411, 1416, 1424, 1431, 1438, 1444, 1449, 1454, 1458, 1475, 1483, 1491, 1503, 1508, 1514, 1521, 1526, 1530, 1540, 1545, 1559, 1569, 1573, 1578, 1588, 1600, 1609, 1616, 1629, 1634, 1639, 1644, 1650, 1660, 1665, 1669, 1674, 1682, 1690, 1698, 1704, 1709, 1715, 1726, 1730, 1734, 1747, 1755, 1763, 1769, 1778, 1785, 1790, 1800, 1805, 1816, 1821, 1828, 1840, 1848, 1853, 1861, 1866, 1870, 1875, 1883, 1889, 1893, 1899, 1903, 1912, 1919, 1923, 1931, 1937, 1945, 1951, 1957, 1962, 1967, 1972, 1977, 1984, 1994, 2000], deadline = 8)
        configuration.add_task(name="Task2", identifier=2, period=3.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=2.091414, acet=2.091414, et_stddev=0.6971379999999999, deadline= 3)
        configuration.add_task(name="Task4", identifier=4, period=6.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.75876, et_stddev=0.25292 , list_activation_dates=[4, 21, 28, 34, 48, 63, 70, 99, 107, 118, 125, 131, 140, 147, 156, 166, 175, 187, 193, 211, 225, 232, 244, 251, 259, 270, 277, 294, 303, 316, 328, 341, 347, 355, 368, 379, 392, 405, 421, 437, 447, 455, 465, 480, 492, 499, 506, 513, 526, 546, 555, 565, 591, 601, 625, 639, 648, 656, 670, 686, 694, 701, 711, 721, 727, 734, 750, 757, 764, 780, 788, 828, 857, 870, 887, 893, 901, 908, 914, 920, 932, 940, 947, 954, 973, 985, 992, 1002, 1019, 1030, 1036, 1051, 1083, 1093, 1100, 1109, 1121, 1138, 1152, 1168, 1176, 1186, 1205, 1218, 1226, 1233, 1251, 1262, 1269, 1279, 1286, 1294, 1300, 1316, 1325, 1337, 1356, 1367, 1375, 1381, 1388, 1395, 1403, 1414, 1421, 1443, 1465, 1472, 1479, 1487, 1496, 1512, 1544, 1563, 1569, 1577, 1583, 1589, 1617, 1623, 1631, 1641, 1651, 1666, 1672, 1681, 1692, 1721, 1730, 1746, 1756, 1764, 1788, 1800, 1811, 1819, 1852, 1866, 1873, 1884, 1892, 1901, 1910, 1921, 1935, 1950, 1959, 1969, 1978, 1985, 1992], deadline = 10)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "32")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "32")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "32")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "32")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task4", identifier=4, period=9.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.40618, et_stddev=0.13539333333333334 , list_activation_dates=[3, 33, 55, 66, 86, 95, 107, 149, 170, 196, 216, 234, 258, 274, 283, 325, 361, 374, 388, 398, 415, 430, 458, 480, 490, 503, 516, 548, 564, 581, 591, 610, 630, 641, 652, 673, 755, 772, 784, 809, 829, 844, 857, 881, 903, 914, 954, 965, 975, 1030, 1044, 1071, 1107, 1128, 1142, 1156, 1186, 1197, 1208, 1220, 1257, 1290, 1302, 1314, 1374, 1400, 1417, 1429, 1440, 1460, 1479, 1494, 1509, 1520, 1532, 1557, 1571, 1583, 1613, 1622, 1652, 1674, 1686, 1698, 1710, 1736, 1758, 1770, 1788, 1798, 1808, 1819, 1835, 1856, 1883, 1901, 1912, 1935, 1955, 1977, 1997], deadline = 1)
        configuration.add_task(name="Task5", identifier=5, period=8.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.054109, et_stddev=0.01803633333333333 , list_activation_dates=[17, 30, 74, 91, 111, 134, 143, 155, 165, 176, 187, 198, 217, 231, 249, 263, 274, 284, 298, 312, 321, 336, 356, 367, 380, 391, 405, 414, 423, 433, 456, 471, 484, 501, 513, 522, 530, 542, 552, 586, 594, 610, 623, 653, 667, 681, 693, 707, 718, 732, 747, 755, 773, 789, 803, 816, 824, 837, 848, 858, 890, 900, 911, 928, 937, 998, 1019, 1045, 1064, 1078, 1086, 1094, 1105, 1113, 1122, 1137, 1146, 1174, 1206, 1221, 1239, 1255, 1271, 1279, 1291, 1314, 1346, 1364, 1378, 1389, 1399, 1408, 1425, 1435, 1446, 1454, 1464, 1472, 1492, 1509, 1518, 1526, 1539, 1548, 1556, 1572, 1591, 1603, 1612, 1629, 1638, 1650, 1669, 1684, 1692, 1709, 1717, 1747, 1760, 1780, 1792, 1801, 1812, 1832, 1843, 1869, 1880, 1948, 1968, 1976, 1997], deadline = 14)
        configuration.add_task(name="Task6", identifier=6, period=21.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=4, acet=3.110208, et_stddev=1.036736 , list_activation_dates=[20, 78, 107, 193, 228, 250, 299, 327, 394, 422, 447, 519, 542, 570, 603, 710, 731, 781, 809, 846, 869, 894, 922, 949, 1069, 1104, 1142, 1166, 1200, 1228, 1301, 1360, 1399, 1449, 1491, 1600, 1623, 1645, 1710, 1784, 1827, 1869, 1898, 1934, 1963, 1985], deadline = 37)
        configuration.add_task(name="Task3", identifier=3, period=7.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=6.492336, acet=6.492336, et_stddev=2.164112, deadline= 11)
        configuration.add_task(name="Task1", identifier=1, period=13.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=6.320462, acet=6.320462, et_stddev=2.1068206666666667, deadline= 10)
        configuration.add_task(name="Task2", identifier=2, period=6.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=1.118003, acet=1.118003, et_stddev=0.3726676666666667, deadline= 6)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "33")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "33")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "33")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "33")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task1", identifier=1, period=2.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=0.820806, acet=0.820806, et_stddev=0.273602, deadline= 2)
        configuration.add_task(name="Task6", identifier=6, period=2.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.31726, et_stddev=0.10575333333333332 , list_activation_dates=[3, 6, 9, 11, 13, 18, 24, 27, 30, 34, 37, 40, 43, 47, 50, 57, 63, 66, 69, 73, 78, 80, 88, 91, 96, 98, 103, 107, 112, 115, 118, 122, 128, 133, 136, 144, 147, 150, 153, 165, 172, 175, 178, 187, 190, 192, 195, 198, 203, 207, 209, 211, 216, 221, 228, 232, 240, 246, 248, 253, 256, 258, 261, 263, 268, 270, 273, 275, 279, 282, 290, 297, 301, 303, 306, 308, 311, 314, 317, 319, 322, 324, 327, 330, 333, 335, 338, 343, 346, 349, 352, 356, 360, 363, 366, 369, 371, 376, 381, 383, 388, 390, 392, 395, 402, 406, 412, 416, 419, 424, 429, 433, 435, 437, 440, 447, 449, 453, 455, 465, 467, 469, 472, 474, 479, 481, 493, 497, 499, 502, 504, 507, 512, 517, 519, 521, 536, 538, 541, 544, 547, 550, 555, 557, 561, 571, 574, 578, 581, 585, 589, 595, 600, 602, 607, 612, 616, 621, 623, 627, 634, 637, 641, 643, 646, 649, 654, 656, 658, 663, 667, 670, 672, 676, 681, 683, 685, 690, 693, 711, 714, 716, 718, 721, 726, 730, 735, 738, 744, 746, 755, 760, 765, 768, 770, 773, 776, 779, 782, 784, 787, 790, 793, 803, 806, 810, 813, 819, 822, 825, 827, 830, 837, 842, 849, 851, 855, 858, 860, 866, 874, 878, 881, 884, 888, 892, 894, 897, 901, 904, 910, 912, 916, 920, 922, 926, 929, 932, 936, 938, 941, 943, 946, 948, 950, 956, 958, 962, 965, 968, 971, 974, 976, 980, 982, 989, 994, 999, 1007, 1011, 1019, 1024, 1027, 1031, 1034, 1039, 1042, 1045, 1047, 1053, 1061, 1066, 1070, 1073, 1079, 1085, 1089, 1091, 1093, 1105, 1112, 1115, 1118, 1122, 1124, 1126, 1130, 1134, 1138, 1143, 1148, 1151, 1159, 1163, 1167, 1172, 1174, 1179, 1183, 1185, 1195, 1204, 1209, 1213, 1215, 1218, 1220, 1222, 1225, 1232, 1235, 1240, 1243, 1246, 1250, 1254, 1259, 1266, 1269, 1272, 1274, 1280, 1283, 1287, 1290, 1294, 1297, 1304, 1307, 1310, 1316, 1319, 1323, 1326, 1328, 1336, 1341, 1350, 1353, 1356, 1360, 1365, 1368, 1373, 1379, 1381, 1387, 1389, 1392, 1394, 1397, 1409, 1412, 1414, 1416, 1420, 1426, 1429, 1435, 1438, 1442, 1448, 1450, 1452, 1455, 1457, 1462, 1466, 1471, 1474, 1478, 1481, 1485, 1488, 1495, 1500, 1504, 1509, 1511, 1521, 1525, 1528, 1532, 1534, 1541, 1553, 1555, 1557, 1560, 1569, 1573, 1578, 1582, 1584, 1589, 1595, 1597, 1600, 1605, 1608, 1611, 1615, 1618, 1624, 1629, 1632, 1640, 1645, 1647, 1653, 1655, 1662, 1668, 1671, 1675, 1677, 1679, 1681, 1686, 1690, 1692, 1694, 1696, 1699, 1706, 1709, 1715, 1719, 1721, 1724, 1726, 1729, 1732, 1736, 1738, 1741, 1745, 1750, 1753, 1757, 1763, 1766, 1772, 1775, 1781, 1784, 1789, 1792, 1797, 1800, 1808, 1813, 1817, 1821, 1824, 1826, 1830, 1832, 1836, 1839, 1850, 1855, 1859, 1863, 1869, 1871, 1878, 1880, 1890, 1892, 1894, 1900, 1905, 1908, 1910, 1913, 1916, 1922, 1925, 1928, 1933, 1940, 1945, 1948, 1950, 1953, 1959, 1967, 1969, 1971, 1978, 1982, 1988, 1991, 1994, 1997, 1999], deadline = 4)
        configuration.add_task(name="Task4", identifier=4, period=1.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.007571, et_stddev=0.0025236666666666667 , list_activation_dates=[1, 2, 6, 8, 10, 11, 13, 15, 17, 19, 23, 25, 26, 28, 29, 31, 33, 34, 35, 38, 40, 41, 43, 46, 48, 53, 54, 55, 57, 59, 60, 62, 63, 68, 69, 70, 71, 73, 74, 80, 82, 85, 86, 90, 91, 92, 93, 95, 97, 99, 102, 103, 105, 109, 113, 114, 116, 118, 119, 120, 122, 124, 127, 132, 136, 138, 140, 142, 146, 148, 149, 153, 156, 157, 159, 160, 161, 164, 168, 170, 174, 175, 176, 177, 179, 181, 184, 185, 187, 188, 191, 192, 193, 196, 197, 200, 203, 205, 208, 209, 214, 217, 218, 220, 222, 224, 227, 229, 230, 233, 235, 237, 240, 242, 244, 245, 246, 249, 252, 253, 254, 255, 256, 257, 259, 260, 262, 263, 264, 266, 267, 270, 275, 277, 278, 279, 282, 284, 285, 286, 289, 290, 292, 294, 295, 297, 299, 301, 302, 303, 306, 307, 311, 313, 317, 319, 322, 326, 327, 329, 330, 333, 334, 336, 337, 338, 339, 341, 345, 346, 351, 354, 356, 360, 361, 363, 364, 366, 367, 368, 369, 372, 374, 377, 380, 381, 385, 386, 390, 392, 395, 400, 401, 402, 403, 404, 405, 406, 407, 408, 410, 412, 415, 416, 419, 420, 421, 422, 423, 424, 426, 428, 430, 431, 434, 436, 438, 439, 440, 441, 443, 445, 446, 447, 450, 453, 455, 457, 458, 459, 461, 463, 464, 467, 469, 472, 474, 479, 481, 483, 484, 485, 487, 489, 492, 493, 494, 495, 500, 502, 505, 506, 507, 510, 512, 513, 515, 516, 517, 518, 520, 521, 523, 525, 527, 529, 532, 535, 539, 541, 543, 545, 546, 547, 548, 550, 552, 554, 555, 558, 560, 562, 563, 564, 566, 567, 569, 572, 574, 580, 582, 584, 585, 587, 588, 590, 593, 596, 597, 600, 607, 609, 610, 611, 612, 614, 615, 619, 624, 628, 630, 633, 635, 640, 643, 647, 650, 654, 655, 657, 658, 661, 663, 665, 667, 668, 669, 670, 671, 672, 673, 676, 680, 681, 682, 684, 688, 690, 691, 692, 694, 702, 705, 706, 707, 708, 710, 711, 712, 714, 720, 721, 723, 725, 728, 730, 731, 735, 736, 738, 743, 748, 750, 751, 752, 755, 758, 759, 761, 762, 763, 765, 766, 769, 772, 773, 778, 781, 784, 785, 787, 788, 789, 791, 794, 795, 798, 799, 800, 802, 804, 805, 807, 809, 810, 812, 814, 816, 818, 820, 822, 823, 824, 826, 830, 832, 834, 836, 838, 839, 840, 841, 847, 848, 851, 853, 855, 856, 859, 861, 862, 864, 867, 868, 869, 871, 874, 875, 878, 881, 883, 885, 887, 890, 894, 897, 898, 899, 901, 903, 905, 908, 910, 912, 914, 915, 916, 919, 921, 923, 926, 928, 930, 932, 934, 935, 936, 937, 938, 939, 940, 942, 945, 949, 952, 954, 955, 956, 957, 958, 961, 962, 964, 967, 971, 973, 975, 976, 978, 979, 981, 983, 985, 988, 989, 991, 992, 995, 997, 998, 1004, 1006, 1007, 1011, 1013, 1015, 1016, 1017, 1018, 1019, 1021, 1024, 1025, 1027, 1031, 1033, 1035, 1038, 1039, 1040, 1042, 1044, 1045, 1048, 1051, 1053, 1056, 1058, 1059, 1060, 1061, 1063, 1064, 1067, 1068, 1069, 1071, 1074, 1076, 1078, 1079, 1081, 1083, 1085, 1087, 1091, 1093, 1095, 1099, 1101, 1103, 1105, 1107, 1108, 1111, 1113, 1115, 1116, 1118, 1119, 1120, 1122, 1124, 1125, 1127, 1129, 1130, 1132, 1133, 1136, 1138, 1140, 1143, 1144, 1145, 1147, 1148, 1149, 1151, 1152, 1153, 1155, 1156, 1157, 1158, 1160, 1162, 1164, 1166, 1167, 1170, 1171, 1173, 1174, 1175, 1176, 1177, 1179, 1184, 1187, 1189, 1192, 1194, 1195, 1196, 1198, 1199, 1200, 1202, 1204, 1206, 1207, 1209, 1211, 1212, 1213, 1215, 1217, 1219, 1222, 1223, 1224, 1227, 1231, 1235, 1236, 1239, 1241, 1242, 1246, 1248, 1250, 1252, 1254, 1255, 1257, 1259, 1261, 1262, 1263, 1264, 1266, 1268, 1269, 1270, 1272, 1274, 1277, 1278, 1280, 1283, 1285, 1286, 1287, 1290, 1292, 1295, 1297, 1299, 1301, 1303, 1304, 1306, 1308, 1309, 1310, 1314, 1315, 1317, 1319, 1320, 1321, 1322, 1323, 1325, 1326, 1327, 1330, 1332, 1336, 1339, 1340, 1342, 1344, 1345, 1347, 1349, 1351, 1355, 1356, 1357, 1360, 1366, 1367, 1368, 1370, 1372, 1373, 1376, 1381, 1382, 1385, 1386, 1387, 1389, 1393, 1397, 1398, 1399, 1402, 1404, 1407, 1409, 1410, 1411, 1413, 1417, 1418, 1420, 1422, 1423, 1424, 1425, 1430, 1432, 1434, 1437, 1438, 1441, 1443, 1444, 1445, 1446, 1448, 1450, 1451, 1452, 1454, 1456, 1457, 1459, 1462, 1464, 1465, 1468, 1470, 1471, 1472, 1473, 1476, 1477, 1479, 1481, 1484, 1487, 1489, 1490, 1491, 1492, 1495, 1496, 1497, 1498, 1500, 1501, 1502, 1503, 1504, 1506, 1512, 1513, 1515, 1517, 1518, 1519, 1522, 1523, 1524, 1527, 1529, 1531, 1532, 1533, 1534, 1535, 1538, 1540, 1542, 1544, 1546, 1547, 1549, 1550, 1552, 1556, 1560, 1561, 1562, 1564, 1566, 1567, 1569, 1570, 1573, 1575, 1576, 1578, 1579, 1581, 1583, 1584, 1589, 1592, 1594, 1597, 1598, 1599, 1600, 1601, 1602, 1603, 1606, 1608, 1610, 1613, 1614, 1616, 1620, 1622, 1623, 1624, 1626, 1627, 1629, 1630, 1632, 1633, 1635, 1639, 1641, 1642, 1643, 1644, 1645, 1646, 1647, 1650, 1651, 1652, 1654, 1657, 1661, 1662, 1663, 1664, 1666, 1668, 1673, 1674, 1676, 1677, 1679, 1681, 1682, 1684, 1686, 1687, 1688, 1691, 1693, 1694, 1695, 1697, 1698, 1699, 1703, 1704, 1705, 1706, 1707, 1709, 1710, 1711, 1714, 1716, 1720, 1722, 1723, 1726, 1732, 1736, 1738, 1742, 1743, 1745, 1746, 1747, 1750, 1751, 1755, 1757, 1759, 1761, 1764, 1766, 1768, 1771, 1772, 1773, 1776, 1778, 1779, 1780, 1784, 1786, 1788, 1792, 1797, 1799, 1802, 1804, 1807, 1808, 1811, 1814, 1816, 1817, 1818, 1819, 1822, 1824, 1825, 1826, 1828, 1830, 1832, 1833, 1835, 1836, 1837, 1839, 1840, 1842, 1844, 1846, 1848, 1850, 1851, 1852, 1853, 1854, 1856, 1857, 1859, 1861, 1863, 1865, 1867, 1868, 1871, 1873, 1875, 1879, 1880, 1883, 1884, 1885, 1886, 1887, 1888, 1891, 1893, 1895, 1896, 1897, 1898, 1900, 1901, 1903, 1905, 1906, 1909, 1910, 1911, 1913, 1914, 1916, 1918, 1920, 1921, 1923, 1924, 1927, 1928, 1930, 1932, 1933, 1934, 1936, 1937, 1938, 1940, 1944, 1946, 1948, 1949, 1951, 1952, 1954, 1955, 1956, 1957, 1960, 1961, 1964, 1967, 1969, 1971, 1973, 1974, 1975, 1977, 1979, 1985, 1986, 1989, 1991, 1992, 1995, 1999], deadline = 2)
        configuration.add_task(name="Task5", identifier=5, period=5.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.16899, et_stddev=0.05633 , list_activation_dates=[1, 7, 18, 23, 29, 35, 42, 60, 79, 87, 93, 103, 115, 125, 130, 139, 146, 155, 162, 168, 173, 183, 197, 204, 211, 221, 228, 239, 245, 252, 278, 286, 294, 300, 307, 325, 342, 352, 363, 379, 386, 394, 404, 411, 422, 431, 438, 447, 458, 465, 470, 481, 496, 502, 509, 515, 521, 539, 551, 557, 579, 590, 603, 615, 626, 634, 644, 656, 666, 677, 683, 694, 700, 710, 724, 737, 746, 758, 764, 774, 780, 786, 793, 804, 810, 817, 828, 839, 866, 875, 892, 900, 919, 926, 942, 962, 968, 975, 988, 995, 1015, 1038, 1051, 1061, 1072, 1082, 1088, 1094, 1102, 1119, 1124, 1133, 1138, 1147, 1152, 1168, 1174, 1184, 1192, 1202, 1207, 1216, 1222, 1232, 1244, 1262, 1269, 1276, 1283, 1288, 1303, 1314, 1331, 1336, 1343, 1349, 1357, 1368, 1394, 1401, 1408, 1416, 1429, 1436, 1443, 1450, 1459, 1473, 1491, 1502, 1509, 1516, 1523, 1533, 1540, 1545, 1551, 1557, 1569, 1578, 1587, 1596, 1608, 1616, 1623, 1639, 1646, 1654, 1660, 1669, 1679, 1690, 1713, 1722, 1731, 1736, 1744, 1754, 1763, 1785, 1791, 1802, 1810, 1817, 1833, 1843, 1853, 1861, 1867, 1883, 1902, 1913, 1920, 1938, 1949, 1959, 1967, 1977, 1984, 1998], deadline = 8)
        configuration.add_task(name="Task3", identifier=3, period=4.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=0.844806, acet=0.844806, et_stddev=0.28160199999999996, deadline= 1)
        configuration.add_task(name="Task2", identifier=2, period=23.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=22.503093, acet=22.503093, et_stddev=7.501031, deadline= 37)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "34")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "34")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "34")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "34")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task1", identifier=1, period=28.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=13.063842, acet=13.063842, et_stddev=4.354614, deadline= 31)
        configuration.add_task(name="Task5", identifier=5, period=8.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.346991, et_stddev=0.11566366666666666 , list_activation_dates=[8, 30, 48, 59, 78, 89, 100, 111, 144, 159, 177, 188, 197, 224, 243, 265, 279, 293, 304, 318, 346, 356, 391, 405, 413, 426, 449, 460, 469, 477, 486, 505, 517, 536, 556, 572, 586, 603, 616, 634, 676, 687, 696, 715, 733, 743, 752, 766, 776, 785, 798, 807, 832, 846, 871, 884, 899, 914, 923, 934, 949, 964, 985, 1034, 1043, 1053, 1065, 1085, 1094, 1108, 1121, 1131, 1141, 1149, 1175, 1191, 1229, 1241, 1254, 1267, 1285, 1299, 1326, 1355, 1365, 1377, 1394, 1432, 1445, 1459, 1493, 1506, 1527, 1543, 1556, 1567, 1576, 1584, 1596, 1618, 1646, 1667, 1684, 1692, 1704, 1728, 1739, 1750, 1790, 1798, 1814, 1831, 1851, 1862, 1887, 1901, 1913, 1926, 1944, 1954, 1974, 1998], deadline = 16)
        configuration.add_task(name="Task4", identifier=4, period=10.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=2, acet=1.432586, et_stddev=0.47752866666666666 , list_activation_dates=[9, 36, 50, 61, 88, 109, 128, 145, 167, 189, 211, 229, 246, 261, 273, 311, 331, 348, 360, 393, 414, 427, 437, 448, 466, 480, 492, 547, 558, 586, 598, 616, 629, 671, 690, 711, 726, 749, 765, 776, 789, 807, 819, 841, 862, 890, 907, 921, 936, 951, 971, 989, 1006, 1020, 1031, 1043, 1054, 1072, 1092, 1106, 1137, 1150, 1164, 1203, 1228, 1238, 1274, 1289, 1304, 1322, 1343, 1360, 1375, 1419, 1437, 1458, 1477, 1491, 1513, 1529, 1540, 1558, 1597, 1607, 1619, 1636, 1662, 1677, 1688, 1711, 1726, 1736, 1751, 1782, 1797, 1834, 1854, 1868, 1891, 1913, 1925, 1941, 1969, 1991], deadline = 10)
        configuration.add_task(name="Task3", identifier=3, period=32.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=14.998712, acet=14.998712, et_stddev=4.999570666666666, deadline= 21)
        configuration.add_task(name="Task6", identifier=6, period=5.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.066837, et_stddev=0.022278999999999997 , list_activation_dates=[5, 13, 39, 53, 59, 65, 77, 83, 92, 115, 122, 132, 141, 153, 176, 196, 204, 210, 220, 229, 245, 259, 273, 284, 292, 303, 308, 324, 335, 347, 354, 366, 375, 381, 387, 395, 402, 413, 424, 430, 436, 442, 448, 457, 462, 472, 477, 489, 508, 519, 541, 547, 554, 564, 572, 581, 592, 604, 609, 622, 634, 643, 653, 664, 671, 686, 694, 699, 707, 715, 730, 737, 755, 761, 771, 787, 793, 816, 823, 830, 836, 843, 851, 866, 886, 892, 901, 907, 917, 927, 933, 943, 952, 959, 966, 993, 1005, 1014, 1020, 1028, 1034, 1041, 1049, 1055, 1068, 1079, 1097, 1106, 1117, 1126, 1133, 1139, 1152, 1161, 1171, 1194, 1210, 1219, 1237, 1242, 1258, 1266, 1280, 1285, 1295, 1304, 1313, 1324, 1344, 1354, 1361, 1369, 1376, 1384, 1395, 1404, 1410, 1415, 1421, 1427, 1442, 1448, 1455, 1464, 1471, 1482, 1504, 1515, 1525, 1535, 1540, 1570, 1576, 1583, 1605, 1611, 1648, 1663, 1681, 1701, 1711, 1719, 1726, 1736, 1741, 1747, 1758, 1770, 1784, 1810, 1818, 1826, 1832, 1840, 1862, 1868, 1874, 1883, 1893, 1904, 1920, 1929, 1939, 1945, 1966, 1982, 1987, 1993], deadline = 10)
        configuration.add_task(name="Task2", identifier=2, period=14.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=9.306142, acet=9.306142, et_stddev=3.102047333333333, deadline= 20)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "35")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "35")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "35")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "35")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task5", identifier=5, period=27.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.774317, et_stddev=0.2581056666666667 , list_activation_dates=[4, 65, 95, 171, 204, 251, 297, 448, 553, 631, 664, 701, 730, 776, 857, 895, 925, 977, 1005, 1049, 1081, 1175, 1268, 1322, 1363, 1441, 1486, 1642, 1675, 1711, 1792, 1826, 1854, 1945], deadline = 42)
        configuration.add_task(name="Task1", identifier=1, period=5.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=1.656507, acet=1.656507, et_stddev=0.552169, deadline= 2)
        configuration.add_task(name="Task2", identifier=2, period=43.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=20.978553, acet=20.978553, et_stddev=6.992851000000001, deadline= 68)
        configuration.add_task(name="Task3", identifier=3, period=9.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=7.027426, acet=7.027426, et_stddev=2.3424753333333332, deadline= 11)
        configuration.add_task(name="Task6", identifier=6, period=5.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.480584, et_stddev=0.16019466666666668 , list_activation_dates=[2, 9, 15, 30, 35, 43, 50, 58, 69, 81, 87, 96, 102, 107, 115, 120, 127, 140, 148, 159, 164, 169, 195, 202, 208, 214, 221, 228, 241, 255, 269, 277, 284, 291, 299, 306, 318, 323, 328, 334, 342, 354, 361, 375, 381, 386, 393, 407, 415, 422, 449, 456, 464, 471, 479, 488, 496, 505, 526, 532, 537, 558, 593, 603, 618, 625, 635, 640, 648, 653, 659, 669, 677, 682, 689, 698, 713, 731, 741, 747, 756, 767, 776, 781, 788, 798, 804, 810, 831, 838, 847, 858, 867, 879, 891, 899, 906, 911, 921, 931, 939, 945, 958, 965, 973, 984, 990, 997, 1007, 1012, 1022, 1028, 1040, 1046, 1057, 1066, 1080, 1090, 1099, 1111, 1116, 1122, 1131, 1146, 1152, 1157, 1164, 1175, 1189, 1196, 1206, 1223, 1228, 1242, 1261, 1273, 1280, 1286, 1292, 1299, 1305, 1319, 1326, 1334, 1340, 1346, 1352, 1357, 1363, 1372, 1379, 1384, 1392, 1400, 1407, 1417, 1439, 1450, 1472, 1485, 1495, 1508, 1521, 1533, 1539, 1546, 1566, 1573, 1580, 1586, 1593, 1607, 1619, 1647, 1660, 1668, 1674, 1693, 1701, 1710, 1720, 1726, 1738, 1756, 1778, 1799, 1810, 1820, 1826, 1855, 1868, 1881, 1886, 1892, 1909, 1916, 1924, 1931, 1938, 1944, 1951, 1959, 1964, 1981, 1990, 2000], deadline = 7)
        configuration.add_task(name="Task4", identifier=4, period=2.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.150409, et_stddev=0.05013633333333333 , list_activation_dates=[5, 7, 9, 13, 16, 18, 21, 25, 30, 37, 41, 47, 51, 56, 60, 62, 71, 75, 78, 81, 83, 87, 92, 95, 99, 102, 107, 110, 112, 117, 119, 122, 124, 126, 130, 136, 138, 142, 146, 148, 152, 159, 165, 168, 174, 179, 182, 186, 189, 194, 198, 204, 207, 210, 215, 218, 225, 227, 231, 233, 236, 245, 247, 249, 253, 261, 264, 267, 274, 277, 282, 284, 289, 291, 293, 296, 299, 302, 305, 307, 310, 312, 320, 323, 327, 330, 336, 341, 344, 349, 352, 355, 358, 360, 364, 366, 371, 383, 387, 391, 394, 399, 405, 407, 413, 415, 423, 427, 430, 432, 440, 443, 447, 449, 455, 459, 462, 467, 469, 472, 474, 477, 480, 482, 484, 489, 493, 496, 499, 503, 505, 509, 511, 516, 519, 522, 529, 532, 537, 540, 547, 553, 557, 563, 565, 569, 575, 578, 581, 585, 588, 591, 594, 607, 610, 615, 617, 621, 623, 625, 629, 632, 639, 641, 646, 648, 651, 654, 656, 659, 661, 663, 668, 671, 674, 676, 682, 685, 693, 697, 703, 709, 711, 714, 718, 721, 725, 730, 737, 740, 749, 754, 759, 762, 767, 776, 778, 782, 785, 787, 789, 792, 796, 799, 802, 807, 810, 813, 815, 817, 821, 823, 827, 833, 836, 842, 845, 848, 851, 856, 858, 863, 866, 868, 871, 874, 879, 881, 886, 888, 898, 900, 903, 907, 913, 917, 923, 927, 931, 937, 941, 943, 951, 955, 957, 961, 965, 968, 972, 974, 976, 980, 982, 990, 992, 995, 997, 1006, 1009, 1013, 1019, 1024, 1028, 1030, 1033, 1037, 1052, 1054, 1057, 1061, 1067, 1071, 1073, 1076, 1080, 1082, 1085, 1090, 1097, 1100, 1102, 1106, 1115, 1117, 1121, 1126, 1129, 1135, 1144, 1147, 1151, 1154, 1156, 1163, 1165, 1169, 1178, 1182, 1185, 1187, 1189, 1195, 1197, 1200, 1204, 1206, 1209, 1211, 1216, 1221, 1223, 1226, 1231, 1234, 1236, 1239, 1241, 1244, 1248, 1252, 1255, 1261, 1263, 1266, 1270, 1273, 1276, 1279, 1284, 1286, 1289, 1291, 1294, 1299, 1302, 1306, 1310, 1320, 1322, 1333, 1336, 1339, 1342, 1345, 1348, 1351, 1354, 1359, 1365, 1367, 1372, 1378, 1381, 1386, 1388, 1393, 1403, 1407, 1411, 1418, 1421, 1425, 1427, 1432, 1436, 1443, 1446, 1449, 1453, 1455, 1457, 1460, 1464, 1467, 1470, 1476, 1478, 1484, 1486, 1488, 1490, 1493, 1498, 1501, 1507, 1510, 1518, 1525, 1532, 1540, 1542, 1544, 1546, 1548, 1554, 1559, 1563, 1567, 1570, 1573, 1576, 1583, 1586, 1589, 1592, 1596, 1599, 1601, 1605, 1608, 1614, 1628, 1630, 1632, 1637, 1640, 1648, 1650, 1655, 1660, 1663, 1666, 1671, 1678, 1682, 1685, 1688, 1693, 1700, 1702, 1706, 1708, 1712, 1716, 1718, 1725, 1731, 1735, 1737, 1740, 1743, 1746, 1750, 1756, 1760, 1764, 1767, 1773, 1778, 1782, 1786, 1788, 1793, 1795, 1798, 1803, 1806, 1812, 1818, 1820, 1829, 1832, 1835, 1839, 1843, 1846, 1856, 1862, 1867, 1870, 1872, 1875, 1881, 1883, 1886, 1895, 1898, 1902, 1912, 1914, 1918, 1921, 1924, 1930, 1935, 1939, 1944, 1948, 1951, 1956, 1963, 1965, 1967, 1971, 1977, 1985, 1988, 1991, 1993], deadline = 1)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "36")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "36")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "36")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "36")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task2", identifier=2, period=8.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=2.919336, acet=2.919336, et_stddev=0.973112, deadline= 8)
        configuration.add_task(name="Task4", identifier=4, period=29.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=2, acet=1.616147, et_stddev=0.5387156666666667 , list_activation_dates=[20, 60, 93, 144, 183, 216, 258, 311, 341, 388, 464, 493, 551, 581, 617, 680, 710, 748, 795, 838, 869, 934, 1028, 1073, 1122, 1209, 1247, 1307, 1337, 1410, 1460, 1506, 1571, 1640, 1760, 1798, 1867, 1979], deadline = 18)
        configuration.add_task(name="Task3", identifier=3, period=1.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=0.320255, acet=0.320255, et_stddev=0.10675166666666668, deadline= 1)
        configuration.add_task(name="Task1", identifier=1, period=45.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=41.167223, acet=41.167223, et_stddev=13.722407666666667, deadline= 90)
        configuration.add_task(name="Task6", identifier=6, period=27.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=3, acet=2.525505, et_stddev=0.841835 , list_activation_dates=[8, 50, 128, 172, 266, 294, 323, 365, 392, 444, 493, 554, 632, 704, 742, 778, 829, 875, 923, 965, 1023, 1052, 1081, 1142, 1193, 1246, 1310, 1376, 1427, 1456, 1519, 1546, 1576, 1657, 1691, 1720, 1748, 1791, 1832, 1930, 1981], deadline = 8)
        configuration.add_task(name="Task5", identifier=5, period=4.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.202934, et_stddev=0.06764466666666667 , list_activation_dates=[1, 7, 20, 27, 46, 55, 60, 64, 69, 74, 79, 88, 92, 97, 102, 108, 114, 121, 127, 143, 149, 156, 166, 172, 177, 181, 188, 194, 206, 213, 219, 226, 233, 241, 247, 255, 265, 273, 280, 289, 295, 302, 307, 312, 318, 328, 336, 342, 349, 359, 366, 374, 389, 393, 399, 406, 411, 422, 426, 432, 440, 447, 453, 462, 467, 475, 488, 494, 499, 503, 516, 524, 529, 533, 537, 546, 550, 560, 566, 582, 592, 599, 605, 610, 616, 626, 631, 669, 676, 684, 689, 700, 705, 710, 720, 736, 740, 745, 749, 761, 773, 786, 791, 798, 805, 810, 816, 824, 829, 839, 844, 849, 863, 869, 877, 885, 890, 896, 909, 916, 920, 933, 941, 949, 954, 959, 973, 979, 985, 989, 1000, 1008, 1016, 1022, 1034, 1039, 1048, 1057, 1070, 1077, 1085, 1091, 1101, 1105, 1113, 1142, 1146, 1150, 1160, 1167, 1179, 1186, 1198, 1203, 1210, 1217, 1226, 1232, 1237, 1246, 1252, 1258, 1273, 1288, 1302, 1308, 1313, 1318, 1322, 1326, 1330, 1336, 1341, 1345, 1350, 1357, 1361, 1366, 1375, 1384, 1390, 1414, 1420, 1425, 1440, 1446, 1452, 1458, 1466, 1482, 1501, 1514, 1518, 1525, 1530, 1541, 1549, 1555, 1570, 1575, 1581, 1591, 1599, 1603, 1608, 1618, 1625, 1631, 1650, 1654, 1658, 1670, 1676, 1688, 1694, 1698, 1703, 1720, 1729, 1741, 1754, 1766, 1774, 1778, 1785, 1792, 1797, 1801, 1807, 1812, 1821, 1831, 1838, 1846, 1850, 1855, 1861, 1866, 1870, 1874, 1884, 1891, 1896, 1907, 1916, 1924, 1928, 1934, 1939, 1959, 1965, 1976, 1982, 1987, 1993, 1998], deadline = 4)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "37")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "37")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "37")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "37")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task1", identifier=1, period=5.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=3.183804, acet=3.183804, et_stddev=1.0612679999999999, deadline= 4)
        configuration.add_task(name="Task3", identifier=3, period=19.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=8.888211, acet=8.888211, et_stddev=2.962737, deadline= 21)
        configuration.add_task(name="Task2", identifier=2, period=2.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=0.990876, acet=0.990876, et_stddev=0.330292, deadline= 3)
        configuration.add_task(name="Task5", identifier=5, period=15.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.282829, et_stddev=0.09427633333333334 , list_activation_dates=[10, 44, 65, 83, 110, 140, 205, 223, 247, 267, 311, 333, 363, 382, 405, 425, 443, 459, 488, 505, 546, 570, 595, 653, 676, 696, 720, 757, 783, 824, 892, 918, 965, 995, 1014, 1042, 1069, 1086, 1108, 1144, 1161, 1200, 1220, 1239, 1259, 1275, 1338, 1358, 1386, 1403, 1444, 1487, 1503, 1540, 1566, 1585, 1612, 1630, 1646, 1670, 1719, 1748, 1775, 1805, 1855, 1891, 1908, 1933, 1952, 1971, 1994], deadline = 11)
        configuration.add_task(name="Task4", identifier=4, period=19.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=4, acet=3.266029, et_stddev=1.0886763333333334 , list_activation_dates=[18, 42, 93, 130, 170, 221, 257, 285, 340, 423, 469, 489, 527, 555, 589, 656, 723, 792, 813, 871, 897, 920, 956, 987, 1009, 1047, 1083, 1108, 1150, 1238, 1276, 1327, 1349, 1397, 1421, 1444, 1486, 1552, 1571, 1639, 1677, 1698, 1765, 1792, 1812, 1881, 1903, 1989], deadline = 16)
        configuration.add_task(name="Task6", identifier=6, period=49.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.453171, et_stddev=0.151057 , list_activation_dates=[89, 208, 323, 386, 518, 647, 709, 820, 960, 1045, 1136, 1195, 1271, 1481, 1606, 1660, 1749, 1845, 1932], deadline = 14)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "38")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "38")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "38")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "38")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task6", identifier=6, period=27.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.591033, et_stddev=0.19701100000000002 , list_activation_dates=[16, 73, 165, 205, 278, 325, 380, 410, 548, 594, 644, 677, 718, 770, 809, 857, 921, 954, 985, 1043, 1083, 1128, 1167, 1288, 1351, 1398, 1456, 1489, 1531, 1581, 1608, 1658, 1691, 1723, 1759, 1789, 1822, 1865, 1924, 1990], deadline = 38)
        configuration.add_task(name="Task5", identifier=5, period=18.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=3, acet=2.369722, et_stddev=0.7899073333333333 , list_activation_dates=[5, 70, 92, 126, 192, 213, 231, 256, 285, 338, 360, 396, 431, 452, 527, 551, 575, 624, 661, 758, 809, 837, 909, 933, 951, 982, 1041, 1080, 1102, 1151, 1201, 1226, 1249, 1276, 1299, 1332, 1365, 1405, 1431, 1449, 1516, 1542, 1574, 1598, 1618, 1637, 1668, 1692, 1722, 1748, 1788, 1808, 1827, 1855, 1874, 1919, 1981], deadline = 11)
        configuration.add_task(name="Task1", identifier=1, period=7.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=6.908354, acet=6.908354, et_stddev=2.3027846666666667, deadline= 7)
        configuration.add_task(name="Task2", identifier=2, period=2.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=1.100887, acet=1.100887, et_stddev=0.36696233333333333, deadline= 4)
        configuration.add_task(name="Task4", identifier=4, period=28.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=2, acet=1.300841, et_stddev=0.4336136666666666 , list_activation_dates=[18, 71, 101, 137, 182, 227, 293, 346, 402, 447, 528, 563, 597, 627, 658, 686, 789, 833, 867, 958, 988, 1038, 1078, 1148, 1196, 1243, 1308, 1398, 1436, 1495, 1652, 1712, 1758, 1843, 1883, 1942, 1988], deadline = 13)
        configuration.add_task(name="Task3", identifier=3, period=16.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=1.002372, acet=1.002372, et_stddev=0.33412400000000003, deadline= 29)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "39")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "39")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "39")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "39")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task3", identifier=3, period=15.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=4.703657, acet=4.703657, et_stddev=1.5678856666666665, deadline= 25)
        configuration.add_task(name="Task2", identifier=2, period=5.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=2.262756, acet=2.262756, et_stddev=0.754252, deadline= 3)
        configuration.add_task(name="Task4", identifier=4, period=2.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.029867, et_stddev=0.009955666666666666 , list_activation_dates=[5, 8, 10, 13, 15, 18, 20, 22, 24, 26, 29, 35, 38, 43, 47, 50, 53, 57, 60, 62, 69, 71, 73, 79, 82, 87, 89, 94, 96, 98, 105, 114, 118, 122, 125, 129, 132, 135, 138, 142, 144, 147, 151, 154, 156, 159, 162, 166, 173, 176, 179, 181, 185, 187, 190, 192, 194, 198, 200, 204, 207, 210, 216, 222, 226, 230, 234, 243, 245, 248, 252, 256, 259, 262, 265, 267, 271, 274, 276, 281, 290, 297, 301, 303, 307, 310, 312, 314, 320, 323, 325, 328, 332, 334, 338, 341, 344, 348, 350, 353, 357, 359, 368, 371, 378, 385, 388, 390, 395, 397, 401, 405, 407, 413, 420, 422, 427, 431, 433, 435, 438, 441, 446, 449, 454, 458, 465, 468, 470, 473, 476, 479, 481, 488, 491, 495, 497, 499, 502, 505, 507, 510, 513, 516, 519, 529, 532, 541, 545, 549, 553, 556, 558, 561, 568, 571, 576, 578, 585, 587, 590, 593, 596, 601, 606, 611, 614, 616, 622, 625, 628, 633, 637, 640, 645, 647, 653, 657, 661, 663, 666, 672, 675, 677, 680, 683, 685, 691, 694, 697, 701, 706, 708, 710, 712, 715, 718, 721, 723, 730, 734, 736, 740, 743, 746, 750, 754, 762, 768, 771, 775, 778, 780, 782, 790, 793, 795, 803, 807, 814, 817, 819, 822, 825, 828, 831, 834, 839, 845, 850, 856, 859, 863, 873, 876, 879, 882, 886, 889, 894, 902, 906, 910, 912, 918, 921, 928, 932, 936, 942, 944, 949, 952, 955, 958, 960, 962, 967, 969, 972, 978, 985, 987, 991, 994, 1001, 1005, 1009, 1016, 1019, 1021, 1026, 1030, 1033, 1037, 1040, 1050, 1052, 1056, 1058, 1064, 1066, 1070, 1073, 1077, 1080, 1083, 1086, 1095, 1097, 1103, 1107, 1110, 1115, 1118, 1123, 1131, 1138, 1141, 1144, 1152, 1154, 1159, 1162, 1164, 1166, 1173, 1178, 1181, 1186, 1189, 1192, 1198, 1204, 1208, 1211, 1214, 1222, 1224, 1227, 1230, 1240, 1247, 1250, 1254, 1264, 1266, 1269, 1271, 1279, 1281, 1284, 1288, 1293, 1298, 1301, 1303, 1307, 1309, 1312, 1314, 1317, 1320, 1325, 1329, 1332, 1335, 1338, 1340, 1344, 1346, 1348, 1351, 1354, 1360, 1364, 1367, 1373, 1380, 1383, 1387, 1389, 1391, 1394, 1402, 1405, 1409, 1412, 1414, 1417, 1421, 1425, 1427, 1430, 1436, 1441, 1444, 1453, 1457, 1463, 1465, 1468, 1470, 1475, 1485, 1488, 1490, 1494, 1499, 1503, 1513, 1519, 1522, 1525, 1530, 1532, 1534, 1538, 1542, 1545, 1550, 1553, 1556, 1563, 1565, 1568, 1573, 1577, 1581, 1589, 1598, 1601, 1604, 1607, 1611, 1617, 1619, 1623, 1627, 1629, 1633, 1636, 1638, 1640, 1643, 1646, 1652, 1657, 1660, 1664, 1668, 1672, 1677, 1680, 1683, 1686, 1688, 1694, 1696, 1704, 1709, 1714, 1716, 1719, 1722, 1727, 1730, 1733, 1738, 1742, 1745, 1751, 1753, 1755, 1761, 1764, 1766, 1769, 1771, 1774, 1776, 1780, 1784, 1788, 1792, 1798, 1804, 1808, 1811, 1814, 1820, 1823, 1832, 1835, 1839, 1844, 1850, 1856, 1859, 1861, 1865, 1868, 1870, 1874, 1877, 1881, 1883, 1885, 1888, 1894, 1897, 1903, 1906, 1910, 1913, 1917, 1921, 1924, 1928, 1930, 1933, 1936, 1938, 1941, 1944, 1949, 1951, 1953, 1957, 1960, 1965, 1970, 1974, 1976, 1979, 1981, 1984, 1987, 1990, 1994, 1996], deadline = 4)
        configuration.add_task(name="Task6", identifier=6, period=44.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=3, acet=2.629468, et_stddev=0.8764893333333333 , list_activation_dates=[91, 171, 281, 367, 452, 527, 631, 681, 786, 890, 936, 1067, 1142, 1211, 1298, 1347, 1474, 1527, 1598, 1685, 1730, 1785, 1832, 1889], deadline = 58)
        configuration.add_task(name="Task1", identifier=1, period=47.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=39.191959, acet=39.191959, et_stddev=13.063986333333332, deadline= 78)
        configuration.add_task(name="Task5", identifier=5, period=6.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.751834, et_stddev=0.25061133333333335 , list_activation_dates=[2, 10, 16, 29, 40, 52, 62, 73, 85, 95, 114, 133, 141, 148, 156, 167, 173, 180, 192, 200, 219, 232, 247, 264, 277, 287, 294, 303, 335, 345, 353, 361, 374, 402, 409, 415, 425, 441, 453, 474, 492, 512, 524, 536, 546, 554, 561, 585, 602, 613, 620, 628, 636, 647, 654, 672, 681, 691, 718, 725, 731, 738, 745, 764, 771, 788, 794, 803, 817, 825, 832, 847, 861, 874, 886, 892, 903, 918, 932, 940, 947, 954, 960, 967, 974, 981, 991, 1001, 1013, 1019, 1029, 1045, 1060, 1076, 1087, 1099, 1116, 1134, 1143, 1154, 1161, 1167, 1174, 1186, 1196, 1203, 1215, 1266, 1275, 1307, 1320, 1329, 1346, 1354, 1361, 1370, 1380, 1389, 1413, 1420, 1428, 1435, 1449, 1459, 1472, 1487, 1505, 1523, 1530, 1541, 1558, 1565, 1573, 1601, 1635, 1647, 1656, 1669, 1688, 1696, 1714, 1727, 1735, 1752, 1763, 1771, 1783, 1800, 1806, 1817, 1824, 1850, 1860, 1883, 1890, 1908, 1921, 1931, 1954, 1971, 1979, 1992, 2000], deadline = 8)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "40")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "40")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "40")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "40")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task6", identifier=6, period=34.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=5, acet=4.426257, et_stddev=1.4754189999999998 , list_activation_dates=[83, 227, 279, 341, 455, 547, 629, 718, 766, 817, 866, 925, 989, 1046, 1081, 1137, 1213, 1256, 1301, 1367, 1426, 1522, 1582, 1617, 1661, 1734, 1807, 1844, 1883, 1930], deadline = 29)
        configuration.add_task(name="Task5", identifier=5, period=1.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.063556, et_stddev=0.021185333333333334 , list_activation_dates=[2, 3, 4, 7, 8, 10, 12, 14, 16, 19, 20, 24, 28, 29, 31, 32, 35, 37, 38, 42, 46, 48, 51, 53, 56, 59, 60, 62, 63, 66, 69, 71, 72, 75, 80, 81, 82, 84, 86, 88, 89, 90, 92, 95, 96, 100, 102, 105, 106, 107, 108, 112, 117, 119, 121, 123, 124, 126, 128, 129, 130, 133, 134, 137, 139, 140, 141, 142, 146, 149, 150, 154, 158, 162, 164, 165, 168, 169, 171, 172, 174, 175, 176, 177, 179, 180, 181, 184, 186, 188, 193, 196, 197, 200, 204, 207, 208, 210, 212, 213, 216, 218, 220, 221, 228, 229, 231, 233, 234, 235, 236, 238, 239, 240, 242, 244, 245, 246, 248, 249, 252, 254, 255, 258, 260, 263, 264, 268, 270, 273, 275, 276, 279, 282, 284, 286, 288, 290, 292, 293, 295, 296, 299, 300, 302, 303, 306, 307, 310, 313, 315, 316, 319, 321, 323, 326, 329, 331, 332, 335, 337, 338, 339, 341, 343, 344, 345, 346, 348, 350, 352, 355, 357, 360, 362, 363, 368, 369, 370, 372, 376, 377, 378, 380, 381, 382, 383, 385, 387, 389, 390, 392, 395, 399, 401, 403, 406, 410, 412, 414, 415, 416, 417, 420, 421, 422, 424, 427, 431, 432, 434, 438, 439, 441, 442, 443, 444, 446, 447, 451, 453, 455, 458, 460, 461, 462, 464, 468, 470, 471, 473, 475, 476, 477, 478, 479, 481, 483, 485, 487, 488, 489, 492, 493, 496, 499, 501, 503, 505, 508, 509, 511, 512, 514, 515, 517, 518, 521, 522, 523, 524, 527, 528, 531, 532, 533, 534, 538, 541, 543, 545, 547, 551, 553, 554, 555, 557, 559, 560, 561, 563, 567, 568, 570, 572, 574, 575, 579, 581, 583, 585, 588, 589, 590, 591, 592, 594, 595, 596, 597, 598, 599, 601, 603, 604, 609, 611, 612, 614, 616, 618, 621, 622, 624, 626, 627, 628, 629, 630, 632, 634, 635, 636, 640, 643, 644, 646, 647, 648, 649, 650, 652, 654, 655, 656, 658, 660, 661, 663, 664, 668, 671, 672, 673, 676, 679, 682, 684, 685, 687, 688, 689, 693, 696, 698, 701, 702, 703, 705, 708, 710, 714, 718, 720, 721, 723, 726, 730, 731, 734, 735, 736, 737, 738, 740, 744, 746, 748, 751, 752, 754, 755, 757, 759, 760, 764, 765, 769, 770, 771, 772, 775, 778, 779, 780, 782, 784, 786, 789, 790, 791, 794, 795, 798, 799, 803, 804, 805, 807, 809, 813, 814, 816, 818, 820, 823, 824, 826, 831, 833, 834, 837, 839, 840, 841, 844, 845, 848, 849, 850, 851, 854, 855, 857, 858, 860, 862, 863, 865, 869, 870, 872, 874, 877, 879, 880, 881, 883, 885, 886, 887, 892, 894, 899, 901, 903, 904, 906, 907, 908, 910, 912, 913, 916, 917, 918, 919, 924, 929, 931, 935, 938, 941, 942, 943, 944, 946, 947, 948, 949, 951, 952, 953, 954, 955, 956, 959, 964, 968, 970, 972, 973, 974, 977, 978, 980, 982, 984, 985, 987, 989, 991, 992, 994, 997, 998, 1000, 1002, 1004, 1007, 1010, 1011, 1012, 1013, 1015, 1016, 1017, 1018, 1020, 1022, 1024, 1025, 1028, 1031, 1033, 1035, 1038, 1040, 1042, 1043, 1044, 1045, 1048, 1049, 1051, 1052, 1056, 1059, 1060, 1061, 1062, 1064, 1065, 1066, 1067, 1068, 1069, 1071, 1074, 1076, 1078, 1080, 1083, 1085, 1087, 1088, 1089, 1094, 1096, 1098, 1099, 1101, 1102, 1104, 1106, 1107, 1108, 1110, 1111, 1112, 1113, 1114, 1116, 1118, 1121, 1124, 1126, 1127, 1129, 1130, 1132, 1133, 1135, 1138, 1139, 1141, 1143, 1144, 1145, 1147, 1148, 1151, 1155, 1158, 1159, 1161, 1163, 1166, 1167, 1169, 1171, 1173, 1176, 1178, 1182, 1184, 1186, 1188, 1190, 1191, 1193, 1194, 1195, 1197, 1198, 1200, 1201, 1205, 1206, 1209, 1211, 1213, 1215, 1217, 1218, 1220, 1222, 1223, 1224, 1225, 1226, 1228, 1230, 1232, 1234, 1236, 1238, 1240, 1241, 1243, 1245, 1247, 1248, 1249, 1253, 1255, 1257, 1258, 1259, 1260, 1261, 1263, 1266, 1269, 1270, 1271, 1272, 1274, 1277, 1279, 1281, 1284, 1286, 1288, 1289, 1290, 1293, 1296, 1298, 1300, 1301, 1302, 1304, 1308, 1310, 1312, 1314, 1315, 1317, 1318, 1319, 1321, 1323, 1325, 1326, 1327, 1328, 1330, 1334, 1336, 1337, 1341, 1343, 1344, 1346, 1348, 1350, 1351, 1352, 1353, 1355, 1357, 1360, 1361, 1363, 1364, 1365, 1367, 1369, 1372, 1374, 1376, 1377, 1378, 1379, 1381, 1383, 1384, 1385, 1387, 1388, 1389, 1390, 1391, 1394, 1396, 1397, 1398, 1400, 1401, 1402, 1403, 1404, 1405, 1406, 1408, 1409, 1411, 1412, 1414, 1415, 1417, 1419, 1421, 1422, 1423, 1424, 1426, 1428, 1429, 1431, 1432, 1436, 1437, 1438, 1441, 1444, 1447, 1449, 1451, 1454, 1456, 1458, 1460, 1462, 1464, 1466, 1469, 1470, 1472, 1474, 1475, 1478, 1480, 1482, 1484, 1486, 1488, 1489, 1491, 1493, 1494, 1497, 1499, 1501, 1502, 1504, 1506, 1508, 1509, 1510, 1513, 1517, 1518, 1519, 1521, 1522, 1526, 1527, 1529, 1532, 1533, 1535, 1538, 1547, 1550, 1553, 1554, 1556, 1557, 1560, 1561, 1563, 1564, 1566, 1567, 1568, 1571, 1574, 1577, 1578, 1580, 1583, 1584, 1585, 1586, 1588, 1590, 1592, 1595, 1596, 1598, 1599, 1601, 1602, 1604, 1605, 1606, 1608, 1610, 1612, 1615, 1616, 1617, 1618, 1619, 1621, 1622, 1624, 1627, 1630, 1631, 1633, 1635, 1636, 1638, 1640, 1642, 1643, 1644, 1646, 1647, 1648, 1650, 1651, 1653, 1655, 1657, 1658, 1661, 1663, 1665, 1667, 1671, 1675, 1680, 1682, 1683, 1685, 1687, 1688, 1689, 1692, 1693, 1695, 1697, 1699, 1701, 1704, 1705, 1706, 1709, 1711, 1715, 1717, 1718, 1720, 1722, 1725, 1726, 1729, 1731, 1734, 1737, 1739, 1743, 1744, 1747, 1748, 1749, 1750, 1751, 1753, 1754, 1757, 1762, 1765, 1767, 1768, 1769, 1770, 1772, 1775, 1776, 1779, 1781, 1782, 1784, 1786, 1787, 1789, 1790, 1791, 1795, 1801, 1804, 1806, 1807, 1808, 1809, 1811, 1813, 1814, 1816, 1818, 1822, 1823, 1824, 1826, 1828, 1829, 1831, 1834, 1836, 1837, 1839, 1842, 1844, 1846, 1847, 1852, 1855, 1857, 1858, 1860, 1867, 1868, 1870, 1872, 1875, 1877, 1879, 1880, 1882, 1883, 1886, 1887, 1889, 1890, 1892, 1893, 1897, 1898, 1900, 1901, 1903, 1904, 1906, 1907, 1911, 1912, 1914, 1915, 1919, 1921, 1922, 1923, 1924, 1925, 1926, 1929, 1930, 1932, 1935, 1936, 1937, 1939, 1943, 1944, 1951, 1953, 1954, 1956, 1957, 1960, 1962, 1963, 1964, 1966, 1967, 1969, 1971, 1972, 1976, 1978, 1980, 1982, 1983, 1984, 1988, 1990, 1993, 1994, 1996, 1998, 2000], deadline = 2)
        configuration.add_task(name="Task1", identifier=1, period=1.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=0.234002, acet=0.234002, et_stddev=0.07800066666666666, deadline= 1)
        configuration.add_task(name="Task3", identifier=3, period=2.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=1.827509, acet=1.827509, et_stddev=0.6091696666666667, deadline= 3)
        configuration.add_task(name="Task4", identifier=4, period=3.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.018779, et_stddev=0.006259666666666667 , list_activation_dates=[1, 18, 23, 33, 38, 42, 47, 51, 55, 60, 64, 68, 72, 81, 85, 106, 109, 114, 119, 131, 135, 143, 156, 162, 171, 175, 179, 192, 196, 200, 204, 208, 212, 215, 219, 223, 227, 237, 245, 253, 257, 260, 264, 270, 276, 279, 286, 292, 296, 302, 305, 317, 325, 331, 338, 342, 348, 352, 367, 371, 378, 386, 392, 400, 404, 409, 413, 420, 427, 431, 437, 441, 449, 458, 461, 465, 468, 474, 478, 489, 497, 503, 511, 517, 522, 529, 536, 540, 547, 555, 562, 572, 575, 583, 594, 601, 604, 609, 613, 618, 624, 628, 648, 652, 658, 662, 665, 672, 677, 697, 702, 707, 712, 715, 720, 723, 728, 735, 738, 748, 751, 756, 767, 774, 778, 785, 791, 797, 801, 805, 808, 812, 816, 820, 830, 836, 842, 862, 869, 873, 877, 887, 891, 896, 902, 913, 918, 921, 924, 930, 939, 943, 947, 956, 960, 967, 971, 976, 980, 983, 987, 990, 993, 997, 1002, 1006, 1009, 1018, 1022, 1028, 1031, 1035, 1040, 1055, 1059, 1065, 1070, 1081, 1084, 1097, 1101, 1105, 1110, 1116, 1123, 1128, 1134, 1141, 1144, 1148, 1151, 1156, 1162, 1168, 1172, 1176, 1180, 1191, 1196, 1201, 1207, 1213, 1220, 1236, 1241, 1245, 1249, 1255, 1261, 1267, 1271, 1290, 1293, 1298, 1308, 1312, 1315, 1320, 1326, 1332, 1344, 1350, 1354, 1358, 1364, 1368, 1374, 1380, 1387, 1393, 1398, 1401, 1405, 1409, 1416, 1423, 1432, 1435, 1439, 1443, 1449, 1454, 1471, 1490, 1497, 1500, 1505, 1512, 1525, 1529, 1532, 1542, 1551, 1555, 1558, 1563, 1568, 1571, 1575, 1581, 1586, 1589, 1593, 1597, 1601, 1605, 1610, 1614, 1620, 1623, 1627, 1632, 1638, 1641, 1648, 1654, 1662, 1666, 1670, 1676, 1682, 1688, 1694, 1702, 1712, 1716, 1721, 1724, 1730, 1739, 1745, 1754, 1757, 1765, 1769, 1773, 1778, 1782, 1786, 1791, 1794, 1798, 1804, 1807, 1811, 1823, 1827, 1839, 1842, 1848, 1857, 1863, 1875, 1878, 1888, 1893, 1897, 1901, 1905, 1921, 1942, 1945, 1948, 1955, 1959, 1963, 1972, 1979, 1984, 1988, 1993, 2000], deadline = 5)
        configuration.add_task(name="Task2", identifier=2, period=6.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=2.713454, acet=2.713454, et_stddev=0.9044846666666667, deadline= 5)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "41")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "41")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "41")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "41")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task4", identifier=4, period=1.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.008392, et_stddev=0.0027973333333333335 , list_activation_dates=[1, 2, 3, 4, 6, 8, 11, 12, 15, 17, 18, 20, 22, 23, 26, 28, 30, 31, 32, 33, 35, 37, 39, 41, 43, 44, 45, 48, 50, 53, 54, 57, 58, 60, 62, 64, 69, 71, 72, 73, 75, 76, 80, 81, 85, 87, 89, 91, 92, 94, 95, 96, 98, 99, 101, 102, 103, 104, 105, 106, 108, 111, 116, 119, 122, 123, 125, 127, 130, 135, 137, 141, 144, 146, 150, 153, 155, 156, 158, 159, 160, 162, 164, 167, 169, 170, 173, 175, 177, 178, 180, 182, 183, 187, 188, 190, 191, 192, 194, 196, 197, 198, 200, 202, 203, 205, 206, 207, 208, 209, 210, 211, 212, 214, 215, 216, 217, 218, 220, 222, 223, 224, 225, 228, 232, 233, 235, 236, 237, 239, 241, 242, 244, 245, 247, 249, 250, 252, 253, 255, 256, 258, 259, 260, 261, 263, 265, 266, 268, 269, 271, 272, 274, 276, 277, 279, 280, 282, 283, 284, 285, 289, 290, 292, 294, 295, 297, 298, 301, 304, 306, 307, 308, 311, 312, 318, 319, 321, 322, 325, 328, 329, 332, 333, 335, 337, 339, 341, 343, 344, 345, 347, 349, 353, 355, 358, 359, 361, 364, 366, 367, 371, 372, 375, 376, 379, 382, 384, 385, 386, 388, 389, 390, 392, 394, 395, 398, 400, 403, 404, 405, 406, 407, 408, 411, 414, 417, 418, 419, 422, 425, 426, 430, 433, 436, 437, 439, 440, 442, 444, 446, 448, 449, 450, 453, 457, 458, 459, 462, 463, 465, 466, 467, 469, 470, 473, 474, 475, 476, 477, 479, 480, 481, 482, 485, 487, 490, 493, 495, 496, 498, 499, 500, 501, 502, 504, 506, 508, 510, 511, 513, 515, 518, 520, 522, 524, 525, 526, 527, 529, 531, 532, 534, 536, 538, 540, 544, 546, 549, 550, 551, 553, 555, 557, 560, 562, 563, 564, 567, 568, 569, 571, 572, 574, 575, 577, 578, 579, 581, 582, 583, 588, 590, 591, 594, 595, 596, 598, 599, 601, 602, 604, 605, 607, 610, 612, 613, 615, 617, 618, 619, 622, 623, 628, 630, 631, 632, 633, 635, 637, 639, 641, 643, 645, 646, 648, 652, 653, 654, 655, 657, 658, 662, 664, 668, 669, 671, 673, 676, 679, 680, 681, 685, 687, 688, 691, 695, 697, 699, 701, 706, 708, 709, 711, 714, 715, 716, 717, 719, 721, 722, 724, 726, 727, 728, 730, 731, 734, 735, 736, 737, 740, 742, 744, 745, 746, 747, 748, 750, 752, 753, 754, 755, 756, 758, 759, 760, 765, 766, 768, 769, 771, 775, 776, 777, 778, 780, 782, 783, 785, 786, 787, 789, 791, 793, 797, 799, 801, 803, 804, 805, 807, 808, 812, 813, 815, 818, 819, 820, 823, 824, 825, 826, 828, 829, 831, 834, 836, 839, 843, 844, 846, 847, 848, 850, 852, 856, 857, 859, 862, 863, 865, 866, 868, 870, 872, 876, 878, 880, 881, 884, 888, 890, 892, 894, 896, 899, 900, 901, 902, 903, 904, 905, 907, 908, 911, 913, 914, 917, 920, 922, 923, 925, 927, 931, 932, 935, 938, 940, 942, 945, 946, 949, 951, 952, 953, 957, 958, 960, 962, 964, 966, 967, 970, 971, 972, 974, 975, 979, 981, 982, 984, 986, 989, 991, 992, 996, 998, 1000, 1003, 1006, 1008, 1011, 1012, 1016, 1017, 1019, 1021, 1022, 1023, 1024, 1026, 1027, 1028, 1032, 1033, 1035, 1037, 1038, 1040, 1041, 1044, 1045, 1048, 1053, 1054, 1056, 1057, 1058, 1060, 1062, 1065, 1066, 1067, 1068, 1069, 1072, 1073, 1074, 1076, 1078, 1079, 1081, 1084, 1085, 1088, 1089, 1090, 1091, 1095, 1097, 1100, 1104, 1105, 1108, 1110, 1114, 1116, 1119, 1125, 1126, 1129, 1132, 1133, 1134, 1137, 1138, 1140, 1142, 1144, 1146, 1150, 1152, 1155, 1156, 1157, 1159, 1160, 1161, 1163, 1167, 1168, 1173, 1174, 1175, 1179, 1181, 1183, 1184, 1186, 1187, 1188, 1189, 1192, 1193, 1194, 1196, 1200, 1201, 1202, 1203, 1204, 1207, 1209, 1213, 1215, 1216, 1217, 1219, 1221, 1227, 1228, 1230, 1232, 1236, 1239, 1241, 1243, 1244, 1245, 1249, 1251, 1255, 1257, 1260, 1261, 1262, 1263, 1264, 1265, 1266, 1267, 1269, 1273, 1274, 1275, 1277, 1278, 1280, 1283, 1285, 1286, 1287, 1288, 1290, 1293, 1294, 1296, 1297, 1299, 1301, 1302, 1303, 1307, 1309, 1311, 1313, 1314, 1316, 1317, 1318, 1320, 1321, 1322, 1323, 1324, 1326, 1328, 1329, 1338, 1339, 1340, 1341, 1345, 1349, 1351, 1353, 1354, 1356, 1358, 1359, 1362, 1364, 1366, 1368, 1369, 1371, 1373, 1374, 1376, 1378, 1380, 1381, 1382, 1383, 1384, 1388, 1390, 1391, 1393, 1395, 1396, 1399, 1403, 1404, 1407, 1408, 1409, 1411, 1412, 1413, 1415, 1419, 1424, 1425, 1428, 1435, 1436, 1437, 1440, 1441, 1445, 1447, 1448, 1450, 1451, 1452, 1453, 1454, 1455, 1458, 1460, 1461, 1464, 1466, 1468, 1469, 1470, 1471, 1472, 1474, 1475, 1477, 1478, 1482, 1483, 1484, 1485, 1487, 1489, 1491, 1494, 1496, 1498, 1499, 1500, 1502, 1505, 1506, 1508, 1510, 1514, 1521, 1524, 1525, 1526, 1528, 1531, 1532, 1534, 1536, 1537, 1540, 1543, 1544, 1545, 1546, 1547, 1550, 1554, 1555, 1557, 1560, 1566, 1568, 1570, 1571, 1572, 1575, 1576, 1577, 1579, 1580, 1584, 1586, 1587, 1589, 1592, 1594, 1597, 1599, 1602, 1605, 1606, 1609, 1611, 1613, 1614, 1616, 1618, 1620, 1623, 1624, 1625, 1627, 1629, 1632, 1634, 1636, 1637, 1639, 1641, 1643, 1644, 1646, 1647, 1648, 1650, 1651, 1653, 1654, 1657, 1661, 1663, 1665, 1666, 1668, 1669, 1671, 1672, 1676, 1677, 1679, 1681, 1683, 1686, 1691, 1694, 1696, 1698, 1700, 1702, 1703, 1704, 1708, 1710, 1711, 1712, 1714, 1717, 1719, 1720, 1723, 1725, 1727, 1729, 1731, 1733, 1734, 1735, 1737, 1738, 1740, 1742, 1744, 1746, 1747, 1749, 1751, 1753, 1754, 1755, 1758, 1767, 1768, 1770, 1773, 1777, 1779, 1781, 1782, 1784, 1785, 1787, 1790, 1792, 1793, 1797, 1798, 1800, 1808, 1809, 1812, 1813, 1814, 1816, 1818, 1823, 1826, 1828, 1830, 1832, 1834, 1835, 1837, 1840, 1841, 1844, 1846, 1847, 1849, 1854, 1858, 1859, 1862, 1863, 1864, 1866, 1868, 1869, 1870, 1871, 1875, 1876, 1878, 1879, 1881, 1882, 1883, 1884, 1885, 1886, 1887, 1891, 1892, 1894, 1899, 1901, 1904, 1906, 1909, 1910, 1912, 1916, 1917, 1919, 1921, 1922, 1925, 1927, 1929, 1930, 1935, 1937, 1939, 1945, 1947, 1949, 1951, 1952, 1954, 1956, 1958, 1959, 1960, 1962, 1964, 1965, 1967, 1968, 1969, 1972, 1975, 1977, 1981, 1983, 1986, 1987, 1989, 1993, 1994, 1996, 1998, 2000], deadline = 1)
        configuration.add_task(name="Task3", identifier=3, period=7.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=3.004286, acet=3.004286, et_stddev=1.0014286666666667, deadline= 9)
        configuration.add_task(name="Task6", identifier=6, period=1.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.022385, et_stddev=0.007461666666666666 , list_activation_dates=[2, 4, 6, 8, 9, 13, 14, 16, 17, 20, 22, 24, 28, 30, 31, 33, 35, 36, 38, 39, 41, 42, 44, 46, 47, 49, 50, 52, 53, 55, 58, 60, 62, 64, 67, 68, 70, 71, 72, 74, 78, 79, 81, 83, 84, 87, 88, 90, 91, 92, 94, 96, 97, 100, 101, 102, 103, 104, 105, 106, 107, 108, 110, 112, 113, 115, 116, 118, 119, 121, 123, 125, 127, 128, 129, 134, 135, 137, 139, 140, 142, 143, 145, 147, 148, 150, 151, 153, 155, 158, 161, 166, 167, 169, 170, 171, 173, 177, 181, 182, 183, 185, 186, 187, 188, 192, 193, 194, 196, 198, 202, 205, 207, 209, 210, 211, 216, 217, 218, 220, 222, 224, 226, 227, 228, 230, 231, 235, 236, 237, 238, 239, 241, 242, 244, 246, 248, 252, 254, 256, 257, 258, 260, 261, 263, 265, 269, 271, 274, 275, 277, 280, 281, 283, 285, 287, 288, 289, 291, 292, 294, 297, 299, 301, 302, 304, 308, 311, 313, 314, 315, 316, 317, 320, 322, 326, 327, 329, 330, 331, 332, 334, 336, 338, 339, 342, 343, 346, 347, 349, 350, 353, 355, 356, 357, 358, 359, 362, 364, 366, 367, 368, 370, 371, 372, 374, 376, 377, 378, 379, 380, 383, 384, 386, 388, 389, 391, 393, 394, 397, 398, 399, 401, 403, 404, 406, 409, 411, 414, 416, 417, 419, 421, 423, 424, 425, 427, 428, 429, 431, 432, 434, 435, 438, 440, 441, 442, 445, 447, 453, 457, 458, 460, 461, 462, 464, 466, 467, 469, 471, 473, 475, 477, 478, 479, 480, 485, 487, 489, 491, 494, 496, 500, 501, 502, 503, 506, 508, 510, 512, 514, 516, 517, 520, 521, 523, 524, 526, 527, 528, 529, 532, 536, 540, 541, 544, 545, 547, 550, 554, 556, 560, 565, 566, 568, 569, 571, 576, 578, 580, 581, 582, 584, 585, 587, 589, 591, 592, 593, 595, 597, 598, 600, 601, 603, 606, 609, 611, 613, 615, 617, 619, 621, 622, 625, 627, 628, 629, 632, 633, 635, 637, 639, 641, 644, 646, 647, 649, 651, 652, 655, 667, 669, 671, 673, 675, 676, 677, 679, 682, 685, 687, 689, 690, 693, 696, 698, 700, 703, 704, 705, 708, 709, 710, 711, 714, 716, 718, 721, 722, 724, 725, 726, 728, 730, 734, 736, 738, 739, 742, 744, 745, 746, 747, 749, 750, 752, 754, 755, 757, 759, 760, 763, 764, 771, 774, 777, 781, 782, 785, 786, 787, 789, 791, 792, 794, 796, 797, 800, 801, 804, 805, 807, 809, 811, 815, 817, 819, 823, 824, 826, 828, 829, 831, 833, 836, 838, 839, 842, 845, 846, 848, 850, 853, 854, 855, 857, 860, 862, 863, 864, 867, 870, 872, 875, 876, 878, 879, 880, 882, 884, 885, 887, 889, 892, 894, 897, 898, 900, 902, 903, 907, 911, 913, 916, 918, 919, 920, 921, 924, 928, 930, 932, 933, 935, 937, 939, 940, 941, 943, 945, 947, 949, 950, 951, 953, 954, 956, 957, 960, 961, 962, 964, 965, 966, 967, 970, 971, 972, 973, 974, 975, 977, 978, 980, 982, 983, 990, 992, 995, 997, 999, 1000, 1001, 1003, 1005, 1006, 1007, 1009, 1010, 1011, 1017, 1021, 1023, 1025, 1027, 1029, 1030, 1031, 1034, 1035, 1037, 1039, 1041, 1044, 1047, 1050, 1051, 1052, 1054, 1057, 1059, 1061, 1062, 1064, 1067, 1071, 1072, 1077, 1079, 1081, 1082, 1083, 1086, 1087, 1089, 1091, 1094, 1098, 1099, 1100, 1101, 1104, 1105, 1107, 1109, 1110, 1111, 1112, 1113, 1117, 1119, 1122, 1124, 1125, 1127, 1129, 1131, 1132, 1133, 1135, 1136, 1137, 1138, 1140, 1142, 1144, 1145, 1147, 1151, 1153, 1158, 1160, 1163, 1164, 1166, 1167, 1169, 1171, 1172, 1175, 1176, 1178, 1181, 1182, 1184, 1185, 1186, 1187, 1191, 1194, 1195, 1197, 1199, 1201, 1202, 1206, 1208, 1210, 1212, 1214, 1217, 1218, 1221, 1222, 1225, 1226, 1227, 1230, 1231, 1233, 1234, 1236, 1238, 1240, 1244, 1245, 1247, 1249, 1252, 1254, 1255, 1257, 1258, 1261, 1264, 1267, 1269, 1271, 1273, 1275, 1277, 1279, 1281, 1282, 1284, 1286, 1291, 1293, 1294, 1296, 1298, 1299, 1301, 1302, 1306, 1308, 1311, 1313, 1315, 1318, 1320, 1321, 1323, 1327, 1329, 1331, 1333, 1334, 1336, 1337, 1339, 1340, 1344, 1345, 1346, 1348, 1349, 1353, 1354, 1356, 1358, 1359, 1361, 1364, 1365, 1368, 1370, 1372, 1374, 1376, 1380, 1384, 1385, 1388, 1389, 1391, 1397, 1398, 1399, 1401, 1402, 1404, 1405, 1406, 1407, 1408, 1410, 1412, 1413, 1415, 1417, 1418, 1419, 1420, 1423, 1424, 1425, 1426, 1429, 1431, 1433, 1435, 1437, 1440, 1442, 1444, 1447, 1448, 1452, 1454, 1455, 1457, 1458, 1460, 1462, 1463, 1466, 1468, 1471, 1472, 1473, 1475, 1477, 1478, 1479, 1482, 1484, 1486, 1487, 1489, 1491, 1494, 1496, 1497, 1501, 1503, 1507, 1509, 1510, 1511, 1513, 1516, 1517, 1519, 1520, 1522, 1525, 1527, 1530, 1532, 1534, 1536, 1537, 1541, 1545, 1546, 1547, 1548, 1550, 1552, 1553, 1555, 1558, 1559, 1563, 1564, 1565, 1567, 1569, 1570, 1571, 1572, 1576, 1578, 1579, 1580, 1581, 1583, 1585, 1587, 1589, 1591, 1593, 1594, 1595, 1597, 1599, 1601, 1603, 1605, 1606, 1609, 1610, 1611, 1613, 1616, 1617, 1619, 1621, 1623, 1626, 1627, 1628, 1630, 1632, 1633, 1637, 1639, 1641, 1643, 1646, 1647, 1648, 1650, 1651, 1654, 1656, 1658, 1662, 1663, 1664, 1666, 1668, 1672, 1673, 1675, 1676, 1679, 1683, 1685, 1686, 1690, 1692, 1693, 1694, 1695, 1697, 1699, 1703, 1705, 1708, 1710, 1712, 1713, 1716, 1720, 1723, 1727, 1728, 1733, 1735, 1737, 1739, 1741, 1743, 1745, 1746, 1749, 1750, 1751, 1752, 1753, 1756, 1758, 1760, 1761, 1763, 1765, 1767, 1769, 1771, 1775, 1777, 1779, 1780, 1781, 1782, 1784, 1787, 1789, 1792, 1795, 1796, 1801, 1803, 1804, 1805, 1806, 1808, 1809, 1811, 1812, 1813, 1814, 1815, 1817, 1820, 1825, 1826, 1828, 1830, 1832, 1833, 1837, 1839, 1848, 1850, 1851, 1852, 1853, 1854, 1855, 1856, 1860, 1861, 1862, 1863, 1866, 1867, 1868, 1870, 1874, 1876, 1881, 1885, 1888, 1889, 1891, 1893, 1895, 1898, 1903, 1904, 1905, 1907, 1911, 1912, 1913, 1914, 1916, 1917, 1919, 1923, 1924, 1925, 1926, 1929, 1932, 1933, 1935, 1938, 1941, 1942, 1946, 1948, 1950, 1953, 1954, 1955, 1956, 1957, 1958, 1960, 1962, 1963, 1965, 1967, 1969, 1970, 1972, 1976, 1978, 1981, 1982, 1984, 1986, 1987, 1989, 1991, 1993, 1995, 1997, 1998], deadline = 2)
        configuration.add_task(name="Task2", identifier=2, period=28.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=20.31672, acet=20.31672, et_stddev=6.77224, deadline= 47)
        configuration.add_task(name="Task1", identifier=1, period=24.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=10.685256, acet=10.685256, et_stddev=3.5617520000000003, deadline= 26)
        configuration.add_task(name="Task5", identifier=5, period=19.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=4, acet=3.215212, et_stddev=1.0717373333333333 , list_activation_dates=[12, 73, 97, 145, 180, 202, 234, 259, 314, 336, 377, 417, 486, 517, 595, 660, 711, 749, 781, 802, 837, 878, 905, 946, 966, 987, 1032, 1067, 1097, 1191, 1264, 1349, 1369, 1394, 1434, 1473, 1505, 1603, 1637, 1658, 1679, 1742, 1781, 1827, 1898, 1930, 1958, 1988], deadline = 30)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "42")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "42")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "42")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "42")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task5", identifier=5, period=13.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.665429, et_stddev=0.22180966666666668 , list_activation_dates=[5, 23, 38, 60, 81, 108, 126, 140, 166, 186, 219, 241, 282, 305, 338, 354, 374, 436, 457, 470, 491, 511, 525, 549, 573, 591, 606, 621, 648, 700, 738, 755, 784, 803, 817, 838, 858, 885, 905, 928, 955, 984, 1005, 1019, 1042, 1071, 1111, 1144, 1164, 1188, 1207, 1225, 1243, 1273, 1303, 1327, 1356, 1374, 1394, 1427, 1456, 1470, 1515, 1534, 1555, 1573, 1599, 1613, 1658, 1680, 1711, 1737, 1781, 1801, 1817, 1857, 1872, 1891, 1908, 1931, 1945, 1966, 1996], deadline = 5)
        configuration.add_task(name="Task1", identifier=1, period=2.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=0.967872, acet=0.967872, et_stddev=0.32262399999999997, deadline= 4)
        configuration.add_task(name="Task6", identifier=6, period=34.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=2, acet=1.328507, et_stddev=0.4428356666666667 , list_activation_dates=[18, 101, 141, 233, 267, 332, 436, 501, 554, 688, 736, 788, 875, 942, 979, 1047, 1098, 1152, 1250, 1304, 1455, 1530, 1574, 1619, 1666, 1715, 1907], deadline = 23)
        configuration.add_task(name="Task2", identifier=2, period=10.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=3.029211, acet=3.029211, et_stddev=1.009737, deadline= 6)
        configuration.add_task(name="Task3", identifier=3, period=40.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=32.5257, acet=32.5257, et_stddev=10.8419, deadline= 53)
        configuration.add_task(name="Task4", identifier=4, period=13.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=2, acet=1.426611, et_stddev=0.47553700000000004 , list_activation_dates=[11, 57, 86, 102, 157, 185, 214, 254, 281, 295, 311, 338, 356, 374, 391, 414, 439, 475, 498, 517, 534, 578, 596, 615, 637, 655, 695, 758, 774, 809, 835, 853, 876, 910, 947, 976, 990, 1014, 1032, 1054, 1068, 1091, 1111, 1137, 1150, 1175, 1254, 1281, 1304, 1319, 1379, 1394, 1439, 1454, 1475, 1522, 1544, 1559, 1575, 1597, 1620, 1642, 1661, 1674, 1720, 1745, 1769, 1787, 1804, 1824, 1845, 1872, 1888, 1904, 1921, 1950, 1979, 1993], deadline = 14)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "43")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "43")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "43")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "43")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task2", identifier=2, period=14.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=6.538519, acet=6.538519, et_stddev=2.1795063333333333, deadline= 8)
        configuration.add_task(name="Task4", identifier=4, period=4.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.013339, et_stddev=0.004446333333333333 , list_activation_dates=[5, 12, 17, 22, 35, 50, 55, 63, 72, 78, 83, 88, 93, 98, 104, 110, 115, 119, 123, 135, 144, 149, 154, 164, 178, 185, 191, 195, 202, 208, 215, 223, 227, 233, 237, 245, 250, 261, 267, 271, 276, 281, 287, 291, 312, 317, 323, 330, 361, 366, 370, 375, 383, 392, 410, 414, 424, 441, 446, 451, 458, 463, 473, 478, 482, 489, 500, 506, 518, 526, 533, 540, 550, 557, 562, 570, 574, 581, 586, 592, 597, 602, 607, 616, 622, 626, 636, 640, 645, 649, 658, 671, 676, 689, 701, 709, 714, 726, 736, 740, 745, 750, 762, 766, 776, 790, 806, 815, 821, 825, 830, 843, 847, 854, 863, 883, 888, 895, 899, 909, 914, 918, 925, 929, 935, 941, 952, 957, 967, 972, 981, 987, 993, 998, 1004, 1013, 1020, 1024, 1029, 1035, 1041, 1050, 1054, 1066, 1084, 1090, 1095, 1099, 1112, 1123, 1131, 1137, 1143, 1160, 1175, 1180, 1190, 1194, 1202, 1211, 1221, 1234, 1238, 1243, 1248, 1255, 1262, 1267, 1275, 1281, 1286, 1291, 1300, 1304, 1309, 1315, 1327, 1333, 1344, 1351, 1359, 1368, 1376, 1381, 1391, 1408, 1413, 1419, 1435, 1440, 1455, 1461, 1471, 1477, 1483, 1490, 1496, 1509, 1515, 1526, 1536, 1547, 1557, 1561, 1571, 1587, 1601, 1606, 1610, 1614, 1619, 1626, 1634, 1646, 1652, 1659, 1667, 1673, 1677, 1682, 1687, 1701, 1712, 1716, 1735, 1741, 1748, 1758, 1764, 1769, 1781, 1791, 1795, 1808, 1815, 1826, 1831, 1839, 1845, 1851, 1856, 1866, 1871, 1876, 1883, 1888, 1896, 1900, 1905, 1916, 1921, 1927, 1941, 1951, 1959, 1971, 1978, 1985, 1994, 2000], deadline = 2)
        configuration.add_task(name="Task3", identifier=3, period=36.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=16.988067, acet=16.988067, et_stddev=5.662689, deadline= 38)
        configuration.add_task(name="Task5", identifier=5, period=25.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=4, acet=3.004302, et_stddev=1.001434 , list_activation_dates=[5, 30, 57, 166, 229, 281, 316, 368, 423, 463, 493, 523, 554, 583, 614, 662, 709, 739, 792, 828, 879, 907, 952, 1015, 1081, 1115, 1165, 1205, 1240, 1265, 1303, 1346, 1376, 1403, 1456, 1500, 1533, 1571, 1650, 1693, 1749, 1777, 1807, 1851, 1896, 1926, 1956, 1992], deadline = 39)
        configuration.add_task(name="Task1", identifier=1, period=1.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=0.661072, acet=0.661072, et_stddev=0.22035733333333332, deadline= 1)
        configuration.add_task(name="Task6", identifier=6, period=11.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.841423, et_stddev=0.2804743333333333 , list_activation_dates=[6, 48, 61, 77, 97, 114, 132, 171, 189, 204, 217, 237, 252, 286, 298, 310, 332, 385, 410, 428, 440, 460, 472, 491, 505, 523, 537, 561, 606, 620, 688, 700, 713, 727, 743, 790, 807, 829, 844, 856, 873, 888, 911, 927, 940, 952, 987, 998, 1013, 1033, 1065, 1088, 1113, 1130, 1143, 1176, 1192, 1228, 1242, 1253, 1266, 1304, 1335, 1373, 1411, 1423, 1434, 1452, 1467, 1495, 1511, 1525, 1547, 1617, 1632, 1648, 1661, 1682, 1698, 1737, 1754, 1770, 1787, 1817, 1837, 1864, 1925, 1937, 1958, 1971, 1994], deadline = 1)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "44")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "44")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "44")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "44")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task2", identifier=2, period=24.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=3.129368, acet=3.129368, et_stddev=1.0431226666666666, deadline= 36)
        configuration.add_task(name="Task4", identifier=4, period=11.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.239928, et_stddev=0.079976 , list_activation_dates=[6, 18, 36, 48, 72, 94, 129, 142, 166, 177, 188, 201, 215, 228, 241, 270, 290, 302, 315, 338, 388, 411, 439, 463, 492, 512, 524, 546, 573, 586, 617, 644, 674, 687, 739, 754, 769, 805, 832, 844, 860, 872, 897, 912, 927, 942, 954, 975, 992, 1011, 1028, 1040, 1051, 1064, 1076, 1094, 1106, 1120, 1145, 1157, 1174, 1193, 1226, 1239, 1254, 1268, 1279, 1291, 1326, 1340, 1351, 1401, 1417, 1428, 1447, 1477, 1503, 1522, 1533, 1546, 1562, 1574, 1595, 1617, 1632, 1645, 1679, 1692, 1705, 1717, 1751, 1769, 1791, 1838, 1863, 1892, 1906, 1929, 1960, 1984], deadline = 9)
        configuration.add_task(name="Task1", identifier=1, period=11.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=6.99834, acet=6.99834, et_stddev=2.33278, deadline= 7)
        configuration.add_task(name="Task5", identifier=5, period=1.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.092076, et_stddev=0.030692 , list_activation_dates=[1, 3, 5, 7, 9, 12, 15, 16, 17, 22, 24, 26, 28, 29, 30, 32, 34, 36, 37, 38, 39, 40, 44, 46, 47, 48, 50, 52, 53, 54, 57, 58, 60, 62, 64, 66, 68, 71, 73, 75, 76, 79, 84, 86, 89, 91, 93, 94, 95, 98, 100, 103, 104, 106, 109, 112, 113, 116, 118, 120, 121, 122, 124, 126, 130, 134, 137, 138, 140, 143, 145, 146, 148, 149, 154, 157, 159, 160, 161, 163, 165, 166, 167, 171, 173, 177, 179, 180, 182, 183, 184, 185, 186, 188, 190, 191, 192, 195, 197, 199, 200, 201, 203, 205, 206, 207, 208, 209, 212, 214, 216, 218, 221, 222, 224, 225, 228, 230, 232, 235, 237, 241, 242, 243, 246, 249, 250, 251, 252, 254, 256, 259, 261, 264, 265, 266, 269, 271, 273, 275, 276, 279, 281, 282, 283, 288, 289, 290, 292, 293, 296, 298, 300, 301, 302, 303, 305, 306, 308, 309, 310, 313, 316, 317, 323, 327, 330, 331, 332, 336, 338, 340, 341, 344, 345, 346, 348, 349, 352, 353, 355, 356, 357, 359, 364, 366, 368, 370, 372, 373, 376, 377, 381, 382, 384, 387, 389, 390, 391, 393, 395, 397, 398, 402, 403, 404, 406, 407, 408, 411, 413, 414, 415, 417, 418, 420, 422, 425, 426, 427, 431, 432, 434, 435, 439, 441, 443, 445, 447, 449, 452, 454, 458, 461, 463, 464, 465, 466, 469, 470, 473, 474, 476, 479, 481, 482, 484, 486, 488, 490, 492, 495, 497, 500, 501, 503, 504, 508, 512, 513, 516, 518, 519, 524, 526, 527, 528, 530, 534, 535, 536, 537, 538, 539, 540, 541, 543, 544, 547, 549, 550, 553, 555, 558, 561, 563, 567, 568, 569, 570, 573, 575, 580, 581, 583, 584, 585, 588, 589, 597, 599, 602, 603, 605, 606, 609, 610, 612, 614, 615, 617, 619, 620, 623, 626, 629, 631, 632, 635, 636, 637, 638, 641, 643, 644, 646, 648, 649, 650, 652, 654, 657, 659, 660, 661, 663, 664, 665, 666, 668, 669, 671, 675, 678, 682, 684, 687, 688, 690, 693, 699, 701, 703, 706, 708, 713, 717, 719, 724, 726, 728, 730, 731, 732, 733, 734, 738, 739, 740, 742, 743, 746, 748, 749, 751, 753, 754, 755, 759, 760, 761, 763, 764, 767, 769, 771, 773, 775, 776, 779, 780, 781, 783, 785, 787, 789, 790, 791, 793, 795, 798, 801, 803, 806, 808, 810, 812, 815, 818, 820, 822, 824, 826, 827, 829, 831, 832, 839, 840, 842, 845, 847, 849, 850, 852, 853, 854, 856, 857, 858, 859, 861, 863, 864, 865, 867, 871, 873, 875, 877, 879, 881, 882, 885, 890, 891, 893, 896, 897, 899, 902, 903, 904, 905, 907, 909, 910, 912, 913, 915, 916, 917, 921, 923, 924, 925, 926, 929, 931, 934, 936, 938, 939, 940, 941, 944, 945, 947, 949, 954, 955, 959, 961, 964, 966, 967, 968, 969, 970, 973, 975, 977, 980, 983, 985, 986, 988, 989, 990, 992, 995, 996, 997, 999, 1001, 1003, 1005, 1008, 1011, 1012, 1013, 1014, 1016, 1018, 1020, 1022, 1025, 1026, 1028, 1029, 1033, 1037, 1040, 1043, 1045, 1046, 1048, 1051, 1052, 1053, 1054, 1055, 1056, 1061, 1063, 1066, 1067, 1068, 1069, 1073, 1074, 1076, 1077, 1078, 1079, 1081, 1083, 1085, 1087, 1089, 1093, 1094, 1096, 1097, 1100, 1101, 1104, 1106, 1109, 1110, 1111, 1114, 1116, 1117, 1118, 1121, 1123, 1125, 1126, 1128, 1129, 1131, 1132, 1133, 1137, 1139, 1140, 1141, 1142, 1143, 1146, 1151, 1152, 1154, 1155, 1156, 1157, 1158, 1159, 1161, 1162, 1164, 1165, 1166, 1168, 1169, 1171, 1172, 1177, 1179, 1180, 1182, 1185, 1189, 1191, 1193, 1194, 1199, 1200, 1201, 1203, 1204, 1206, 1207, 1209, 1212, 1213, 1214, 1218, 1221, 1223, 1224, 1226, 1230, 1232, 1233, 1236, 1237, 1238, 1239, 1241, 1242, 1244, 1245, 1248, 1250, 1256, 1258, 1260, 1263, 1264, 1265, 1266, 1271, 1276, 1279, 1280, 1282, 1285, 1288, 1291, 1295, 1298, 1300, 1302, 1307, 1309, 1311, 1313, 1315, 1320, 1322, 1325, 1329, 1332, 1334, 1337, 1340, 1342, 1343, 1346, 1349, 1352, 1353, 1354, 1355, 1357, 1358, 1360, 1362, 1364, 1365, 1368, 1369, 1374, 1376, 1377, 1379, 1380, 1383, 1386, 1387, 1388, 1390, 1391, 1394, 1396, 1398, 1400, 1402, 1403, 1405, 1408, 1410, 1412, 1414, 1416, 1418, 1420, 1426, 1429, 1430, 1431, 1433, 1436, 1438, 1440, 1445, 1449, 1450, 1453, 1455, 1458, 1460, 1461, 1468, 1471, 1473, 1476, 1479, 1480, 1481, 1482, 1484, 1487, 1491, 1493, 1494, 1495, 1496, 1497, 1498, 1502, 1506, 1507, 1509, 1510, 1511, 1512, 1515, 1517, 1520, 1521, 1522, 1524, 1529, 1531, 1532, 1534, 1536, 1539, 1540, 1542, 1548, 1550, 1552, 1555, 1556, 1557, 1558, 1559, 1560, 1562, 1563, 1566, 1568, 1570, 1572, 1574, 1575, 1576, 1577, 1578, 1579, 1582, 1587, 1590, 1591, 1593, 1594, 1595, 1596, 1598, 1600, 1603, 1605, 1606, 1609, 1610, 1616, 1618, 1620, 1621, 1623, 1624, 1626, 1629, 1631, 1633, 1634, 1636, 1637, 1638, 1639, 1641, 1643, 1644, 1646, 1647, 1648, 1649, 1652, 1655, 1659, 1661, 1662, 1664, 1666, 1669, 1670, 1671, 1672, 1674, 1675, 1678, 1680, 1682, 1684, 1687, 1688, 1690, 1692, 1693, 1695, 1700, 1702, 1704, 1706, 1707, 1709, 1711, 1712, 1714, 1715, 1717, 1719, 1720, 1721, 1722, 1724, 1725, 1726, 1727, 1728, 1730, 1732, 1735, 1738, 1739, 1740, 1741, 1742, 1746, 1747, 1749, 1751, 1752, 1757, 1758, 1759, 1761, 1762, 1764, 1769, 1771, 1772, 1773, 1774, 1775, 1780, 1784, 1786, 1794, 1796, 1800, 1801, 1802, 1803, 1804, 1805, 1806, 1807, 1808, 1811, 1813, 1814, 1816, 1818, 1820, 1822, 1823, 1827, 1828, 1829, 1830, 1832, 1833, 1834, 1836, 1838, 1840, 1842, 1843, 1844, 1845, 1847, 1849, 1851, 1853, 1856, 1858, 1860, 1862, 1865, 1868, 1870, 1871, 1873, 1875, 1877, 1879, 1880, 1882, 1883, 1885, 1886, 1890, 1891, 1893, 1898, 1900, 1901, 1903, 1904, 1905, 1907, 1908, 1911, 1913, 1915, 1917, 1919, 1920, 1921, 1922, 1925, 1928, 1929, 1930, 1934, 1935, 1938, 1939, 1940, 1941, 1943, 1945, 1946, 1948, 1949, 1955, 1957, 1958, 1959, 1960, 1962, 1963, 1965, 1966, 1968, 1971, 1974, 1975, 1977, 1980, 1981, 1985, 1987, 1988, 1989, 1990, 1991, 1993, 1994, 1996, 1998, 2000], deadline = 2)
        configuration.add_task(name="Task3", identifier=3, period=12.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=10.000762, acet=10.000762, et_stddev=3.3335873333333335, deadline= 24)
        configuration.add_task(name="Task6", identifier=6, period=49.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=5, acet=4.219495, et_stddev=1.4064983333333334 , list_activation_dates=[135, 217, 268, 325, 493, 547, 754, 807, 901, 1010, 1083, 1135, 1246, 1313, 1381, 1435, 1567, 1645, 1699, 1774, 1847], deadline = 92)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "46")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "46")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "46")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "46")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task2", identifier=2, period=27.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=7.112013, acet=7.112013, et_stddev=2.370671, deadline= 46)
        configuration.add_task(name="Task5", identifier=5, period=5.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.788131, et_stddev=0.2627103333333333 , list_activation_dates=[15, 22, 28, 33, 42, 49, 55, 62, 68, 76, 81, 95, 102, 110, 128, 134, 139, 153, 160, 175, 185, 190, 198, 207, 214, 225, 230, 246, 252, 257, 268, 279, 284, 296, 302, 310, 316, 327, 342, 354, 367, 372, 378, 392, 399, 405, 418, 437, 445, 452, 460, 468, 483, 490, 497, 506, 519, 533, 544, 552, 567, 575, 581, 592, 610, 618, 628, 637, 644, 653, 665, 671, 677, 686, 691, 701, 711, 718, 748, 753, 768, 774, 780, 786, 796, 807, 818, 827, 845, 850, 857, 871, 879, 890, 895, 901, 907, 927, 935, 940, 959, 966, 975, 981, 992, 997, 1003, 1031, 1038, 1045, 1050, 1060, 1088, 1093, 1101, 1110, 1124, 1132, 1139, 1144, 1153, 1163, 1168, 1174, 1181, 1194, 1204, 1210, 1221, 1227, 1237, 1248, 1267, 1283, 1288, 1304, 1331, 1360, 1366, 1374, 1382, 1389, 1398, 1403, 1410, 1416, 1425, 1440, 1467, 1479, 1496, 1501, 1507, 1514, 1520, 1526, 1535, 1544, 1550, 1565, 1578, 1586, 1598, 1610, 1624, 1634, 1642, 1649, 1655, 1665, 1676, 1707, 1715, 1720, 1726, 1735, 1742, 1751, 1757, 1764, 1770, 1779, 1788, 1804, 1810, 1818, 1824, 1830, 1835, 1844, 1853, 1863, 1878, 1892, 1904, 1916, 1923, 1935, 1944, 1952, 1971, 1979, 1991], deadline = 6)
        configuration.add_task(name="Task1", identifier=1, period=42.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=38.498082, acet=38.498082, et_stddev=12.832693999999998, deadline= 46)
        configuration.add_task(name="Task6", identifier=6, period=18.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.673383, et_stddev=0.224461 , list_activation_dates=[2, 57, 113, 133, 152, 176, 195, 214, 278, 303, 346, 368, 406, 486, 527, 566, 625, 645, 670, 746, 775, 876, 932, 954, 981, 1031, 1066, 1098, 1146, 1183, 1248, 1267, 1293, 1317, 1347, 1385, 1413, 1434, 1479, 1547, 1567, 1587, 1611, 1630, 1650, 1692, 1730, 1749, 1776, 1801, 1829, 1849, 1888, 1909, 1931], deadline = 35)
        configuration.add_task(name="Task3", identifier=3, period=14.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=5.879595, acet=5.879595, et_stddev=1.959865, deadline= 24)
        configuration.add_task(name="Task4", identifier=4, period=2.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.009926, et_stddev=0.003308666666666667 , list_activation_dates=[5, 9, 11, 14, 17, 20, 31, 34, 37, 39, 41, 44, 47, 53, 60, 70, 74, 83, 85, 93, 96, 100, 103, 107, 113, 117, 123, 126, 130, 132, 134, 137, 145, 148, 153, 156, 159, 161, 164, 170, 175, 180, 183, 192, 200, 203, 205, 209, 212, 215, 218, 223, 226, 231, 238, 240, 244, 252, 256, 258, 261, 265, 269, 271, 273, 275, 279, 284, 289, 292, 294, 300, 309, 315, 318, 322, 328, 336, 340, 342, 347, 349, 352, 356, 359, 362, 365, 369, 382, 392, 395, 400, 403, 409, 413, 417, 421, 424, 431, 441, 443, 450, 452, 455, 457, 464, 467, 472, 476, 481, 485, 488, 490, 493, 497, 502, 504, 510, 515, 518, 521, 523, 528, 532, 535, 542, 549, 554, 560, 562, 565, 567, 571, 577, 580, 583, 586, 591, 593, 597, 600, 604, 609, 614, 619, 625, 630, 633, 639, 641, 645, 651, 653, 657, 660, 665, 669, 676, 679, 683, 685, 690, 693, 696, 699, 701, 708, 710, 712, 717, 720, 722, 725, 727, 731, 736, 739, 741, 750, 753, 755, 757, 759, 764, 768, 771, 774, 782, 785, 788, 793, 800, 803, 808, 811, 819, 822, 825, 827, 829, 833, 839, 842, 844, 846, 850, 853, 858, 867, 872, 877, 879, 884, 892, 897, 900, 903, 907, 912, 916, 920, 925, 931, 933, 936, 943, 946, 948, 953, 955, 960, 964, 968, 972, 974, 977, 981, 983, 986, 992, 999, 1002, 1006, 1011, 1016, 1025, 1030, 1034, 1037, 1045, 1047, 1049, 1056, 1059, 1065, 1070, 1072, 1076, 1080, 1085, 1088, 1091, 1093, 1097, 1101, 1104, 1111, 1115, 1117, 1124, 1126, 1128, 1131, 1133, 1137, 1139, 1143, 1149, 1151, 1154, 1158, 1162, 1166, 1173, 1177, 1181, 1184, 1187, 1191, 1197, 1199, 1201, 1209, 1212, 1215, 1218, 1223, 1231, 1237, 1241, 1244, 1247, 1252, 1255, 1262, 1264, 1267, 1276, 1279, 1286, 1288, 1295, 1299, 1306, 1309, 1311, 1314, 1319, 1321, 1327, 1330, 1335, 1337, 1340, 1343, 1345, 1347, 1350, 1353, 1358, 1362, 1367, 1371, 1385, 1388, 1394, 1397, 1401, 1404, 1407, 1411, 1415, 1417, 1420, 1423, 1428, 1430, 1432, 1438, 1440, 1442, 1445, 1447, 1454, 1457, 1462, 1464, 1468, 1472, 1475, 1478, 1481, 1483, 1486, 1492, 1494, 1501, 1503, 1505, 1507, 1513, 1517, 1523, 1527, 1529, 1531, 1533, 1542, 1547, 1551, 1555, 1560, 1563, 1567, 1569, 1577, 1584, 1587, 1592, 1595, 1598, 1601, 1603, 1608, 1611, 1613, 1616, 1622, 1624, 1627, 1630, 1634, 1636, 1638, 1641, 1645, 1648, 1651, 1655, 1657, 1660, 1662, 1664, 1666, 1670, 1676, 1680, 1685, 1693, 1696, 1701, 1703, 1706, 1711, 1719, 1721, 1725, 1729, 1733, 1735, 1742, 1745, 1747, 1751, 1755, 1758, 1763, 1766, 1771, 1776, 1780, 1783, 1788, 1792, 1797, 1800, 1804, 1806, 1810, 1814, 1816, 1819, 1821, 1826, 1829, 1834, 1838, 1840, 1845, 1847, 1849, 1851, 1855, 1859, 1863, 1867, 1870, 1872, 1876, 1880, 1892, 1895, 1898, 1901, 1904, 1911, 1916, 1920, 1922, 1926, 1929, 1933, 1937, 1941, 1944, 1946, 1948, 1954, 1959, 1966, 1969, 1972, 1974, 1977, 1981, 1986, 1989, 1991, 1995, 1998], deadline = 2)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "47")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "47")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "47")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "47")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task6", identifier=6, period=28.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.547565, et_stddev=0.18252166666666667 , list_activation_dates=[59, 110, 141, 190, 228, 258, 350, 390, 491, 636, 672, 727, 810, 903, 954, 1032, 1146, 1201, 1289, 1317, 1419, 1455, 1522, 1576, 1605, 1675, 1719, 1774, 1821, 1869, 1907, 1935, 1984], deadline = 4)
        configuration.add_task(name="Task5", identifier=5, period=1.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.156412, et_stddev=0.052137333333333334 , list_activation_dates=[2, 4, 6, 8, 11, 13, 16, 17, 19, 24, 26, 27, 28, 29, 30, 31, 34, 36, 37, 38, 39, 41, 42, 44, 45, 46, 48, 50, 54, 55, 59, 63, 65, 69, 71, 73, 74, 77, 78, 80, 81, 83, 86, 87, 91, 94, 95, 98, 99, 102, 103, 106, 108, 109, 110, 112, 115, 116, 119, 120, 121, 122, 123, 124, 125, 126, 128, 130, 132, 133, 135, 136, 140, 142, 147, 149, 150, 151, 153, 154, 155, 157, 160, 162, 165, 166, 167, 170, 172, 175, 177, 179, 180, 181, 183, 188, 192, 193, 194, 200, 201, 204, 206, 207, 208, 210, 212, 213, 214, 217, 218, 219, 220, 222, 226, 228, 229, 235, 236, 237, 238, 242, 250, 251, 252, 253, 255, 257, 258, 260, 261, 262, 264, 266, 267, 270, 271, 273, 277, 279, 280, 282, 283, 285, 288, 290, 291, 293, 296, 297, 298, 300, 304, 305, 306, 307, 310, 313, 314, 316, 319, 327, 328, 330, 333, 334, 336, 337, 338, 339, 340, 342, 344, 345, 347, 349, 350, 351, 353, 357, 359, 360, 361, 363, 365, 366, 367, 369, 370, 371, 373, 377, 378, 379, 380, 382, 383, 386, 388, 392, 393, 395, 398, 399, 400, 401, 403, 405, 407, 408, 410, 414, 415, 416, 417, 419, 421, 422, 423, 425, 427, 429, 430, 431, 432, 435, 439, 441, 443, 449, 451, 453, 454, 456, 459, 460, 461, 462, 464, 465, 468, 472, 473, 474, 475, 476, 478, 480, 482, 484, 486, 487, 488, 489, 490, 493, 494, 495, 496, 498, 500, 501, 504, 505, 508, 510, 511, 512, 513, 515, 516, 517, 519, 521, 524, 529, 532, 534, 537, 538, 540, 541, 545, 548, 549, 551, 553, 554, 555, 557, 559, 560, 561, 562, 563, 564, 566, 567, 570, 571, 574, 577, 582, 584, 589, 591, 593, 595, 597, 599, 600, 602, 607, 609, 612, 614, 617, 619, 620, 622, 623, 624, 626, 629, 631, 632, 634, 635, 636, 637, 639, 641, 642, 645, 651, 653, 656, 661, 663, 666, 667, 669, 671, 672, 673, 675, 677, 678, 679, 680, 682, 683, 687, 690, 691, 695, 696, 698, 701, 703, 706, 710, 712, 714, 718, 720, 722, 724, 727, 728, 730, 731, 732, 733, 737, 740, 742, 743, 745, 747, 748, 750, 751, 753, 757, 759, 760, 764, 766, 768, 770, 772, 773, 775, 776, 778, 780, 787, 788, 791, 795, 796, 797, 798, 799, 801, 802, 803, 804, 805, 806, 807, 808, 810, 812, 814, 815, 820, 821, 823, 825, 826, 828, 830, 831, 833, 836, 838, 841, 844, 847, 849, 851, 852, 854, 856, 858, 861, 867, 870, 872, 874, 876, 877, 879, 881, 882, 885, 886, 887, 888, 890, 891, 896, 898, 899, 901, 902, 904, 906, 908, 909, 912, 913, 915, 917, 918, 920, 921, 925, 927, 930, 931, 933, 934, 936, 939, 941, 942, 944, 946, 947, 950, 953, 954, 956, 958, 959, 961, 962, 963, 966, 968, 970, 973, 976, 977, 979, 983, 985, 987, 988, 989, 991, 993, 996, 1001, 1003, 1005, 1006, 1008, 1010, 1012, 1014, 1018, 1020, 1021, 1028, 1030, 1031, 1034, 1036, 1038, 1039, 1041, 1044, 1045, 1047, 1049, 1051, 1052, 1055, 1058, 1061, 1063, 1066, 1067, 1068, 1071, 1072, 1073, 1075, 1077, 1079, 1080, 1082, 1084, 1085, 1086, 1087, 1091, 1093, 1094, 1095, 1097, 1098, 1099, 1101, 1104, 1106, 1108, 1110, 1112, 1114, 1117, 1119, 1122, 1125, 1127, 1133, 1136, 1139, 1141, 1144, 1146, 1148, 1150, 1152, 1155, 1156, 1157, 1160, 1163, 1164, 1166, 1167, 1170, 1172, 1176, 1178, 1180, 1182, 1184, 1185, 1187, 1189, 1192, 1194, 1201, 1204, 1205, 1207, 1209, 1210, 1214, 1215, 1217, 1219, 1220, 1222, 1225, 1226, 1227, 1230, 1232, 1233, 1237, 1240, 1242, 1244, 1246, 1251, 1253, 1256, 1257, 1259, 1260, 1261, 1265, 1267, 1269, 1271, 1272, 1274, 1275, 1277, 1279, 1281, 1282, 1283, 1284, 1292, 1294, 1297, 1298, 1300, 1301, 1302, 1305, 1309, 1310, 1312, 1314, 1317, 1318, 1319, 1320, 1323, 1325, 1327, 1328, 1333, 1335, 1336, 1338, 1340, 1343, 1345, 1347, 1349, 1352, 1355, 1357, 1358, 1360, 1362, 1363, 1364, 1367, 1368, 1369, 1371, 1374, 1376, 1378, 1379, 1380, 1382, 1383, 1385, 1386, 1387, 1390, 1391, 1392, 1394, 1395, 1397, 1398, 1401, 1402, 1406, 1408, 1410, 1411, 1412, 1414, 1416, 1417, 1419, 1420, 1422, 1424, 1426, 1427, 1429, 1430, 1431, 1433, 1434, 1435, 1437, 1440, 1441, 1446, 1448, 1452, 1454, 1455, 1456, 1457, 1458, 1461, 1465, 1467, 1469, 1471, 1472, 1476, 1481, 1483, 1485, 1486, 1488, 1489, 1492, 1493, 1495, 1499, 1500, 1501, 1502, 1505, 1506, 1508, 1512, 1514, 1517, 1518, 1519, 1520, 1522, 1523, 1524, 1525, 1527, 1529, 1530, 1532, 1535, 1537, 1539, 1541, 1543, 1546, 1548, 1549, 1551, 1553, 1554, 1556, 1557, 1559, 1562, 1564, 1568, 1571, 1575, 1578, 1579, 1580, 1581, 1583, 1586, 1589, 1590, 1593, 1594, 1596, 1597, 1599, 1602, 1604, 1605, 1607, 1610, 1611, 1612, 1616, 1618, 1620, 1623, 1625, 1628, 1631, 1632, 1633, 1635, 1636, 1637, 1638, 1641, 1643, 1647, 1651, 1654, 1656, 1660, 1661, 1663, 1665, 1666, 1671, 1674, 1676, 1681, 1683, 1684, 1686, 1687, 1689, 1691, 1692, 1694, 1695, 1696, 1699, 1700, 1701, 1702, 1704, 1706, 1708, 1709, 1710, 1712, 1715, 1716, 1717, 1719, 1721, 1722, 1725, 1726, 1728, 1730, 1731, 1732, 1736, 1738, 1739, 1741, 1743, 1745, 1748, 1749, 1750, 1751, 1753, 1755, 1761, 1763, 1765, 1767, 1770, 1774, 1776, 1778, 1780, 1781, 1782, 1783, 1784, 1786, 1788, 1791, 1794, 1795, 1796, 1799, 1800, 1802, 1804, 1806, 1808, 1809, 1811, 1814, 1816, 1817, 1819, 1820, 1821, 1825, 1827, 1828, 1830, 1831, 1832, 1834, 1835, 1838, 1839, 1840, 1841, 1842, 1844, 1845, 1847, 1848, 1849, 1850, 1852, 1854, 1858, 1860, 1861, 1862, 1863, 1864, 1865, 1866, 1869, 1870, 1872, 1873, 1877, 1878, 1880, 1881, 1883, 1884, 1885, 1886, 1888, 1891, 1892, 1894, 1900, 1901, 1905, 1906, 1908, 1910, 1913, 1919, 1920, 1922, 1925, 1928, 1930, 1933, 1936, 1937, 1938, 1941, 1945, 1947, 1948, 1951, 1952, 1954, 1955, 1960, 1962, 1963, 1966, 1970, 1972, 1974, 1977, 1979, 1983, 1984, 1986, 1988, 1989, 1990, 1991, 1996, 1998, 2000], deadline = 2)
        configuration.add_task(name="Task3", identifier=3, period=8.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=5.977387, acet=5.977387, et_stddev=1.9924623333333333, deadline= 15)
        configuration.add_task(name="Task2", identifier=2, period=5.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=1.58697, acet=1.58697, et_stddev=0.52899, deadline= 6)
        configuration.add_task(name="Task1", identifier=1, period=3.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=1.606297, acet=1.606297, et_stddev=0.5354323333333334, deadline= 3)
        configuration.add_task(name="Task4", identifier=4, period=16.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.384498, et_stddev=0.128166 , list_activation_dates=[2, 46, 85, 101, 121, 165, 184, 219, 237, 262, 287, 336, 352, 394, 413, 439, 468, 488, 506, 525, 591, 624, 665, 691, 713, 751, 768, 809, 830, 859, 909, 990, 1019, 1044, 1061, 1080, 1133, 1189, 1207, 1250, 1280, 1311, 1335, 1360, 1377, 1397, 1429, 1467, 1493, 1542, 1567, 1611, 1630, 1652, 1668, 1704, 1731, 1751, 1796, 1833, 1884, 1901, 1921, 1938, 1986], deadline = 13)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "48")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "48")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "48")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "48")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task4", identifier=4, period=3.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.079842, et_stddev=0.026614 , list_activation_dates=[2, 5, 10, 15, 19, 23, 27, 33, 44, 51, 54, 58, 61, 72, 77, 83, 88, 93, 97, 101, 105, 115, 122, 125, 140, 145, 152, 156, 163, 172, 175, 181, 184, 188, 191, 198, 206, 210, 214, 221, 225, 230, 246, 249, 253, 260, 264, 267, 274, 278, 286, 297, 301, 305, 314, 319, 323, 329, 334, 342, 350, 356, 360, 365, 371, 377, 381, 384, 393, 397, 400, 414, 421, 426, 429, 435, 439, 444, 447, 450, 453, 457, 463, 467, 470, 475, 480, 485, 489, 496, 500, 508, 538, 543, 547, 554, 558, 562, 571, 576, 584, 588, 592, 600, 607, 616, 625, 629, 634, 639, 644, 649, 653, 669, 675, 682, 688, 699, 703, 707, 716, 719, 723, 727, 731, 737, 744, 747, 751, 755, 767, 772, 776, 779, 784, 793, 796, 804, 808, 822, 829, 834, 845, 849, 852, 856, 866, 875, 879, 889, 892, 898, 902, 909, 914, 919, 936, 946, 954, 960, 967, 970, 976, 981, 984, 987, 991, 997, 1001, 1005, 1009, 1016, 1019, 1024, 1032, 1052, 1057, 1061, 1068, 1071, 1074, 1080, 1086, 1089, 1093, 1100, 1106, 1110, 1113, 1119, 1127, 1136, 1143, 1152, 1158, 1162, 1171, 1177, 1186, 1191, 1194, 1197, 1207, 1217, 1223, 1228, 1240, 1244, 1248, 1256, 1261, 1264, 1269, 1272, 1284, 1288, 1297, 1304, 1310, 1314, 1318, 1322, 1325, 1329, 1333, 1343, 1350, 1355, 1386, 1392, 1402, 1406, 1410, 1413, 1418, 1425, 1430, 1436, 1445, 1450, 1454, 1458, 1461, 1469, 1475, 1478, 1481, 1488, 1492, 1501, 1505, 1509, 1514, 1521, 1527, 1536, 1544, 1548, 1552, 1560, 1565, 1576, 1580, 1587, 1591, 1597, 1600, 1606, 1615, 1623, 1633, 1637, 1643, 1647, 1650, 1653, 1658, 1665, 1677, 1680, 1683, 1686, 1695, 1699, 1703, 1706, 1713, 1721, 1732, 1740, 1745, 1755, 1758, 1761, 1764, 1772, 1776, 1780, 1784, 1789, 1793, 1798, 1803, 1807, 1811, 1815, 1821, 1830, 1836, 1841, 1848, 1854, 1859, 1863, 1876, 1882, 1890, 1893, 1897, 1902, 1914, 1919, 1925, 1931, 1934, 1941, 1946, 1950, 1955, 1962, 1966, 1987, 1995, 1999], deadline = 3)
        configuration.add_task(name="Task2", identifier=2, period=6.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=3.236118, acet=3.236118, et_stddev=1.078706, deadline= 6)
        configuration.add_task(name="Task1", identifier=1, period=21.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=11.672381, acet=11.672381, et_stddev=3.8907936666666667, deadline= 13)
        configuration.add_task(name="Task3", identifier=3, period=12.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=6.057829, acet=6.057829, et_stddev=2.0192763333333335, deadline= 24)
        configuration.add_task(name="Task5", identifier=5, period=7.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.390137, et_stddev=0.13004566666666667 , list_activation_dates=[2, 10, 22, 32, 48, 55, 74, 82, 99, 107, 119, 128, 140, 155, 170, 178, 187, 203, 214, 228, 241, 256, 263, 275, 287, 298, 306, 315, 329, 337, 345, 363, 374, 391, 415, 428, 446, 474, 483, 497, 513, 521, 540, 547, 570, 598, 609, 622, 639, 647, 657, 665, 672, 696, 703, 727, 750, 768, 776, 783, 811, 820, 836, 848, 868, 876, 888, 902, 911, 930, 963, 978, 987, 998, 1005, 1019, 1038, 1055, 1066, 1089, 1104, 1119, 1130, 1138, 1147, 1163, 1171, 1188, 1202, 1230, 1247, 1254, 1263, 1272, 1282, 1290, 1298, 1306, 1316, 1334, 1347, 1360, 1370, 1385, 1393, 1407, 1422, 1440, 1449, 1461, 1469, 1476, 1487, 1505, 1542, 1559, 1568, 1596, 1619, 1626, 1637, 1646, 1665, 1684, 1701, 1710, 1725, 1748, 1755, 1767, 1774, 1782, 1789, 1801, 1809, 1817, 1826, 1839, 1851, 1860, 1879, 1892, 1902, 1911, 1919, 1936, 1947, 1963, 1973, 1993], deadline = 4)
        configuration.add_task(name="Task6", identifier=6, period=10.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=2, acet=1.176517, et_stddev=0.39217233333333334 , list_activation_dates=[6, 18, 88, 99, 116, 130, 153, 170, 182, 198, 210, 233, 243, 265, 308, 346, 356, 367, 416, 430, 447, 460, 471, 489, 515, 528, 538, 550, 582, 611, 623, 635, 655, 677, 701, 719, 731, 741, 763, 781, 794, 805, 820, 851, 867, 909, 923, 943, 957, 971, 990, 1002, 1015, 1033, 1047, 1057, 1086, 1104, 1126, 1140, 1158, 1200, 1215, 1233, 1259, 1274, 1294, 1309, 1324, 1344, 1369, 1398, 1413, 1423, 1451, 1461, 1474, 1487, 1507, 1519, 1540, 1564, 1575, 1591, 1607, 1632, 1655, 1694, 1717, 1730, 1744, 1754, 1789, 1804, 1833, 1844, 1856, 1869, 1898, 1935, 1946, 1960, 1973], deadline = 18)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "49")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "49")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "49")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "49")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task2", identifier=2, period=8.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=5.688854, acet=5.688854, et_stddev=1.8962846666666666, deadline= 11)
        configuration.add_task(name="Task4", identifier=4, period=21.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=3, acet=2.17346, et_stddev=0.7244866666666666 , list_activation_dates=[23, 47, 71, 94, 143, 205, 238, 274, 297, 322, 346, 396, 426, 459, 494, 563, 618, 646, 671, 702, 777, 840, 874, 898, 922, 963, 989, 1029, 1118, 1172, 1197, 1226, 1280, 1308, 1351, 1382, 1410, 1442, 1474, 1517, 1599, 1636, 1711, 1745, 1770, 1794, 1818, 1968, 1996], deadline = 20)
        configuration.add_task(name="Task5", identifier=5, period=1.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.019576, et_stddev=0.0065253333333333335 , list_activation_dates=[2, 3, 5, 7, 10, 11, 13, 15, 16, 19, 20, 21, 23, 25, 28, 30, 33, 34, 38, 39, 41, 44, 46, 49, 53, 56, 58, 59, 61, 63, 65, 68, 69, 71, 72, 74, 77, 79, 80, 81, 83, 84, 87, 90, 92, 94, 98, 101, 102, 105, 106, 110, 111, 115, 116, 118, 120, 121, 125, 126, 130, 132, 133, 138, 145, 147, 149, 151, 152, 153, 154, 156, 158, 163, 166, 170, 171, 174, 176, 178, 184, 186, 187, 192, 193, 196, 201, 203, 205, 207, 208, 210, 212, 215, 220, 221, 223, 225, 229, 231, 235, 237, 242, 243, 249, 251, 252, 254, 255, 258, 259, 260, 261, 263, 264, 265, 267, 269, 270, 271, 272, 273, 275, 277, 279, 280, 282, 286, 290, 291, 293, 294, 295, 296, 298, 300, 302, 303, 304, 306, 309, 310, 312, 313, 314, 318, 320, 323, 324, 326, 328, 329, 330, 331, 333, 335, 336, 338, 339, 340, 341, 346, 347, 349, 352, 354, 355, 357, 359, 361, 362, 364, 365, 366, 368, 370, 372, 375, 376, 381, 382, 387, 388, 390, 391, 392, 393, 395, 399, 401, 403, 405, 406, 407, 408, 410, 411, 412, 416, 419, 422, 424, 425, 427, 429, 430, 432, 433, 434, 435, 437, 439, 441, 442, 444, 445, 446, 448, 451, 452, 453, 454, 456, 458, 460, 463, 465, 466, 467, 469, 470, 471, 472, 476, 477, 480, 481, 482, 484, 485, 488, 490, 492, 497, 498, 499, 501, 503, 505, 506, 509, 511, 512, 513, 514, 517, 518, 521, 522, 524, 525, 526, 528, 530, 533, 536, 539, 540, 542, 544, 545, 547, 548, 549, 550, 551, 552, 553, 554, 556, 557, 559, 560, 561, 563, 564, 566, 570, 571, 576, 578, 580, 583, 585, 586, 588, 590, 598, 599, 601, 603, 605, 607, 611, 612, 613, 614, 616, 619, 620, 622, 623, 625, 626, 628, 630, 631, 633, 635, 637, 638, 641, 642, 643, 647, 648, 651, 653, 654, 656, 659, 662, 664, 666, 667, 670, 671, 672, 674, 676, 677, 678, 680, 682, 686, 688, 689, 691, 692, 696, 699, 700, 702, 704, 705, 707, 709, 711, 713, 715, 717, 719, 722, 724, 725, 726, 728, 729, 731, 733, 741, 743, 748, 751, 753, 756, 757, 760, 763, 766, 767, 769, 770, 771, 772, 773, 775, 778, 779, 782, 784, 786, 787, 788, 789, 791, 793, 794, 798, 801, 803, 805, 810, 813, 814, 816, 819, 824, 825, 826, 828, 830, 832, 837, 838, 841, 843, 847, 848, 850, 852, 853, 855, 858, 860, 864, 868, 869, 870, 871, 873, 874, 875, 877, 878, 879, 881, 883, 886, 888, 890, 892, 893, 894, 896, 898, 899, 901, 903, 905, 907, 908, 910, 911, 914, 916, 917, 919, 921, 922, 923, 926, 928, 929, 931, 932, 934, 935, 938, 941, 943, 945, 946, 949, 950, 952, 953, 955, 956, 962, 969, 970, 971, 974, 975, 979, 981, 982, 984, 985, 987, 988, 990, 993, 994, 997, 998, 999, 1001, 1002, 1006, 1008, 1009, 1011, 1013, 1014, 1015, 1017, 1020, 1022, 1023, 1024, 1027, 1029, 1030, 1031, 1034, 1037, 1039, 1041, 1042, 1043, 1045, 1047, 1049, 1050, 1051, 1055, 1056, 1057, 1060, 1062, 1063, 1065, 1067, 1068, 1071, 1072, 1075, 1077, 1079, 1084, 1085, 1090, 1091, 1094, 1095, 1097, 1098, 1099, 1101, 1103, 1105, 1106, 1109, 1111, 1114, 1116, 1117, 1118, 1119, 1121, 1124, 1125, 1128, 1132, 1134, 1139, 1141, 1142, 1143, 1145, 1146, 1148, 1150, 1151, 1155, 1156, 1160, 1161, 1163, 1165, 1167, 1169, 1171, 1172, 1174, 1175, 1176, 1177, 1180, 1183, 1185, 1187, 1188, 1190, 1192, 1195, 1196, 1198, 1199, 1201, 1203, 1205, 1207, 1209, 1212, 1215, 1217, 1218, 1220, 1222, 1225, 1226, 1228, 1234, 1235, 1237, 1240, 1241, 1242, 1244, 1245, 1246, 1247, 1250, 1251, 1254, 1255, 1257, 1260, 1265, 1267, 1268, 1269, 1271, 1272, 1275, 1276, 1279, 1282, 1284, 1288, 1291, 1292, 1293, 1295, 1296, 1299, 1300, 1306, 1307, 1311, 1312, 1315, 1316, 1317, 1318, 1324, 1325, 1329, 1330, 1334, 1335, 1338, 1339, 1342, 1344, 1345, 1347, 1349, 1351, 1352, 1354, 1356, 1361, 1362, 1364, 1370, 1373, 1374, 1377, 1381, 1385, 1386, 1390, 1392, 1394, 1395, 1396, 1397, 1398, 1400, 1401, 1402, 1404, 1406, 1408, 1410, 1411, 1413, 1414, 1416, 1420, 1421, 1422, 1424, 1426, 1427, 1429, 1431, 1432, 1433, 1434, 1435, 1437, 1438, 1440, 1442, 1445, 1447, 1448, 1449, 1450, 1451, 1453, 1456, 1459, 1461, 1464, 1465, 1469, 1470, 1473, 1475, 1476, 1478, 1479, 1480, 1483, 1486, 1487, 1490, 1491, 1494, 1496, 1497, 1498, 1499, 1500, 1504, 1506, 1507, 1508, 1510, 1512, 1514, 1516, 1518, 1520, 1521, 1522, 1523, 1524, 1526, 1527, 1528, 1529, 1531, 1535, 1538, 1542, 1543, 1548, 1549, 1551, 1557, 1558, 1560, 1562, 1564, 1566, 1570, 1573, 1577, 1578, 1579, 1582, 1584, 1585, 1587, 1589, 1591, 1594, 1595, 1597, 1599, 1600, 1602, 1604, 1606, 1607, 1610, 1611, 1613, 1615, 1618, 1619, 1621, 1622, 1625, 1626, 1628, 1631, 1632, 1635, 1639, 1641, 1642, 1643, 1645, 1646, 1647, 1649, 1651, 1653, 1655, 1658, 1659, 1662, 1665, 1666, 1670, 1672, 1673, 1674, 1675, 1677, 1679, 1680, 1682, 1684, 1685, 1691, 1693, 1696, 1698, 1704, 1706, 1708, 1709, 1710, 1713, 1717, 1718, 1720, 1721, 1722, 1724, 1725, 1727, 1731, 1732, 1733, 1736, 1739, 1740, 1742, 1747, 1748, 1749, 1750, 1753, 1755, 1756, 1759, 1761, 1762, 1765, 1766, 1768, 1769, 1771, 1773, 1775, 1780, 1781, 1783, 1785, 1787, 1788, 1790, 1797, 1798, 1801, 1802, 1803, 1804, 1806, 1808, 1809, 1811, 1812, 1814, 1817, 1818, 1819, 1820, 1828, 1829, 1832, 1834, 1836, 1837, 1839, 1840, 1841, 1842, 1845, 1846, 1850, 1852, 1855, 1859, 1861, 1864, 1866, 1868, 1870, 1872, 1875, 1877, 1878, 1879, 1884, 1885, 1888, 1890, 1891, 1893, 1896, 1897, 1898, 1900, 1902, 1904, 1905, 1907, 1909, 1910, 1912, 1913, 1914, 1916, 1918, 1919, 1923, 1924, 1925, 1926, 1929, 1931, 1932, 1933, 1934, 1937, 1938, 1939, 1940, 1942, 1944, 1946, 1947, 1948, 1950, 1952, 1953, 1955, 1956, 1958, 1962, 1963, 1965, 1966, 1969, 1972, 1974, 1975, 1977, 1978, 1979, 1980, 1983, 1986, 1987, 1990, 1991, 1992, 1993, 1995, 1998, 1999], deadline = 1)
        configuration.add_task(name="Task6", identifier=6, period=2.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.15385, et_stddev=0.05128333333333333 , list_activation_dates=[1, 4, 8, 12, 16, 22, 24, 26, 28, 30, 32, 37, 39, 41, 50, 54, 57, 59, 67, 71, 74, 76, 80, 82, 84, 88, 91, 94, 97, 101, 104, 110, 117, 120, 127, 129, 134, 136, 141, 146, 150, 153, 163, 167, 170, 184, 189, 191, 197, 201, 205, 208, 211, 215, 220, 222, 228, 230, 234, 237, 252, 256, 263, 266, 273, 276, 278, 280, 284, 286, 293, 295, 298, 309, 313, 323, 331, 334, 338, 345, 348, 354, 357, 360, 362, 366, 368, 372, 375, 382, 387, 393, 400, 405, 410, 416, 418, 422, 424, 426, 430, 432, 434, 439, 443, 445, 448, 450, 452, 455, 457, 461, 465, 470, 476, 479, 481, 486, 491, 493, 499, 503, 506, 512, 515, 523, 526, 529, 535, 537, 540, 544, 548, 555, 561, 564, 570, 574, 578, 583, 586, 594, 597, 600, 605, 608, 611, 616, 620, 622, 627, 633, 636, 638, 641, 643, 648, 655, 662, 664, 668, 671, 678, 681, 683, 686, 691, 693, 696, 699, 701, 704, 706, 708, 711, 714, 717, 725, 730, 733, 737, 739, 742, 745, 753, 762, 766, 769, 772, 775, 783, 787, 790, 793, 800, 813, 815, 820, 823, 825, 829, 832, 834, 839, 841, 845, 847, 849, 855, 861, 865, 869, 871, 875, 878, 885, 894, 897, 899, 901, 905, 908, 910, 916, 919, 922, 928, 930, 932, 935, 939, 942, 947, 953, 960, 963, 967, 970, 976, 979, 981, 985, 987, 991, 994, 996, 1000, 1002, 1006, 1011, 1014, 1018, 1023, 1030, 1034, 1037, 1040, 1045, 1049, 1053, 1056, 1058, 1064, 1072, 1074, 1076, 1080, 1084, 1087, 1090, 1095, 1098, 1112, 1114, 1118, 1123, 1127, 1129, 1137, 1142, 1146, 1149, 1152, 1155, 1160, 1164, 1167, 1170, 1172, 1176, 1180, 1183, 1187, 1191, 1194, 1207, 1211, 1213, 1218, 1222, 1225, 1228, 1230, 1232, 1243, 1247, 1252, 1259, 1262, 1264, 1267, 1270, 1272, 1275, 1277, 1282, 1284, 1287, 1291, 1295, 1298, 1301, 1305, 1309, 1311, 1316, 1319, 1325, 1328, 1330, 1334, 1338, 1340, 1344, 1349, 1354, 1358, 1361, 1364, 1366, 1370, 1374, 1377, 1384, 1388, 1393, 1399, 1404, 1407, 1411, 1414, 1418, 1420, 1422, 1425, 1431, 1435, 1437, 1439, 1442, 1445, 1448, 1451, 1457, 1463, 1466, 1470, 1475, 1479, 1482, 1488, 1494, 1500, 1505, 1509, 1511, 1516, 1518, 1521, 1523, 1526, 1529, 1534, 1537, 1541, 1545, 1548, 1550, 1555, 1566, 1568, 1570, 1574, 1576, 1579, 1583, 1585, 1590, 1595, 1599, 1602, 1610, 1613, 1619, 1622, 1626, 1628, 1631, 1635, 1639, 1641, 1644, 1648, 1650, 1655, 1658, 1664, 1670, 1674, 1677, 1679, 1684, 1688, 1693, 1696, 1700, 1702, 1705, 1711, 1716, 1720, 1724, 1731, 1733, 1736, 1740, 1743, 1746, 1749, 1751, 1754, 1757, 1762, 1765, 1768, 1771, 1777, 1781, 1785, 1790, 1794, 1797, 1800, 1803, 1806, 1809, 1813, 1818, 1821, 1827, 1832, 1834, 1838, 1842, 1846, 1848, 1851, 1854, 1865, 1867, 1871, 1877, 1880, 1883, 1888, 1891, 1893, 1895, 1898, 1903, 1908, 1913, 1917, 1922, 1926, 1929, 1933, 1936, 1939, 1942, 1945, 1947, 1950, 1952, 1958, 1962, 1964, 1966, 1972, 1977, 1982, 1989, 1994, 1997], deadline = 3)
        configuration.add_task(name="Task1", identifier=1, period=32.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=28.099401, acet=28.099401, et_stddev=9.366467, deadline= 45)
        configuration.add_task(name="Task3", identifier=3, period=21.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=0.226523, acet=0.226523, et_stddev=0.07550766666666667, deadline= 25)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "50")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "50")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "50")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "50")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task4", identifier=4, period=14.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=3, acet=2.345408, et_stddev=0.7818026666666666 , list_activation_dates=[48, 71, 87, 101, 121, 154, 171, 192, 233, 259, 285, 323, 377, 409, 425, 468, 489, 519, 546, 573, 587, 609, 634, 656, 685, 719, 737, 761, 775, 789, 826, 868, 884, 913, 933, 989, 1006, 1023, 1040, 1067, 1093, 1110, 1130, 1153, 1181, 1212, 1232, 1246, 1263, 1291, 1307, 1340, 1371, 1395, 1426, 1453, 1497, 1512, 1553, 1584, 1610, 1635, 1651, 1687, 1709, 1759, 1795, 1846, 1865, 1886, 1903, 1926, 1943, 1981], deadline = 6)
        configuration.add_task(name="Task2", identifier=2, period=2.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=1.94496, acet=1.94496, et_stddev=0.64832, deadline= 3)
        configuration.add_task(name="Task1", identifier=1, period=1.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=0.148662, acet=0.148662, et_stddev=0.049553999999999994, deadline= 2)
        configuration.add_task(name="Task3", identifier=3, period=12.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=5.74628, acet=5.74628, et_stddev=1.9154266666666666, deadline= 23)
        configuration.add_task(name="Task6", identifier=6, period=9.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.255855, et_stddev=0.085285 , list_activation_dates=[5, 15, 48, 69, 83, 95, 106, 115, 149, 163, 198, 208, 221, 238, 250, 264, 288, 301, 315, 329, 339, 354, 368, 436, 451, 471, 481, 500, 517, 541, 562, 581, 631, 640, 655, 666, 722, 733, 745, 771, 781, 799, 828, 839, 869, 888, 906, 921, 940, 950, 964, 974, 992, 1009, 1019, 1042, 1059, 1070, 1087, 1096, 1139, 1161, 1176, 1191, 1200, 1212, 1223, 1237, 1253, 1264, 1274, 1286, 1298, 1313, 1352, 1366, 1379, 1393, 1405, 1444, 1470, 1494, 1505, 1517, 1529, 1553, 1568, 1583, 1607, 1616, 1631, 1652, 1665, 1674, 1693, 1702, 1734, 1746, 1797, 1822, 1844, 1864, 1877, 1891, 1954, 1964, 1994], deadline = 14)
        configuration.add_task(name="Task5", identifier=5, period=6.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.024254, et_stddev=0.008084666666666667 , list_activation_dates=[15, 23, 29, 40, 63, 69, 76, 83, 96, 104, 131, 142, 151, 157, 171, 182, 193, 199, 208, 219, 232, 239, 246, 252, 260, 289, 326, 333, 340, 346, 356, 368, 390, 397, 408, 414, 422, 435, 443, 451, 471, 477, 487, 494, 501, 518, 542, 554, 560, 567, 579, 592, 603, 612, 620, 627, 644, 651, 661, 701, 711, 720, 727, 741, 748, 755, 767, 774, 807, 813, 822, 839, 862, 869, 885, 891, 912, 923, 938, 953, 959, 967, 975, 986, 997, 1013, 1029, 1044, 1061, 1073, 1083, 1101, 1111, 1124, 1148, 1155, 1165, 1180, 1194, 1209, 1216, 1225, 1240, 1250, 1260, 1276, 1284, 1298, 1307, 1326, 1336, 1348, 1355, 1362, 1377, 1389, 1403, 1414, 1423, 1431, 1450, 1463, 1472, 1489, 1497, 1511, 1518, 1526, 1540, 1547, 1568, 1574, 1584, 1591, 1612, 1619, 1626, 1637, 1646, 1656, 1663, 1675, 1696, 1718, 1724, 1731, 1738, 1751, 1762, 1773, 1788, 1795, 1806, 1831, 1838, 1849, 1858, 1877, 1883, 1891, 1901, 1909, 1931, 1939, 1946, 1958, 1969, 1976, 1993, 1999], deadline = 4)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "51")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "51")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "51")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "51")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task3", identifier=3, period=14.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=8.804215, acet=8.804215, et_stddev=2.9347383333333332, deadline= 10)
        configuration.add_task(name="Task5", identifier=5, period=2.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.311062, et_stddev=0.10368733333333334 , list_activation_dates=[5, 9, 12, 17, 20, 31, 41, 43, 46, 48, 50, 52, 55, 58, 62, 64, 66, 71, 80, 84, 86, 90, 94, 97, 99, 103, 105, 108, 111, 113, 118, 120, 122, 126, 128, 132, 136, 139, 143, 146, 152, 154, 156, 159, 161, 163, 166, 169, 172, 177, 183, 192, 195, 197, 201, 206, 209, 216, 226, 232, 237, 247, 251, 256, 265, 271, 273, 276, 280, 283, 292, 295, 298, 306, 310, 312, 315, 318, 324, 328, 336, 341, 343, 346, 349, 351, 353, 356, 361, 366, 376, 378, 384, 386, 388, 396, 398, 401, 405, 409, 412, 415, 418, 429, 433, 436, 438, 440, 443, 447, 450, 458, 463, 468, 470, 475, 478, 484, 487, 490, 492, 495, 497, 500, 503, 507, 510, 515, 524, 526, 529, 534, 537, 541, 544, 546, 548, 555, 561, 564, 571, 573, 575, 578, 582, 585, 590, 593, 597, 599, 602, 606, 608, 611, 616, 620, 623, 626, 630, 633, 636, 639, 647, 650, 653, 657, 661, 665, 668, 671, 676, 679, 684, 687, 693, 696, 700, 702, 705, 708, 711, 714, 719, 721, 726, 729, 733, 735, 737, 739, 743, 745, 748, 758, 761, 765, 777, 780, 783, 786, 788, 791, 797, 801, 803, 818, 822, 826, 829, 831, 835, 839, 841, 843, 845, 850, 854, 856, 859, 863, 866, 869, 872, 874, 878, 881, 884, 887, 892, 896, 901, 905, 907, 910, 913, 918, 931, 933, 936, 940, 942, 944, 947, 952, 959, 964, 968, 970, 973, 975, 977, 983, 986, 990, 996, 998, 1002, 1010, 1012, 1014, 1018, 1023, 1026, 1029, 1033, 1035, 1038, 1041, 1044, 1047, 1054, 1057, 1067, 1072, 1075, 1078, 1085, 1093, 1095, 1099, 1103, 1106, 1109, 1114, 1117, 1120, 1125, 1127, 1131, 1135, 1138, 1140, 1142, 1145, 1149, 1151, 1157, 1162, 1165, 1168, 1170, 1173, 1175, 1178, 1180, 1184, 1188, 1194, 1196, 1201, 1205, 1211, 1215, 1221, 1228, 1232, 1235, 1238, 1241, 1243, 1245, 1247, 1250, 1255, 1258, 1261, 1263, 1266, 1268, 1272, 1280, 1282, 1287, 1289, 1293, 1295, 1298, 1300, 1302, 1305, 1308, 1311, 1315, 1318, 1322, 1326, 1329, 1333, 1339, 1341, 1347, 1351, 1355, 1358, 1360, 1363, 1365, 1369, 1372, 1377, 1380, 1384, 1387, 1389, 1392, 1396, 1403, 1409, 1412, 1416, 1419, 1421, 1424, 1426, 1431, 1434, 1437, 1439, 1441, 1445, 1447, 1450, 1455, 1460, 1463, 1468, 1470, 1476, 1480, 1483, 1491, 1495, 1500, 1503, 1505, 1508, 1511, 1514, 1521, 1527, 1534, 1539, 1541, 1545, 1550, 1552, 1554, 1560, 1565, 1571, 1573, 1579, 1581, 1588, 1593, 1595, 1600, 1603, 1607, 1610, 1616, 1618, 1626, 1631, 1634, 1637, 1640, 1644, 1648, 1653, 1656, 1658, 1660, 1663, 1668, 1671, 1677, 1679, 1681, 1684, 1689, 1692, 1699, 1702, 1705, 1707, 1712, 1715, 1720, 1722, 1728, 1734, 1736, 1741, 1747, 1754, 1759, 1761, 1765, 1767, 1770, 1773, 1777, 1781, 1785, 1788, 1790, 1793, 1798, 1802, 1809, 1822, 1827, 1833, 1835, 1839, 1847, 1849, 1852, 1854, 1857, 1859, 1864, 1867, 1874, 1882, 1886, 1888, 1890, 1895, 1900, 1908, 1912, 1914, 1916, 1923, 1926, 1928, 1930, 1938, 1941, 1944, 1948, 1951, 1958, 1964, 1966, 1970, 1972, 1975, 1978, 1981, 1989, 1991, 1999], deadline = 2)
        configuration.add_task(name="Task2", identifier=2, period=35.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=4.460044, acet=4.460044, et_stddev=1.4866813333333333, deadline= 64)
        configuration.add_task(name="Task6", identifier=6, period=4.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.141782, et_stddev=0.047260666666666666 , list_activation_dates=[4, 8, 14, 22, 27, 37, 52, 56, 62, 74, 84, 98, 102, 106, 118, 123, 128, 137, 142, 149, 155, 164, 175, 183, 192, 205, 211, 223, 233, 238, 243, 252, 257, 262, 271, 276, 293, 305, 316, 321, 325, 338, 353, 358, 362, 367, 372, 380, 385, 389, 393, 398, 403, 408, 418, 422, 428, 444, 454, 466, 470, 476, 483, 488, 493, 508, 514, 526, 541, 552, 557, 567, 576, 584, 594, 600, 610, 618, 626, 633, 637, 641, 646, 659, 663, 680, 692, 699, 704, 714, 718, 722, 742, 750, 755, 760, 766, 784, 788, 793, 799, 803, 811, 818, 862, 867, 877, 882, 892, 898, 902, 911, 917, 924, 934, 940, 944, 951, 957, 967, 974, 979, 990, 1010, 1015, 1020, 1025, 1029, 1036, 1040, 1052, 1059, 1063, 1072, 1086, 1098, 1107, 1114, 1121, 1126, 1133, 1138, 1143, 1152, 1157, 1163, 1168, 1172, 1179, 1185, 1192, 1199, 1211, 1222, 1237, 1245, 1251, 1255, 1260, 1267, 1272, 1276, 1295, 1299, 1305, 1313, 1317, 1323, 1332, 1342, 1349, 1361, 1375, 1380, 1386, 1398, 1404, 1411, 1419, 1430, 1436, 1450, 1455, 1463, 1469, 1474, 1482, 1487, 1497, 1506, 1512, 1525, 1543, 1554, 1560, 1565, 1571, 1582, 1587, 1596, 1610, 1618, 1622, 1627, 1636, 1650, 1658, 1667, 1672, 1679, 1688, 1697, 1705, 1709, 1724, 1735, 1743, 1750, 1757, 1766, 1785, 1789, 1805, 1812, 1819, 1824, 1828, 1837, 1842, 1848, 1853, 1859, 1867, 1873, 1877, 1885, 1889, 1896, 1900, 1907, 1912, 1925, 1931, 1944, 1950, 1955, 1960, 1970, 1977, 1983, 1989], deadline = 5)
        configuration.add_task(name="Task4", identifier=4, period=9.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.081208, et_stddev=0.027069333333333334 , list_activation_dates=[4, 15, 26, 42, 69, 81, 90, 107, 118, 128, 145, 161, 177, 194, 212, 222, 247, 258, 275, 310, 322, 333, 349, 377, 392, 408, 424, 436, 447, 484, 506, 527, 539, 550, 561, 575, 590, 616, 632, 647, 679, 691, 706, 717, 741, 751, 773, 783, 796, 806, 823, 864, 881, 892, 907, 918, 927, 940, 951, 973, 983, 995, 1029, 1053, 1072, 1118, 1131, 1152, 1170, 1188, 1209, 1229, 1242, 1255, 1266, 1289, 1339, 1351, 1371, 1389, 1400, 1413, 1424, 1440, 1460, 1470, 1483, 1531, 1546, 1558, 1571, 1586, 1600, 1616, 1627, 1646, 1657, 1670, 1680, 1694, 1709, 1739, 1763, 1778, 1800, 1810, 1819, 1836, 1872, 1883, 1894, 1908, 1918, 1928, 1942, 1952, 1972, 1981], deadline = 13)
        configuration.add_task(name="Task1", identifier=1, period=9.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=7.593278, acet=7.593278, et_stddev=2.5310926666666664, deadline= 11)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "52")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "52")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "52")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "52")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task3", identifier=3, period=5.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=2.489377, acet=2.489377, et_stddev=0.8297923333333334, deadline= 10)
        configuration.add_task(name="Task1", identifier=1, period=3.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=0.515865, acet=0.515865, et_stddev=0.171955, deadline= 5)
        configuration.add_task(name="Task4", identifier=4, period=5.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.220853, et_stddev=0.07361766666666666 , list_activation_dates=[1, 6, 12, 20, 26, 33, 44, 54, 61, 70, 77, 88, 103, 110, 116, 123, 129, 134, 154, 160, 174, 179, 184, 211, 217, 230, 237, 244, 250, 257, 276, 288, 296, 302, 313, 320, 329, 335, 343, 355, 377, 383, 394, 402, 412, 422, 430, 442, 447, 493, 506, 513, 522, 527, 538, 544, 553, 560, 566, 571, 583, 589, 605, 624, 635, 644, 655, 669, 681, 688, 693, 708, 716, 724, 731, 739, 745, 755, 765, 775, 790, 808, 815, 822, 831, 844, 861, 867, 877, 885, 899, 904, 916, 922, 929, 936, 942, 947, 954, 961, 967, 973, 980, 987, 997, 1002, 1011, 1017, 1023, 1028, 1035, 1045, 1055, 1065, 1091, 1107, 1113, 1121, 1131, 1139, 1145, 1152, 1162, 1168, 1177, 1215, 1222, 1235, 1241, 1269, 1278, 1300, 1308, 1320, 1333, 1344, 1350, 1355, 1366, 1384, 1395, 1413, 1423, 1435, 1448, 1460, 1470, 1479, 1484, 1490, 1497, 1520, 1530, 1536, 1543, 1554, 1571, 1576, 1585, 1609, 1619, 1626, 1652, 1661, 1686, 1696, 1713, 1731, 1746, 1751, 1759, 1776, 1786, 1792, 1798, 1803, 1809, 1840, 1848, 1854, 1865, 1874, 1899, 1907, 1919, 1946, 1953, 1959, 1968, 1976, 1995], deadline = 4)
        configuration.add_task(name="Task6", identifier=6, period=15.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.627471, et_stddev=0.209157 , list_activation_dates=[18, 62, 87, 112, 130, 160, 180, 212, 227, 263, 278, 306, 331, 347, 374, 410, 435, 462, 498, 526, 548, 563, 614, 640, 656, 700, 717, 740, 756, 778, 805, 824, 848, 880, 902, 922, 966, 1007, 1022, 1038, 1104, 1161, 1213, 1237, 1255, 1279, 1295, 1362, 1387, 1412, 1438, 1455, 1471, 1497, 1554, 1573, 1604, 1664, 1681, 1728, 1770, 1842, 1864, 1881, 1897, 1923, 1938, 1960], deadline = 22)
        configuration.add_task(name="Task5", identifier=5, period=16.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=2, acet=1.823967, et_stddev=0.607989 , list_activation_dates=[14, 44, 78, 101, 120, 165, 191, 207, 228, 246, 263, 300, 331, 375, 400, 463, 486, 502, 554, 573, 591, 614, 672, 719, 736, 785, 804, 826, 851, 882, 934, 960, 978, 998, 1016, 1034, 1059, 1095, 1112, 1139, 1177, 1216, 1257, 1295, 1313, 1339, 1379, 1395, 1445, 1507, 1539, 1571, 1601, 1643, 1675, 1738, 1760, 1781, 1805, 1849, 1867, 1883, 1911, 1938, 1966, 1993], deadline = 7)
        configuration.add_task(name="Task2", identifier=2, period=1.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=0.930169, acet=0.930169, et_stddev=0.3100563333333333, deadline= 1)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "53")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "53")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "53")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "53")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task4", identifier=4, period=49.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=7, acet=6.185339, et_stddev=2.061779666666667 , list_activation_dates=[20, 93, 164, 233, 322, 455, 530, 586, 644, 741, 837, 1040, 1234, 1313, 1433, 1516, 1640, 1728], deadline = 47)
        configuration.add_task(name="Task2", identifier=2, period=6.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=3.031873, acet=3.031873, et_stddev=1.0106243333333333, deadline= 9)
        configuration.add_task(name="Task6", identifier=6, period=2.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.11086, et_stddev=0.03695333333333333 , list_activation_dates=[2, 4, 8, 10, 15, 18, 21, 27, 30, 35, 42, 46, 51, 53, 56, 65, 68, 74, 78, 84, 87, 94, 100, 105, 108, 113, 116, 121, 127, 135, 145, 153, 156, 159, 162, 165, 167, 169, 172, 176, 179, 182, 185, 187, 189, 191, 195, 198, 202, 204, 208, 210, 212, 217, 222, 226, 231, 234, 241, 251, 257, 259, 262, 265, 268, 271, 278, 280, 282, 289, 292, 295, 301, 307, 310, 317, 320, 323, 327, 336, 339, 342, 346, 355, 360, 363, 365, 368, 372, 379, 385, 391, 393, 396, 403, 406, 410, 412, 415, 418, 425, 430, 432, 436, 443, 449, 453, 457, 462, 466, 469, 471, 477, 481, 483, 487, 490, 493, 499, 502, 505, 507, 510, 514, 518, 520, 523, 526, 532, 534, 538, 542, 545, 549, 552, 554, 559, 566, 568, 577, 579, 582, 587, 591, 595, 598, 603, 607, 610, 618, 625, 629, 632, 634, 644, 647, 650, 655, 660, 665, 667, 670, 673, 678, 683, 686, 688, 692, 695, 701, 705, 708, 710, 714, 719, 722, 726, 729, 732, 734, 737, 740, 743, 745, 748, 750, 753, 757, 760, 763, 766, 775, 780, 783, 786, 794, 798, 802, 804, 812, 816, 820, 822, 828, 834, 838, 842, 844, 848, 852, 859, 868, 871, 875, 879, 882, 885, 887, 891, 897, 899, 905, 907, 912, 914, 917, 925, 927, 930, 932, 939, 942, 946, 949, 953, 958, 961, 963, 966, 970, 972, 975, 985, 990, 993, 1000, 1002, 1007, 1012, 1014, 1020, 1022, 1026, 1032, 1035, 1038, 1043, 1045, 1049, 1052, 1057, 1059, 1061, 1065, 1067, 1071, 1082, 1085, 1094, 1098, 1104, 1107, 1112, 1115, 1118, 1121, 1124, 1127, 1133, 1136, 1140, 1143, 1146, 1149, 1153, 1156, 1160, 1164, 1168, 1173, 1177, 1181, 1187, 1194, 1198, 1206, 1210, 1215, 1218, 1221, 1224, 1230, 1235, 1246, 1248, 1250, 1254, 1256, 1259, 1264, 1268, 1270, 1274, 1276, 1278, 1284, 1288, 1291, 1293, 1295, 1301, 1305, 1309, 1312, 1316, 1318, 1322, 1325, 1327, 1332, 1335, 1338, 1341, 1343, 1345, 1348, 1351, 1354, 1358, 1360, 1363, 1367, 1369, 1372, 1376, 1378, 1394, 1398, 1401, 1406, 1410, 1413, 1418, 1424, 1427, 1431, 1433, 1438, 1441, 1443, 1447, 1451, 1454, 1459, 1462, 1464, 1470, 1474, 1480, 1485, 1488, 1492, 1496, 1498, 1500, 1503, 1507, 1512, 1515, 1517, 1522, 1525, 1527, 1530, 1535, 1539, 1546, 1550, 1555, 1559, 1567, 1570, 1574, 1582, 1584, 1589, 1591, 1593, 1601, 1603, 1607, 1610, 1614, 1620, 1623, 1627, 1629, 1633, 1637, 1639, 1641, 1645, 1652, 1657, 1662, 1664, 1668, 1672, 1675, 1679, 1681, 1685, 1688, 1691, 1693, 1700, 1702, 1704, 1714, 1716, 1720, 1725, 1727, 1734, 1739, 1743, 1749, 1751, 1760, 1765, 1767, 1769, 1774, 1778, 1784, 1787, 1794, 1800, 1804, 1811, 1817, 1821, 1825, 1831, 1837, 1849, 1853, 1862, 1865, 1868, 1877, 1881, 1885, 1888, 1893, 1896, 1899, 1903, 1906, 1909, 1912, 1919, 1924, 1930, 1933, 1938, 1943, 1949, 1953, 1955, 1959, 1963, 1966, 1969, 1972, 1978, 1983, 1988, 1993, 1996], deadline = 1)
        configuration.add_task(name="Task3", identifier=3, period=1.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=0.545898, acet=0.545898, et_stddev=0.181966, deadline= 1)
        configuration.add_task(name="Task1", identifier=1, period=5.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=2.743946, acet=2.743946, et_stddev=0.9146486666666668, deadline= 5)
        configuration.add_task(name="Task5", identifier=5, period=11.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.201719, et_stddev=0.06723966666666667 , list_activation_dates=[12, 50, 65, 114, 130, 142, 169, 218, 242, 270, 284, 298, 356, 443, 471, 491, 523, 538, 556, 582, 629, 641, 655, 679, 699, 715, 754, 766, 783, 804, 820, 832, 844, 859, 870, 883, 903, 923, 944, 975, 995, 1017, 1033, 1063, 1093, 1121, 1133, 1153, 1166, 1199, 1220, 1237, 1286, 1304, 1330, 1354, 1367, 1379, 1397, 1409, 1423, 1437, 1482, 1495, 1513, 1548, 1560, 1577, 1594, 1614, 1634, 1652, 1678, 1743, 1761, 1777, 1804, 1837, 1849, 1864, 1877, 1906, 1924, 1943, 1958, 1989], deadline = 2)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "54")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "54")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "54")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "54")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task6", identifier=6, period=2.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.265293, et_stddev=0.088431 , list_activation_dates=[3, 8, 11, 13, 16, 19, 21, 26, 29, 31, 33, 36, 39, 41, 45, 49, 55, 57, 61, 64, 66, 71, 73, 78, 81, 83, 88, 91, 94, 96, 102, 115, 118, 121, 125, 128, 134, 137, 139, 141, 147, 150, 153, 156, 158, 161, 175, 182, 186, 190, 193, 198, 202, 209, 214, 218, 230, 233, 235, 239, 241, 245, 247, 251, 257, 261, 265, 268, 271, 273, 279, 283, 286, 290, 292, 294, 300, 303, 308, 313, 316, 318, 322, 326, 329, 331, 336, 338, 340, 344, 346, 350, 355, 360, 364, 369, 372, 374, 379, 384, 393, 398, 405, 413, 417, 424, 426, 429, 431, 434, 437, 440, 445, 449, 452, 458, 461, 466, 469, 471, 476, 482, 485, 489, 491, 493, 500, 502, 506, 512, 515, 517, 521, 528, 531, 535, 538, 541, 546, 550, 553, 559, 567, 570, 572, 575, 578, 581, 584, 586, 591, 593, 597, 602, 606, 608, 611, 619, 623, 630, 633, 644, 647, 656, 662, 664, 667, 672, 680, 685, 687, 690, 699, 702, 705, 712, 716, 718, 721, 723, 729, 737, 744, 747, 749, 751, 755, 757, 763, 769, 774, 782, 789, 794, 797, 801, 804, 806, 808, 812, 817, 819, 825, 832, 834, 836, 840, 843, 845, 847, 851, 858, 861, 863, 871, 875, 879, 884, 887, 893, 897, 901, 904, 908, 913, 915, 918, 923, 927, 930, 934, 937, 940, 942, 944, 947, 950, 954, 957, 963, 965, 969, 972, 976, 981, 986, 989, 991, 994, 998, 1001, 1005, 1008, 1010, 1015, 1018, 1021, 1026, 1034, 1036, 1042, 1049, 1054, 1057, 1060, 1063, 1067, 1069, 1076, 1084, 1086, 1088, 1090, 1093, 1099, 1107, 1111, 1116, 1119, 1121, 1125, 1128, 1131, 1134, 1138, 1142, 1145, 1147, 1151, 1155, 1157, 1160, 1163, 1165, 1169, 1172, 1176, 1180, 1182, 1188, 1191, 1195, 1199, 1204, 1209, 1213, 1215, 1218, 1226, 1228, 1233, 1235, 1238, 1241, 1245, 1248, 1253, 1255, 1259, 1261, 1266, 1273, 1275, 1277, 1282, 1285, 1287, 1291, 1297, 1300, 1302, 1306, 1310, 1312, 1318, 1324, 1333, 1337, 1342, 1348, 1352, 1355, 1360, 1363, 1366, 1369, 1373, 1376, 1381, 1386, 1390, 1392, 1395, 1401, 1408, 1418, 1424, 1430, 1436, 1438, 1441, 1443, 1446, 1449, 1453, 1459, 1461, 1463, 1467, 1471, 1474, 1478, 1483, 1491, 1493, 1495, 1498, 1500, 1502, 1505, 1509, 1511, 1515, 1517, 1524, 1529, 1531, 1535, 1540, 1543, 1548, 1550, 1554, 1557, 1560, 1566, 1569, 1572, 1579, 1581, 1587, 1593, 1595, 1598, 1600, 1602, 1606, 1610, 1614, 1616, 1621, 1624, 1628, 1632, 1639, 1642, 1645, 1654, 1661, 1664, 1667, 1680, 1685, 1690, 1694, 1696, 1699, 1702, 1704, 1709, 1711, 1715, 1717, 1719, 1723, 1726, 1731, 1734, 1737, 1743, 1745, 1748, 1752, 1759, 1763, 1768, 1771, 1773, 1776, 1779, 1791, 1793, 1795, 1798, 1802, 1807, 1809, 1811, 1814, 1818, 1826, 1828, 1830, 1835, 1839, 1842, 1846, 1848, 1855, 1858, 1861, 1864, 1866, 1871, 1873, 1880, 1882, 1888, 1892, 1895, 1897, 1906, 1909, 1914, 1920, 1922, 1925, 1928, 1932, 1935, 1938, 1944, 1948, 1951, 1957, 1962, 1965, 1968, 1971, 1973, 1975, 1978, 1981, 1986, 1989, 1994, 1998], deadline = 3)
        configuration.add_task(name="Task3", identifier=3, period=3.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=0.434414, acet=0.434414, et_stddev=0.14480466666666666, deadline= 1)
        configuration.add_task(name="Task2", identifier=2, period=1.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=0.880099, acet=0.880099, et_stddev=0.29336633333333334, deadline= 1)
        configuration.add_task(name="Task4", identifier=4, period=7.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.079772, et_stddev=0.026590666666666665 , list_activation_dates=[11, 24, 42, 52, 74, 88, 131, 140, 153, 179, 188, 196, 206, 219, 227, 239, 248, 272, 281, 293, 304, 320, 333, 351, 359, 378, 397, 404, 417, 425, 446, 453, 478, 496, 512, 527, 547, 557, 568, 578, 586, 600, 614, 621, 631, 645, 661, 671, 678, 693, 712, 757, 776, 785, 802, 823, 832, 847, 854, 862, 872, 885, 911, 924, 947, 955, 965, 979, 999, 1009, 1019, 1035, 1044, 1059, 1071, 1079, 1107, 1116, 1124, 1134, 1157, 1176, 1185, 1220, 1232, 1249, 1256, 1268, 1275, 1307, 1327, 1334, 1358, 1374, 1405, 1417, 1427, 1440, 1474, 1488, 1560, 1575, 1603, 1611, 1628, 1637, 1655, 1668, 1686, 1693, 1702, 1711, 1727, 1739, 1752, 1764, 1777, 1798, 1808, 1820, 1829, 1838, 1855, 1863, 1873, 1883, 1899, 1917, 1924, 1940, 1948, 1975, 1989], deadline = 9)
        configuration.add_task(name="Task1", identifier=1, period=13.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=7.476239, acet=7.476239, et_stddev=2.4920796666666667, deadline= 9)
        configuration.add_task(name="Task5", identifier=5, period=6.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.335742, et_stddev=0.111914 , list_activation_dates=[6, 21, 30, 42, 54, 63, 72, 83, 89, 99, 106, 115, 136, 147, 154, 160, 173, 180, 191, 200, 212, 221, 228, 237, 255, 264, 270, 297, 307, 314, 322, 336, 344, 351, 358, 366, 375, 392, 410, 419, 428, 447, 455, 467, 493, 505, 519, 532, 550, 560, 569, 586, 597, 610, 621, 636, 645, 676, 685, 694, 715, 725, 736, 742, 753, 770, 777, 783, 793, 799, 805, 816, 826, 835, 842, 869, 887, 894, 921, 935, 958, 966, 977, 983, 997, 1010, 1026, 1041, 1047, 1070, 1100, 1120, 1146, 1157, 1170, 1187, 1202, 1212, 1229, 1239, 1247, 1261, 1279, 1287, 1305, 1315, 1334, 1341, 1348, 1371, 1382, 1391, 1399, 1409, 1427, 1434, 1454, 1461, 1473, 1481, 1494, 1514, 1530, 1544, 1554, 1561, 1577, 1584, 1590, 1596, 1616, 1626, 1641, 1659, 1675, 1689, 1697, 1708, 1727, 1739, 1747, 1755, 1763, 1775, 1784, 1791, 1802, 1820, 1827, 1837, 1843, 1849, 1857, 1875, 1890, 1903, 1909, 1923, 1936, 1948, 1972, 1980, 1987, 1998], deadline = 8)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "55")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "55")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "55")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "55")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task1", identifier=1, period=30.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=10.144655, acet=10.144655, et_stddev=3.3815516666666667, deadline= 46)
        configuration.add_task(name="Task5", identifier=5, period=12.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.68516, et_stddev=0.22838666666666665 , list_activation_dates=[8, 25, 58, 113, 129, 172, 192, 208, 222, 241, 284, 328, 386, 399, 419, 440, 452, 479, 513, 527, 552, 580, 592, 610, 631, 669, 683, 701, 717, 730, 744, 763, 778, 790, 812, 838, 864, 905, 919, 947, 964, 979, 1041, 1054, 1068, 1080, 1093, 1132, 1144, 1170, 1239, 1253, 1305, 1317, 1334, 1350, 1363, 1390, 1413, 1428, 1461, 1477, 1507, 1531, 1545, 1558, 1603, 1619, 1632, 1653, 1696, 1710, 1732, 1745, 1762, 1791, 1821, 1834, 1855, 1868, 1883, 1897, 1919, 1957, 1971], deadline = 24)
        configuration.add_task(name="Task6", identifier=6, period=2.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.115911, et_stddev=0.038637 , list_activation_dates=[2, 10, 13, 16, 20, 23, 26, 28, 31, 37, 40, 42, 46, 50, 52, 57, 61, 65, 68, 70, 72, 78, 81, 89, 93, 96, 102, 106, 109, 114, 117, 120, 122, 130, 133, 137, 141, 147, 151, 154, 157, 159, 166, 169, 172, 175, 178, 183, 186, 190, 192, 195, 198, 201, 205, 209, 212, 215, 222, 225, 228, 235, 239, 241, 245, 247, 254, 257, 261, 264, 269, 272, 279, 283, 286, 288, 291, 294, 297, 302, 308, 313, 317, 324, 327, 330, 333, 338, 341, 343, 345, 349, 357, 362, 364, 370, 373, 376, 380, 383, 385, 387, 390, 397, 400, 403, 407, 412, 417, 420, 422, 425, 429, 431, 435, 438, 442, 448, 454, 458, 463, 465, 468, 472, 475, 478, 484, 490, 494, 499, 503, 510, 516, 522, 527, 530, 533, 539, 544, 547, 550, 555, 557, 562, 566, 569, 573, 576, 581, 584, 587, 593, 596, 606, 610, 612, 614, 618, 622, 626, 629, 631, 636, 638, 640, 648, 653, 655, 657, 664, 666, 671, 674, 679, 682, 684, 687, 690, 692, 697, 701, 704, 707, 709, 712, 714, 716, 723, 726, 728, 731, 734, 737, 739, 742, 748, 750, 753, 756, 761, 765, 769, 774, 780, 784, 788, 794, 800, 804, 806, 808, 811, 813, 818, 822, 825, 831, 833, 836, 839, 848, 853, 862, 867, 873, 877, 879, 882, 885, 894, 896, 903, 907, 910, 915, 924, 927, 929, 933, 936, 940, 942, 944, 947, 950, 955, 960, 966, 971, 976, 979, 982, 985, 989, 991, 993, 996, 1000, 1003, 1005, 1011, 1014, 1016, 1023, 1028, 1032, 1035, 1037, 1039, 1042, 1044, 1047, 1050, 1052, 1055, 1058, 1061, 1064, 1067, 1069, 1074, 1076, 1085, 1089, 1092, 1096, 1101, 1106, 1116, 1119, 1124, 1130, 1133, 1138, 1142, 1144, 1148, 1151, 1158, 1173, 1175, 1178, 1180, 1182, 1186, 1188, 1194, 1199, 1201, 1204, 1207, 1210, 1214, 1225, 1228, 1231, 1235, 1238, 1241, 1244, 1247, 1251, 1255, 1258, 1261, 1267, 1277, 1279, 1284, 1286, 1297, 1303, 1307, 1310, 1313, 1316, 1321, 1325, 1332, 1335, 1338, 1341, 1346, 1356, 1361, 1363, 1366, 1369, 1379, 1383, 1386, 1392, 1396, 1402, 1404, 1407, 1412, 1415, 1417, 1425, 1427, 1429, 1433, 1435, 1437, 1441, 1444, 1448, 1452, 1454, 1458, 1461, 1464, 1466, 1473, 1476, 1479, 1482, 1485, 1488, 1492, 1500, 1504, 1508, 1510, 1512, 1514, 1521, 1529, 1532, 1535, 1537, 1540, 1545, 1549, 1555, 1563, 1565, 1572, 1578, 1580, 1584, 1590, 1592, 1595, 1598, 1602, 1609, 1613, 1615, 1618, 1622, 1629, 1631, 1634, 1637, 1639, 1644, 1646, 1653, 1658, 1663, 1668, 1671, 1673, 1678, 1684, 1688, 1693, 1696, 1702, 1706, 1710, 1716, 1719, 1723, 1726, 1728, 1731, 1736, 1739, 1749, 1752, 1755, 1758, 1767, 1770, 1774, 1778, 1782, 1786, 1790, 1798, 1803, 1806, 1808, 1812, 1814, 1816, 1821, 1824, 1828, 1831, 1835, 1843, 1849, 1853, 1858, 1863, 1868, 1871, 1875, 1878, 1885, 1891, 1893, 1895, 1897, 1899, 1901, 1911, 1914, 1918, 1921, 1925, 1928, 1931, 1935, 1941, 1945, 1947, 1950, 1954, 1957, 1960, 1962, 1965, 1968, 1970, 1976, 1983, 1986, 1988, 1992, 1996, 1999], deadline = 4)
        configuration.add_task(name="Task2", identifier=2, period=25.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=11.687007, acet=11.687007, et_stddev=3.895669, deadline= 29)
        configuration.add_task(name="Task4", identifier=4, period=11.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.934423, et_stddev=0.31147433333333335 , list_activation_dates=[12, 29, 48, 68, 81, 97, 114, 133, 145, 169, 185, 203, 221, 235, 250, 262, 280, 331, 346, 370, 392, 403, 416, 431, 451, 463, 476, 488, 503, 545, 560, 578, 597, 656, 680, 707, 723, 736, 751, 772, 786, 802, 843, 861, 877, 891, 924, 961, 974, 987, 1002, 1018, 1067, 1082, 1102, 1129, 1142, 1154, 1170, 1184, 1198, 1218, 1240, 1256, 1271, 1293, 1326, 1351, 1393, 1407, 1441, 1479, 1505, 1524, 1537, 1549, 1601, 1612, 1624, 1646, 1678, 1700, 1723, 1740, 1791, 1828, 1845, 1861, 1872, 1883, 1916, 1934, 1948, 1962, 1994], deadline = 6)
        configuration.add_task(name="Task3", identifier=3, period=40.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=31.77458, acet=31.77458, et_stddev=10.591526666666667, deadline= 55)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "56")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "56")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "56")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "56")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task5", identifier=5, period=47.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=4, acet=3.359921, et_stddev=1.1199736666666666 , list_activation_dates=[25, 86, 134, 183, 264, 338, 405, 468, 541, 647, 714, 835, 883, 1008, 1123, 1304, 1456, 1584, 1738, 1875, 1934, 1984], deadline = 55)
        configuration.add_task(name="Task3", identifier=3, period=31.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=12.792742, acet=12.792742, et_stddev=4.2642473333333335, deadline= 45)
        configuration.add_task(name="Task2", identifier=2, period=5.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=4.745608, acet=4.745608, et_stddev=1.5818693333333333, deadline= 8)
        configuration.add_task(name="Task1", identifier=1, period=2.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=0.476418, acet=0.476418, et_stddev=0.158806, deadline= 3)
        configuration.add_task(name="Task6", identifier=6, period=39.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=3, acet=2.354195, et_stddev=0.7847316666666666 , list_activation_dates=[34, 107, 147, 195, 268, 334, 399, 499, 573, 631, 685, 880, 940, 1001, 1055, 1096, 1145, 1259, 1311, 1353, 1468, 1511, 1570, 1652, 1701, 1772, 1896], deadline = 7)
        configuration.add_task(name="Task4", identifier=4, period=2.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.136296, et_stddev=0.045432 , list_activation_dates=[4, 8, 20, 24, 27, 30, 32, 36, 48, 51, 54, 60, 64, 67, 71, 74, 76, 79, 87, 90, 95, 99, 105, 107, 109, 114, 118, 121, 124, 126, 129, 131, 135, 138, 142, 145, 147, 149, 152, 157, 160, 165, 177, 181, 184, 186, 189, 198, 201, 204, 207, 210, 213, 219, 224, 227, 229, 234, 237, 240, 243, 245, 248, 254, 258, 262, 265, 268, 270, 272, 274, 277, 279, 284, 288, 290, 294, 296, 300, 303, 305, 311, 313, 325, 331, 336, 339, 344, 347, 350, 355, 360, 363, 366, 369, 372, 375, 381, 383, 388, 390, 399, 403, 406, 409, 422, 430, 434, 436, 438, 440, 443, 446, 451, 453, 458, 461, 464, 467, 470, 472, 479, 483, 487, 489, 492, 498, 506, 508, 518, 520, 523, 526, 530, 532, 537, 539, 545, 547, 550, 554, 557, 561, 563, 565, 568, 571, 575, 577, 580, 583, 585, 589, 593, 597, 599, 601, 604, 608, 610, 613, 616, 619, 627, 631, 635, 639, 643, 649, 652, 655, 659, 661, 664, 668, 672, 676, 679, 688, 691, 693, 701, 707, 712, 716, 718, 725, 728, 730, 732, 735, 738, 741, 744, 748, 751, 762, 767, 770, 775, 777, 786, 789, 792, 803, 809, 819, 822, 825, 827, 831, 833, 840, 842, 850, 853, 857, 860, 874, 879, 881, 886, 892, 895, 901, 903, 905, 908, 910, 912, 915, 921, 925, 932, 936, 940, 948, 951, 957, 960, 964, 968, 973, 975, 977, 983, 987, 997, 999, 1002, 1006, 1009, 1011, 1016, 1021, 1025, 1029, 1035, 1038, 1041, 1045, 1047, 1054, 1061, 1067, 1073, 1075, 1077, 1080, 1083, 1086, 1092, 1098, 1100, 1102, 1106, 1108, 1112, 1116, 1123, 1126, 1129, 1135, 1140, 1145, 1150, 1153, 1156, 1167, 1169, 1171, 1174, 1176, 1187, 1191, 1196, 1199, 1203, 1205, 1210, 1214, 1216, 1221, 1223, 1226, 1228, 1231, 1233, 1235, 1237, 1239, 1243, 1246, 1250, 1260, 1263, 1267, 1269, 1278, 1280, 1282, 1285, 1288, 1293, 1295, 1297, 1300, 1303, 1305, 1308, 1314, 1317, 1320, 1323, 1326, 1330, 1334, 1337, 1340, 1349, 1355, 1361, 1363, 1365, 1368, 1371, 1374, 1376, 1382, 1387, 1390, 1394, 1400, 1409, 1411, 1414, 1416, 1419, 1423, 1425, 1428, 1431, 1438, 1440, 1446, 1459, 1463, 1469, 1473, 1477, 1479, 1487, 1490, 1492, 1494, 1500, 1504, 1511, 1514, 1518, 1521, 1523, 1525, 1529, 1531, 1539, 1542, 1545, 1547, 1550, 1554, 1559, 1561, 1569, 1572, 1576, 1579, 1582, 1587, 1589, 1591, 1594, 1597, 1601, 1608, 1610, 1613, 1617, 1620, 1623, 1625, 1630, 1634, 1641, 1644, 1650, 1652, 1654, 1662, 1665, 1667, 1671, 1675, 1681, 1685, 1687, 1689, 1694, 1698, 1700, 1707, 1710, 1714, 1719, 1721, 1728, 1735, 1739, 1743, 1746, 1749, 1752, 1756, 1759, 1762, 1766, 1776, 1781, 1785, 1790, 1793, 1796, 1800, 1809, 1813, 1816, 1819, 1822, 1824, 1829, 1832, 1844, 1852, 1855, 1857, 1860, 1864, 1867, 1873, 1876, 1879, 1881, 1884, 1888, 1890, 1893, 1896, 1899, 1903, 1905, 1908, 1910, 1912, 1917, 1926, 1928, 1931, 1935, 1939, 1947, 1950, 1954, 1970, 1980, 1984, 1992, 1994, 1997], deadline = 3)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "57")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "57")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "57")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "57")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task1", identifier=1, period=4.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=1.232332, acet=1.232332, et_stddev=0.4107773333333333, deadline= 8)
        configuration.add_task(name="Task2", identifier=2, period=1.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=0.521528, acet=0.521528, et_stddev=0.17384266666666667, deadline= 2)
        configuration.add_task(name="Task5", identifier=5, period=44.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=3, acet=2.540314, et_stddev=0.8467713333333333 , list_activation_dates=[23, 135, 254, 312, 365, 411, 466, 541, 609, 677, 777, 825, 876, 932, 984, 1030, 1075, 1132, 1209, 1319, 1436, 1493, 1554, 1651, 1720, 1774, 1902, 1957], deadline = 36)
        configuration.add_task(name="Task6", identifier=6, period=49.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.800578, et_stddev=0.26685933333333334 , list_activation_dates=[54, 135, 274, 394, 468, 536, 585, 635, 729, 814, 867, 993, 1080, 1134, 1197, 1247, 1313, 1382, 1475, 1541, 1644, 1728, 1831, 1972], deadline = 1)
        configuration.add_task(name="Task4", identifier=4, period=5.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.629636, et_stddev=0.20987866666666666 , list_activation_dates=[17, 23, 34, 43, 72, 93, 99, 105, 115, 121, 126, 132, 140, 148, 167, 175, 180, 189, 195, 206, 218, 224, 235, 242, 255, 263, 269, 278, 283, 296, 305, 310, 321, 326, 335, 348, 369, 382, 399, 411, 422, 431, 439, 446, 453, 472, 495, 500, 510, 520, 538, 550, 566, 574, 588, 593, 601, 608, 616, 630, 645, 667, 673, 680, 686, 706, 714, 720, 734, 740, 746, 759, 768, 791, 800, 805, 819, 831, 837, 847, 871, 905, 911, 928, 935, 944, 954, 960, 979, 984, 991, 1000, 1008, 1023, 1034, 1041, 1046, 1055, 1065, 1076, 1092, 1100, 1117, 1124, 1130, 1139, 1148, 1169, 1177, 1195, 1212, 1218, 1224, 1238, 1244, 1251, 1262, 1281, 1287, 1295, 1301, 1311, 1318, 1327, 1347, 1354, 1368, 1374, 1385, 1395, 1404, 1417, 1425, 1431, 1440, 1448, 1457, 1465, 1480, 1492, 1506, 1514, 1520, 1531, 1542, 1548, 1555, 1561, 1568, 1573, 1578, 1585, 1595, 1616, 1624, 1635, 1646, 1654, 1663, 1670, 1680, 1686, 1697, 1709, 1716, 1723, 1732, 1746, 1762, 1769, 1781, 1787, 1797, 1820, 1832, 1842, 1854, 1863, 1882, 1893, 1904, 1910, 1919, 1925, 1939, 1957, 1968, 1973, 1981, 1992], deadline = 7)
        configuration.add_task(name="Task3", identifier=3, period=3.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=2.311165, acet=2.311165, et_stddev=0.7703883333333333, deadline= 6)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "58")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "58")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "58")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "58")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task3", identifier=3, period=41.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=18.478485, acet=18.478485, et_stddev=6.159495, deadline= 49)
        configuration.add_task(name="Task5", identifier=5, period=2.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.201042, et_stddev=0.067014 , list_activation_dates=[3, 6, 15, 17, 20, 25, 28, 31, 36, 41, 43, 45, 48, 52, 54, 57, 60, 63, 68, 77, 81, 88, 90, 95, 97, 102, 106, 113, 116, 120, 127, 129, 132, 136, 144, 147, 153, 155, 157, 160, 163, 166, 170, 174, 179, 182, 185, 193, 195, 199, 202, 205, 213, 219, 224, 235, 240, 243, 245, 249, 256, 258, 262, 264, 267, 270, 273, 276, 280, 282, 285, 295, 298, 301, 306, 309, 311, 315, 322, 325, 327, 329, 334, 336, 340, 342, 346, 353, 361, 363, 366, 368, 370, 374, 376, 381, 383, 389, 393, 396, 400, 403, 409, 412, 415, 424, 426, 430, 435, 438, 443, 446, 455, 460, 462, 465, 467, 475, 481, 483, 485, 488, 492, 495, 499, 503, 508, 510, 512, 521, 523, 525, 527, 530, 533, 538, 543, 546, 555, 558, 564, 567, 571, 578, 581, 585, 588, 591, 594, 597, 600, 604, 607, 614, 622, 629, 639, 642, 644, 648, 650, 653, 659, 667, 670, 676, 679, 684, 687, 690, 693, 696, 700, 702, 706, 710, 716, 719, 721, 724, 727, 730, 734, 740, 744, 749, 751, 755, 759, 762, 768, 772, 775, 779, 782, 784, 786, 792, 795, 798, 800, 804, 813, 816, 819, 821, 825, 828, 831, 833, 835, 837, 840, 843, 845, 847, 850, 855, 859, 865, 867, 874, 879, 882, 886, 889, 895, 898, 901, 903, 907, 910, 913, 916, 918, 921, 927, 930, 934, 937, 939, 941, 944, 947, 949, 956, 958, 960, 963, 968, 975, 978, 982, 988, 993, 996, 999, 1001, 1004, 1010, 1012, 1018, 1021, 1024, 1027, 1029, 1031, 1034, 1037, 1043, 1049, 1051, 1053, 1057, 1060, 1062, 1066, 1073, 1077, 1082, 1086, 1089, 1092, 1096, 1101, 1104, 1107, 1110, 1113, 1117, 1125, 1128, 1132, 1135, 1139, 1143, 1145, 1149, 1152, 1155, 1158, 1164, 1167, 1170, 1175, 1182, 1186, 1189, 1192, 1195, 1197, 1203, 1207, 1211, 1216, 1220, 1223, 1226, 1232, 1236, 1241, 1244, 1246, 1249, 1253, 1257, 1260, 1266, 1268, 1271, 1275, 1279, 1282, 1285, 1288, 1291, 1294, 1297, 1300, 1303, 1305, 1310, 1312, 1315, 1323, 1328, 1334, 1336, 1339, 1346, 1350, 1353, 1357, 1360, 1368, 1371, 1375, 1380, 1383, 1386, 1388, 1396, 1399, 1402, 1405, 1409, 1411, 1421, 1425, 1429, 1436, 1439, 1442, 1445, 1454, 1457, 1459, 1462, 1464, 1468, 1471, 1480, 1484, 1488, 1496, 1499, 1506, 1508, 1521, 1526, 1532, 1534, 1536, 1540, 1543, 1545, 1551, 1554, 1556, 1558, 1562, 1568, 1578, 1580, 1582, 1588, 1590, 1597, 1599, 1603, 1606, 1611, 1614, 1617, 1620, 1623, 1626, 1629, 1633, 1637, 1639, 1642, 1647, 1649, 1652, 1655, 1660, 1664, 1666, 1668, 1673, 1675, 1679, 1681, 1684, 1690, 1694, 1702, 1704, 1709, 1713, 1718, 1721, 1724, 1727, 1730, 1736, 1738, 1740, 1744, 1747, 1754, 1757, 1761, 1763, 1767, 1781, 1783, 1786, 1790, 1792, 1797, 1799, 1803, 1808, 1812, 1816, 1819, 1824, 1831, 1835, 1837, 1840, 1845, 1848, 1853, 1856, 1859, 1862, 1864, 1870, 1873, 1876, 1886, 1894, 1899, 1902, 1904, 1907, 1912, 1916, 1921, 1927, 1934, 1937, 1944, 1947, 1950, 1953, 1960, 1964, 1967, 1972, 1976, 1980, 1988, 1991, 1994, 1997], deadline = 3)
        configuration.add_task(name="Task1", identifier=1, period=3.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=1.066941, acet=1.066941, et_stddev=0.355647, deadline= 3)
        configuration.add_task(name="Task2", identifier=2, period=1.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=0.793658, acet=0.793658, et_stddev=0.26455266666666666, deadline= 1)
        configuration.add_task(name="Task4", identifier=4, period=5.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.268671, et_stddev=0.089557 , list_activation_dates=[14, 21, 27, 45, 55, 61, 69, 87, 99, 104, 109, 116, 135, 145, 154, 162, 187, 198, 206, 215, 222, 230, 242, 253, 259, 264, 270, 277, 292, 312, 321, 332, 361, 368, 374, 379, 389, 396, 405, 414, 421, 431, 438, 444, 474, 485, 494, 502, 510, 522, 530, 538, 546, 565, 571, 588, 595, 603, 610, 633, 640, 648, 656, 665, 685, 705, 716, 722, 730, 740, 746, 753, 759, 775, 784, 797, 807, 821, 838, 843, 849, 855, 863, 869, 877, 883, 893, 902, 908, 921, 938, 948, 958, 973, 986, 991, 997, 1005, 1016, 1024, 1030, 1041, 1057, 1070, 1079, 1089, 1098, 1128, 1135, 1141, 1149, 1155, 1160, 1177, 1185, 1195, 1201, 1211, 1224, 1235, 1247, 1254, 1267, 1274, 1282, 1295, 1303, 1309, 1317, 1330, 1338, 1363, 1371, 1380, 1387, 1397, 1417, 1424, 1436, 1465, 1472, 1484, 1493, 1502, 1534, 1546, 1554, 1561, 1567, 1579, 1588, 1593, 1599, 1609, 1618, 1626, 1631, 1638, 1648, 1654, 1663, 1671, 1682, 1697, 1703, 1717, 1730, 1741, 1776, 1783, 1788, 1794, 1806, 1819, 1825, 1831, 1848, 1854, 1871, 1877, 1887, 1893, 1899, 1905, 1914, 1927, 1937, 1942, 1954, 1965, 1971, 1989, 1996], deadline = 9)
        configuration.add_task(name="Task6", identifier=6, period=17.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.777657, et_stddev=0.25921900000000003 , list_activation_dates=[10, 30, 69, 142, 162, 207, 224, 254, 317, 337, 366, 440, 462, 495, 516, 547, 591, 623, 644, 687, 723, 753, 788, 813, 835, 867, 913, 933, 958, 981, 1021, 1056, 1119, 1156, 1176, 1233, 1266, 1315, 1335, 1352, 1401, 1468, 1492, 1527, 1552, 1575, 1607, 1636, 1675, 1699, 1727, 1753, 1771, 1791, 1811, 1835, 1856, 1885, 1907], deadline = 23)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "59")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "59")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "59")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "59")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task1", identifier=1, period=12.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=10.001859, acet=10.001859, et_stddev=3.3339529999999997, deadline= 24)
        configuration.add_task(name="Task2", identifier=2, period=8.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=5.240953, acet=5.240953, et_stddev=1.7469843333333335, deadline= 13)
        configuration.add_task(name="Task4", identifier=4, period=1.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.071412, et_stddev=0.023804000000000002 , list_activation_dates=[1, 3, 5, 6, 7, 9, 10, 12, 15, 17, 21, 23, 24, 26, 28, 30, 31, 34, 35, 36, 38, 39, 40, 41, 43, 44, 45, 47, 48, 50, 53, 56, 59, 60, 62, 65, 68, 71, 73, 74, 75, 78, 79, 81, 83, 84, 85, 87, 89, 91, 93, 95, 96, 98, 99, 101, 102, 104, 107, 109, 110, 112, 114, 116, 118, 120, 122, 124, 126, 129, 130, 134, 136, 137, 138, 139, 140, 141, 143, 145, 146, 148, 149, 151, 152, 153, 154, 157, 159, 161, 162, 163, 164, 166, 168, 170, 172, 174, 175, 176, 178, 179, 181, 182, 185, 187, 189, 191, 193, 195, 197, 198, 201, 203, 205, 207, 209, 210, 214, 216, 217, 218, 221, 222, 224, 225, 227, 228, 230, 232, 233, 234, 235, 237, 238, 240, 242, 245, 246, 250, 251, 256, 257, 259, 263, 265, 266, 267, 269, 270, 271, 273, 277, 280, 281, 282, 284, 286, 287, 288, 289, 290, 292, 297, 299, 300, 302, 303, 305, 306, 312, 314, 318, 319, 320, 322, 324, 326, 328, 330, 332, 334, 337, 339, 341, 343, 345, 346, 348, 350, 351, 354, 357, 359, 361, 362, 365, 366, 369, 371, 373, 374, 375, 377, 379, 380, 382, 384, 387, 389, 390, 391, 392, 394, 395, 397, 399, 404, 405, 406, 409, 410, 411, 415, 420, 421, 422, 424, 426, 428, 431, 432, 433, 435, 436, 439, 441, 442, 443, 445, 446, 447, 449, 451, 452, 453, 454, 456, 462, 463, 468, 470, 471, 472, 473, 474, 476, 480, 481, 482, 483, 485, 488, 489, 490, 492, 494, 496, 498, 500, 501, 503, 505, 510, 511, 514, 516, 517, 521, 523, 527, 531, 532, 534, 544, 545, 549, 551, 554, 557, 559, 560, 561, 562, 563, 565, 566, 567, 569, 570, 572, 573, 575, 577, 582, 583, 584, 586, 588, 592, 595, 596, 598, 599, 601, 603, 605, 607, 608, 609, 610, 612, 613, 615, 618, 620, 621, 622, 625, 626, 627, 630, 633, 635, 637, 640, 643, 646, 648, 650, 651, 653, 655, 656, 657, 659, 661, 663, 664, 666, 669, 670, 672, 674, 677, 678, 680, 681, 683, 684, 685, 689, 690, 691, 692, 693, 696, 697, 699, 700, 703, 705, 707, 711, 712, 713, 715, 716, 719, 720, 721, 722, 724, 726, 728, 731, 733, 735, 736, 738, 740, 743, 744, 748, 751, 752, 754, 755, 759, 761, 762, 763, 764, 766, 767, 768, 771, 772, 774, 775, 777, 779, 782, 785, 787, 793, 795, 796, 798, 801, 805, 806, 807, 808, 810, 811, 813, 815, 817, 819, 820, 821, 822, 824, 828, 829, 831, 833, 835, 836, 837, 839, 842, 844, 845, 846, 849, 852, 853, 855, 858, 859, 862, 864, 866, 868, 869, 871, 873, 874, 876, 880, 881, 883, 884, 887, 889, 891, 892, 893, 895, 896, 897, 899, 900, 902, 903, 904, 907, 908, 909, 910, 913, 914, 916, 919, 920, 922, 923, 925, 926, 927, 929, 931, 932, 933, 934, 935, 936, 938, 939, 940, 942, 948, 949, 951, 952, 955, 956, 958, 959, 960, 961, 964, 966, 969, 971, 972, 974, 976, 979, 981, 982, 984, 988, 989, 990, 992, 994, 996, 999, 1001, 1002, 1006, 1009, 1015, 1018, 1020, 1025, 1027, 1029, 1031, 1035, 1036, 1038, 1039, 1040, 1042, 1043, 1045, 1047, 1049, 1050, 1052, 1054, 1057, 1059, 1060, 1061, 1064, 1066, 1068, 1070, 1073, 1074, 1075, 1076, 1077, 1079, 1081, 1083, 1085, 1086, 1088, 1091, 1092, 1094, 1096, 1098, 1102, 1105, 1106, 1107, 1109, 1110, 1112, 1113, 1117, 1119, 1121, 1124, 1125, 1128, 1129, 1130, 1132, 1133, 1136, 1137, 1138, 1139, 1142, 1143, 1144, 1147, 1149, 1153, 1155, 1156, 1158, 1160, 1161, 1162, 1163, 1165, 1168, 1170, 1172, 1173, 1174, 1177, 1180, 1181, 1183, 1184, 1186, 1188, 1189, 1190, 1192, 1194, 1196, 1197, 1198, 1200, 1204, 1205, 1208, 1209, 1211, 1213, 1215, 1216, 1217, 1219, 1220, 1222, 1224, 1226, 1228, 1230, 1231, 1234, 1235, 1238, 1239, 1242, 1244, 1246, 1251, 1254, 1258, 1261, 1263, 1264, 1266, 1268, 1269, 1271, 1272, 1274, 1277, 1279, 1282, 1284, 1285, 1286, 1288, 1290, 1291, 1293, 1294, 1296, 1300, 1301, 1302, 1306, 1311, 1313, 1317, 1318, 1323, 1326, 1327, 1329, 1330, 1331, 1332, 1335, 1336, 1338, 1340, 1341, 1344, 1346, 1348, 1351, 1352, 1354, 1357, 1358, 1360, 1361, 1364, 1365, 1368, 1371, 1376, 1377, 1378, 1379, 1383, 1384, 1386, 1387, 1389, 1390, 1393, 1394, 1395, 1397, 1398, 1399, 1401, 1405, 1410, 1412, 1413, 1416, 1418, 1420, 1422, 1424, 1425, 1426, 1427, 1430, 1431, 1433, 1435, 1436, 1439, 1442, 1444, 1446, 1448, 1450, 1451, 1452, 1453, 1454, 1456, 1457, 1460, 1462, 1466, 1467, 1468, 1475, 1476, 1477, 1479, 1481, 1483, 1484, 1486, 1487, 1491, 1492, 1493, 1494, 1496, 1500, 1501, 1502, 1503, 1506, 1508, 1514, 1517, 1518, 1520, 1522, 1524, 1526, 1527, 1529, 1532, 1535, 1536, 1540, 1545, 1548, 1550, 1551, 1553, 1555, 1556, 1559, 1560, 1561, 1562, 1564, 1565, 1567, 1568, 1571, 1573, 1574, 1575, 1576, 1577, 1582, 1583, 1585, 1587, 1588, 1589, 1594, 1599, 1600, 1601, 1603, 1604, 1605, 1607, 1609, 1611, 1615, 1617, 1619, 1623, 1624, 1625, 1626, 1627, 1629, 1632, 1636, 1637, 1640, 1642, 1643, 1646, 1647, 1649, 1651, 1655, 1656, 1658, 1660, 1665, 1666, 1667, 1668, 1675, 1676, 1679, 1681, 1682, 1684, 1686, 1688, 1690, 1692, 1695, 1696, 1698, 1699, 1701, 1702, 1703, 1704, 1705, 1706, 1708, 1710, 1712, 1714, 1717, 1718, 1719, 1720, 1722, 1724, 1726, 1731, 1732, 1733, 1734, 1735, 1738, 1742, 1744, 1745, 1746, 1747, 1750, 1752, 1754, 1756, 1757, 1758, 1761, 1763, 1765, 1766, 1767, 1769, 1771, 1772, 1775, 1776, 1777, 1782, 1785, 1786, 1787, 1790, 1791, 1794, 1795, 1796, 1797, 1798, 1799, 1803, 1807, 1810, 1812, 1813, 1815, 1816, 1819, 1821, 1824, 1827, 1830, 1837, 1838, 1839, 1840, 1842, 1845, 1847, 1849, 1853, 1857, 1859, 1860, 1863, 1865, 1867, 1868, 1870, 1871, 1872, 1875, 1876, 1879, 1881, 1883, 1884, 1885, 1886, 1887, 1888, 1889, 1893, 1895, 1897, 1901, 1904, 1906, 1909, 1910, 1912, 1913, 1915, 1916, 1917, 1919, 1920, 1921, 1923, 1925, 1926, 1927, 1929, 1930, 1931, 1933, 1934, 1935, 1937, 1941, 1944, 1945, 1946, 1947, 1952, 1954, 1955, 1957, 1959, 1960, 1964, 1970, 1973, 1975, 1977, 1978, 1980, 1981, 1982, 1983, 1985, 1987, 1988, 1990, 1993, 1994, 1996, 1998], deadline = 1)
        configuration.add_task(name="Task6", identifier=6, period=3.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.325614, et_stddev=0.10853800000000001 , list_activation_dates=[3, 11, 15, 23, 30, 33, 38, 49, 70, 74, 83, 94, 104, 108, 111, 117, 121, 125, 128, 131, 141, 145, 157, 165, 170, 179, 185, 188, 192, 196, 200, 204, 209, 213, 218, 231, 237, 240, 244, 253, 262, 267, 277, 282, 287, 302, 306, 309, 315, 323, 334, 338, 342, 347, 354, 359, 363, 380, 386, 390, 399, 405, 413, 417, 427, 432, 435, 440, 458, 462, 467, 474, 481, 489, 495, 502, 509, 513, 519, 523, 529, 535, 547, 551, 561, 565, 576, 581, 588, 598, 603, 606, 610, 613, 618, 622, 629, 634, 638, 645, 648, 652, 661, 665, 671, 674, 679, 687, 696, 699, 710, 714, 719, 724, 728, 736, 740, 745, 753, 761, 766, 771, 781, 787, 792, 800, 809, 822, 830, 834, 837, 846, 856, 860, 872, 877, 881, 892, 901, 905, 911, 917, 925, 929, 935, 944, 953, 958, 964, 969, 972, 979, 983, 986, 990, 994, 999, 1002, 1010, 1022, 1027, 1038, 1042, 1045, 1048, 1056, 1065, 1070, 1076, 1081, 1089, 1093, 1097, 1101, 1108, 1116, 1120, 1126, 1129, 1140, 1144, 1147, 1157, 1163, 1174, 1184, 1189, 1192, 1196, 1204, 1210, 1214, 1220, 1224, 1231, 1242, 1250, 1254, 1258, 1261, 1268, 1275, 1285, 1290, 1293, 1302, 1307, 1315, 1322, 1329, 1333, 1338, 1350, 1356, 1361, 1364, 1374, 1384, 1387, 1390, 1395, 1400, 1405, 1409, 1414, 1417, 1421, 1424, 1429, 1432, 1435, 1440, 1444, 1455, 1464, 1467, 1481, 1491, 1494, 1499, 1507, 1512, 1516, 1522, 1526, 1531, 1535, 1541, 1547, 1551, 1556, 1560, 1570, 1576, 1581, 1591, 1594, 1605, 1609, 1620, 1627, 1632, 1636, 1640, 1648, 1651, 1656, 1661, 1670, 1673, 1682, 1689, 1698, 1704, 1708, 1713, 1719, 1732, 1735, 1740, 1747, 1750, 1755, 1759, 1762, 1772, 1778, 1784, 1789, 1793, 1799, 1803, 1807, 1810, 1814, 1817, 1826, 1829, 1837, 1844, 1847, 1854, 1859, 1865, 1875, 1878, 1885, 1889, 1892, 1897, 1901, 1912, 1917, 1921, 1924, 1928, 1932, 1940, 1949, 1958, 1965, 1975, 1978], deadline = 2)
        configuration.add_task(name="Task3", identifier=3, period=1.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=0.111392, acet=0.111392, et_stddev=0.037130666666666666, deadline= 2)
        configuration.add_task(name="Task5", identifier=5, period=1.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.020049, et_stddev=0.006683000000000001 , list_activation_dates=[1, 2, 4, 6, 8, 10, 11, 13, 16, 19, 20, 22, 23, 25, 27, 28, 32, 36, 38, 40, 44, 46, 47, 48, 49, 51, 52, 54, 55, 56, 57, 58, 59, 61, 62, 64, 65, 66, 67, 69, 71, 73, 75, 78, 81, 83, 90, 91, 94, 95, 97, 98, 99, 101, 103, 104, 106, 107, 109, 111, 115, 116, 118, 120, 121, 123, 125, 127, 131, 134, 135, 137, 139, 140, 141, 143, 145, 146, 148, 151, 152, 155, 158, 163, 164, 166, 168, 169, 171, 175, 178, 180, 181, 184, 185, 187, 190, 191, 192, 194, 195, 197, 200, 201, 203, 204, 206, 208, 209, 210, 212, 214, 216, 218, 219, 220, 222, 225, 227, 228, 231, 233, 235, 237, 238, 239, 241, 244, 245, 247, 248, 250, 251, 254, 257, 258, 259, 261, 264, 266, 268, 269, 273, 275, 277, 278, 279, 280, 281, 283, 285, 286, 288, 290, 291, 294, 295, 296, 299, 301, 302, 303, 305, 307, 309, 310, 312, 316, 317, 319, 321, 322, 324, 326, 327, 330, 331, 332, 336, 338, 340, 341, 345, 346, 348, 351, 352, 353, 355, 357, 359, 360, 362, 364, 367, 370, 372, 376, 378, 379, 382, 385, 387, 390, 391, 392, 394, 395, 396, 397, 399, 401, 402, 404, 405, 406, 409, 410, 412, 413, 415, 417, 420, 422, 424, 426, 427, 429, 433, 434, 436, 438, 442, 444, 446, 447, 448, 450, 452, 453, 455, 457, 459, 461, 463, 465, 467, 469, 471, 474, 476, 477, 478, 480, 483, 484, 488, 489, 492, 494, 496, 499, 503, 504, 506, 509, 511, 512, 514, 515, 516, 518, 520, 522, 523, 525, 527, 529, 531, 533, 535, 536, 537, 540, 543, 544, 546, 548, 549, 550, 552, 554, 556, 558, 559, 560, 562, 566, 568, 569, 571, 572, 575, 577, 581, 583, 584, 586, 589, 590, 594, 595, 597, 598, 600, 601, 603, 606, 607, 609, 610, 611, 614, 616, 618, 620, 623, 625, 626, 627, 630, 631, 632, 633, 635, 636, 637, 640, 642, 644, 647, 649, 650, 651, 654, 656, 658, 660, 661, 663, 668, 673, 674, 676, 678, 680, 682, 683, 684, 689, 691, 694, 695, 698, 699, 700, 702, 704, 705, 706, 707, 708, 710, 712, 713, 715, 717, 718, 719, 725, 726, 728, 730, 733, 734, 736, 738, 739, 740, 741, 742, 744, 746, 748, 749, 750, 752, 753, 755, 757, 758, 760, 762, 764, 766, 767, 768, 769, 772, 773, 774, 777, 778, 779, 781, 784, 786, 787, 788, 791, 792, 794, 796, 799, 801, 803, 804, 805, 807, 809, 811, 813, 815, 817, 820, 822, 823, 825, 828, 830, 832, 833, 834, 836, 839, 840, 841, 844, 845, 847, 848, 849, 850, 852, 853, 855, 856, 857, 859, 861, 864, 868, 869, 871, 873, 877, 878, 879, 880, 881, 882, 888, 889, 893, 895, 897, 899, 900, 903, 904, 906, 907, 909, 913, 915, 916, 918, 919, 924, 926, 927, 929, 931, 932, 933, 935, 936, 938, 940, 942, 943, 945, 947, 948, 949, 952, 954, 955, 956, 957, 960, 963, 965, 966, 967, 968, 969, 970, 971, 974, 976, 977, 978, 980, 984, 986, 987, 989, 991, 993, 994, 995, 998, 999, 1000, 1001, 1003, 1004, 1009, 1010, 1013, 1014, 1016, 1017, 1018, 1019, 1020, 1022, 1023, 1026, 1027, 1028, 1029, 1030, 1031, 1034, 1036, 1039, 1041, 1043, 1044, 1045, 1047, 1048, 1052, 1053, 1056, 1058, 1059, 1061, 1062, 1065, 1067, 1068, 1070, 1072, 1074, 1075, 1076, 1077, 1079, 1081, 1083, 1084, 1087, 1089, 1090, 1092, 1093, 1094, 1095, 1100, 1102, 1104, 1105, 1106, 1109, 1111, 1113, 1114, 1116, 1119, 1121, 1122, 1124, 1127, 1128, 1131, 1134, 1135, 1136, 1138, 1141, 1142, 1144, 1145, 1147, 1148, 1149, 1152, 1158, 1160, 1162, 1163, 1164, 1166, 1167, 1174, 1175, 1176, 1177, 1179, 1181, 1182, 1184, 1187, 1192, 1194, 1197, 1199, 1200, 1201, 1202, 1203, 1205, 1208, 1209, 1211, 1213, 1218, 1219, 1220, 1221, 1222, 1223, 1224, 1225, 1227, 1228, 1229, 1230, 1232, 1236, 1237, 1239, 1240, 1242, 1243, 1245, 1246, 1247, 1248, 1249, 1252, 1254, 1256, 1257, 1259, 1260, 1262, 1263, 1269, 1271, 1272, 1274, 1276, 1277, 1279, 1280, 1283, 1285, 1286, 1290, 1291, 1293, 1294, 1295, 1298, 1300, 1304, 1305, 1308, 1310, 1311, 1314, 1317, 1319, 1323, 1326, 1329, 1332, 1333, 1334, 1338, 1340, 1342, 1344, 1345, 1347, 1349, 1352, 1353, 1355, 1356, 1357, 1359, 1360, 1361, 1363, 1365, 1367, 1371, 1374, 1375, 1377, 1378, 1380, 1382, 1384, 1386, 1387, 1389, 1391, 1393, 1394, 1396, 1399, 1401, 1403, 1405, 1407, 1408, 1409, 1412, 1413, 1416, 1417, 1418, 1421, 1426, 1430, 1431, 1432, 1433, 1436, 1438, 1440, 1443, 1444, 1446, 1447, 1448, 1451, 1454, 1455, 1456, 1458, 1459, 1460, 1463, 1465, 1466, 1472, 1474, 1476, 1478, 1480, 1481, 1483, 1485, 1488, 1491, 1493, 1494, 1495, 1498, 1499, 1500, 1502, 1504, 1505, 1506, 1508, 1509, 1510, 1517, 1519, 1521, 1522, 1524, 1525, 1526, 1528, 1530, 1532, 1535, 1537, 1540, 1541, 1543, 1545, 1547, 1550, 1551, 1552, 1554, 1557, 1561, 1563, 1564, 1565, 1568, 1570, 1571, 1572, 1574, 1575, 1576, 1580, 1582, 1584, 1585, 1588, 1589, 1592, 1593, 1596, 1597, 1599, 1601, 1602, 1603, 1604, 1605, 1606, 1608, 1609, 1611, 1612, 1613, 1615, 1618, 1621, 1622, 1624, 1625, 1626, 1628, 1632, 1633, 1635, 1639, 1641, 1644, 1646, 1649, 1651, 1654, 1656, 1658, 1659, 1661, 1662, 1664, 1666, 1667, 1670, 1673, 1674, 1676, 1678, 1681, 1685, 1686, 1688, 1691, 1692, 1694, 1696, 1697, 1698, 1702, 1704, 1705, 1707, 1709, 1711, 1712, 1714, 1716, 1717, 1719, 1723, 1725, 1727, 1728, 1732, 1734, 1735, 1736, 1737, 1739, 1740, 1742, 1747, 1748, 1749, 1752, 1754, 1755, 1756, 1760, 1762, 1764, 1765, 1767, 1770, 1777, 1779, 1782, 1783, 1785, 1789, 1791, 1794, 1796, 1798, 1800, 1801, 1804, 1805, 1806, 1807, 1808, 1812, 1814, 1815, 1818, 1819, 1820, 1823, 1824, 1826, 1830, 1831, 1835, 1837, 1839, 1841, 1843, 1844, 1845, 1848, 1850, 1852, 1853, 1857, 1860, 1863, 1865, 1867, 1868, 1869, 1870, 1872, 1876, 1877, 1880, 1881, 1885, 1886, 1888, 1890, 1891, 1892, 1894, 1896, 1898, 1899, 1900, 1903, 1905, 1908, 1912, 1914, 1916, 1918, 1920, 1922, 1923, 1925, 1926, 1928, 1929, 1931, 1938, 1940, 1942, 1943, 1945, 1947, 1950, 1952, 1953, 1954, 1955, 1959, 1960, 1962, 1964, 1966, 1967, 1970, 1973, 1975, 1977, 1979, 1982, 1984, 1986, 1988, 1994, 1996, 1998, 2000], deadline = 1)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "60")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "60")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "60")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "60")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task3", identifier=3, period=10.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=0.476186, acet=0.476186, et_stddev=0.15872866666666666, deadline= 11)
        configuration.add_task(name="Task1", identifier=1, period=2.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=1.780012, acet=1.780012, et_stddev=0.5933373333333333, deadline= 4)
        configuration.add_task(name="Task4", identifier=4, period=2.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.285874, et_stddev=0.09529133333333334 , list_activation_dates=[3, 5, 9, 17, 19, 21, 25, 31, 35, 39, 42, 44, 47, 50, 57, 59, 62, 75, 79, 82, 84, 86, 89, 92, 96, 99, 101, 106, 108, 112, 114, 120, 122, 124, 128, 132, 135, 140, 145, 148, 152, 159, 161, 165, 170, 173, 176, 180, 183, 187, 189, 195, 199, 202, 212, 226, 229, 231, 234, 237, 241, 243, 247, 253, 257, 260, 263, 267, 269, 273, 278, 281, 283, 286, 289, 292, 296, 298, 301, 303, 307, 309, 314, 317, 319, 328, 333, 337, 340, 344, 350, 353, 358, 360, 363, 367, 370, 372, 380, 384, 389, 392, 396, 399, 405, 411, 413, 417, 419, 422, 431, 439, 442, 445, 448, 451, 454, 457, 459, 463, 474, 478, 480, 484, 486, 488, 491, 496, 498, 500, 510, 514, 517, 520, 523, 532, 537, 540, 548, 556, 560, 568, 570, 573, 576, 582, 587, 591, 595, 597, 600, 602, 605, 607, 610, 614, 616, 630, 637, 641, 644, 647, 653, 657, 659, 663, 665, 670, 672, 674, 679, 681, 683, 686, 688, 690, 693, 695, 704, 707, 710, 712, 715, 718, 721, 723, 726, 728, 733, 735, 738, 741, 743, 747, 754, 762, 765, 775, 779, 784, 790, 794, 798, 800, 803, 806, 816, 819, 824, 829, 836, 839, 846, 849, 851, 856, 861, 866, 871, 874, 878, 881, 886, 895, 898, 902, 905, 912, 917, 922, 925, 928, 931, 934, 941, 944, 946, 949, 951, 958, 961, 967, 969, 974, 977, 981, 983, 989, 995, 998, 1006, 1009, 1011, 1015, 1022, 1024, 1028, 1034, 1037, 1039, 1045, 1051, 1054, 1060, 1066, 1068, 1075, 1078, 1083, 1086, 1088, 1091, 1094, 1097, 1100, 1104, 1107, 1110, 1115, 1118, 1120, 1126, 1129, 1134, 1140, 1143, 1149, 1153, 1156, 1159, 1161, 1165, 1169, 1176, 1180, 1191, 1196, 1198, 1208, 1210, 1214, 1217, 1219, 1225, 1229, 1234, 1238, 1240, 1242, 1246, 1249, 1253, 1257, 1260, 1262, 1265, 1270, 1272, 1275, 1279, 1281, 1287, 1290, 1294, 1297, 1302, 1305, 1308, 1311, 1315, 1317, 1321, 1324, 1328, 1331, 1347, 1349, 1352, 1356, 1360, 1363, 1367, 1370, 1375, 1379, 1382, 1386, 1389, 1392, 1402, 1407, 1412, 1415, 1419, 1426, 1430, 1432, 1436, 1439, 1443, 1452, 1457, 1464, 1469, 1472, 1475, 1479, 1486, 1494, 1497, 1503, 1508, 1510, 1512, 1516, 1522, 1525, 1527, 1530, 1532, 1537, 1540, 1544, 1552, 1556, 1561, 1566, 1571, 1573, 1575, 1578, 1581, 1585, 1591, 1594, 1597, 1599, 1603, 1605, 1608, 1610, 1615, 1618, 1621, 1623, 1626, 1628, 1631, 1633, 1637, 1639, 1642, 1644, 1651, 1659, 1663, 1672, 1676, 1680, 1682, 1684, 1686, 1690, 1700, 1704, 1708, 1710, 1713, 1717, 1722, 1724, 1737, 1740, 1751, 1754, 1761, 1764, 1767, 1769, 1771, 1776, 1780, 1782, 1787, 1791, 1794, 1799, 1806, 1809, 1811, 1813, 1815, 1823, 1825, 1827, 1831, 1847, 1850, 1853, 1861, 1863, 1866, 1869, 1872, 1876, 1880, 1882, 1889, 1892, 1897, 1900, 1903, 1912, 1914, 1917, 1919, 1924, 1931, 1934, 1943, 1954, 1963, 1966, 1969, 1972, 1975, 1978, 1980, 1985, 1989, 1995, 1998], deadline = 4)
        configuration.add_task(name="Task6", identifier=6, period=1.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.018256, et_stddev=0.006085333333333334 , list_activation_dates=[2, 5, 6, 7, 10, 11, 12, 14, 16, 20, 21, 23, 25, 27, 28, 29, 30, 32, 33, 34, 38, 40, 41, 43, 46, 48, 50, 52, 54, 56, 60, 67, 68, 69, 70, 71, 72, 74, 76, 81, 83, 84, 86, 88, 90, 92, 95, 97, 98, 99, 100, 102, 104, 105, 107, 108, 110, 112, 113, 114, 115, 116, 117, 118, 121, 122, 126, 129, 131, 135, 137, 139, 140, 141, 142, 145, 148, 149, 151, 153, 155, 156, 158, 160, 165, 168, 173, 175, 178, 180, 182, 184, 185, 191, 195, 196, 198, 199, 200, 202, 203, 204, 205, 207, 208, 210, 213, 216, 217, 218, 220, 222, 223, 224, 225, 226, 228, 231, 233, 235, 239, 241, 243, 246, 248, 250, 252, 253, 255, 256, 259, 260, 261, 264, 265, 267, 268, 269, 271, 273, 274, 275, 279, 280, 282, 283, 285, 287, 289, 291, 293, 295, 299, 303, 304, 305, 307, 309, 310, 314, 316, 318, 319, 323, 324, 326, 328, 330, 332, 335, 336, 337, 339, 342, 344, 345, 347, 348, 349, 353, 354, 356, 357, 358, 361, 363, 365, 369, 372, 374, 376, 377, 381, 382, 385, 391, 393, 395, 396, 397, 399, 400, 402, 404, 405, 407, 409, 411, 413, 414, 417, 421, 422, 426, 427, 429, 431, 432, 433, 436, 438, 440, 441, 443, 444, 446, 447, 450, 451, 454, 455, 456, 458, 459, 461, 465, 466, 467, 469, 470, 471, 472, 474, 475, 477, 479, 480, 483, 484, 487, 489, 492, 495, 496, 499, 501, 506, 507, 508, 509, 510, 513, 514, 516, 518, 519, 520, 522, 524, 525, 527, 529, 531, 533, 534, 535, 536, 538, 539, 540, 541, 543, 546, 548, 549, 553, 555, 556, 558, 560, 561, 562, 564, 566, 567, 568, 571, 572, 576, 579, 581, 582, 584, 585, 586, 588, 589, 590, 591, 594, 596, 599, 600, 602, 603, 606, 614, 615, 616, 619, 620, 622, 623, 625, 626, 629, 630, 631, 633, 635, 637, 640, 643, 645, 646, 647, 650, 653, 655, 656, 661, 665, 668, 671, 672, 674, 676, 678, 679, 680, 684, 687, 689, 691, 692, 693, 695, 697, 699, 701, 703, 704, 705, 706, 707, 711, 713, 714, 715, 718, 722, 724, 726, 729, 736, 742, 746, 747, 748, 751, 753, 754, 756, 761, 763, 765, 767, 769, 772, 775, 777, 778, 780, 782, 783, 784, 785, 787, 789, 790, 791, 792, 794, 795, 800, 803, 806, 807, 810, 812, 815, 817, 820, 821, 824, 829, 831, 834, 835, 838, 840, 841, 843, 845, 847, 849, 851, 856, 857, 859, 861, 862, 863, 866, 867, 869, 870, 873, 876, 877, 878, 879, 881, 882, 884, 885, 888, 893, 895, 897, 898, 902, 903, 904, 906, 907, 909, 911, 912, 913, 914, 917, 919, 921, 923, 926, 927, 928, 932, 934, 935, 936, 937, 939, 940, 944, 948, 949, 951, 952, 953, 956, 957, 961, 962, 963, 968, 970, 971, 973, 979, 982, 984, 985, 988, 990, 992, 994, 995, 999, 1000, 1003, 1005, 1006, 1007, 1008, 1010, 1011, 1013, 1017, 1019, 1021, 1022, 1025, 1028, 1030, 1032, 1034, 1035, 1036, 1038, 1039, 1041, 1042, 1044, 1046, 1048, 1052, 1053, 1054, 1057, 1058, 1062, 1066, 1069, 1072, 1074, 1075, 1077, 1078, 1081, 1082, 1084, 1087, 1090, 1093, 1095, 1096, 1099, 1100, 1101, 1106, 1111, 1114, 1117, 1120, 1121, 1122, 1123, 1129, 1131, 1132, 1134, 1136, 1138, 1141, 1143, 1145, 1147, 1148, 1150, 1152, 1154, 1155, 1157, 1158, 1161, 1163, 1164, 1166, 1169, 1174, 1175, 1177, 1183, 1184, 1185, 1186, 1188, 1192, 1193, 1195, 1196, 1197, 1199, 1200, 1201, 1204, 1205, 1207, 1209, 1210, 1215, 1216, 1217, 1221, 1223, 1225, 1226, 1227, 1229, 1230, 1232, 1233, 1235, 1237, 1240, 1241, 1242, 1243, 1245, 1247, 1249, 1250, 1252, 1253, 1256, 1257, 1259, 1260, 1262, 1264, 1268, 1269, 1270, 1272, 1273, 1274, 1275, 1277, 1280, 1283, 1285, 1286, 1288, 1289, 1291, 1294, 1296, 1297, 1299, 1303, 1304, 1307, 1309, 1314, 1317, 1322, 1323, 1324, 1329, 1331, 1334, 1336, 1339, 1342, 1343, 1345, 1347, 1348, 1351, 1352, 1353, 1358, 1360, 1365, 1366, 1368, 1370, 1371, 1372, 1373, 1375, 1376, 1377, 1378, 1380, 1381, 1383, 1384, 1385, 1386, 1387, 1388, 1390, 1394, 1395, 1398, 1400, 1401, 1403, 1404, 1405, 1406, 1408, 1410, 1411, 1413, 1416, 1418, 1419, 1423, 1424, 1426, 1428, 1430, 1431, 1433, 1435, 1439, 1440, 1443, 1444, 1446, 1447, 1449, 1450, 1453, 1454, 1455, 1456, 1459, 1463, 1466, 1468, 1469, 1470, 1471, 1472, 1473, 1475, 1477, 1480, 1483, 1484, 1485, 1487, 1490, 1496, 1497, 1498, 1499, 1501, 1505, 1506, 1507, 1508, 1510, 1511, 1512, 1515, 1516, 1518, 1519, 1520, 1523, 1524, 1526, 1528, 1529, 1531, 1532, 1536, 1538, 1541, 1542, 1543, 1544, 1546, 1548, 1550, 1553, 1555, 1557, 1559, 1561, 1564, 1566, 1567, 1568, 1570, 1572, 1574, 1576, 1578, 1580, 1582, 1583, 1584, 1585, 1586, 1587, 1590, 1591, 1593, 1596, 1597, 1599, 1602, 1604, 1605, 1606, 1608, 1610, 1612, 1616, 1617, 1618, 1619, 1622, 1624, 1626, 1627, 1629, 1630, 1632, 1634, 1636, 1638, 1639, 1640, 1642, 1644, 1645, 1646, 1648, 1650, 1651, 1652, 1654, 1658, 1662, 1666, 1669, 1670, 1674, 1676, 1677, 1678, 1680, 1681, 1683, 1684, 1685, 1686, 1688, 1690, 1692, 1695, 1698, 1699, 1702, 1705, 1708, 1710, 1711, 1712, 1715, 1716, 1717, 1718, 1720, 1721, 1722, 1723, 1724, 1725, 1726, 1729, 1731, 1733, 1735, 1737, 1740, 1742, 1743, 1744, 1745, 1746, 1748, 1749, 1751, 1753, 1755, 1758, 1760, 1761, 1762, 1763, 1765, 1766, 1767, 1768, 1769, 1771, 1774, 1777, 1782, 1786, 1788, 1792, 1793, 1794, 1796, 1797, 1798, 1800, 1802, 1804, 1805, 1808, 1810, 1811, 1813, 1814, 1818, 1820, 1823, 1825, 1827, 1828, 1830, 1831, 1832, 1836, 1839, 1843, 1845, 1847, 1849, 1853, 1855, 1856, 1857, 1858, 1861, 1863, 1866, 1869, 1870, 1872, 1876, 1878, 1879, 1881, 1882, 1884, 1886, 1890, 1896, 1897, 1899, 1900, 1901, 1903, 1904, 1906, 1908, 1909, 1910, 1913, 1914, 1916, 1921, 1922, 1926, 1927, 1930, 1931, 1932, 1938, 1939, 1941, 1942, 1944, 1945, 1948, 1949, 1950, 1953, 1954, 1956, 1958, 1960, 1961, 1965, 1966, 1967, 1969, 1970, 1972, 1974, 1975, 1977, 1980, 1981, 1982, 1984, 1985, 1986, 1988, 1990, 1991, 1992, 1993, 1994, 1995, 1996, 1997, 1999, 2000], deadline = 1)
        configuration.add_task(name="Task2", identifier=2, period=4.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=2.649499, acet=2.649499, et_stddev=0.8831663333333334, deadline= 8)
        configuration.add_task(name="Task5", identifier=5, period=6.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.232838, et_stddev=0.07761266666666666 , list_activation_dates=[2, 15, 23, 31, 39, 48, 65, 71, 77, 96, 105, 117, 128, 137, 143, 158, 173, 183, 199, 210, 220, 229, 235, 242, 249, 264, 270, 291, 298, 318, 333, 342, 372, 379, 411, 417, 433, 439, 455, 462, 469, 477, 492, 499, 512, 518, 525, 534, 552, 567, 584, 595, 607, 618, 632, 640, 651, 665, 673, 698, 706, 726, 733, 740, 749, 763, 773, 799, 806, 819, 832, 838, 856, 865, 872, 879, 898, 910, 924, 932, 968, 975, 987, 994, 1004, 1019, 1032, 1038, 1050, 1060, 1067, 1078, 1092, 1098, 1106, 1115, 1122, 1132, 1140, 1154, 1178, 1184, 1193, 1205, 1212, 1219, 1229, 1238, 1245, 1263, 1270, 1276, 1303, 1313, 1323, 1333, 1370, 1384, 1392, 1400, 1409, 1419, 1427, 1434, 1447, 1464, 1474, 1484, 1494, 1500, 1507, 1535, 1544, 1553, 1568, 1578, 1587, 1600, 1609, 1626, 1635, 1644, 1655, 1662, 1685, 1700, 1708, 1721, 1729, 1736, 1753, 1766, 1777, 1789, 1799, 1808, 1820, 1831, 1839, 1846, 1865, 1880, 1888, 1912, 1923, 1949, 1961, 1969, 1985, 1994], deadline = 9)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "61")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "61")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "61")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "61")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task3", identifier=3, period=1.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=0.874271, acet=0.874271, et_stddev=0.2914236666666667, deadline= 2)
        configuration.add_task(name="Task1", identifier=1, period=9.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=1.86193, acet=1.86193, et_stddev=0.6206433333333333, deadline= 15)
        configuration.add_task(name="Task2", identifier=2, period=6.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=3.113083, acet=3.113083, et_stddev=1.0376943333333333, deadline= 7)
        configuration.add_task(name="Task6", identifier=6, period=40.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=2, acet=1.340043, et_stddev=0.44668100000000005 , list_activation_dates=[164, 427, 520, 572, 667, 716, 831, 910, 1015, 1078, 1291, 1529, 1604, 1654, 1710, 1778, 1942, 1995], deadline = 8)
        configuration.add_task(name="Task5", identifier=5, period=2.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.316414, et_stddev=0.10547133333333332 , list_activation_dates=[3, 5, 10, 14, 16, 18, 22, 30, 34, 37, 42, 45, 48, 52, 55, 59, 67, 70, 72, 78, 85, 88, 90, 96, 99, 104, 108, 112, 115, 120, 130, 132, 134, 136, 145, 148, 151, 154, 156, 164, 166, 169, 179, 183, 188, 193, 196, 199, 201, 205, 212, 219, 222, 225, 230, 232, 235, 239, 244, 246, 249, 253, 256, 262, 265, 268, 271, 276, 281, 288, 290, 293, 296, 305, 309, 314, 319, 322, 324, 326, 328, 332, 336, 339, 344, 351, 355, 361, 366, 369, 372, 375, 384, 387, 389, 392, 396, 399, 403, 406, 410, 413, 415, 418, 425, 428, 432, 435, 439, 442, 446, 453, 457, 460, 463, 466, 470, 474, 477, 479, 482, 485, 489, 491, 499, 502, 506, 510, 513, 515, 519, 522, 528, 532, 537, 540, 542, 544, 555, 558, 561, 565, 569, 572, 575, 579, 582, 584, 592, 596, 600, 606, 608, 610, 615, 618, 621, 623, 628, 634, 644, 647, 651, 653, 657, 661, 663, 668, 672, 674, 676, 679, 682, 688, 692, 697, 701, 704, 708, 711, 715, 723, 725, 731, 734, 744, 747, 751, 756, 759, 766, 769, 773, 776, 780, 787, 793, 798, 806, 810, 812, 815, 818, 821, 824, 828, 831, 835, 839, 845, 848, 868, 874, 881, 884, 886, 892, 895, 899, 903, 906, 909, 915, 921, 924, 928, 932, 934, 939, 941, 944, 946, 949, 952, 959, 961, 965, 968, 970, 973, 978, 983, 989, 995, 998, 1001, 1008, 1010, 1012, 1015, 1017, 1019, 1022, 1025, 1029, 1031, 1034, 1042, 1045, 1048, 1052, 1057, 1060, 1062, 1065, 1068, 1070, 1077, 1081, 1083, 1088, 1094, 1100, 1107, 1116, 1119, 1122, 1126, 1128, 1130, 1133, 1136, 1139, 1143, 1149, 1153, 1155, 1157, 1160, 1162, 1164, 1167, 1170, 1173, 1175, 1179, 1182, 1191, 1194, 1200, 1206, 1210, 1213, 1219, 1223, 1228, 1230, 1234, 1238, 1246, 1248, 1252, 1255, 1260, 1263, 1266, 1270, 1274, 1284, 1286, 1291, 1298, 1302, 1304, 1310, 1316, 1321, 1325, 1327, 1330, 1332, 1335, 1341, 1348, 1351, 1355, 1360, 1362, 1365, 1376, 1385, 1391, 1393, 1399, 1404, 1407, 1412, 1415, 1419, 1422, 1424, 1427, 1430, 1437, 1441, 1446, 1448, 1452, 1458, 1461, 1465, 1468, 1473, 1476, 1481, 1484, 1488, 1491, 1494, 1496, 1503, 1506, 1509, 1515, 1518, 1524, 1527, 1535, 1539, 1542, 1546, 1550, 1552, 1560, 1563, 1566, 1569, 1571, 1573, 1577, 1584, 1588, 1591, 1595, 1604, 1607, 1611, 1616, 1618, 1621, 1624, 1628, 1630, 1633, 1635, 1638, 1641, 1644, 1648, 1651, 1654, 1663, 1668, 1670, 1672, 1677, 1681, 1685, 1688, 1690, 1692, 1694, 1699, 1701, 1704, 1711, 1713, 1716, 1719, 1722, 1724, 1728, 1731, 1735, 1738, 1742, 1748, 1753, 1755, 1758, 1763, 1767, 1771, 1774, 1777, 1782, 1785, 1796, 1800, 1808, 1812, 1814, 1818, 1822, 1825, 1832, 1835, 1838, 1845, 1848, 1854, 1857, 1861, 1864, 1867, 1870, 1873, 1875, 1878, 1883, 1887, 1893, 1896, 1908, 1912, 1920, 1923, 1928, 1932, 1935, 1940, 1944, 1949, 1952, 1956, 1958, 1964, 1967, 1969, 1973, 1975, 1980, 1983, 1990, 2000], deadline = 1)
        configuration.add_task(name="Task4", identifier=4, period=28.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.232169, et_stddev=0.07738966666666666 , list_activation_dates=[41, 74, 104, 238, 274, 310, 349, 387, 434, 553, 633, 716, 746, 878, 921, 950, 1014, 1066, 1127, 1163, 1217, 1248, 1312, 1443, 1505, 1534, 1616, 1736, 1802, 1837, 1881, 1918, 1962], deadline = 24)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "62")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "62")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "62")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "62")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task5", identifier=5, period=19.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=3, acet=2.220369, et_stddev=0.740123 , list_activation_dates=[14, 60, 94, 139, 185, 217, 256, 387, 418, 476, 499, 521, 545, 569, 654, 687, 708, 738, 762, 784, 847, 874, 926, 946, 968, 992, 1039, 1060, 1084, 1169, 1198, 1222, 1245, 1266, 1287, 1336, 1385, 1408, 1479, 1500, 1533, 1564, 1600, 1667, 1698, 1752, 1782, 1804, 1826, 1868, 1891], deadline = 11)
        configuration.add_task(name="Task1", identifier=1, period=33.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=23.458597, acet=23.458597, et_stddev=7.819532333333334, deadline= 26)
        configuration.add_task(name="Task3", identifier=3, period=13.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=10.325598, acet=10.325598, et_stddev=3.4418659999999996, deadline= 22)
        configuration.add_task(name="Task4", identifier=4, period=5.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.00972, et_stddev=0.00324 , list_activation_dates=[22, 29, 38, 55, 63, 73, 81, 92, 100, 110, 119, 134, 141, 178, 190, 197, 203, 215, 231, 244, 250, 271, 283, 290, 300, 316, 327, 342, 348, 362, 370, 378, 387, 394, 402, 416, 423, 430, 440, 446, 451, 466, 472, 480, 488, 505, 512, 529, 544, 551, 562, 567, 576, 582, 588, 595, 610, 624, 639, 646, 653, 666, 678, 685, 690, 695, 707, 712, 718, 723, 734, 746, 751, 762, 770, 776, 784, 794, 799, 806, 821, 829, 834, 840, 847, 868, 879, 891, 896, 902, 909, 922, 942, 947, 953, 960, 969, 976, 983, 997, 1005, 1013, 1026, 1032, 1043, 1049, 1054, 1059, 1065, 1078, 1091, 1100, 1128, 1152, 1158, 1164, 1169, 1178, 1186, 1192, 1197, 1204, 1213, 1219, 1225, 1233, 1242, 1248, 1253, 1261, 1267, 1273, 1288, 1298, 1304, 1310, 1320, 1340, 1346, 1360, 1366, 1372, 1379, 1390, 1396, 1419, 1424, 1444, 1449, 1459, 1467, 1485, 1490, 1499, 1509, 1518, 1530, 1543, 1551, 1559, 1576, 1581, 1611, 1627, 1632, 1639, 1647, 1655, 1662, 1674, 1692, 1705, 1712, 1729, 1734, 1739, 1745, 1753, 1759, 1765, 1775, 1795, 1812, 1817, 1832, 1851, 1857, 1865, 1873, 1888, 1895, 1902, 1911, 1919, 1934, 1943, 1955, 1968, 1973, 1979], deadline = 3)
        configuration.add_task(name="Task2", identifier=2, period=2.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=0.189713, acet=0.189713, et_stddev=0.06323766666666666, deadline= 2)
        configuration.add_task(name="Task6", identifier=6, period=28.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=3, acet=2.273439, et_stddev=0.7578130000000001 , list_activation_dates=[49, 150, 223, 321, 358, 389, 475, 510, 553, 582, 612, 711, 781, 852, 910, 939, 992, 1046, 1079, 1114, 1148, 1249, 1304, 1332, 1393, 1442, 1477, 1514, 1547, 1585, 1633, 1668, 1699, 1819, 1867, 1898, 1944, 1979], deadline = 46)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "63")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "63")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "63")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "63")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task3", identifier=3, period=17.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=7.326235, acet=7.326235, et_stddev=2.4420783333333334, deadline= 20)
        configuration.add_task(name="Task6", identifier=6, period=7.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.671271, et_stddev=0.22375699999999998 , list_activation_dates=[2, 12, 27, 36, 57, 70, 82, 91, 110, 118, 125, 134, 143, 163, 173, 185, 214, 223, 251, 261, 270, 302, 315, 326, 350, 360, 372, 382, 407, 429, 440, 449, 458, 468, 477, 492, 522, 530, 546, 554, 571, 593, 601, 630, 640, 649, 657, 665, 677, 687, 698, 707, 723, 745, 778, 792, 802, 829, 840, 847, 869, 888, 895, 917, 961, 979, 990, 1005, 1013, 1022, 1029, 1042, 1050, 1058, 1069, 1082, 1099, 1107, 1116, 1147, 1156, 1179, 1192, 1200, 1217, 1237, 1246, 1255, 1274, 1292, 1319, 1329, 1342, 1352, 1361, 1390, 1398, 1420, 1435, 1443, 1456, 1485, 1495, 1503, 1526, 1538, 1567, 1576, 1587, 1606, 1629, 1637, 1650, 1661, 1669, 1699, 1720, 1729, 1737, 1755, 1795, 1804, 1814, 1834, 1843, 1856, 1868, 1877, 1885, 1906, 1930, 1938, 1969, 1989], deadline = 13)
        configuration.add_task(name="Task5", identifier=5, period=2.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.178474, et_stddev=0.059491333333333334 , list_activation_dates=[6, 9, 14, 17, 21, 31, 34, 38, 43, 48, 52, 54, 59, 63, 67, 79, 83, 88, 96, 102, 109, 118, 120, 124, 126, 128, 131, 133, 136, 138, 145, 150, 153, 156, 159, 161, 163, 169, 172, 177, 181, 185, 190, 193, 201, 204, 207, 209, 214, 218, 224, 227, 229, 237, 241, 248, 252, 254, 259, 264, 269, 271, 273, 276, 278, 281, 283, 290, 292, 297, 300, 304, 312, 319, 325, 328, 331, 333, 336, 339, 344, 348, 351, 354, 357, 360, 365, 368, 371, 374, 378, 382, 386, 392, 395, 397, 403, 406, 410, 413, 419, 422, 425, 428, 431, 435, 437, 441, 453, 455, 460, 464, 468, 471, 475, 478, 480, 484, 487, 491, 493, 496, 499, 503, 508, 512, 514, 517, 520, 523, 526, 529, 534, 537, 540, 544, 548, 557, 559, 561, 567, 569, 571, 574, 580, 584, 588, 592, 594, 600, 602, 604, 608, 613, 616, 623, 625, 628, 632, 636, 639, 641, 645, 647, 652, 659, 661, 664, 670, 673, 677, 682, 689, 692, 696, 698, 703, 706, 710, 714, 716, 718, 721, 724, 727, 730, 736, 740, 744, 750, 753, 757, 762, 765, 769, 772, 774, 777, 780, 783, 785, 787, 791, 794, 802, 805, 807, 809, 813, 815, 818, 820, 823, 825, 829, 835, 839, 844, 847, 850, 852, 855, 857, 863, 865, 869, 873, 875, 877, 881, 884, 888, 892, 894, 902, 904, 907, 909, 912, 915, 917, 921, 925, 928, 931, 934, 937, 941, 947, 950, 959, 962, 965, 967, 970, 972, 974, 982, 984, 990, 993, 996, 1001, 1003, 1005, 1015, 1018, 1023, 1029, 1031, 1034, 1041, 1043, 1057, 1061, 1064, 1068, 1071, 1074, 1081, 1084, 1088, 1092, 1095, 1102, 1107, 1110, 1116, 1119, 1122, 1125, 1127, 1129, 1133, 1137, 1140, 1144, 1153, 1157, 1162, 1166, 1170, 1173, 1177, 1180, 1183, 1185, 1188, 1191, 1193, 1197, 1201, 1206, 1209, 1213, 1215, 1219, 1222, 1228, 1230, 1232, 1241, 1244, 1246, 1253, 1256, 1260, 1266, 1271, 1276, 1281, 1286, 1289, 1296, 1303, 1306, 1309, 1312, 1315, 1321, 1324, 1327, 1331, 1334, 1336, 1339, 1342, 1348, 1351, 1355, 1360, 1363, 1370, 1375, 1379, 1383, 1386, 1390, 1397, 1400, 1403, 1407, 1411, 1415, 1419, 1423, 1426, 1428, 1431, 1435, 1439, 1442, 1446, 1450, 1455, 1457, 1462, 1465, 1468, 1471, 1475, 1478, 1480, 1487, 1494, 1497, 1501, 1504, 1515, 1519, 1522, 1528, 1530, 1533, 1537, 1540, 1544, 1547, 1550, 1552, 1554, 1556, 1563, 1566, 1569, 1573, 1576, 1584, 1588, 1591, 1594, 1600, 1605, 1607, 1610, 1613, 1616, 1622, 1629, 1641, 1644, 1647, 1652, 1654, 1656, 1661, 1668, 1673, 1678, 1682, 1685, 1688, 1691, 1696, 1699, 1703, 1706, 1710, 1713, 1718, 1723, 1726, 1730, 1733, 1740, 1744, 1748, 1750, 1752, 1756, 1759, 1762, 1764, 1767, 1772, 1776, 1778, 1782, 1785, 1787, 1790, 1792, 1796, 1800, 1807, 1809, 1811, 1820, 1823, 1826, 1829, 1832, 1835, 1840, 1844, 1848, 1858, 1862, 1864, 1866, 1870, 1873, 1876, 1879, 1885, 1888, 1890, 1894, 1899, 1903, 1905, 1917, 1920, 1924, 1930, 1934, 1936, 1938, 1941, 1947, 1956, 1960, 1963, 1966, 1969, 1971, 1974, 1981, 1987, 1991, 1996], deadline = 4)
        configuration.add_task(name="Task2", identifier=2, period=2.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=0.713915, acet=0.713915, et_stddev=0.23797166666666666, deadline= 1)
        configuration.add_task(name="Task4", identifier=4, period=8.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.118933, et_stddev=0.03964433333333333 , list_activation_dates=[3, 14, 27, 36, 53, 61, 75, 87, 102, 127, 135, 144, 160, 179, 188, 196, 236, 269, 282, 294, 303, 322, 344, 354, 370, 380, 397, 406, 438, 453, 468, 476, 492, 507, 518, 527, 537, 556, 565, 576, 597, 631, 646, 656, 675, 691, 709, 719, 743, 752, 770, 783, 800, 826, 837, 873, 885, 910, 919, 927, 937, 947, 958, 971, 984, 1003, 1012, 1030, 1046, 1089, 1108, 1118, 1131, 1147, 1160, 1179, 1211, 1220, 1236, 1247, 1266, 1274, 1299, 1308, 1318, 1331, 1352, 1360, 1368, 1377, 1401, 1410, 1431, 1441, 1454, 1484, 1498, 1511, 1522, 1530, 1554, 1576, 1591, 1607, 1620, 1638, 1648, 1658, 1667, 1680, 1690, 1699, 1720, 1743, 1757, 1788, 1799, 1807, 1818, 1855, 1867, 1879, 1890, 1927, 1938, 1948, 1959, 1970, 1981], deadline = 13)
        configuration.add_task(name="Task1", identifier=1, period=9.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=7.308787, acet=7.308787, et_stddev=2.436262333333333, deadline= 14)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "64")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "64")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "64")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "64")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task4", identifier=4, period=2.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.319004, et_stddev=0.10633466666666667 , list_activation_dates=[5, 7, 10, 14, 20, 25, 28, 31, 39, 43, 47, 49, 53, 56, 58, 62, 65, 68, 78, 82, 87, 90, 95, 99, 103, 105, 109, 114, 116, 119, 121, 123, 130, 135, 138, 145, 150, 152, 156, 159, 161, 170, 173, 176, 180, 184, 187, 190, 194, 201, 203, 210, 214, 218, 220, 227, 230, 233, 238, 242, 248, 251, 253, 258, 262, 266, 272, 276, 280, 282, 286, 289, 292, 295, 299, 304, 311, 315, 320, 327, 330, 332, 337, 345, 351, 356, 360, 365, 367, 369, 371, 374, 376, 385, 389, 392, 395, 402, 409, 412, 414, 418, 429, 438, 442, 444, 446, 448, 450, 454, 457, 463, 467, 469, 475, 479, 482, 485, 488, 493, 495, 499, 502, 507, 510, 513, 515, 517, 523, 532, 536, 541, 546, 549, 552, 557, 560, 563, 569, 573, 579, 585, 587, 591, 593, 595, 600, 604, 607, 610, 617, 622, 626, 631, 634, 637, 640, 645, 649, 652, 654, 658, 665, 667, 674, 676, 678, 680, 682, 685, 689, 696, 700, 703, 715, 718, 721, 728, 731, 735, 737, 741, 744, 752, 755, 762, 767, 770, 774, 776, 780, 785, 790, 793, 795, 797, 802, 804, 807, 812, 819, 821, 824, 827, 830, 832, 834, 845, 848, 851, 856, 858, 860, 863, 868, 871, 873, 881, 886, 891, 895, 898, 906, 909, 911, 914, 916, 919, 925, 933, 936, 938, 942, 946, 948, 954, 957, 960, 964, 969, 974, 979, 982, 985, 987, 990, 994, 996, 1001, 1006, 1008, 1010, 1015, 1018, 1021, 1025, 1028, 1031, 1033, 1036, 1040, 1046, 1048, 1051, 1057, 1059, 1063, 1066, 1068, 1075, 1078, 1081, 1086, 1090, 1092, 1096, 1099, 1105, 1108, 1110, 1117, 1119, 1125, 1128, 1131, 1135, 1138, 1142, 1145, 1149, 1152, 1154, 1158, 1162, 1166, 1176, 1181, 1184, 1186, 1190, 1199, 1202, 1206, 1210, 1213, 1216, 1219, 1223, 1230, 1232, 1237, 1240, 1244, 1246, 1248, 1253, 1255, 1267, 1270, 1273, 1278, 1281, 1284, 1292, 1295, 1302, 1306, 1309, 1314, 1318, 1321, 1324, 1327, 1330, 1334, 1337, 1339, 1341, 1343, 1346, 1348, 1350, 1356, 1359, 1363, 1367, 1369, 1372, 1376, 1380, 1386, 1392, 1397, 1399, 1401, 1406, 1412, 1414, 1420, 1425, 1428, 1431, 1434, 1436, 1439, 1442, 1448, 1450, 1453, 1456, 1463, 1466, 1469, 1472, 1475, 1479, 1487, 1489, 1491, 1502, 1505, 1507, 1513, 1519, 1525, 1527, 1532, 1536, 1539, 1541, 1543, 1545, 1547, 1550, 1553, 1559, 1562, 1566, 1569, 1573, 1575, 1577, 1580, 1585, 1588, 1591, 1594, 1598, 1601, 1606, 1611, 1614, 1618, 1621, 1630, 1634, 1636, 1641, 1644, 1646, 1650, 1659, 1662, 1664, 1672, 1674, 1677, 1681, 1683, 1686, 1688, 1690, 1692, 1694, 1699, 1704, 1708, 1712, 1717, 1719, 1721, 1724, 1728, 1734, 1741, 1752, 1759, 1765, 1768, 1770, 1772, 1776, 1778, 1782, 1785, 1789, 1794, 1797, 1799, 1807, 1809, 1814, 1820, 1824, 1826, 1828, 1830, 1832, 1835, 1842, 1845, 1847, 1849, 1853, 1856, 1859, 1863, 1867, 1869, 1872, 1875, 1878, 1883, 1887, 1890, 1893, 1896, 1900, 1902, 1908, 1912, 1915, 1917, 1928, 1932, 1939, 1942, 1945, 1948, 1953, 1959, 1961, 1965, 1968, 1971, 1976, 1980, 1983, 1986, 1993, 1995, 1997, 2000], deadline = 3)
        configuration.add_task(name="Task2", identifier=2, period=16.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=12.794267, acet=12.794267, et_stddev=4.264755666666667, deadline= 25)
        configuration.add_task(name="Task6", identifier=6, period=14.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.536528, et_stddev=0.17884266666666668 , list_activation_dates=[7, 34, 53, 75, 135, 168, 220, 236, 264, 287, 316, 332, 351, 387, 402, 417, 479, 500, 523, 541, 570, 586, 626, 660, 707, 730, 754, 810, 840, 857, 874, 892, 914, 947, 961, 1017, 1032, 1055, 1071, 1120, 1199, 1230, 1246, 1270, 1297, 1313, 1348, 1362, 1392, 1410, 1455, 1476, 1520, 1550, 1580, 1596, 1642, 1686, 1702, 1739, 1757, 1771, 1788, 1812, 1829, 1861, 1879, 1907, 1943, 1959, 1992], deadline = 13)
        configuration.add_task(name="Task3", identifier=3, period=10.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=1.727511, acet=1.727511, et_stddev=0.575837, deadline= 17)
        configuration.add_task(name="Task5", identifier=5, period=2.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.004348, et_stddev=0.0014493333333333335 , list_activation_dates=[2, 6, 9, 11, 20, 22, 25, 29, 34, 37, 40, 43, 47, 51, 56, 58, 64, 68, 70, 73, 78, 81, 83, 87, 91, 97, 106, 108, 110, 116, 120, 122, 125, 128, 130, 137, 141, 146, 148, 151, 157, 161, 165, 168, 174, 181, 183, 187, 189, 196, 204, 208, 214, 217, 219, 224, 228, 230, 234, 243, 249, 252, 254, 258, 267, 270, 272, 276, 281, 285, 288, 292, 295, 299, 302, 307, 311, 313, 322, 326, 331, 336, 344, 347, 351, 356, 362, 365, 373, 377, 381, 384, 387, 389, 392, 399, 402, 407, 410, 413, 415, 418, 421, 423, 427, 432, 435, 439, 447, 452, 455, 461, 463, 466, 468, 470, 475, 479, 482, 488, 490, 492, 495, 499, 502, 508, 511, 513, 517, 521, 527, 531, 535, 537, 541, 543, 546, 550, 553, 557, 560, 567, 570, 573, 576, 585, 590, 593, 598, 601, 605, 608, 611, 614, 616, 629, 634, 636, 639, 641, 644, 647, 650, 655, 660, 662, 665, 668, 672, 678, 682, 692, 702, 704, 706, 709, 712, 720, 724, 728, 732, 735, 738, 745, 747, 751, 756, 758, 765, 768, 771, 777, 780, 783, 788, 792, 794, 798, 800, 807, 809, 812, 815, 818, 823, 829, 837, 840, 843, 848, 850, 853, 856, 859, 868, 877, 882, 885, 891, 894, 900, 904, 906, 908, 914, 924, 927, 934, 936, 938, 942, 946, 949, 951, 953, 955, 958, 962, 968, 972, 974, 976, 979, 982, 984, 987, 995, 997, 1003, 1012, 1015, 1019, 1032, 1034, 1044, 1052, 1058, 1061, 1064, 1068, 1070, 1079, 1083, 1087, 1091, 1094, 1099, 1107, 1115, 1118, 1122, 1127, 1130, 1136, 1139, 1143, 1146, 1150, 1153, 1156, 1159, 1162, 1164, 1168, 1171, 1174, 1177, 1179, 1181, 1184, 1190, 1193, 1196, 1199, 1206, 1209, 1213, 1220, 1223, 1228, 1230, 1235, 1241, 1244, 1248, 1251, 1255, 1258, 1262, 1265, 1270, 1274, 1283, 1287, 1290, 1292, 1295, 1299, 1303, 1311, 1314, 1317, 1322, 1325, 1327, 1329, 1342, 1345, 1350, 1353, 1355, 1359, 1361, 1364, 1367, 1370, 1373, 1375, 1380, 1383, 1386, 1390, 1394, 1397, 1399, 1403, 1407, 1410, 1415, 1419, 1422, 1428, 1432, 1436, 1439, 1442, 1445, 1448, 1451, 1454, 1456, 1460, 1463, 1465, 1469, 1473, 1478, 1481, 1485, 1487, 1489, 1491, 1494, 1498, 1503, 1505, 1508, 1510, 1514, 1516, 1526, 1528, 1533, 1540, 1543, 1546, 1552, 1562, 1566, 1570, 1573, 1576, 1578, 1581, 1583, 1591, 1594, 1599, 1602, 1610, 1612, 1615, 1618, 1621, 1625, 1631, 1635, 1637, 1640, 1643, 1645, 1652, 1655, 1658, 1661, 1663, 1666, 1671, 1673, 1675, 1678, 1681, 1686, 1690, 1694, 1696, 1699, 1702, 1706, 1713, 1715, 1718, 1726, 1730, 1732, 1738, 1740, 1744, 1746, 1750, 1754, 1757, 1767, 1770, 1775, 1778, 1782, 1785, 1787, 1791, 1794, 1796, 1800, 1804, 1808, 1811, 1813, 1816, 1821, 1826, 1829, 1833, 1840, 1844, 1846, 1851, 1854, 1858, 1861, 1864, 1872, 1874, 1877, 1884, 1887, 1890, 1894, 1899, 1902, 1909, 1915, 1922, 1925, 1930, 1933, 1937, 1939, 1942, 1946, 1948, 1956, 1960, 1972, 1975, 1978, 1981, 1985, 1993, 1995], deadline = 4)
        configuration.add_task(name="Task1", identifier=1, period=1.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=0.627607, acet=0.627607, et_stddev=0.20920233333333335, deadline= 1)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "65")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "65")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "65")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "65")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task2", identifier=2, period=11.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=1.884372, acet=1.884372, et_stddev=0.628124, deadline= 19)
        configuration.add_task(name="Task3", identifier=3, period=8.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=6.495149, acet=6.495149, et_stddev=2.1650496666666665, deadline= 12)
        configuration.add_task(name="Task1", identifier=1, period=1.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=0.616799, acet=0.616799, et_stddev=0.20559966666666665, deadline= 2)
        configuration.add_task(name="Task6", identifier=6, period=1.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.119917, et_stddev=0.03997233333333333 , list_activation_dates=[2, 4, 8, 9, 13, 15, 18, 19, 22, 25, 28, 32, 33, 34, 35, 36, 37, 39, 40, 42, 45, 46, 48, 51, 52, 54, 59, 60, 62, 64, 66, 68, 69, 70, 74, 75, 76, 77, 80, 82, 86, 88, 89, 92, 96, 97, 99, 101, 105, 107, 112, 114, 115, 118, 120, 121, 123, 124, 127, 129, 131, 134, 137, 138, 142, 144, 145, 147, 149, 152, 154, 155, 157, 159, 160, 162, 163, 165, 168, 170, 176, 180, 181, 183, 185, 186, 190, 191, 194, 197, 201, 203, 204, 205, 207, 210, 211, 213, 217, 218, 220, 222, 223, 228, 229, 232, 234, 235, 236, 238, 241, 242, 243, 245, 247, 248, 250, 253, 254, 255, 257, 258, 259, 261, 264, 270, 273, 275, 276, 277, 281, 282, 283, 284, 286, 287, 290, 291, 293, 295, 297, 299, 301, 303, 305, 306, 307, 309, 311, 313, 316, 318, 321, 323, 325, 326, 327, 328, 335, 336, 338, 340, 341, 342, 343, 344, 345, 346, 348, 350, 351, 352, 354, 356, 358, 359, 363, 365, 369, 371, 372, 373, 374, 377, 379, 382, 383, 384, 385, 386, 387, 389, 391, 393, 395, 396, 398, 400, 402, 404, 406, 408, 410, 412, 413, 414, 416, 417, 421, 424, 426, 429, 433, 435, 438, 439, 443, 445, 448, 450, 454, 458, 460, 462, 464, 469, 472, 476, 478, 480, 481, 483, 485, 486, 489, 490, 491, 492, 494, 495, 497, 498, 502, 503, 506, 508, 510, 511, 513, 514, 517, 520, 521, 522, 523, 526, 528, 529, 530, 531, 533, 534, 536, 538, 541, 543, 545, 546, 547, 549, 550, 554, 556, 558, 559, 561, 563, 565, 566, 568, 569, 570, 571, 575, 579, 581, 582, 583, 586, 588, 590, 592, 594, 596, 598, 599, 600, 603, 604, 606, 607, 609, 611, 613, 614, 616, 617, 619, 620, 624, 626, 629, 630, 632, 635, 637, 640, 642, 644, 645, 646, 647, 648, 649, 651, 653, 654, 656, 658, 659, 662, 664, 666, 670, 672, 673, 674, 675, 676, 681, 683, 689, 693, 694, 695, 697, 698, 699, 703, 705, 706, 708, 710, 711, 713, 715, 716, 718, 720, 721, 727, 728, 729, 730, 731, 734, 736, 739, 740, 743, 745, 747, 749, 751, 752, 754, 755, 757, 758, 759, 760, 762, 765, 767, 770, 773, 777, 778, 779, 782, 784, 786, 787, 788, 789, 793, 794, 797, 799, 800, 801, 803, 804, 806, 807, 809, 811, 813, 817, 818, 820, 821, 823, 825, 829, 830, 833, 834, 836, 837, 838, 839, 840, 841, 842, 844, 846, 847, 849, 850, 852, 857, 860, 862, 864, 865, 866, 867, 870, 872, 873, 874, 878, 880, 882, 884, 885, 887, 889, 894, 896, 898, 902, 906, 908, 911, 916, 917, 920, 922, 925, 927, 928, 930, 933, 935, 938, 940, 942, 943, 944, 946, 948, 949, 951, 954, 956, 958, 959, 960, 962, 965, 967, 969, 972, 973, 975, 976, 978, 980, 982, 984, 986, 989, 990, 991, 997, 998, 999, 1000, 1003, 1005, 1008, 1011, 1013, 1015, 1016, 1017, 1020, 1022, 1023, 1025, 1027, 1030, 1031, 1032, 1034, 1035, 1037, 1039, 1042, 1044, 1045, 1047, 1049, 1051, 1052, 1053, 1054, 1057, 1059, 1063, 1066, 1069, 1071, 1073, 1075, 1080, 1081, 1082, 1083, 1087, 1093, 1095, 1096, 1098, 1101, 1103, 1105, 1107, 1110, 1111, 1112, 1114, 1115, 1117, 1119, 1122, 1123, 1124, 1125, 1127, 1130, 1131, 1132, 1133, 1134, 1135, 1136, 1138, 1143, 1144, 1146, 1149, 1152, 1155, 1156, 1157, 1158, 1160, 1164, 1166, 1167, 1168, 1170, 1171, 1177, 1180, 1182, 1184, 1187, 1189, 1190, 1192, 1193, 1194, 1195, 1197, 1199, 1201, 1204, 1205, 1206, 1208, 1210, 1213, 1214, 1216, 1219, 1221, 1223, 1227, 1229, 1232, 1233, 1234, 1236, 1237, 1240, 1242, 1243, 1247, 1248, 1249, 1250, 1253, 1254, 1255, 1257, 1259, 1261, 1262, 1264, 1269, 1271, 1273, 1275, 1276, 1278, 1279, 1281, 1285, 1286, 1289, 1292, 1298, 1300, 1302, 1305, 1306, 1307, 1308, 1309, 1310, 1311, 1312, 1313, 1314, 1315, 1316, 1318, 1319, 1321, 1322, 1324, 1325, 1328, 1331, 1332, 1333, 1334, 1336, 1338, 1341, 1343, 1346, 1349, 1350, 1352, 1355, 1359, 1360, 1361, 1363, 1364, 1368, 1370, 1373, 1374, 1376, 1377, 1379, 1381, 1382, 1384, 1385, 1387, 1388, 1389, 1392, 1395, 1397, 1398, 1399, 1401, 1403, 1405, 1407, 1410, 1412, 1415, 1417, 1420, 1423, 1425, 1427, 1429, 1431, 1434, 1435, 1436, 1438, 1440, 1441, 1446, 1450, 1452, 1454, 1458, 1459, 1460, 1462, 1463, 1465, 1467, 1469, 1470, 1472, 1475, 1476, 1477, 1479, 1480, 1481, 1482, 1485, 1486, 1488, 1490, 1493, 1496, 1498, 1499, 1502, 1503, 1505, 1507, 1508, 1509, 1512, 1515, 1517, 1520, 1522, 1523, 1525, 1526, 1528, 1531, 1532, 1535, 1536, 1537, 1539, 1541, 1543, 1544, 1548, 1549, 1550, 1553, 1555, 1557, 1559, 1560, 1561, 1565, 1566, 1567, 1568, 1570, 1571, 1573, 1574, 1576, 1577, 1579, 1581, 1583, 1586, 1587, 1588, 1590, 1593, 1596, 1597, 1601, 1602, 1605, 1607, 1610, 1613, 1615, 1617, 1618, 1619, 1621, 1623, 1625, 1626, 1629, 1631, 1632, 1637, 1639, 1640, 1642, 1645, 1646, 1648, 1651, 1658, 1661, 1662, 1664, 1666, 1668, 1670, 1671, 1672, 1674, 1677, 1678, 1679, 1683, 1684, 1685, 1687, 1688, 1689, 1690, 1693, 1695, 1697, 1699, 1700, 1702, 1703, 1704, 1706, 1708, 1711, 1712, 1714, 1716, 1718, 1719, 1721, 1722, 1723, 1728, 1729, 1732, 1734, 1736, 1738, 1739, 1740, 1741, 1742, 1744, 1747, 1749, 1750, 1751, 1752, 1754, 1755, 1756, 1759, 1761, 1763, 1765, 1767, 1770, 1773, 1775, 1778, 1779, 1781, 1783, 1785, 1788, 1790, 1791, 1794, 1795, 1801, 1802, 1804, 1805, 1808, 1809, 1810, 1811, 1813, 1818, 1819, 1820, 1825, 1826, 1828, 1830, 1832, 1833, 1837, 1838, 1842, 1843, 1846, 1848, 1851, 1852, 1855, 1857, 1859, 1862, 1863, 1865, 1866, 1867, 1869, 1870, 1872, 1874, 1878, 1880, 1884, 1885, 1887, 1889, 1890, 1891, 1892, 1893, 1894, 1896, 1897, 1899, 1901, 1902, 1903, 1905, 1906, 1910, 1911, 1913, 1916, 1917, 1919, 1921, 1923, 1925, 1926, 1927, 1928, 1930, 1933, 1934, 1936, 1937, 1938, 1942, 1945, 1946, 1947, 1949, 1950, 1952, 1953, 1957, 1958, 1959, 1961, 1963, 1965, 1967, 1969, 1973, 1975, 1976, 1979, 1980, 1982, 1985, 1986, 1988, 1989, 1992, 1993, 1996, 1998, 2000], deadline = 1)
        configuration.add_task(name="Task5", identifier=5, period=5.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.08398, et_stddev=0.027993333333333332 , list_activation_dates=[11, 21, 31, 50, 73, 79, 93, 99, 108, 118, 126, 138, 149, 159, 165, 181, 186, 198, 204, 216, 229, 242, 255, 269, 280, 287, 292, 300, 315, 324, 329, 338, 348, 357, 367, 376, 381, 388, 399, 404, 410, 444, 451, 462, 468, 473, 485, 493, 503, 512, 525, 533, 547, 553, 562, 568, 573, 583, 594, 607, 614, 626, 633, 641, 649, 657, 666, 679, 688, 696, 709, 715, 725, 730, 739, 747, 758, 767, 775, 782, 789, 794, 808, 818, 834, 842, 857, 873, 879, 886, 892, 899, 907, 922, 932, 952, 957, 963, 970, 976, 990, 1015, 1022, 1027, 1033, 1041, 1049, 1065, 1073, 1079, 1086, 1093, 1100, 1106, 1112, 1121, 1126, 1137, 1147, 1152, 1159, 1167, 1174, 1181, 1196, 1205, 1214, 1225, 1233, 1240, 1249, 1258, 1278, 1291, 1299, 1318, 1328, 1336, 1372, 1391, 1397, 1404, 1416, 1425, 1435, 1440, 1452, 1459, 1467, 1473, 1482, 1499, 1520, 1530, 1546, 1552, 1563, 1572, 1578, 1590, 1595, 1605, 1618, 1623, 1630, 1637, 1650, 1655, 1665, 1678, 1683, 1691, 1697, 1703, 1709, 1718, 1732, 1739, 1754, 1780, 1785, 1799, 1806, 1813, 1826, 1838, 1845, 1853, 1859, 1876, 1884, 1889, 1895, 1901, 1912, 1924, 1933, 1942, 1948, 1954, 1971, 1977, 1983, 1993], deadline = 9)
        configuration.add_task(name="Task4", identifier=4, period=8.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.506293, et_stddev=0.16876433333333332 , list_activation_dates=[4, 26, 44, 61, 91, 102, 116, 125, 155, 168, 181, 209, 224, 236, 245, 253, 273, 288, 299, 311, 320, 329, 346, 355, 365, 379, 391, 403, 441, 451, 466, 479, 510, 528, 537, 549, 575, 584, 597, 607, 618, 641, 657, 667, 691, 706, 718, 732, 743, 761, 775, 807, 822, 840, 858, 872, 882, 914, 929, 943, 958, 992, 1031, 1041, 1053, 1079, 1098, 1113, 1125, 1136, 1154, 1172, 1185, 1214, 1225, 1233, 1242, 1260, 1290, 1306, 1329, 1384, 1394, 1408, 1430, 1444, 1457, 1475, 1517, 1525, 1536, 1547, 1555, 1565, 1575, 1595, 1607, 1617, 1635, 1653, 1669, 1719, 1748, 1767, 1786, 1809, 1826, 1849, 1859, 1867, 1875, 1883, 1894, 1909, 1935, 1958, 1981], deadline = 15)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "66")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "66")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "66")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "66")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task5", identifier=5, period=2.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.129551, et_stddev=0.04318366666666667 , list_activation_dates=[2, 4, 6, 9, 16, 20, 23, 26, 29, 33, 36, 38, 42, 48, 56, 59, 63, 65, 70, 72, 75, 79, 82, 85, 92, 96, 98, 101, 104, 107, 115, 118, 120, 122, 126, 129, 131, 133, 136, 139, 141, 147, 149, 153, 158, 160, 163, 165, 171, 176, 178, 181, 188, 191, 196, 198, 201, 203, 205, 208, 211, 214, 221, 224, 227, 229, 232, 235, 237, 241, 247, 251, 255, 258, 269, 274, 278, 282, 284, 291, 293, 296, 299, 301, 309, 314, 319, 323, 331, 337, 342, 344, 349, 351, 353, 355, 359, 363, 367, 373, 376, 382, 398, 400, 404, 410, 412, 420, 423, 426, 431, 435, 440, 442, 450, 453, 456, 459, 462, 469, 472, 476, 480, 487, 491, 497, 499, 503, 511, 513, 515, 518, 522, 524, 527, 530, 533, 537, 540, 544, 547, 550, 555, 557, 560, 564, 568, 572, 576, 578, 582, 585, 588, 590, 593, 595, 600, 603, 605, 607, 610, 615, 619, 623, 628, 633, 636, 638, 646, 648, 651, 654, 657, 660, 665, 669, 671, 675, 678, 681, 686, 688, 690, 695, 697, 700, 704, 707, 709, 713, 722, 728, 733, 735, 740, 744, 749, 753, 759, 763, 769, 771, 779, 786, 793, 798, 804, 811, 814, 817, 821, 823, 825, 830, 833, 838, 840, 844, 846, 849, 852, 859, 863, 865, 868, 871, 874, 876, 878, 881, 885, 889, 892, 902, 905, 912, 915, 917, 923, 928, 931, 935, 940, 942, 944, 946, 949, 954, 960, 968, 971, 974, 978, 980, 983, 986, 989, 994, 1002, 1004, 1009, 1012, 1014, 1016, 1018, 1021, 1024, 1028, 1031, 1034, 1037, 1040, 1042, 1045, 1048, 1050, 1052, 1054, 1062, 1066, 1069, 1074, 1077, 1080, 1082, 1092, 1094, 1098, 1101, 1105, 1107, 1114, 1117, 1122, 1126, 1130, 1133, 1136, 1139, 1143, 1146, 1151, 1154, 1156, 1158, 1161, 1164, 1167, 1173, 1178, 1180, 1182, 1186, 1192, 1195, 1197, 1200, 1206, 1209, 1212, 1215, 1230, 1232, 1235, 1239, 1242, 1245, 1247, 1253, 1258, 1262, 1269, 1272, 1274, 1277, 1280, 1283, 1288, 1292, 1299, 1302, 1305, 1307, 1309, 1312, 1314, 1320, 1325, 1329, 1333, 1336, 1339, 1343, 1346, 1353, 1358, 1366, 1368, 1370, 1373, 1377, 1385, 1389, 1392, 1398, 1401, 1406, 1411, 1415, 1417, 1422, 1427, 1429, 1435, 1438, 1440, 1442, 1447, 1450, 1461, 1469, 1476, 1479, 1481, 1484, 1487, 1489, 1491, 1495, 1498, 1504, 1507, 1511, 1515, 1517, 1520, 1523, 1525, 1528, 1533, 1537, 1539, 1543, 1545, 1551, 1559, 1564, 1567, 1571, 1573, 1576, 1578, 1582, 1586, 1590, 1594, 1599, 1602, 1604, 1608, 1613, 1615, 1617, 1620, 1622, 1627, 1630, 1635, 1638, 1641, 1644, 1649, 1652, 1656, 1658, 1667, 1671, 1673, 1679, 1684, 1689, 1691, 1697, 1699, 1702, 1704, 1709, 1713, 1717, 1719, 1721, 1728, 1734, 1739, 1746, 1750, 1759, 1763, 1765, 1767, 1769, 1787, 1790, 1793, 1795, 1797, 1799, 1801, 1803, 1805, 1808, 1813, 1817, 1820, 1826, 1831, 1835, 1837, 1844, 1850, 1856, 1858, 1862, 1866, 1868, 1873, 1876, 1879, 1881, 1886, 1888, 1890, 1895, 1899, 1906, 1912, 1916, 1923, 1926, 1936, 1947, 1950, 1954, 1959, 1962, 1968, 1973, 1979, 1981, 1985, 1987, 1993, 1996, 1998], deadline = 3)
        configuration.add_task(name="Task2", identifier=2, period=4.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=3.603992, acet=3.603992, et_stddev=1.2013306666666665, deadline= 6)
        configuration.add_task(name="Task3", identifier=3, period=3.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=2.036892, acet=2.036892, et_stddev=0.678964, deadline= 6)
        configuration.add_task(name="Task1", identifier=1, period=11.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=0.220416, acet=0.220416, et_stddev=0.073472, deadline= 6)
        configuration.add_task(name="Task4", identifier=4, period=2.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.149212, et_stddev=0.049737333333333335 , list_activation_dates=[6, 8, 23, 28, 31, 34, 38, 42, 48, 51, 61, 64, 66, 70, 74, 78, 81, 83, 86, 90, 95, 98, 103, 108, 110, 113, 117, 120, 124, 127, 130, 136, 139, 142, 145, 148, 153, 156, 161, 164, 166, 168, 171, 180, 182, 185, 187, 192, 195, 198, 203, 208, 210, 212, 214, 217, 220, 226, 230, 232, 235, 239, 247, 250, 258, 260, 262, 265, 271, 275, 281, 288, 290, 294, 296, 298, 305, 308, 310, 313, 320, 322, 325, 334, 336, 339, 344, 348, 350, 353, 360, 363, 368, 373, 375, 380, 383, 386, 400, 404, 406, 409, 414, 417, 422, 424, 428, 431, 433, 436, 438, 441, 449, 452, 455, 459, 469, 474, 476, 479, 483, 487, 490, 492, 497, 500, 508, 513, 516, 520, 523, 526, 528, 533, 535, 537, 542, 546, 551, 557, 562, 564, 566, 569, 571, 574, 577, 583, 587, 591, 594, 603, 606, 610, 612, 615, 618, 621, 623, 625, 628, 632, 641, 644, 647, 650, 653, 656, 658, 661, 666, 668, 671, 676, 679, 685, 688, 691, 694, 702, 705, 708, 715, 718, 721, 724, 729, 733, 737, 740, 742, 744, 746, 749, 752, 754, 757, 765, 767, 771, 774, 780, 782, 786, 794, 802, 805, 808, 811, 816, 822, 825, 827, 836, 839, 842, 846, 848, 851, 854, 857, 865, 869, 872, 876, 878, 882, 888, 895, 898, 902, 907, 913, 916, 920, 923, 926, 928, 930, 936, 939, 941, 951, 965, 967, 974, 986, 990, 996, 1005, 1015, 1017, 1021, 1023, 1025, 1027, 1031, 1033, 1036, 1039, 1043, 1048, 1052, 1055, 1058, 1062, 1066, 1068, 1072, 1076, 1081, 1084, 1086, 1093, 1096, 1098, 1102, 1105, 1110, 1114, 1117, 1121, 1124, 1127, 1131, 1134, 1137, 1139, 1144, 1147, 1150, 1154, 1156, 1159, 1163, 1167, 1175, 1178, 1181, 1189, 1192, 1196, 1198, 1204, 1210, 1219, 1228, 1232, 1236, 1238, 1243, 1247, 1249, 1261, 1264, 1267, 1270, 1275, 1285, 1289, 1293, 1295, 1299, 1301, 1304, 1308, 1312, 1319, 1322, 1325, 1329, 1331, 1335, 1341, 1344, 1352, 1366, 1368, 1371, 1375, 1380, 1387, 1390, 1395, 1398, 1404, 1406, 1409, 1414, 1421, 1425, 1428, 1430, 1438, 1442, 1445, 1449, 1455, 1458, 1468, 1471, 1475, 1478, 1482, 1484, 1486, 1489, 1493, 1498, 1502, 1506, 1510, 1514, 1517, 1519, 1522, 1525, 1529, 1532, 1544, 1547, 1551, 1555, 1559, 1564, 1569, 1576, 1579, 1584, 1588, 1590, 1592, 1594, 1597, 1599, 1602, 1606, 1609, 1619, 1623, 1627, 1630, 1632, 1636, 1639, 1642, 1649, 1654, 1658, 1663, 1665, 1667, 1669, 1671, 1673, 1676, 1678, 1681, 1684, 1688, 1691, 1695, 1697, 1699, 1706, 1714, 1716, 1719, 1722, 1724, 1731, 1735, 1738, 1741, 1744, 1747, 1750, 1752, 1757, 1760, 1762, 1768, 1773, 1781, 1785, 1789, 1792, 1795, 1800, 1807, 1811, 1813, 1817, 1823, 1826, 1835, 1839, 1841, 1843, 1849, 1851, 1855, 1859, 1864, 1875, 1877, 1884, 1887, 1892, 1899, 1902, 1904, 1907, 1910, 1917, 1924, 1932, 1935, 1939, 1943, 1948, 1951, 1955, 1958, 1960, 1965, 1969, 1975, 1978, 1981, 1983, 1985, 1993, 1995, 1998], deadline = 3)
        configuration.add_task(name="Task6", identifier=6, period=5.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.303091, et_stddev=0.10103033333333333 , list_activation_dates=[2, 11, 20, 26, 32, 38, 43, 49, 60, 71, 90, 103, 113, 125, 134, 148, 157, 166, 183, 189, 196, 203, 218, 225, 232, 240, 251, 257, 266, 272, 278, 285, 292, 304, 315, 328, 333, 338, 343, 353, 367, 374, 394, 401, 411, 418, 425, 431, 437, 451, 456, 464, 470, 475, 485, 491, 499, 519, 539, 545, 552, 557, 564, 578, 585, 595, 602, 607, 621, 627, 645, 651, 658, 664, 681, 695, 702, 711, 723, 732, 739, 751, 757, 763, 770, 778, 793, 803, 818, 824, 835, 846, 857, 862, 870, 876, 884, 892, 904, 912, 927, 937, 942, 951, 957, 965, 976, 988, 994, 1000, 1007, 1015, 1023, 1029, 1035, 1042, 1048, 1063, 1069, 1075, 1083, 1099, 1105, 1114, 1122, 1130, 1137, 1147, 1157, 1164, 1174, 1182, 1188, 1196, 1211, 1217, 1226, 1233, 1241, 1248, 1254, 1261, 1266, 1278, 1284, 1293, 1300, 1309, 1318, 1339, 1352, 1367, 1373, 1378, 1393, 1399, 1407, 1413, 1420, 1437, 1446, 1465, 1478, 1486, 1492, 1498, 1505, 1511, 1520, 1526, 1581, 1591, 1611, 1620, 1635, 1643, 1648, 1655, 1662, 1669, 1675, 1694, 1700, 1707, 1718, 1726, 1735, 1742, 1752, 1757, 1767, 1777, 1789, 1799, 1809, 1817, 1827, 1836, 1843, 1853, 1864, 1883, 1899, 1907, 1917, 1924, 1933, 1940, 1946, 1951, 1957, 1965, 1982, 1989, 1996], deadline = 9)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "67")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "67")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "67")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "67")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task2", identifier=2, period=38.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=22.174649, acet=22.174649, et_stddev=7.391549666666666, deadline= 49)
        configuration.add_task(name="Task4", identifier=4, period=2.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.209102, et_stddev=0.06970066666666667 , list_activation_dates=[2, 8, 13, 22, 28, 34, 36, 44, 46, 50, 53, 59, 64, 66, 69, 75, 80, 83, 86, 90, 93, 97, 102, 104, 108, 111, 113, 115, 118, 123, 131, 135, 139, 145, 149, 152, 157, 160, 163, 166, 168, 172, 176, 184, 186, 189, 192, 194, 196, 200, 203, 206, 210, 215, 219, 221, 224, 227, 239, 242, 247, 252, 257, 259, 262, 266, 270, 274, 280, 282, 290, 294, 296, 299, 302, 307, 311, 313, 317, 319, 326, 330, 344, 346, 348, 351, 357, 360, 368, 370, 374, 377, 379, 383, 389, 393, 398, 405, 412, 418, 422, 426, 430, 432, 436, 441, 443, 446, 448, 450, 454, 456, 460, 465, 467, 473, 476, 478, 485, 489, 491, 494, 507, 511, 514, 523, 526, 530, 535, 541, 544, 547, 549, 558, 562, 564, 568, 570, 573, 575, 584, 590, 592, 596, 602, 609, 611, 614, 618, 622, 625, 627, 629, 635, 639, 646, 649, 652, 654, 663, 666, 673, 677, 681, 685, 688, 690, 696, 700, 702, 706, 710, 713, 717, 719, 722, 728, 732, 736, 741, 744, 746, 751, 758, 766, 770, 773, 781, 788, 797, 801, 803, 808, 813, 817, 821, 823, 825, 827, 835, 839, 842, 847, 850, 853, 860, 865, 869, 872, 874, 876, 880, 884, 886, 888, 891, 894, 897, 901, 908, 916, 918, 924, 928, 930, 933, 935, 945, 958, 965, 967, 970, 978, 982, 984, 987, 989, 993, 1001, 1006, 1009, 1013, 1016, 1022, 1026, 1029, 1031, 1034, 1040, 1045, 1052, 1054, 1056, 1059, 1063, 1065, 1067, 1069, 1071, 1074, 1077, 1080, 1083, 1086, 1088, 1091, 1103, 1113, 1115, 1119, 1121, 1125, 1127, 1130, 1137, 1144, 1147, 1151, 1159, 1162, 1164, 1170, 1173, 1176, 1178, 1181, 1184, 1188, 1190, 1192, 1204, 1213, 1218, 1222, 1226, 1229, 1233, 1236, 1241, 1244, 1247, 1250, 1256, 1260, 1264, 1268, 1274, 1278, 1280, 1282, 1285, 1289, 1291, 1294, 1298, 1305, 1308, 1311, 1317, 1321, 1326, 1329, 1331, 1336, 1340, 1345, 1348, 1353, 1356, 1359, 1367, 1372, 1375, 1380, 1383, 1386, 1389, 1392, 1394, 1397, 1399, 1401, 1403, 1408, 1415, 1421, 1423, 1426, 1429, 1431, 1434, 1444, 1455, 1458, 1465, 1470, 1473, 1477, 1479, 1486, 1491, 1493, 1496, 1498, 1500, 1508, 1511, 1513, 1516, 1519, 1522, 1525, 1528, 1531, 1535, 1540, 1544, 1548, 1551, 1555, 1561, 1563, 1567, 1571, 1573, 1575, 1578, 1585, 1587, 1589, 1593, 1596, 1600, 1602, 1606, 1609, 1614, 1618, 1626, 1628, 1631, 1635, 1638, 1650, 1653, 1657, 1668, 1671, 1676, 1679, 1681, 1684, 1689, 1693, 1701, 1705, 1707, 1709, 1712, 1715, 1718, 1722, 1724, 1726, 1729, 1734, 1738, 1741, 1743, 1747, 1750, 1753, 1756, 1762, 1765, 1768, 1771, 1773, 1778, 1790, 1793, 1796, 1802, 1805, 1809, 1820, 1823, 1826, 1829, 1831, 1835, 1838, 1840, 1842, 1845, 1851, 1854, 1861, 1864, 1871, 1874, 1878, 1881, 1884, 1892, 1894, 1897, 1899, 1902, 1904, 1906, 1909, 1912, 1914, 1919, 1922, 1926, 1929, 1932, 1935, 1941, 1945, 1947, 1949, 1954, 1957, 1961, 1964, 1967, 1970, 1972, 1975, 1977, 1980, 1985, 1989, 1991, 1994, 1999], deadline = 4)
        configuration.add_task(name="Task1", identifier=1, period=26.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=7.437731, acet=7.437731, et_stddev=2.4792436666666666, deadline= 27)
        configuration.add_task(name="Task6", identifier=6, period=13.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.701891, et_stddev=0.23396366666666668 , list_activation_dates=[16, 32, 48, 86, 103, 118, 137, 164, 191, 228, 293, 306, 341, 357, 398, 444, 460, 480, 514, 527, 549, 563, 595, 625, 671, 688, 712, 727, 765, 789, 805, 821, 848, 898, 912, 926, 974, 994, 1039, 1066, 1092, 1116, 1139, 1172, 1185, 1205, 1242, 1257, 1275, 1290, 1328, 1358, 1386, 1401, 1421, 1438, 1456, 1484, 1500, 1553, 1579, 1592, 1620, 1637, 1653, 1683, 1721, 1743, 1776, 1827, 1848, 1871, 1920, 1946, 1969, 1994], deadline = 18)
        configuration.add_task(name="Task3", identifier=3, period=25.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=18.259749, acet=18.259749, et_stddev=6.086583, deadline= 27)
        configuration.add_task(name="Task5", identifier=5, period=14.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.580399, et_stddev=0.19346633333333332 , list_activation_dates=[15, 42, 62, 79, 96, 121, 157, 171, 191, 208, 268, 282, 310, 327, 383, 401, 418, 436, 457, 485, 513, 531, 548, 564, 602, 629, 649, 675, 711, 734, 762, 781, 805, 837, 868, 906, 942, 958, 1032, 1049, 1129, 1146, 1161, 1177, 1200, 1247, 1264, 1337, 1353, 1372, 1390, 1410, 1442, 1472, 1494, 1522, 1548, 1579, 1594, 1614, 1643, 1662, 1713, 1734, 1751, 1776, 1807, 1861, 1880, 1899, 1940, 1984], deadline = 2)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "68")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "68")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "68")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "68")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task4", identifier=4, period=47.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=4, acet=3.09673, et_stddev=1.0322433333333334 , list_activation_dates=[7, 110, 243, 350, 404, 510, 596, 672, 733, 864, 916, 970, 1040, 1113, 1170, 1264, 1322, 1468, 1546, 1632, 1745, 1794, 1929], deadline = 22)
        configuration.add_task(name="Task6", identifier=6, period=37.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.338541, et_stddev=0.11284699999999999 , list_activation_dates=[70, 205, 264, 302, 340, 383, 474, 513, 576, 621, 726, 765, 863, 954, 996, 1037, 1086, 1193, 1281, 1393, 1432, 1478, 1587, 1678, 1719, 1869, 1929, 2000], deadline = 15)
        configuration.add_task(name="Task5", identifier=5, period=8.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.999698, et_stddev=0.3332326666666667 , list_activation_dates=[8, 17, 46, 58, 76, 85, 94, 104, 114, 136, 182, 199, 213, 227, 239, 247, 257, 266, 274, 287, 299, 315, 324, 332, 340, 353, 368, 377, 396, 404, 430, 458, 466, 475, 485, 495, 511, 526, 553, 561, 571, 587, 599, 629, 643, 653, 666, 677, 689, 698, 712, 725, 739, 750, 761, 778, 807, 818, 837, 846, 856, 866, 874, 883, 906, 946, 961, 970, 985, 996, 1007, 1027, 1037, 1047, 1059, 1071, 1089, 1106, 1116, 1133, 1157, 1170, 1181, 1194, 1203, 1226, 1235, 1268, 1277, 1291, 1306, 1325, 1341, 1353, 1383, 1394, 1427, 1435, 1452, 1473, 1497, 1512, 1535, 1544, 1553, 1569, 1578, 1590, 1601, 1610, 1633, 1645, 1666, 1683, 1701, 1721, 1732, 1743, 1756, 1765, 1791, 1800, 1814, 1831, 1849, 1858, 1881, 1892, 1919, 1936, 1958, 1973, 1994], deadline = 12)
        configuration.add_task(name="Task3", identifier=3, period=3.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=0.446335, acet=0.446335, et_stddev=0.14877833333333332, deadline= 4)
        configuration.add_task(name="Task1", identifier=1, period=3.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=2.869273, acet=2.869273, et_stddev=0.9564243333333334, deadline= 3)
        configuration.add_task(name="Task2", identifier=2, period=31.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=15.338702, acet=15.338702, et_stddev=5.1129006666666665, deadline= 49)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "69")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "69")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "69")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "69")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

import sys
from simso.core import Model
from simso.configuration import Configuration
from simso.core.Task import SporadicTask

def main(argv):
    if len(argv) == 2:
        #  Configuration load from a file.
        configuration = Configuration(argv[1])
    else:
        # Manual configuration:
        configuration = Configuration()
        configuration.duration = 1500 * configuration.cycles_per_ms
        configuration.etm = "acet"
        #  Add tasks:
        configuration.add_task(name="Task3", identifier=3, period=26.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=22.599469, acet=22.599469, et_stddev=7.533156333333333, deadline= 33)
        configuration.add_task(name="Task1", identifier=1, period=8.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=3.910266, acet=3.910266, et_stddev=1.303422, deadline= 4)
        configuration.add_task(name="Task4", identifier=4, period=5.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.57434, et_stddev=0.19144666666666665 , list_activation_dates=[5, 18, 24, 31, 36, 41, 48, 63, 71, 79, 84, 101, 111, 118, 124, 132, 154, 160, 196, 205, 217, 226, 234, 252, 257, 267, 276, 283, 290, 302, 310, 316, 334, 340, 352, 358, 371, 384, 389, 399, 410, 417, 423, 437, 442, 458, 464, 472, 482, 489, 496, 501, 506, 511, 528, 535, 553, 562, 568, 574, 582, 588, 596, 603, 614, 622, 637, 687, 695, 701, 717, 732, 746, 753, 775, 793, 824, 830, 838, 846, 862, 867, 873, 884, 889, 900, 905, 914, 922, 927, 933, 938, 944, 951, 957, 971, 977, 997, 1003, 1015, 1022, 1027, 1037, 1047, 1062, 1068, 1075, 1092, 1098, 1105, 1115, 1121, 1141, 1155, 1167, 1176, 1182, 1207, 1213, 1224, 1231, 1240, 1245, 1254, 1261, 1269, 1279, 1289, 1294, 1306, 1314, 1328, 1334, 1348, 1358, 1364, 1370, 1397, 1402, 1408, 1442, 1447, 1452, 1463, 1473, 1493, 1506, 1521, 1532, 1539, 1560, 1575, 1584, 1590, 1600, 1611, 1620, 1630, 1639, 1658, 1679, 1691, 1709, 1716, 1721, 1727, 1737, 1743, 1757, 1767, 1772, 1779, 1790, 1796, 1804, 1811, 1816, 1821, 1830, 1838, 1844, 1853, 1864, 1871, 1883, 1895, 1904, 1916, 1945, 1952, 1963, 1969, 1977, 1985], deadline = 10)
        configuration.add_task(name="Task5", identifier=5, period=47.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=2, acet=1.918671, et_stddev=0.639557 , list_activation_dates=[18, 108, 207, 261, 327, 384, 460, 571, 668, 764, 836, 905, 971, 1085, 1246, 1366, 1450, 1548, 1627, 1718, 1783, 1856, 1952], deadline = 40)
        configuration.add_task(name="Task6", identifier=6, period=11.0, activation_date=0, abort_on_miss=False, task_type="Sporadic", wcet=1, acet=0.4874, et_stddev=0.16246666666666668 , list_activation_dates=[11, 28, 46, 84, 128, 140, 164, 188, 234, 254, 295, 312, 360, 373, 393, 409, 434, 457, 474, 495, 553, 576, 650, 670, 699, 718, 740, 752, 771, 805, 818, 853, 870, 899, 924, 944, 985, 1000, 1015, 1083, 1122, 1134, 1177, 1196, 1215, 1226, 1257, 1272, 1295, 1314, 1326, 1342, 1358, 1378, 1389, 1406, 1459, 1479, 1493, 1504, 1516, 1529, 1551, 1576, 1606, 1684, 1696, 1714, 1732, 1775, 1808, 1821, 1834, 1845, 1870, 1891, 1902, 1978, 1995], deadline = 3)
        configuration.add_task(name="Task2", identifier=2, period=5.0, activation_date=0, abort_on_miss=True, task_type="Periodic", wcet=1.210031, acet=1.210031, et_stddev=0.4033436666666667, deadline= 3)

        # Add a processor:
        configuration.add_processor(name="CPU 1", identifier=1)
        configuration.add_processor(name="CPU 2", identifier=2)

        # Add a scheduler:
        configuration.scheduler_info.clas = "simso.schedulers.EDF_LQ"

    # Check the config before trying to run it.
    configuration.check_all()

    # Init a model from the configuration.
    model = Model(configuration)

    # Execute the simulation.
    try:
        model.run_model()
    except SystemExit as e:
        return()

    # Print average response time log file.
    print("Printing Log File ** RESPONSE TIME AND TARDINESS **")

    arq3 = open("C:\log\log_avg_response_time.txt", "a")
    arq3.write("\n" + "CONJUNTO" + "70")

    # Print tardiness log file.
    arq4 = open("C:\log\log_tardiness.txt", "a")
    arq4.write("\n" + "CONJUNTO" + "70")

    # Print number of jobs log file.
    print("Printing Log File ** NUMBER OF JOBS (Executed vs. Missed) **")
    arq7 = open("C:\log\log_number_jobs.txt", "a")
    arq7.write("\n" + "CONJUNTO" + "70")
    for task in model.results.tasks:
        cont = 0
        total_response_time = 0
        tardiness = 0
        jobs_deadline_miss = 0
        for job in task.jobs:
            if isinstance(job.task, SporadicTask) and job.end_date is not None:
                if (job.end_date/1000000) - job.absolute_deadline <= 0:
                    tardiness = 0
                else:
                    tardiness = (job.end_date/1000000) - job.absolute_deadline
                    jobs_deadline_miss = jobs_deadline_miss + 1
                if tardiness > 0:
                    arq4.write("\n%s %s %.6f ms %.6f ms %.6f ms" % (task.name, job.name, job.absolute_deadline, job.end_date/1000000, tardiness))
            if (job.response_time is not None):
                total_response_time = total_response_time + (job.response_time/job.deadline)
                cont = cont + 1
        if cont > 0:
            arq3.write("\n%s %.6f %d %.6f " % (task.name, total_response_time/cont, task._job_count, total_response_time))
            arq7.write("\n%s %d %d %d " % (task.name, cont, jobs_deadline_miss, cont+jobs_deadline_miss ))
    arq3.close()
    arq4.close()
    arq7.close()

    # Print preemption and migration log file.
    print("Printing Log File ** PREEMPTION AND MIGRATION **")
    arq5 = open("C:\log\log_preemption_migration.txt", "a")
    arq5.write("\n" + "CONJUNTO" + "70")
    for task in model.results.tasks.values():
        arq5.write("\n%s %d %d" % (task.name, task.preemption_count, task.migration_count))
    arq5.close()

main(sys.argv)

